(function(){"use strict";function ut(e){return e&&e.__esModule&&Object.prototype.hasOwnProperty.call(e,"default")?e.default:e}var Z={exports:{}},mt=Z.exports,fe;function gt(){return fe||(fe=1,(function(e,t){(function(n,r){r(e)})(typeof globalThis<"u"?globalThis:typeof self<"u"?self:mt,function(n){if(!(globalThis.chrome&&globalThis.chrome.runtime&&globalThis.chrome.runtime.id))throw new Error("This script should only be loaded in a browser extension.");if(globalThis.browser&&globalThis.browser.runtime&&globalThis.browser.runtime.id)n.exports=globalThis.browser;else{const r="The message port closed before a response was received.",i=s=>{const a={alarms:{clear:{minArgs:0,maxArgs:1},clearAll:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getAll:{minArgs:0,maxArgs:0}},bookmarks:{create:{minArgs:1,maxArgs:1},get:{minArgs:1,maxArgs:1},getChildren:{minArgs:1,maxArgs:1},getRecent:{minArgs:1,maxArgs:1},getSubTree:{minArgs:1,maxArgs:1},getTree:{minArgs:0,maxArgs:0},move:{minArgs:2,maxArgs:2},remove:{minArgs:1,maxArgs:1},removeTree:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1},update:{minArgs:2,maxArgs:2}},browserAction:{disable:{minArgs:0,maxArgs:1,fallbackToNoCallback:!0},enable:{minArgs:0,maxArgs:1,fallbackToNoCallback:!0},getBadgeBackgroundColor:{minArgs:1,maxArgs:1},getBadgeText:{minArgs:1,maxArgs:1},getPopup:{minArgs:1,maxArgs:1},getTitle:{minArgs:1,maxArgs:1},openPopup:{minArgs:0,maxArgs:0},setBadgeBackgroundColor:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setBadgeText:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setIcon:{minArgs:1,maxArgs:1},setPopup:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setTitle:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},browsingData:{remove:{minArgs:2,maxArgs:2},removeCache:{minArgs:1,maxArgs:1},removeCookies:{minArgs:1,maxArgs:1},removeDownloads:{minArgs:1,maxArgs:1},removeFormData:{minArgs:1,maxArgs:1},removeHistory:{minArgs:1,maxArgs:1},removeLocalStorage:{minArgs:1,maxArgs:1},removePasswords:{minArgs:1,maxArgs:1},removePluginData:{minArgs:1,maxArgs:1},settings:{minArgs:0,maxArgs:0}},commands:{getAll:{minArgs:0,maxArgs:0}},contextMenus:{remove:{minArgs:1,maxArgs:1},removeAll:{minArgs:0,maxArgs:0},update:{minArgs:2,maxArgs:2}},cookies:{get:{minArgs:1,maxArgs:1},getAll:{minArgs:1,maxArgs:1},getAllCookieStores:{minArgs:0,maxArgs:0},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}},devtools:{inspectedWindow:{eval:{minArgs:1,maxArgs:2,singleCallbackArg:!1}},panels:{create:{minArgs:3,maxArgs:3,singleCallbackArg:!0},elements:{createSidebarPane:{minArgs:1,maxArgs:1}}}},downloads:{cancel:{minArgs:1,maxArgs:1},download:{minArgs:1,maxArgs:1},erase:{minArgs:1,maxArgs:1},getFileIcon:{minArgs:1,maxArgs:2},open:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},pause:{minArgs:1,maxArgs:1},removeFile:{minArgs:1,maxArgs:1},resume:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1},show:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},extension:{isAllowedFileSchemeAccess:{minArgs:0,maxArgs:0},isAllowedIncognitoAccess:{minArgs:0,maxArgs:0}},history:{addUrl:{minArgs:1,maxArgs:1},deleteAll:{minArgs:0,maxArgs:0},deleteRange:{minArgs:1,maxArgs:1},deleteUrl:{minArgs:1,maxArgs:1},getVisits:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1}},i18n:{detectLanguage:{minArgs:1,maxArgs:1},getAcceptLanguages:{minArgs:0,maxArgs:0}},identity:{launchWebAuthFlow:{minArgs:1,maxArgs:1}},idle:{queryState:{minArgs:1,maxArgs:1}},management:{get:{minArgs:1,maxArgs:1},getAll:{minArgs:0,maxArgs:0},getSelf:{minArgs:0,maxArgs:0},setEnabled:{minArgs:2,maxArgs:2},uninstallSelf:{minArgs:0,maxArgs:1}},notifications:{clear:{minArgs:1,maxArgs:1},create:{minArgs:1,maxArgs:2},getAll:{minArgs:0,maxArgs:0},getPermissionLevel:{minArgs:0,maxArgs:0},update:{minArgs:2,maxArgs:2}},pageAction:{getPopup:{minArgs:1,maxArgs:1},getTitle:{minArgs:1,maxArgs:1},hide:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setIcon:{minArgs:1,maxArgs:1},setPopup:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setTitle:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},show:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},permissions:{contains:{minArgs:1,maxArgs:1},getAll:{minArgs:0,maxArgs:0},remove:{minArgs:1,maxArgs:1},request:{minArgs:1,maxArgs:1}},runtime:{getBackgroundPage:{minArgs:0,maxArgs:0},getPlatformInfo:{minArgs:0,maxArgs:0},openOptionsPage:{minArgs:0,maxArgs:0},requestUpdateCheck:{minArgs:0,maxArgs:0},sendMessage:{minArgs:1,maxArgs:3},sendNativeMessage:{minArgs:2,maxArgs:2},setUninstallURL:{minArgs:1,maxArgs:1}},sessions:{getDevices:{minArgs:0,maxArgs:1},getRecentlyClosed:{minArgs:0,maxArgs:1},restore:{minArgs:0,maxArgs:1}},storage:{local:{clear:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}},managed:{get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1}},sync:{clear:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}}},tabs:{captureVisibleTab:{minArgs:0,maxArgs:2},create:{minArgs:1,maxArgs:1},detectLanguage:{minArgs:0,maxArgs:1},discard:{minArgs:0,maxArgs:1},duplicate:{minArgs:1,maxArgs:1},executeScript:{minArgs:1,maxArgs:2},get:{minArgs:1,maxArgs:1},getCurrent:{minArgs:0,maxArgs:0},getZoom:{minArgs:0,maxArgs:1},getZoomSettings:{minArgs:0,maxArgs:1},goBack:{minArgs:0,maxArgs:1},goForward:{minArgs:0,maxArgs:1},highlight:{minArgs:1,maxArgs:1},insertCSS:{minArgs:1,maxArgs:2},move:{minArgs:2,maxArgs:2},query:{minArgs:1,maxArgs:1},reload:{minArgs:0,maxArgs:2},remove:{minArgs:1,maxArgs:1},removeCSS:{minArgs:1,maxArgs:2},sendMessage:{minArgs:2,maxArgs:3},setZoom:{minArgs:1,maxArgs:2},setZoomSettings:{minArgs:1,maxArgs:2},update:{minArgs:1,maxArgs:2}},topSites:{get:{minArgs:0,maxArgs:0}},webNavigation:{getAllFrames:{minArgs:1,maxArgs:1},getFrame:{minArgs:1,maxArgs:1}},webRequest:{handlerBehaviorChanged:{minArgs:0,maxArgs:0}},windows:{create:{minArgs:0,maxArgs:1},get:{minArgs:1,maxArgs:2},getAll:{minArgs:0,maxArgs:1},getCurrent:{minArgs:0,maxArgs:1},getLastFocused:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},update:{minArgs:2,maxArgs:2}}};if(Object.keys(a).length===0)throw new Error("api-metadata.json has not been included in browser-polyfill");class d extends WeakMap{constructor(u,p=void 0){super(p),this.createItem=u}get(u){return this.has(u)||this.set(u,this.createItem(u)),super.get(u)}}const g=l=>l&&typeof l=="object"&&typeof l.then=="function",h=(l,u)=>(...p)=>{s.runtime.lastError?l.reject(new Error(s.runtime.lastError.message)):u.singleCallbackArg||p.length<=1&&u.singleCallbackArg!==!1?l.resolve(p[0]):l.resolve(p)},c=l=>l==1?"argument":"arguments",A=(l,u)=>function(y,...C){if(C.length<u.minArgs)throw new Error(`Expected at least ${u.minArgs} ${c(u.minArgs)} for ${l}(), got ${C.length}`);if(C.length>u.maxArgs)throw new Error(`Expected at most ${u.maxArgs} ${c(u.maxArgs)} for ${l}(), got ${C.length}`);return new Promise((I,M)=>{if(u.fallbackToNoCallback)try{y[l](...C,h({resolve:I,reject:M},u))}catch(m){console.warn(`${l} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `,m),y[l](...C),u.fallbackToNoCallback=!1,u.noCallback=!0,I()}else u.noCallback?(y[l](...C),I()):y[l](...C,h({resolve:I,reject:M},u))})},w=(l,u,p)=>new Proxy(u,{apply(y,C,I){return p.call(C,l,...I)}});let T=Function.call.bind(Object.prototype.hasOwnProperty);const z=(l,u={},p={})=>{let y=Object.create(null),C={has(M,m){return m in l||m in y},get(M,m,S){if(m in y)return y[m];if(!(m in l))return;let E=l[m];if(typeof E=="function")if(typeof u[m]=="function")E=w(l,l[m],u[m]);else if(T(p,m)){let q=A(m,p[m]);E=w(l,l[m],q)}else E=E.bind(l);else if(typeof E=="object"&&E!==null&&(T(u,m)||T(p,m)))E=z(E,u[m],p[m]);else if(T(p,"*"))E=z(E,u[m],p["*"]);else return Object.defineProperty(y,m,{configurable:!0,enumerable:!0,get(){return l[m]},set(q){l[m]=q}}),E;return y[m]=E,E},set(M,m,S,E){return m in y?y[m]=S:l[m]=S,!0},defineProperty(M,m,S){return Reflect.defineProperty(y,m,S)},deleteProperty(M,m){return Reflect.deleteProperty(y,m)}},I=Object.create(l);return new Proxy(I,C)},G=l=>({addListener(u,p,...y){u.addListener(l.get(p),...y)},hasListener(u,p){return u.hasListener(l.get(p))},removeListener(u,p){u.removeListener(l.get(p))}}),re=new d(l=>typeof l!="function"?l:function(p){const y=z(p,{},{getContent:{minArgs:0,maxArgs:0}});l(y)}),j=new d(l=>typeof l!="function"?l:function(p,y,C){let I=!1,M,m=new Promise(K=>{M=function(B){I=!0,K(B)}}),S;try{S=l(p,y,M)}catch(K){S=Promise.reject(K)}const E=S!==!0&&g(S);if(S!==!0&&!E&&!I)return!1;const q=K=>{K.then(B=>{C(B)},B=>{let pe;B&&(B instanceof Error||typeof B.message=="string")?pe=B.message:pe="An unexpected error occurred",C({__mozWebExtensionPolyfillReject__:!0,message:pe})}).catch(B=>{console.error("Failed to send onMessage rejected reply",B)})};return q(E?S:m),!0}),ue=({reject:l,resolve:u},p)=>{s.runtime.lastError?s.runtime.lastError.message===r?u():l(new Error(s.runtime.lastError.message)):p&&p.__mozWebExtensionPolyfillReject__?l(new Error(p.message)):u(p)},k=(l,u,p,...y)=>{if(y.length<u.minArgs)throw new Error(`Expected at least ${u.minArgs} ${c(u.minArgs)} for ${l}(), got ${y.length}`);if(y.length>u.maxArgs)throw new Error(`Expected at most ${u.maxArgs} ${c(u.maxArgs)} for ${l}(), got ${y.length}`);return new Promise((C,I)=>{const M=ue.bind(null,{resolve:C,reject:I});y.push(M),p.sendMessage(...y)})},me={devtools:{network:{onRequestFinished:G(re)}},runtime:{onMessage:G(j),onMessageExternal:G(j),sendMessage:k.bind(null,"sendMessage",{minArgs:1,maxArgs:3})},tabs:{sendMessage:k.bind(null,"sendMessage",{minArgs:2,maxArgs:3})}},ge={clear:{minArgs:1,maxArgs:1},get:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}};return a.privacy={network:{"*":ge},services:{"*":ge},websites:{"*":ge}},z(s,me,a)};n.exports=i(chrome)}})})(Z)),Z.exports}var pt=gt();const x=ut(pt),ft="arc-todo-capture",_="arc-todo-qa-overlay",ht=2147483645,oe="arcTodo.overlayPosition",ie="arcTodo.overlaySections";function he(e,t,n,r,i,s){const a=Math.max(0,Math.min(e,n)),d=Math.max(0,Math.min(t,r)),g=Math.min(i,Math.max(e,n)),h=Math.min(s,Math.max(t,r)),c=g-a,A=h-d;return c<4||A<4?null:{x:a,y:d,width:c,height:A}}function ye(e,t,n){return t.width===0||t.height===0?{x:0,y:0}:{x:e.x/t.width*n.width,y:e.y/t.height*n.height}}function yt(e,t,n){const r=ye({x:e.x,y:e.y},t,n),i=ye({x:e.x+e.width,y:e.y+e.height},t,n);return he(r.x,r.y,i.x,i.y,n.width,n.height)}function xt(e,t,n,r,i){const s=he(e,t,n,r,i.width,i.height);return s?{rect:s,viewport:i}:null}function At(e,t,n){return yt(e,t,n)}const W="arc-todo-region-overlay",Y="arc-todo-region-marquee",xe=["pointerdown","mousedown","mouseup","auxclick","contextmenu","dblclick"];let O=!1,Ae="",D=null;function bt(){return{position:"fixed",inset:"0",zIndex:"2147483646",cursor:"crosshair",background:"rgba(0, 0, 0, 0.35)",boxSizing:"border-box"}}function vt(){return{position:"fixed",pointerEvents:"none",zIndex:"2147483646",outline:"2px solid #ffffff",outlineOffset:"0",boxShadow:"0 0 0 99999px rgba(0, 0, 0, 0.35)",boxSizing:"border-box",display:"none",background:"transparent"}}function wt(e){let t=e.getElementById(W);return t||(t=e.createElement("div"),t.id=W,t.setAttribute("aria-hidden","true"),Object.assign(t.style,bt()),e.documentElement.appendChild(t),t)}function be(e){let t=e.getElementById(Y);return t||(t=e.createElement("div"),t.id=Y,t.setAttribute("aria-hidden","true"),Object.assign(t.style,vt()),e.documentElement.appendChild(t),t)}function kt(e){return e?e.id===_?!0:!!e.closest(`#${_}`):!1}function Et(e,t,n){const r=e.getElementById(W),i=e.getElementById(Y);r&&(r.style.pointerEvents="none"),i&&(i.style.pointerEvents="none");const s=e.elementFromPoint(t,n);return r&&(r.style.pointerEvents="auto"),s}function ve(e){O&&(e.preventDefault(),e.stopPropagation(),e.stopImmediatePropagation())}function Ct(e,t,n,r){const i=Math.min(e,n),s=Math.min(t,r),a=be(document);a.style.display="block",a.style.left=`${i}px`,a.style.top=`${s}px`,a.style.width=`${Math.abs(n-e)}px`,a.style.height=`${Math.abs(r-t)}px`}function we(){const e=document.getElementById(Y);e&&(e.style.display="none")}function Tt(){return{width:window.innerWidth,height:window.innerHeight}}function ke(e){if(!O||e.button!==0)return;const t=Et(document,e.clientX,e.clientY);kt(t)||(D={x:e.clientX,y:e.clientY},we())}function Ee(e){!O||!D||Ct(D.x,D.y,e.clientX,e.clientY)}function Ce(e){if(!O||!D)return;const t=D;D=null;const n=xt(t.x,t.y,e.clientX,e.clientY,Tt());we(),n&&(x.runtime.sendMessage({type:"region.picked",rect:n.rect,viewport:n.viewport,devicePixelRatio:window.devicePixelRatio}),se())}function Te(e){!O||e.key!=="Escape"||(e.preventDefault(),se(),x.runtime.sendMessage({type:"region.cancelled"}))}function It(){if(window===window.top&&!O){O=!0,Ae=document.documentElement.style.cursor,document.documentElement.style.cursor="crosshair",wt(document),be(document),document.addEventListener("pointerdown",ke,!0),document.addEventListener("pointermove",Ee,!0),document.addEventListener("pointerup",Ce,!0),document.addEventListener("keydown",Te,!0);for(const e of xe)document.addEventListener(e,ve,!0)}}function se(){var e,t;if(!(!O&&!document.getElementById(W))){O=!1,D=null,document.documentElement.style.cursor=Ae,document.removeEventListener("pointerdown",ke,!0),document.removeEventListener("pointermove",Ee,!0),document.removeEventListener("pointerup",Ce,!0),document.removeEventListener("keydown",Te,!0);for(const n of xe)document.removeEventListener(n,ve,!0);(e=document.getElementById(W))==null||e.remove(),(t=document.getElementById(Y))==null||t.remove()}}function Mt(){window===window.top&&x.runtime.onMessage.addListener(e=>{if(!e||typeof e!="object"||!("type"in e))return;const t=e.type;t==="region.arm"&&It(),t==="region.disarm"&&se()})}function St(e){var t;return((t=e.find(n=>!n.checked))==null?void 0:t.id)??null}function Nt(e,t){var i;const n=e.findIndex(s=>s.id===t);return((i=(n>=0?e.slice(n+1):e).find(s=>!s.checked))==null?void 0:i.id)??St(e)}function Lt(e,t){if(t&&e.some(n=>n.id===t))return t}function Pt(e,t){return t==="panel"||t==="overlay"?t!==e:!0}function Rt(e,t,n,r,i=48){const s=i-r.width,a=n.width-i,d=0,g=Math.max(0,n.height-i);return{left:Math.min(a,Math.max(s,e)),top:Math.min(g,Math.max(d,t))}}function Bt(e,t,n=16){return{left:Math.max(n,e.width-t.width-n),top:Math.max(n,e.height-t.height-n)}}const Ie=/(\*\*[^*]+\*\*|\*[^*]+\*|`[^`]+`|\[[^\]]+\]\(https?:\/\/[^)\s]+\))/g;function Ot(e){const t=[];let n=0;Ie.lastIndex=0;let r;for(;r=Ie.exec(e);){r.index>n&&t.push({type:"text",text:e.slice(n,r.index)});const i=r[0];if(i.startsWith("**"))t.push({type:"strong",text:i.slice(2,-2)});else if(i.startsWith("*"))t.push({type:"em",text:i.slice(1,-1)});else if(i.startsWith("`"))t.push({type:"code",text:i.slice(1,-1)});else{const s=i.match(/^\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)$/);s&&t.push({type:"a",text:s[1],href:s[2]})}n=r.index+i.length}return n<e.length&&t.push({type:"text",text:e.slice(n)}),t.length>0?t:[{type:"text",text:e}]}function $t(e,t){const n=t.join(`
`).trim();n&&e.push({type:"p",text:n})}function _t(e){return`h${Math.min(e.length,4)}`}function Dt(e){const t=[];let n=[],r=[],i=[],s=null;function a(){r.length!==0&&(t.push({type:"ul",items:r}),r=[])}function d(){i.length!==0&&(t.push({type:"ol",items:i}),i=[])}function g(){const c=n;n=[],$t(t,c)}function h(){a(),d()}for(const c of e.split(`
`)){if(s){c.startsWith("```")?(t.push({type:"pre",text:s.join(`
`)}),s=null):s.push(c);continue}if(c.startsWith("```")){h(),g(),s=[];continue}const A=c.match(/^(#{1,4})\s+(.*)$/),w=c.match(/^[-*]\s+(.*)$/),T=c.match(/^\d+\.\s+(.*)$/);if(A){h(),g(),t.push({type:_t(A[1]),text:A[2]});continue}if(w){d(),g(),r.push(w[1]);continue}if(T){a(),g(),i.push(T[1]);continue}if(!c.trim()){h(),g();continue}h(),n.push(c)}return s&&t.push({type:"pre",text:s.join(`
`)}),h(),g(),t}function Me(e,t){for(const n of Ot(t)){if(n.type==="text"){e.appendChild(document.createTextNode(n.text));continue}if(n.type==="a"){const i=document.createElement("a");i.href=n.href,i.target="_blank",i.rel="noopener noreferrer",i.textContent=n.text,e.appendChild(i);continue}const r=document.createElement(n.type==="strong"?"strong":n.type==="em"?"em":"code");r.textContent=n.text,e.appendChild(r)}}function Ft(e,t){for(const n of Dt(t)){if(n.type==="ul"||n.type==="ol"){const i=document.createElement(n.type);for(const s of n.items){const a=document.createElement("li");Me(a,s),i.appendChild(a)}e.appendChild(i);continue}if(n.type==="pre"){const i=document.createElement("pre"),s=document.createElement("code");s.textContent=n.text,i.appendChild(s),e.appendChild(i);continue}const r=document.createElement(n.type);Me(r,n.text),e.appendChild(r)}}function zt(e){if(!e||typeof e!="object"||Array.isArray(e))return null;const t=e;return typeof t.left!="number"||typeof t.top!="number"||!Number.isFinite(t.left)||!Number.isFinite(t.top)?null:{left:t.left,top:t.top}}const Se=60;function Ht(e){const t=e.replace(/\*\*/g,"").trim(),n=e.match(/^\s*\*\*(.+?)\*\*/);if(n)return{short:n[1].replace(/\*\*/g,"").trim(),full:t,fromBold:!0};const r=t.indexOf(":");return r>0?{short:t.slice(0,r).trim(),full:t,fromBold:!1}:t.length>Se?{short:`${t.slice(0,Se)}…`,full:t,fromBold:!1}:{short:t,full:t,fromBold:!1}}function Ne(e){return e.map(t=>{const n=Ht(t.label);return{id:t.id,short:n.short,full:n.full,checked:t.checked,bugged:t.bugged,notes:t.notes}})}const Q={instructionsCollapsed:!1,checklistCollapsed:!1};function jt(e){if(!e||typeof e!="object"||Array.isArray(e))return null;const t=e;return typeof t.instructionsCollapsed!="boolean"||typeof t.checklistCollapsed!="boolean"?null:{instructionsCollapsed:t.instructionsCollapsed,checklistCollapsed:t.checklistCollapsed}}const qt=`
:host {
  all: initial;
  position: fixed;
  z-index: 2147483645;
  font-family: system-ui, sans-serif;
  color-scheme: dark;
  --bg-surface: #1b2230;
  --bg-elevated: #252e3d;
  --text-primary: #e8ecf4;
  --text-muted: #9aa6bc;
  --border: rgba(142, 160, 188, 0.18);
  --accent: #4862ce;
  --accent-contrast: #f7f8fc;
  --radius: 0.75rem;
  --type-body: 0.8125rem;
  --type-meta: 0.7rem;
  --type-section: 0.9rem;
}

@media (prefers-color-scheme: light) {
  :host {
    color-scheme: light;
    --bg-surface: #fbfcfe;
    --bg-elevated: #eef1f6;
    --text-primary: #1b2230;
    --text-muted: #5a6578;
    --border: rgba(46, 53, 69, 0.16);
    --accent: #3d52b8;
  }
}

*, *::before, *::after { box-sizing: border-box; }

.panel {
  width: min(420px, calc(100vw - 24px));
  max-height: min(70vh, 520px);
  display: flex;
  flex-direction: column;
  background: var(--bg-surface);
  color: var(--text-primary);
  border: 1px solid var(--border);
  border-radius: var(--radius);
  box-shadow: 0 12px 40px rgba(0, 0, 0, 0.35);
  overflow: hidden;
  font-size: var(--type-body);
  line-height: 1.4;
}

.panel.is-collapsed .body { display: none; }

.header {
  display: flex;
  align-items: flex-start;
  gap: 0.5rem;
  padding: 0.55rem 0.65rem;
  background: var(--bg-elevated);
  border-bottom: 1px solid var(--border);
  cursor: grab;
  touch-action: none;
  user-select: none;
}

.header:active { cursor: grabbing; }

.header-text {
  flex: 1;
  min-width: 0;
}

.display-id {
  margin: 0;
  font-size: var(--type-meta);
  color: var(--text-muted);
  font-weight: 600;
}

.title {
  margin: 0.1rem 0 0;
  font-size: var(--type-section);
  font-weight: 700;
  line-height: 1.25;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.header-actions {
  display: flex;
  gap: 0.25rem;
  flex-shrink: 0;
}

.icon-btn {
  appearance: none;
  border: 1px solid var(--border);
  background: transparent;
  color: var(--text-primary);
  border-radius: calc(var(--radius) - 0.25rem);
  width: 1.75rem;
  height: 1.75rem;
  font: inherit;
  font-size: 0.85rem;
  line-height: 1;
  cursor: pointer;
  padding: 0;
}

.icon-btn:hover { background: var(--bg-surface); }

.body {
  overflow: auto;
  padding: 0.5rem;
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

.hint {
  margin: 0;
  font-size: var(--type-meta);
  color: var(--text-muted);
}

.list {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
  gap: 0.375rem;
}

.row {
  border: 1px solid var(--border);
  border-radius: calc(var(--radius) - 0.2rem);
  background: var(--bg-elevated);
  padding: 0.375rem;
}

.row.is-bugged { border-color: rgba(220, 80, 80, 0.45); }
.row.is-current { border-color: var(--accent); }

.row-main {
  display: flex;
  gap: 0.35rem;
  align-items: center;
}

.tick {
  appearance: none;
  border: 0;
  background: transparent;
  color: var(--text-primary);
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  padding: 0.1rem;
  font: inherit;
  min-width: 1.4rem;
}

.tick-mark {
  width: 1.1rem;
  height: 1.1rem;
  border-radius: 999px;
  border: 2px solid var(--text-muted);
  display: block;
}

.tick.is-checked .tick-mark {
  border-color: var(--accent);
  background: var(--accent);
  box-shadow: inset 0 0 0 2px var(--bg-elevated);
}

.expand {
  appearance: none;
  border: 0;
  background: transparent;
  color: var(--text-primary);
  text-align: left;
  flex: 1;
  min-width: 0;
  cursor: pointer;
  font: inherit;
  padding: 0.15rem 0;
}

.expand strong { font-weight: 650; }

.row-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 0.25rem;
  margin-top: 0.35rem;
}

.btn {
  appearance: none;
  border: 1px solid var(--border);
  background: var(--bg-surface);
  color: var(--text-primary);
  border-radius: calc(var(--radius) - 0.25rem);
  font: inherit;
  font-size: var(--type-meta);
  font-weight: 600;
  padding: 0.3rem 0.5rem;
  cursor: pointer;
}

.btn-primary {
  background: var(--accent);
  border-color: var(--accent);
  color: var(--accent-contrast);
}

.btn:disabled {
  opacity: 0.45;
  cursor: not-allowed;
}

.bug-form {
  display: flex;
  flex-direction: column;
  gap: 0.35rem;
  margin-top: 0.35rem;
}

.bug-form label {
  display: flex;
  flex-direction: column;
  gap: 0.2rem;
  font-size: var(--type-meta);
  color: var(--text-muted);
}

.bug-form textarea {
  resize: vertical;
  min-height: 3.5rem;
  border: 1px solid var(--border);
  border-radius: calc(var(--radius) - 0.25rem);
  background: var(--bg-surface);
  color: var(--text-primary);
  font: inherit;
  padding: 0.35rem;
}

.warning {
  margin: 0;
  font-size: var(--type-meta);
  color: var(--text-muted);
}

.error {
  margin: 0;
  font-size: var(--type-meta);
  color: #e07070;
}

.notes {
  margin: 0.25rem 0 0;
  padding-left: 1rem;
  font-size: var(--type-meta);
  color: var(--text-muted);
}

.section {
  display: flex;
  flex-direction: column;
  gap: 0.35rem;
  min-width: 0;
}

.section-toggle {
  appearance: none;
  display: flex;
  align-items: baseline;
  gap: 0.4rem;
  width: 100%;
  margin: 0;
  padding: 0.25rem 0;
  border: 0;
  background: transparent;
  color: var(--text-muted);
  font: inherit;
  font-size: var(--type-meta);
  font-weight: 700;
  letter-spacing: 0.02em;
  text-transform: uppercase;
  text-align: left;
  cursor: pointer;
}

.section-progress {
  font-weight: 650;
  color: var(--text-primary);
  text-transform: none;
  letter-spacing: 0;
}

.help {
  display: flex;
  flex-direction: column;
  gap: 0.4rem;
  min-width: 0;
}

.help p,
.help li {
  margin: 0;
  font-size: var(--type-meta);
  color: var(--text-muted);
}

.help ul,
.help ol {
  margin: 0;
  padding-left: 1.1rem;
}

.help h1,
.help h2,
.help h3,
.help h4 {
  margin: 0;
  font-size: var(--type-body);
  font-weight: 650;
  color: var(--text-primary);
}

.help strong { font-weight: 700; color: var(--text-primary); }
.help em { font-style: italic; }
.help code {
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  font-size: 0.88em;
  padding: 0.05em 0.3em;
  border-radius: 4px;
  border: 1px solid var(--border);
}
.help a { color: var(--accent); }
.help pre {
  margin: 0;
  padding: 0.45rem 0.55rem;
  overflow-x: auto;
  border: 1px solid var(--border);
  border-radius: 0.35rem;
  font-size: var(--type-meta);
}
.help pre code { padding: 0; border: none; }
`,f={itemDone:"Feito",itemOpen:"A fazer",flagAsBug:"Marcar como bug",solveBug:"Marcar como resolvido",solveItem:"Resolvido",motivo:"Motivo",motivoPlaceholder:"Descreva o problema encontrado",cancelFlag:"Cancelar",taskBugWarning:"Este card volta para To Do, inclusive as subtarefas.",noChecklist:"Esta tarefa não tem checklist.",collapseOverlay:"Recolher",expandOverlay:"Expandir",closeFloatingChecklist:"Fechar checklist flutuante",overlayDragHint:"Arraste pelo cabeçalho",instructionsHeading:"Instruções",checklistHeading:"Checklist",checklistChanged:"A checklist mudou. Recarregue e tente de novo.",motivoRequired:"O motivo do bug é obrigatório.",itemMotivoRequired:"O motivo do bug do item é obrigatório.",apiError:"Não foi possível falar com a API. Tente de novo.",sessionExpired:"Sessão expirada. Entre de novo no Arc Todo.",signInFirst:"Entre no Arc Todo primeiro"};let v=null,R=null,o=null,N=null;function Wt(e){return e.status==="expired"?f.sessionExpired:e.status==="not_signed_in"?f.signInFirst:e.error==="stale"?f.checklistChanged:e.error==="motivo"?f.motivoRequired:e.error==="api"||e.status==="error"?f.apiError:null}function Yt(){const e=document.getElementById(_);if(e&&R&&v===e)return{host:e,shadow:R};e==null||e.remove();const t=document.createElement("div");t.id=_,t.setAttribute("aria-hidden","false"),Object.assign(t.style,{position:"fixed",zIndex:String(ht),left:"0px",top:"0px"});const n=t.attachShadow({mode:"open"}),r=document.createElement("style");return r.textContent=qt,n.appendChild(r),document.documentElement.appendChild(t),v=t,R=n,{host:t,shadow:n}}async function Ut(){try{const e=await x.storage.local.get(oe);return zt(e[oe])}catch{return null}}async function Xt(e,t){try{await x.storage.local.set({[oe]:{left:e,top:t}})}catch{}}async function Vt(){try{const e=await x.storage.local.get(ie);return jt(e[ie])??Q}catch{return Q}}async function Le(){if(o)try{await x.storage.local.set({[ie]:{instructionsCollapsed:o.instructionsCollapsed,checklistCollapsed:o.checklistCollapsed}})}catch{}}function ae(e,t){if(!v)return;const n=v.getBoundingClientRect(),r=Rt(e,t,{width:window.innerWidth,height:window.innerHeight},{width:n.width||420,height:Math.min(n.height||48,48)});v.style.left=`${r.left}px`,v.style.top=`${r.top}px`}function Pe(){if(!v)return;const e=Number.parseFloat(v.style.left||"0"),t=Number.parseFloat(v.style.top||"0");ae(e,t)}async function Gt(){if(!v)return;const e=await Ut(),t={width:420,height:320},n=e??Bt({width:window.innerWidth,height:window.innerHeight},t);ae(n.left,n.top)}function Kt(e){if(!v||e.button!==0)return;const t=e.target;if(t!=null&&t.closest("button"))return;const n=Number.parseFloat(v.style.left||"0"),r=Number.parseFloat(v.style.top||"0");N={pointerId:e.pointerId,startX:e.clientX,startY:e.clientY,originLeft:n,originTop:r},e.currentTarget.setPointerCapture(e.pointerId),e.preventDefault()}function Zt(e){!N||e.pointerId!==N.pointerId||ae(N.originLeft+(e.clientX-N.startX),N.originTop+(e.clientY-N.startY))}function Re(e){if(!N||e.pointerId!==N.pointerId||!v)return;N=null;const t=Number.parseFloat(v.style.left||"0"),n=Number.parseFloat(v.style.top||"0");Xt(t,n)}function b(){if(!R||!o)return;const e=R.querySelector(".panel");if(!e)return;e.classList.toggle("is-collapsed",o.collapsed);const t=R.querySelector(".title"),n=R.querySelector(".display-id");t&&(t.textContent=o.task.title),n&&(n.textContent=o.task.displayId);const r=R.querySelector('[data-action="collapse"]');r&&(r.setAttribute("aria-label",o.collapsed?f.expandOverlay:f.collapseOverlay),r.textContent=o.collapsed?"▸":"▾");const i=R.querySelector(".body");if(!i)return;if(i.replaceChildren(),o.error){const d=document.createElement("p");d.className="error",d.setAttribute("role","alert"),d.textContent=o.error,i.appendChild(d)}const s=document.createElement("p");s.className="hint",s.textContent=f.overlayDragHint,i.appendChild(s),o.helpMarkdown&&i.appendChild(Jt(o.helpMarkdown));const a=Ne(o.items);if(a.length===0){const d=document.createElement("p");d.className="hint",d.textContent=f.noChecklist,i.appendChild(d)}else i.appendChild(en(a.map(d=>d.id)));if(o.taskBugOpen)i.appendChild(nn());else if(o.isBug){const d=document.createElement("button");d.type="button",d.className="btn",d.textContent=f.solveBug,d.disabled=o.busy,d.addEventListener("click",()=>{cn()}),i.appendChild(d)}else{const d=document.createElement("button");d.type="button",d.className="btn",d.textContent=f.flagAsBug,d.disabled=o.busy,d.addEventListener("click",()=>{o&&(o.taskBugOpen=!0,o.taskNote="",o.error=null,b())}),i.appendChild(d)}}function Qt(e){const t=o.items.find(c=>c.id===e),n=document.createElement("li"),r=Lt(o.items,o.expandedId);n.className=["row",t.bugged?"is-bugged":"",t.id===r?"is-current":""].filter(Boolean).join(" ");const i=document.createElement("div");i.className="row-main";const s=document.createElement("button");s.type="button",s.className=t.checked?"tick is-checked":"tick",s.setAttribute("aria-pressed",String(t.checked)),s.setAttribute("aria-label",t.checked?f.itemDone:f.itemOpen),s.disabled=o.busy;const a=document.createElement("span");a.className="tick-mark",a.setAttribute("aria-hidden","true"),s.append(a),s.addEventListener("click",()=>{rn(t.id)});const d=Ne([t])[0],g=document.createElement("button");g.type="button",g.className="expand";const h=o.expandedId===t.id;if(g.setAttribute("aria-expanded",String(h)),h)g.textContent=d.full;else{const c=document.createElement("strong");c.textContent=d.short,g.appendChild(c)}if(g.addEventListener("click",()=>{o&&(o.expandedId=o.expandedId===t.id?null:t.id,b())}),i.append(s,g),n.appendChild(i),t.notes.length){const c=document.createElement("ul");c.className="notes";for(const A of t.notes){const w=document.createElement("li");w.innerHTML="";const T=document.createElement("strong");T.textContent=`${f.motivo}: `,w.append(T,document.createTextNode(A)),c.appendChild(w)}n.appendChild(c)}if(o.reportingItemId===t.id)n.appendChild(tn(t.id));else if(h){const c=document.createElement("div");c.className="row-actions";const A=document.createElement("button");if(A.type="button",A.className="btn",A.textContent=f.flagAsBug,A.disabled=o.busy,A.addEventListener("click",()=>{o&&(o.reportingItemId=t.id,o.itemNote="",o.error=null,b())}),c.appendChild(A),t.bugged){const w=document.createElement("button");w.type="button",w.className="btn",w.textContent=f.solveItem,w.disabled=o.busy,w.addEventListener("click",()=>{an(t.id)}),c.appendChild(w)}n.appendChild(c)}return n}function Be(e,t,n,r){const i=document.createElement("button");i.type="button",i.className="section-toggle",i.setAttribute("aria-expanded",String(t));const s=document.createTextNode(e);if(i.appendChild(s),r){i.appendChild(document.createTextNode(" "));const a=document.createElement("span");a.className="section-progress",a.textContent=r,i.appendChild(a)}return i.addEventListener("click",n),i}function Jt(e){const t=document.createElement("section");t.className="section";const n=!o.instructionsCollapsed;if(t.appendChild(Be(f.instructionsHeading,n,()=>{o&&(o.instructionsCollapsed=!o.instructionsCollapsed,Le(),b())})),n){const r=document.createElement("div");r.className="help markdown-content",Ft(r,e),t.appendChild(r)}return t}function en(e){const t=document.createElement("section");t.className="section";const n=!o.checklistCollapsed,r=o.items.filter(i=>i.checked).length;if(t.appendChild(Be(f.checklistHeading,n,()=>{o&&(o.checklistCollapsed=!o.checklistCollapsed,Le(),b())},`${r}/${o.items.length}`)),n){const i=document.createElement("ul");i.className="list";for(const s of e)i.appendChild(Qt(s));t.appendChild(i)}return t}function tn(e){const t=document.createElement("div");t.className="bug-form";const n=document.createElement("label");n.textContent=f.motivo;const r=document.createElement("textarea");r.value=o.itemNote,r.placeholder=f.motivoPlaceholder,r.rows=3,r.addEventListener("input",()=>{o&&(o.itemNote=r.value,s.disabled=o.busy||!o.itemNote.trim())}),n.appendChild(r);const i=document.createElement("div");i.className="row-actions";const s=document.createElement("button");s.type="button",s.className="btn btn-primary",s.textContent=f.flagAsBug,s.disabled=o.busy||!o.itemNote.trim(),s.addEventListener("click",()=>{on(e)});const a=document.createElement("button");return a.type="button",a.className="btn",a.textContent=f.cancelFlag,a.addEventListener("click",()=>{o&&(o.reportingItemId=null,o.itemNote="",b())}),i.append(s,a),t.append(n,i),t}function nn(){const e=document.createElement("div");e.className="bug-form";const t=document.createElement("p");t.className="warning",t.textContent=f.taskBugWarning;const n=document.createElement("label");n.textContent=f.motivo;const r=document.createElement("textarea");r.value=o.taskNote,r.placeholder=f.motivoPlaceholder,r.rows=3,r.addEventListener("input",()=>{o&&(o.taskNote=r.value,s.disabled=o.busy||!o.taskNote.trim())}),n.appendChild(r);const i=document.createElement("div");i.className="row-actions";const s=document.createElement("button");s.type="button",s.className="btn btn-primary",s.textContent=f.flagAsBug,s.disabled=o.busy||!o.taskNote.trim(),s.addEventListener("click",()=>{sn()});const a=document.createElement("button");return a.type="button",a.className="btn",a.textContent=f.cancelFlag,a.addEventListener("click",()=>{o&&(o.taskBugOpen=!1,o.taskNote="",b())}),i.append(s,a),e.append(t,n,i),e}function H(e){if(!o)return!1;const t=Wt(e);if(t)return o.error=t,!1;if(o.error=null,e.items){o.items=e.items;const n=o.expandedId;n&&!e.items.some(r=>r.id===n)&&(o.expandedId=null)}return e.snapshot&&(o.snapshot=e.snapshot),e.helpMarkdown!==void 0&&(o.helpMarkdown=e.helpMarkdown??null),e.isBug!==void 0&&(o.isBug=e.isBug),!0}async function Oe(){if(o){o.busy=!0,b();try{const e=await x.runtime.sendMessage({type:"task.get",task:o.task});H(e)}finally{o&&(o.busy=!1),b()}}}async function rn(e){if(!(!o||o.busy)){o.busy=!0,o.error=null,b();try{const t=await x.runtime.sendMessage({type:"checklist.tick",task:o.task,itemId:e,snapshot:o.snapshot,source:"overlay"});if(H(t),o){const n=o.items.find(r=>r.id===e);n!=null&&n.checked?o.expandedId=Nt(o.items,e):o.expandedId=e}}finally{o&&(o.busy=!1),b()}}}async function on(e){if(!(!o||o.busy)){if(!o.itemNote.trim()){o.error=f.itemMotivoRequired,b();return}o.busy=!0,o.error=null,b();try{const t=await x.runtime.sendMessage({type:"checklist.flagItem",task:o.task,itemId:e,note:o.itemNote,snapshot:o.snapshot,source:"overlay"});H(t)&&(o.reportingItemId=null,o.itemNote="")}finally{o&&(o.busy=!1),b()}}}async function sn(){if(!(!o||o.busy)){if(!o.taskNote.trim()){o.error=f.motivoRequired,b();return}o.busy=!0,o.error=null,b();try{const e=await x.runtime.sendMessage({type:"task.flag",task:o.task,note:o.taskNote,source:"overlay"});H(e)&&(o.taskBugOpen=!1,o.taskNote="")}finally{o&&(o.busy=!1),b()}}}async function an(e){if(!(!o||o.busy)){o.busy=!0,o.error=null,b();try{const t=await x.runtime.sendMessage({type:"checklist.unflagItem",task:o.task,itemId:e,snapshot:o.snapshot,source:"overlay"});H(t)}finally{o&&(o.busy=!1),b()}}}async function cn(){if(!(!o||o.busy)){o.busy=!0,o.error=null,b();try{const e=await x.runtime.sendMessage({type:"task.unflag",task:o.task,source:"overlay"});H(e)}finally{o&&(o.busy=!1),b()}}}function ln(){const{shadow:e}=Yt();if(e.querySelector(".panel"))return;const n=document.createElement("div");n.className="panel",n.setAttribute("role","dialog"),n.setAttribute("aria-label","Checklist");const r=document.createElement("div");r.className="header",r.addEventListener("pointerdown",Kt),r.addEventListener("pointermove",Zt),r.addEventListener("pointerup",Re),r.addEventListener("pointercancel",Re);const i=document.createElement("div");i.className="header-text";const s=document.createElement("p");s.className="display-id";const a=document.createElement("h2");a.className="title",i.append(s,a);const d=document.createElement("div");d.className="header-actions";const g=document.createElement("button");g.type="button",g.className="icon-btn",g.dataset.action="collapse",g.addEventListener("click",()=>{o&&(o.collapsed=!o.collapsed,b())});const h=document.createElement("button");h.type="button",h.className="icon-btn",h.setAttribute("aria-label",f.closeFloatingChecklist),h.textContent="×",h.addEventListener("click",()=>{$e()}),d.append(g,h),r.append(i,d);const c=document.createElement("div");c.className="body",n.append(r,c),e.appendChild(n),window.addEventListener("resize",Pe)}function dn(e){window===window.top&&(ln(),o={task:e,items:[],snapshot:{items:[]},expandedId:null,reportingItemId:null,itemNote:"",taskBugOpen:!1,taskNote:"",collapsed:!1,instructionsCollapsed:Q.instructionsCollapsed,checklistCollapsed:Q.checklistCollapsed,helpMarkdown:null,isBug:!1,busy:!1,error:null},v&&(v.style.display="block"),b(),Promise.all([Gt(),Vt()]).then(([,t])=>{o&&(o.instructionsCollapsed=t.instructionsCollapsed,o.checklistCollapsed=t.checklistCollapsed,b(),Oe())}))}function $e(){N=null,o=null,window.removeEventListener("resize",Pe),v==null||v.remove(),v=null,R=null}function un(){window===window.top&&x.runtime.onMessage.addListener(e=>{if(!e||typeof e!="object"||!("type"in e))return;const t=e.type;if(t==="overlay.open"){const n=e.task;n!=null&&n.id&&dn(n)}if(t==="overlay.close"&&$e(),t==="qa.checklistChanged"){if(!o||e.taskId!==o.task.id||!Pt("overlay",e.source))return;Oe()}})}const mn=".task-card[data-task-id], .task-list-row[data-task-id]",U="arc-todo-card-highlight";function gn(e){return e.length===0?null:[...e].reverse().find(n=>!n.className.split(/\s+/).includes("is-subtask"))??e[0]}function pn(e){var a,d,g,h,c;const t=(a=e.taskId)==null?void 0:a.trim(),n=(d=e.displayId)==null?void 0:d.trim(),r=(g=e.organizationId)==null?void 0:g.trim(),i=(h=e.projectId)==null?void 0:h.trim(),s=((c=e.taskTitle)==null?void 0:c.trim())||n;return!t||!n||!s||!r||!i?null:{id:t,displayId:n,title:s,organizationId:r,projectId:i}}let F=!1,_e="";function De(e){let t=e.getElementById(U);return t||(t=e.createElement("div"),t.id=U,t.setAttribute("aria-hidden","true"),Object.assign(t.style,{position:"fixed",pointerEvents:"none",zIndex:"2147483647",outline:"2px solid #4862ce",outlineOffset:"2px",background:"rgba(72, 98, 206, 0.14)",borderRadius:"18px",boxSizing:"border-box",display:"none"}),e.documentElement.appendChild(t),t)}function fn(e){const t=[];let n=e;for(;n;){const r=n.closest(mn);if(!(r instanceof HTMLElement))break;t.push(r),n=r.parentElement}return t}function Fe(e,t,n){const r=e.elementFromPoint(t,n);return!r||r.id===U||r.id===_||r.closest(`#${_}`)?null:gn(fn(r))}function hn(e,t){const n=De(e);if(!t){n.style.display="none";return}const r=t.getBoundingClientRect();n.style.display="block",n.style.left=`${r.left}px`,n.style.top=`${r.top}px`,n.style.width=`${r.width}px`,n.style.height=`${r.height}px`}function ze(e){F&&hn(document,Fe(document,e.clientX,e.clientY))}function He(e){if(!F)return;const t=Fe(document,e.clientX,e.clientY);if(!t)return;const n=pn({taskId:t.dataset.taskId,displayId:t.dataset.displayId,taskTitle:t.dataset.taskTitle,organizationId:t.dataset.organizationId,projectId:t.dataset.projectId});n&&(e.preventDefault(),e.stopPropagation(),e.stopImmediatePropagation(),ce(),x.runtime.sendMessage({type:"card.picked",task:n}))}function je(e){!F||e.key!=="Escape"||(e.preventDefault(),ce(),x.runtime.sendMessage({type:"card.cancelled"}))}function yn(){window===window.top&&(F||(F=!0,_e=document.documentElement.style.cursor,document.documentElement.style.cursor="pointer",De(document),document.addEventListener("mousemove",ze,!0),document.addEventListener("click",He,!0),document.addEventListener("keydown",je,!0)))}function ce(){var e;!F&&!document.getElementById(U)||(F=!1,document.documentElement.style.cursor=_e,document.removeEventListener("mousemove",ze,!0),document.removeEventListener("click",He,!0),document.removeEventListener("keydown",je,!0),(e=document.getElementById(U))==null||e.remove())}function xn(){window===window.top&&x.runtime.onMessage.addListener(e=>{if(!e||typeof e!="object"||!("type"in e))return;const t=e.type;t==="card.arm"&&yn(),t==="card.disarm"&&ce()})}const An=["video/webm;codecs=vp9","video/webm;codecs=vp8"];function bn(e){return An.find(t=>e(t))}const vn=12e4,wn=12e5,kn=1e3,qe={video:{width:{max:1280},frameRate:{ideal:15,max:15}},audio:!1},En={...qe,preferCurrentTab:!0,selfBrowserSurface:"include",surfaceSwitching:"exclude",systemAudio:"exclude",monitorTypeSurfaces:"exclude"};function Cn(){return{getDisplayMedia:e=>navigator.mediaDevices.getDisplayMedia(e),createRecorder:(e,t)=>new MediaRecorder(e,t),isTypeSupported:e=>typeof MediaRecorder<"u"&&MediaRecorder.isTypeSupported(e)}}function We(e){if(!e||typeof e!="object")return!1;const t=e.name;return t==="NotAllowedError"||t==="AbortError"}async function Tn(e){try{return await e(En)}catch(t){if(We(t))throw t;return e(qe)}}function Ye(e){for(const t of e.getTracks())t.stop()}function Ue(e,t,n){const r=bn(t.isTypeSupported),i={bitsPerSecond:wn};r&&(i.mimeType=r);const s=t.createRecorder(e,i),a=[],d=(t.now??Date.now)(),g=t.setTimeoutFn??setTimeout,h=t.clearTimeoutFn??clearTimeout;let c,A=!1,w,T;const z=new Promise((k,me)=>{w=k,T=me});function G(k){A||(A=!0,c!==void 0&&h(c),n==null||n(),Ye(e),w(k))}function re(k){A||(A=!0,c!==void 0&&h(c),n==null||n(),Ye(e),T(k))}s.ondataavailable=k=>{k.data&&k.data.size>0&&a.push(k.data)},s.onerror=k=>{re(k)},s.onstop=()=>{const k=(r==null?void 0:r.split(";")[0])??"video/webm";G(new Blob(a,{type:k}))};function j(){return!A&&s.state!=="inactive"&&s.stop(),z}const ue=()=>{j()};for(const k of e.getTracks())k.addEventListener("ended",ue);c=g(()=>{j()},vn);try{s.start(kn)}catch(k){throw re(k),k}return{startedAt:d,mimeType:r??"video/webm",stop:j,done:z}}async function Xe(e,t,n=globalThis){try{if(n.RestrictionTarget&&typeof e.restrictTo=="function"){const r=await n.RestrictionTarget.fromElement(t);return await e.restrictTo(r),!0}if(n.CropTarget&&typeof e.cropTo=="function"){const r=await n.CropTarget.fromElement(t);return await e.cropTo(r),!0}}catch{return!1}return!1}function In(e,t,n){const r=document.createElement("canvas"),i=t();r.width=Math.max(1,Math.round((i==null?void 0:i.width)??1)),r.height=Math.max(1,Math.round((i==null?void 0:i.height)??1));const s=r.getContext("2d");let a=0,d=!0;const g=()=>{if(!d||!s)return;const c=t();if(c){const A=Math.max(1,Math.round(c.width)),w=Math.max(1,Math.round(c.height));r.width!==A&&(r.width=A),r.height!==w&&(r.height=w),s.drawImage(e.source,c.x,c.y,c.width,c.height,0,0,r.width,r.height)}a=requestAnimationFrame(g)};g();const h=r.captureStream(n);return{stream:h,stop:()=>{d=!1,cancelAnimationFrame(a);for(const c of h.getTracks())c.stop()}}}function Ve(e){for(const t of e.getTracks())t.stop()}async function Mn(e){return Tn(e)}function Sn(){return{...Cn(),isolateTrack:(e,t)=>Xe(e,t),attachDisplay:async e=>{const t=document.createElement("video");return t.muted=!0,t.playsInline=!0,t.srcObject=e,await t.play(),(!t.videoWidth||!t.videoHeight)&&await new Promise(n=>{t.onloadedmetadata=()=>n()}),{width:t.videoWidth,height:t.videoHeight,source:t}},captureLive:In}}function Nn(e,t,n={width:window.innerWidth,height:window.innerHeight}){const r=e.getBoundingClientRect();return At({x:r.left,y:r.top,width:r.width,height:r.height},n,t)}async function Ln(e,t){const n=await Mn(t.getDisplayMedia);try{const r=n.getTracks()[0];if(r?await(t.isolateTrack??Xe)(r,e):!1)return Ue(n,t);const s=await t.attachDisplay(n),a=t.captureLive(s,()=>Nn(e,{width:s.width,height:s.height}),15);return Ue(a.stream,t,()=>{a.stop(),Ve(n)})}catch(r){throw Ve(n),r}}const Pn=6,Rn=200,Bn=3;function On(e){return{color:(e==null?void 0:e.color)??"",fontSize:(e==null?void 0:e.fontSize)??"",display:(e==null?void 0:e.display)??""}}function Ge(e){const{x:t,y:n,width:r,height:i}=e.rect;return`${e.selector}@${Math.round(t)},${Math.round(n)},${Math.round(r)},${Math.round(i)}`}function J(e){return typeof CSS<"u"&&typeof CSS.escape=="function"?CSS.escape(e):e.replace(/([^\w-])/g,"\\$1")}function $n(e){return e.filter(t=>/^[A-Za-z_][\w-]*$/.test(t)).slice(0,Bn)}function _n(e,t=Rn){const n=(e??"").replace(/\s+/g," ").trim();return n.length<=t?n:n.slice(0,t)}function Dn(e){const t=e.parentElement;return t?Array.from(t.children).indexOf(e)+1:1}function Fn(e,t){if(!t)return!1;try{return e.querySelectorAll(`#${J(t)}`).length===1}catch{return!1}}function Ke(e){return{tagName:e.tagName,id:e.id,classes:Array.from(e.classList),nthChild:Dn(e),parent:e.parentElement?Ke(e.parentElement):null}}function zn(e){const t=e.tagName.toLowerCase();if(t==="html"||t==="body")return t;const n=$n(e.classes);let r=t;return n.length&&(r+=n.map(i=>`.${J(i)}`).join("")),e.nthChild>0&&(r+=`:nth-child(${e.nthChild})`),r}function Hn(e,t,n=Pn){if(e.id&&t(e.id))return`#${J(e.id)}`;const r=[];let i=e,s=0;for(;i&&s<n;){if(i.id&&t(i.id)){r.unshift(`#${J(i.id)}`);break}if(r.unshift(zn(i)),i.tagName.toLowerCase()==="html")break;i=i.parent,s+=1}return r.join(" > ")}function jn(e,t){const n=e.getBoundingClientRect(),r=typeof getComputedStyle=="function"?getComputedStyle(e):void 0;return{tag:e.tagName.toLowerCase(),id:e.id,classes:Array.from(e.classList),text:_n(e.textContent),title:t.document.title??"",url:t.locationHref??(typeof location<"u"?location.href:""),selector:Hn(Ke(e),i=>Fn(t.document,i)),rect:{x:n.left,y:n.top,width:n.width,height:n.height},viewport:{width:t.innerWidth,height:t.innerHeight},computed:On(r)}}function qn(e,t){const n=e.classes.length?e.classes.join(", "):"(none)";return`\`\`\`markdown
${["## Element","",`- Selector: \`${e.selector}\``,`- Tag: ${e.tag}`,`- Id: ${e.id||"(none)"}`,`- Classes: ${n}`,`- Text: ${e.text||"(none)"}`,`- Title: ${e.title||"(none)"}`,`- URL: ${e.url}`,"- Screenshot: omitted"].join(`
`)}
\`\`\``}function Wn(e){if(!e||typeof e!="object")return"dev";const t=e.purpose;return t==="qa-crop"||t==="qa-record"||t==="design"?t:"dev"}function Yn(e){return e==="dev"}function Un(e){return e!=="design"}function Xn(e,t,n){return e==="qa-crop"?{type:"capture.elementPicked",hit:t}:e==="qa-record"?{type:"capture.elementForRecord",hit:t}:{type:"picker.picked",hit:t,keepArmed:e==="design",removed:n==null?void 0:n.removed}}let X=null,ee=!1;const V="arc-todo-picker-hover",Ze="arc-todo-picker-selected",Qe=["pointerdown","mousedown","mouseup","auxclick","contextmenu","dblclick"];let $=!1,L="dev",Je="",et=0;const P=new Map;function tt(){return{position:"fixed",pointerEvents:"none",zIndex:"2147483647",outline:"2px solid #4862ce",outlineOffset:"1px",background:"rgba(72, 98, 206, 0.12)",boxSizing:"border-box",display:"none"}}function le(e,t){e.style.display="block",e.style.left=`${t.left}px`,e.style.top=`${t.top}px`,e.style.width=`${t.width}px`,e.style.height=`${t.height}px`}function de(e){let t=e.getElementById(V);return t||(t=e.createElement("div"),t.id=V,t.setAttribute("aria-hidden","true"),Object.assign(t.style,tt()),e.documentElement.appendChild(t),t)}function Vn(e){const t=e.createElement("div");return t.className=Ze,t.id=`arc-todo-picker-selected-${et}`,et+=1,t.setAttribute("aria-hidden","true"),Object.assign(t.style,tt(),{display:"block"}),e.documentElement.appendChild(t),t}function Gn(e){return e?e.id===_?!0:!!e.closest(`#${_}`):!1}function Kn(e){return e?e.id===V||e.classList.contains(Ze)||Gn(e):!1}function nt(e,t,n){const r=e.elementFromPoint(t,n);return!r||Kn(r)?null:r}function rt(e){$&&(e.preventDefault(),e.stopPropagation(),e.stopImmediatePropagation())}function Zn(e,t){const n=de(e);if(!t){n.style.display="none";return}le(n,t.getBoundingClientRect())}function ot(e){return jn(e,{document,innerWidth:window.innerWidth,innerHeight:window.innerHeight,locationHref:location.href})}function Qn(e){if(P.has(e))return e;for(const t of P.keys())if(Ge(P.get(t).hit)===Ge(ot(e)))return t;return null}function Jn(e,t){const n=Vn(document);le(n,e.getBoundingClientRect()),P.set(e,{hit:t,box:n})}function it(e){const t=P.get(e);return t==null||t.box.remove(),P.delete(e),t==null?void 0:t.hit}function st(){for(const e of P.values())e.box.remove();P.clear()}function er(){for(const[e,t]of P){if(!e.isConnected){it(e);continue}le(t.box,e.getBoundingClientRect())}}function at(e){$&&Zn(document,nt(document,e.clientX,e.clientY))}function te(){!$||L!=="design"||er()}async function tr(e,t){try{const n=await Ln(e,Sn());X=n,ee=!1,x.runtime.sendMessage({type:"capture.pageElementRecordStarted",hit:t,startedAt:n.startedAt}),n.done.then(async r=>{if(ee||X!==n)return;X=null;const i=await r.arrayBuffer();x.runtime.sendMessage({type:"capture.pageElementRecordFinished",mimeType:n.mimeType,buffer:i,startedAt:n.startedAt})})}catch(n){if(We(n)){x.runtime.sendMessage({type:"picker.cancelled"});return}x.runtime.sendMessage({type:"capture.elementForRecord",hit:t})}}async function nr(){const e=X;if(!e)return{error:"idle"};ee=!0,X=null;try{const t=await e.stop();return{mimeType:e.mimeType,buffer:await t.arrayBuffer(),startedAt:e.startedAt}}catch{return ee=!1,{error:"failed"}}}async function ct(e){if(!$)return;const t=nt(document,e.clientX,e.clientY);if(!t)return;e.preventDefault(),e.stopPropagation(),e.stopImmediatePropagation();const n=Qn(t),r=L==="design"&&(!!n||e.shiftKey),i=r&&n?P.get(n).hit:ot(t);if(L==="qa-record"){ne(),tr(t,i);return}if(L==="design")if(r&&n)it(n);else if(!r)Jn(t,i);else return;if(Yn(L)){const a=qn(i);try{await navigator.clipboard.writeText(a)}catch{}}const s=Xn(L,i,{removed:r});Un(L)&&ne(),x.runtime.sendMessage(s)}function lt(e){!$||e.key!=="Escape"||(e.preventDefault(),ne(),x.runtime.sendMessage({type:"picker.cancelled"}))}function rr(e="dev"){if(window===window.top){if($){L!==e&&(st(),de(document).style.display="none"),L=e;return}$=!0,L=e,Je=document.documentElement.style.cursor,document.documentElement.style.cursor="crosshair",de(document),document.addEventListener("mousemove",at,!0),document.addEventListener("click",ct,!0),document.addEventListener("keydown",lt,!0);for(const t of Qe)document.addEventListener(t,rt,!0);window.addEventListener("scroll",te,!0),window.addEventListener("resize",te)}}function ne(){var e;if(!(!$&&!document.getElementById(V)&&P.size===0)){$=!1,L="dev",document.documentElement.style.cursor=Je,document.removeEventListener("mousemove",at,!0),document.removeEventListener("click",ct,!0),document.removeEventListener("keydown",lt,!0);for(const t of Qe)document.removeEventListener(t,rt,!0);window.removeEventListener("scroll",te,!0),window.removeEventListener("resize",te),(e=document.getElementById(V))==null||e.remove(),st()}}function or(){window===window.top&&x.runtime.onMessage.addListener(e=>{if(!e||typeof e!="object"||!("type"in e))return;const t=e.type;if(t==="picker.arm"&&rr(Wn(e)),t==="picker.disarm"&&ne(),t==="capture.stopElementRecord")return nr()})}const dt=window;function ir(e){return!!(e&&typeof e=="object"&&e.type==="content.ping")}x.runtime.onMessage.addListener(e=>{if(ir(e))return Promise.resolve(!0)}),dt.__arcTodoContentReady||(dt.__arcTodoContentReady=!0,window.addEventListener(ft,e=>{const t=e.detail;typeof t=="string"&&x.runtime.sendMessage({type:"capture.console",payload:t})}),x.runtime.sendMessage({type:"capture.pageReady"}),or(),Mt(),xn(),un())})();
