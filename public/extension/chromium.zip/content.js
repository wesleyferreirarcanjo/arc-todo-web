(function(){"use strict";function Ke(e){return e&&e.__esModule&&Object.prototype.hasOwnProperty.call(e,"default")?e.default:e}var W={exports:{}},Ze=W.exports,ce;function Qe(){return ce||(ce=1,(function(e,t){(function(n,o){o(e)})(typeof globalThis<"u"?globalThis:typeof self<"u"?self:Ze,function(n){if(!(globalThis.chrome&&globalThis.chrome.runtime&&globalThis.chrome.runtime.id))throw new Error("This script should only be loaded in a browser extension.");if(globalThis.browser&&globalThis.browser.runtime&&globalThis.browser.runtime.id)n.exports=globalThis.browser;else{const o="The message port closed before a response was received.",i=s=>{const a={alarms:{clear:{minArgs:0,maxArgs:1},clearAll:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getAll:{minArgs:0,maxArgs:0}},bookmarks:{create:{minArgs:1,maxArgs:1},get:{minArgs:1,maxArgs:1},getChildren:{minArgs:1,maxArgs:1},getRecent:{minArgs:1,maxArgs:1},getSubTree:{minArgs:1,maxArgs:1},getTree:{minArgs:0,maxArgs:0},move:{minArgs:2,maxArgs:2},remove:{minArgs:1,maxArgs:1},removeTree:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1},update:{minArgs:2,maxArgs:2}},browserAction:{disable:{minArgs:0,maxArgs:1,fallbackToNoCallback:!0},enable:{minArgs:0,maxArgs:1,fallbackToNoCallback:!0},getBadgeBackgroundColor:{minArgs:1,maxArgs:1},getBadgeText:{minArgs:1,maxArgs:1},getPopup:{minArgs:1,maxArgs:1},getTitle:{minArgs:1,maxArgs:1},openPopup:{minArgs:0,maxArgs:0},setBadgeBackgroundColor:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setBadgeText:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setIcon:{minArgs:1,maxArgs:1},setPopup:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setTitle:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},browsingData:{remove:{minArgs:2,maxArgs:2},removeCache:{minArgs:1,maxArgs:1},removeCookies:{minArgs:1,maxArgs:1},removeDownloads:{minArgs:1,maxArgs:1},removeFormData:{minArgs:1,maxArgs:1},removeHistory:{minArgs:1,maxArgs:1},removeLocalStorage:{minArgs:1,maxArgs:1},removePasswords:{minArgs:1,maxArgs:1},removePluginData:{minArgs:1,maxArgs:1},settings:{minArgs:0,maxArgs:0}},commands:{getAll:{minArgs:0,maxArgs:0}},contextMenus:{remove:{minArgs:1,maxArgs:1},removeAll:{minArgs:0,maxArgs:0},update:{minArgs:2,maxArgs:2}},cookies:{get:{minArgs:1,maxArgs:1},getAll:{minArgs:1,maxArgs:1},getAllCookieStores:{minArgs:0,maxArgs:0},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}},devtools:{inspectedWindow:{eval:{minArgs:1,maxArgs:2,singleCallbackArg:!1}},panels:{create:{minArgs:3,maxArgs:3,singleCallbackArg:!0},elements:{createSidebarPane:{minArgs:1,maxArgs:1}}}},downloads:{cancel:{minArgs:1,maxArgs:1},download:{minArgs:1,maxArgs:1},erase:{minArgs:1,maxArgs:1},getFileIcon:{minArgs:1,maxArgs:2},open:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},pause:{minArgs:1,maxArgs:1},removeFile:{minArgs:1,maxArgs:1},resume:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1},show:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},extension:{isAllowedFileSchemeAccess:{minArgs:0,maxArgs:0},isAllowedIncognitoAccess:{minArgs:0,maxArgs:0}},history:{addUrl:{minArgs:1,maxArgs:1},deleteAll:{minArgs:0,maxArgs:0},deleteRange:{minArgs:1,maxArgs:1},deleteUrl:{minArgs:1,maxArgs:1},getVisits:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1}},i18n:{detectLanguage:{minArgs:1,maxArgs:1},getAcceptLanguages:{minArgs:0,maxArgs:0}},identity:{launchWebAuthFlow:{minArgs:1,maxArgs:1}},idle:{queryState:{minArgs:1,maxArgs:1}},management:{get:{minArgs:1,maxArgs:1},getAll:{minArgs:0,maxArgs:0},getSelf:{minArgs:0,maxArgs:0},setEnabled:{minArgs:2,maxArgs:2},uninstallSelf:{minArgs:0,maxArgs:1}},notifications:{clear:{minArgs:1,maxArgs:1},create:{minArgs:1,maxArgs:2},getAll:{minArgs:0,maxArgs:0},getPermissionLevel:{minArgs:0,maxArgs:0},update:{minArgs:2,maxArgs:2}},pageAction:{getPopup:{minArgs:1,maxArgs:1},getTitle:{minArgs:1,maxArgs:1},hide:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setIcon:{minArgs:1,maxArgs:1},setPopup:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setTitle:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},show:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},permissions:{contains:{minArgs:1,maxArgs:1},getAll:{minArgs:0,maxArgs:0},remove:{minArgs:1,maxArgs:1},request:{minArgs:1,maxArgs:1}},runtime:{getBackgroundPage:{minArgs:0,maxArgs:0},getPlatformInfo:{minArgs:0,maxArgs:0},openOptionsPage:{minArgs:0,maxArgs:0},requestUpdateCheck:{minArgs:0,maxArgs:0},sendMessage:{minArgs:1,maxArgs:3},sendNativeMessage:{minArgs:2,maxArgs:2},setUninstallURL:{minArgs:1,maxArgs:1}},sessions:{getDevices:{minArgs:0,maxArgs:1},getRecentlyClosed:{minArgs:0,maxArgs:1},restore:{minArgs:0,maxArgs:1}},storage:{local:{clear:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}},managed:{get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1}},sync:{clear:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}}},tabs:{captureVisibleTab:{minArgs:0,maxArgs:2},create:{minArgs:1,maxArgs:1},detectLanguage:{minArgs:0,maxArgs:1},discard:{minArgs:0,maxArgs:1},duplicate:{minArgs:1,maxArgs:1},executeScript:{minArgs:1,maxArgs:2},get:{minArgs:1,maxArgs:1},getCurrent:{minArgs:0,maxArgs:0},getZoom:{minArgs:0,maxArgs:1},getZoomSettings:{minArgs:0,maxArgs:1},goBack:{minArgs:0,maxArgs:1},goForward:{minArgs:0,maxArgs:1},highlight:{minArgs:1,maxArgs:1},insertCSS:{minArgs:1,maxArgs:2},move:{minArgs:2,maxArgs:2},query:{minArgs:1,maxArgs:1},reload:{minArgs:0,maxArgs:2},remove:{minArgs:1,maxArgs:1},removeCSS:{minArgs:1,maxArgs:2},sendMessage:{minArgs:2,maxArgs:3},setZoom:{minArgs:1,maxArgs:2},setZoomSettings:{minArgs:1,maxArgs:2},update:{minArgs:1,maxArgs:2}},topSites:{get:{minArgs:0,maxArgs:0}},webNavigation:{getAllFrames:{minArgs:1,maxArgs:1},getFrame:{minArgs:1,maxArgs:1}},webRequest:{handlerBehaviorChanged:{minArgs:0,maxArgs:0}},windows:{create:{minArgs:0,maxArgs:1},get:{minArgs:1,maxArgs:2},getAll:{minArgs:0,maxArgs:1},getCurrent:{minArgs:0,maxArgs:1},getLastFocused:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},update:{minArgs:2,maxArgs:2}}};if(Object.keys(a).length===0)throw new Error("api-metadata.json has not been included in browser-polyfill");class d extends WeakMap{constructor(c,m=void 0){super(m),this.createItem=c}get(c){return this.has(c)||this.set(c,this.createItem(c)),super.get(c)}}const h=l=>l&&typeof l=="object"&&typeof l.then=="function",v=(l,c)=>(...m)=>{s.runtime.lastError?l.reject(new Error(s.runtime.lastError.message)):c.singleCallbackArg||m.length<=1&&c.singleCallbackArg!==!1?l.resolve(m[0]):l.resolve(m)},f=l=>l==1?"argument":"arguments",w=(l,c)=>function(p,...k){if(k.length<c.minArgs)throw new Error(`Expected at least ${c.minArgs} ${f(c.minArgs)} for ${l}(), got ${k.length}`);if(k.length>c.maxArgs)throw new Error(`Expected at most ${c.maxArgs} ${f(c.maxArgs)} for ${l}(), got ${k.length}`);return new Promise((E,C)=>{if(c.fallbackToNoCallback)try{p[l](...k,v({resolve:E,reject:C},c))}catch(u){console.warn(`${l} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `,u),p[l](...k),c.fallbackToNoCallback=!1,c.noCallback=!0,E()}else c.noCallback?(p[l](...k),E()):p[l](...k,v({resolve:E,reject:C},c))})},j=(l,c,m)=>new Proxy(c,{apply(p,k,E){return m.call(k,l,...E)}});let _=Function.call.bind(Object.prototype.hasOwnProperty);const K=(l,c={},m={})=>{let p=Object.create(null),k={has(C,u){return u in l||u in p},get(C,u,S){if(u in p)return p[u];if(!(u in l))return;let y=l[u];if(typeof y=="function")if(typeof c[u]=="function")y=j(l,l[u],c[u]);else if(_(m,u)){let q=w(u,m[u]);y=j(l,l[u],q)}else y=y.bind(l);else if(typeof y=="object"&&y!==null&&(_(c,u)||_(m,u)))y=K(y,c[u],m[u]);else if(_(m,"*"))y=K(y,c[u],m["*"]);else return Object.defineProperty(p,u,{configurable:!0,enumerable:!0,get(){return l[u]},set(q){l[u]=q}}),y;return p[u]=y,y},set(C,u,S,y){return u in p?p[u]=S:l[u]=S,!0},defineProperty(C,u,S){return Reflect.defineProperty(p,u,S)},deleteProperty(C,u){return Reflect.deleteProperty(p,u)}},E=Object.create(l);return new Proxy(E,k)},se=l=>({addListener(c,m,...p){c.addListener(l.get(m),...p)},hasListener(c,m){return c.hasListener(l.get(m))},removeListener(c,m){c.removeListener(l.get(m))}}),En=new d(l=>typeof l!="function"?l:function(m){const p=K(m,{},{getContent:{minArgs:0,maxArgs:0}});l(p)}),Ve=new d(l=>typeof l!="function"?l:function(m,p,k){let E=!1,C,u=new Promise(Y=>{C=function(M){E=!0,Y(M)}}),S;try{S=l(m,p,C)}catch(Y){S=Promise.reject(Y)}const y=S!==!0&&h(S);if(S!==!0&&!y&&!E)return!1;const q=Y=>{Y.then(M=>{k(M)},M=>{let le;M&&(M instanceof Error||typeof M.message=="string")?le=M.message:le="An unexpected error occurred",k({__mozWebExtensionPolyfillReject__:!0,message:le})}).catch(M=>{console.error("Failed to send onMessage rejected reply",M)})};return q(y?S:u),!0}),Cn=({reject:l,resolve:c},m)=>{s.runtime.lastError?s.runtime.lastError.message===o?c():l(new Error(s.runtime.lastError.message)):m&&m.__mozWebExtensionPolyfillReject__?l(new Error(m.message)):c(m)},Ge=(l,c,m,...p)=>{if(p.length<c.minArgs)throw new Error(`Expected at least ${c.minArgs} ${f(c.minArgs)} for ${l}(), got ${p.length}`);if(p.length>c.maxArgs)throw new Error(`Expected at most ${c.maxArgs} ${f(c.maxArgs)} for ${l}(), got ${p.length}`);return new Promise((k,E)=>{const C=Cn.bind(null,{resolve:k,reject:E});p.push(C),m.sendMessage(...p)})},Sn={devtools:{network:{onRequestFinished:se(En)}},runtime:{onMessage:se(Ve),onMessageExternal:se(Ve),sendMessage:Ge.bind(null,"sendMessage",{minArgs:1,maxArgs:3})},tabs:{sendMessage:Ge.bind(null,"sendMessage",{minArgs:2,maxArgs:3})}},ae={clear:{minArgs:1,maxArgs:1},get:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}};return a.privacy={network:{"*":ae},services:{"*":ae},websites:{"*":ae}},K(s,Sn,a)};n.exports=i(chrome)}})})(W)),W.exports}var Je=Qe();const x=Ke(Je),et="arc-todo-capture",R="arc-todo-qa-overlay",tt=2147483646,Z="arcTodo.overlayPosition",Q="arcTodo.overlaySections",nt=6,rt=200,ot=3;function it(e){return{color:(e==null?void 0:e.color)??"",fontSize:(e==null?void 0:e.fontSize)??"",display:(e==null?void 0:e.display)??""}}function de(e){const{x:t,y:n,width:o,height:i}=e.rect;return`${e.selector}@${Math.round(t)},${Math.round(n)},${Math.round(o)},${Math.round(i)}`}function X(e){return typeof CSS<"u"&&typeof CSS.escape=="function"?CSS.escape(e):e.replace(/([^\w-])/g,"\\$1")}function st(e){return e.filter(t=>/^[A-Za-z_][\w-]*$/.test(t)).slice(0,ot)}function at(e,t=rt){const n=(e??"").replace(/\s+/g," ").trim();return n.length<=t?n:n.slice(0,t)}function lt(e){const t=e.parentElement;return t?Array.from(t.children).indexOf(e)+1:1}function ct(e,t){if(!t)return!1;try{return e.querySelectorAll(`#${X(t)}`).length===1}catch{return!1}}function ue(e){return{tagName:e.tagName,id:e.id,classes:Array.from(e.classList),nthChild:lt(e),parent:e.parentElement?ue(e.parentElement):null}}function dt(e){const t=e.tagName.toLowerCase();if(t==="html"||t==="body")return t;const n=st(e.classes);let o=t;return n.length&&(o+=n.map(i=>`.${X(i)}`).join("")),e.nthChild>0&&(o+=`:nth-child(${e.nthChild})`),o}function ut(e,t,n=nt){if(e.id&&t(e.id))return`#${X(e.id)}`;const o=[];let i=e,s=0;for(;i&&s<n;){if(i.id&&t(i.id)){o.unshift(`#${X(i.id)}`);break}if(o.unshift(dt(i)),i.tagName.toLowerCase()==="html")break;i=i.parent,s+=1}return o.join(" > ")}function mt(e,t){const n=e.getBoundingClientRect(),o=typeof getComputedStyle=="function"?getComputedStyle(e):void 0;return{tag:e.tagName.toLowerCase(),id:e.id,classes:Array.from(e.classList),text:at(e.textContent),title:t.document.title??"",url:t.locationHref??(typeof location<"u"?location.href:""),selector:ut(ue(e),i=>ct(t.document,i)),rect:{x:n.left,y:n.top,width:n.width,height:n.height},viewport:{width:t.innerWidth,height:t.innerHeight},computed:it(o)}}function gt(e,t){const n=e.classes.length?e.classes.join(", "):"(none)";return`\`\`\`markdown
${["## Element","",`- Selector: \`${e.selector}\``,`- Tag: ${e.tag}`,`- Id: ${e.id||"(none)"}`,`- Classes: ${n}`,`- Text: ${e.text||"(none)"}`,`- Title: ${e.title||"(none)"}`,`- URL: ${e.url}`,"- Screenshot: omitted"].join(`
`)}
\`\`\``}function pt(e){if(!e||typeof e!="object")return"dev";const t=e.purpose;return t==="qa-crop"||t==="qa-record"||t==="design"?t:"dev"}function ft(e){return e==="dev"}function ht(e){return e!=="design"}function At(e,t,n){return e==="qa-crop"?{type:"capture.elementPicked",hit:t}:e==="qa-record"?{type:"capture.elementForRecord",hit:t}:{type:"picker.picked",hit:t,keepArmed:e==="design",removed:n==null?void 0:n.removed}}const F="arc-todo-picker-hover",J="arc-todo-picker-selected",me=["pointerdown","mousedown","mouseup","auxclick","contextmenu","dblclick"];let P=!1,I="dev",ge="",pe=0;const L=new Map;function fe(){return{position:"fixed",pointerEvents:"none",zIndex:"2147483647",outline:"2px solid #4862ce",outlineOffset:"1px",background:"rgba(72, 98, 206, 0.12)",boxSizing:"border-box",display:"none"}}function ee(e,t){e.style.display="block",e.style.left=`${t.left}px`,e.style.top=`${t.top}px`,e.style.width=`${t.width}px`,e.style.height=`${t.height}px`}function te(e){let t=e.getElementById(F);return t||(t=e.createElement("div"),t.id=F,t.setAttribute("aria-hidden","true"),Object.assign(t.style,fe()),e.documentElement.appendChild(t),t)}function xt(e){const t=e.createElement("div");return t.className=J,t.id=`arc-todo-picker-selected-${pe}`,pe+=1,t.setAttribute("aria-hidden","true"),Object.assign(t.style,fe(),{display:"block"}),e.documentElement.appendChild(t),t}function bt(e){return e?e.id===R?!0:!!e.closest(`#${R}`):!1}function yt(e){return e?e.id===F||e.classList.contains(J)||bt(e):!1}function he(e,t,n){const o=e.elementFromPoint(t,n);return!o||yt(o)?null:o}function Ae(e){P&&(e.preventDefault(),e.stopPropagation(),e.stopImmediatePropagation())}function vt(e,t){const n=te(e);if(!t){n.style.display="none";return}ee(n,t.getBoundingClientRect())}function xe(e){return mt(e,{document,innerWidth:window.innerWidth,innerHeight:window.innerHeight,locationHref:location.href})}function kt(e){if(L.has(e))return e;for(const t of L.keys())if(de(L.get(t).hit)===de(xe(e)))return t;return null}function wt(e,t){const n=xt(document);ee(n,e.getBoundingClientRect()),L.set(e,{hit:t,box:n})}function be(e){const t=L.get(e);return t==null||t.box.remove(),L.delete(e),t==null?void 0:t.hit}function ye(){for(const e of L.values())e.box.remove();L.clear()}function Et(){for(const[e,t]of L){if(!e.isConnected){be(e);continue}ee(t.box,e.getBoundingClientRect())}}function ve(e){P&&vt(document,he(document,e.clientX,e.clientY))}function U(){!P||I!=="design"||Et()}async function ke(e){if(!P)return;const t=he(document,e.clientX,e.clientY);if(!t)return;e.preventDefault(),e.stopPropagation(),e.stopImmediatePropagation();const n=kt(t),o=I==="design"&&(!!n||e.shiftKey),i=o&&n?L.get(n).hit:xe(t);if(I==="design")if(o&&n)be(n);else if(!o)wt(t,i);else return;if(ft(I)){const a=gt(i);try{await navigator.clipboard.writeText(a)}catch{}}const s=At(I,i,{removed:o});ht(I)&&ne(),x.runtime.sendMessage(s)}function we(e){!P||e.key!=="Escape"||(e.preventDefault(),ne(),x.runtime.sendMessage({type:"picker.cancelled"}))}function Ct(e="dev"){if(window===window.top){if(P){I!==e&&(ye(),te(document).style.display="none"),I=e;return}P=!0,I=e,ge=document.documentElement.style.cursor,document.documentElement.style.cursor="crosshair",te(document),document.addEventListener("mousemove",ve,!0),document.addEventListener("click",ke,!0),document.addEventListener("keydown",we,!0);for(const t of me)document.addEventListener(t,Ae,!0);window.addEventListener("scroll",U,!0),window.addEventListener("resize",U)}}function ne(){var e;if(!(!P&&!document.getElementById(F)&&L.size===0)){P=!1,I="dev",document.documentElement.style.cursor=ge,document.removeEventListener("mousemove",ve,!0),document.removeEventListener("click",ke,!0),document.removeEventListener("keydown",we,!0);for(const t of me)document.removeEventListener(t,Ae,!0);window.removeEventListener("scroll",U,!0),window.removeEventListener("resize",U),(e=document.getElementById(F))==null||e.remove(),ye()}}function St(){window===window.top&&x.runtime.onMessage.addListener(e=>{if(!e||typeof e!="object"||!("type"in e))return;const t=e.type;t==="picker.arm"&&Ct(pt(e)),t==="picker.disarm"&&ne()})}function Lt(e,t,n,o,i,s){const a=Math.max(0,Math.min(e,n)),d=Math.max(0,Math.min(t,o)),h=Math.min(i,Math.max(e,n)),v=Math.min(s,Math.max(t,o)),f=h-a,w=v-d;return f<4||w<4?null:{x:a,y:d,width:f,height:w}}function Nt(e,t,n,o,i){const s=Lt(e,t,n,o,i.width,i.height);return s?{rect:s,viewport:i}:null}const z="arc-todo-region-overlay",H="arc-todo-region-marquee",Ee=["pointerdown","mousedown","mouseup","auxclick","contextmenu","dblclick"];let $=!1,Ce="",O=null;function It(){return{position:"fixed",inset:"0",zIndex:"2147483645",cursor:"crosshair",background:"rgba(0, 0, 0, 0.35)",boxSizing:"border-box"}}function Tt(){return{position:"fixed",pointerEvents:"none",zIndex:"2147483645",outline:"2px solid #ffffff",outlineOffset:"0",boxShadow:"0 0 0 99999px rgba(0, 0, 0, 0.35)",boxSizing:"border-box",display:"none",background:"transparent"}}function Mt(e){let t=e.getElementById(z);return t||(t=e.createElement("div"),t.id=z,t.setAttribute("aria-hidden","true"),Object.assign(t.style,It()),e.documentElement.appendChild(t),t)}function Se(e){let t=e.getElementById(H);return t||(t=e.createElement("div"),t.id=H,t.setAttribute("aria-hidden","true"),Object.assign(t.style,Tt()),e.documentElement.appendChild(t),t)}function Pt(e){return e?e.id===R?!0:!!e.closest(`#${R}`):!1}function $t(e){return e?e.id===z||e.id===H:!1}function Rt(e){return e?e.id===F||e.classList.contains(J)||Pt(e):!1}function Ot(e,t,n){const o=e.getElementById(z),i=e.getElementById(H);o&&(o.style.pointerEvents="none"),i&&(i.style.pointerEvents="none");const s=e.elementFromPoint(t,n);return o&&(o.style.pointerEvents="auto"),s}function Le(e){$&&(e.preventDefault(),e.stopPropagation(),e.stopImmediatePropagation())}function Bt(e,t,n,o){const i=Math.min(e,n),s=Math.min(t,o),a=Se(document);a.style.display="block",a.style.left=`${i}px`,a.style.top=`${s}px`,a.style.width=`${Math.abs(n-e)}px`,a.style.height=`${Math.abs(o-t)}px`}function Ne(){const e=document.getElementById(H);e&&(e.style.display="none")}function _t(){return{width:window.innerWidth,height:window.innerHeight}}function Ie(e){if(!$||e.button!==0)return;const t=Ot(document,e.clientX,e.clientY);Rt(t)||$t(t)||(O={x:e.clientX,y:e.clientY},Ne())}function Te(e){!$||!O||Bt(O.x,O.y,e.clientX,e.clientY)}function Me(e){if(!$||!O)return;const t=O;O=null;const n=Nt(t.x,t.y,e.clientX,e.clientY,_t());Ne(),n&&(x.runtime.sendMessage({type:"region.picked",rect:n.rect,viewport:n.viewport,devicePixelRatio:window.devicePixelRatio}),re())}function Pe(e){!$||e.key!=="Escape"||(e.preventDefault(),re(),x.runtime.sendMessage({type:"region.cancelled"}))}function Ft(){if(window===window.top&&!$){$=!0,Ce=document.documentElement.style.cursor,document.documentElement.style.cursor="crosshair",Mt(document),Se(document),document.addEventListener("pointerdown",Ie,!0),document.addEventListener("pointermove",Te,!0),document.addEventListener("pointerup",Me,!0),document.addEventListener("keydown",Pe,!0);for(const e of Ee)document.addEventListener(e,Le,!0)}}function re(){var e,t;if(!(!$&&!document.getElementById(z))){$=!1,O=null,document.documentElement.style.cursor=Ce,document.removeEventListener("pointerdown",Ie,!0),document.removeEventListener("pointermove",Te,!0),document.removeEventListener("pointerup",Me,!0),document.removeEventListener("keydown",Pe,!0);for(const n of Ee)document.removeEventListener(n,Le,!0);(e=document.getElementById(z))==null||e.remove(),(t=document.getElementById(H))==null||t.remove()}}function zt(){window===window.top&&x.runtime.onMessage.addListener(e=>{if(!e||typeof e!="object"||!("type"in e))return;const t=e.type;t==="region.arm"&&Ft(),t==="region.disarm"&&re()})}function Ht(e,t){return t==="panel"||t==="overlay"?t!==e:!0}function jt(e,t,n,o,i=48){const s=i-o.width,a=n.width-i,d=0,h=Math.max(0,n.height-i);return{left:Math.min(a,Math.max(s,e)),top:Math.min(h,Math.max(d,t))}}function qt(e,t,n=16){return{left:Math.max(n,e.width-t.width-n),top:Math.max(n,e.height-t.height-n)}}function Dt(e,t){const n=t.join(`
`).trim();n&&e.push({type:"p",text:n})}function Yt(e){const t=[];let n=[],o=[];function i(){o.length!==0&&(t.push({type:"ul",items:o}),o=[])}function s(){const a=n;n=[],Dt(t,a)}for(const a of e.split(`
`)){const d=a.match(/^(#{1,3})\s+(.*)$/),h=a.match(/^[-*]\s+(.*)$/);if(d){i(),s(),t.push({type:d[1].length===1?"h3":"h4",text:d[2]});continue}if(h){s(),o.push(h[1]);continue}if(!a.trim()){i(),s();continue}i(),n.push(a)}return i(),s(),t}function Wt(e,t){for(const n of Yt(t)){if(n.type==="ul"){const i=document.createElement("ul");for(const s of n.items){const a=document.createElement("li");a.textContent=s,i.appendChild(a)}e.appendChild(i);continue}const o=document.createElement(n.type);o.textContent=n.text,e.appendChild(o)}}function Xt(e){if(!e||typeof e!="object"||Array.isArray(e))return null;const t=e;return typeof t.left!="number"||typeof t.top!="number"||!Number.isFinite(t.left)||!Number.isFinite(t.top)?null:{left:t.left,top:t.top}}const $e=60;function Ut(e){const t=e.replace(/\*\*/g,"").trim(),n=e.match(/^\s*\*\*(.+?)\*\*/);if(n)return{short:n[1].replace(/\*\*/g,"").trim(),full:t,fromBold:!0};const o=t.indexOf(":");return o>0?{short:t.slice(0,o).trim(),full:t,fromBold:!1}:t.length>$e?{short:`${t.slice(0,$e)}…`,full:t,fromBold:!1}:{short:t,full:t,fromBold:!1}}function Re(e){return e.map(t=>{const n=Ut(t.label);return{id:t.id,short:n.short,full:n.full,checked:t.checked,bugged:t.bugged,notes:t.notes}})}const V={instructionsCollapsed:!0,checklistCollapsed:!1};function Vt(e){if(!e||typeof e!="object"||Array.isArray(e))return null;const t=e;return typeof t.instructionsCollapsed!="boolean"||typeof t.checklistCollapsed!="boolean"?null:{instructionsCollapsed:t.instructionsCollapsed,checklistCollapsed:t.checklistCollapsed}}const Gt=`
:host {
  all: initial;
  position: fixed;
  z-index: 2147483646;
  font-family: system-ui, sans-serif;
  color-scheme: dark;
  --bg-surface: #1b2230;
  --bg-elevated: #252e3d;
  --text-primary: #e8ecf4;
  --text-muted: #9aa6bc;
  --border: rgba(142, 160, 188, 0.18);
  --accent: #4862ce;
  --accent-contrast: #f7f8fc;
  --radius: 0.75rem;
  --type-body: 0.8125rem;
  --type-meta: 0.7rem;
  --type-section: 0.9rem;
}

@media (prefers-color-scheme: light) {
  :host {
    color-scheme: light;
    --bg-surface: #fbfcfe;
    --bg-elevated: #eef1f6;
    --text-primary: #1b2230;
    --text-muted: #5a6578;
    --border: rgba(46, 53, 69, 0.16);
    --accent: #3d52b8;
  }
}

*, *::before, *::after { box-sizing: border-box; }

.panel {
  width: min(420px, calc(100vw - 24px));
  max-height: min(70vh, 520px);
  display: flex;
  flex-direction: column;
  background: var(--bg-surface);
  color: var(--text-primary);
  border: 1px solid var(--border);
  border-radius: var(--radius);
  box-shadow: 0 12px 40px rgba(0, 0, 0, 0.35);
  overflow: hidden;
  font-size: var(--type-body);
  line-height: 1.4;
}

.panel.is-collapsed .body { display: none; }

.header {
  display: flex;
  align-items: flex-start;
  gap: 0.5rem;
  padding: 0.55rem 0.65rem;
  background: var(--bg-elevated);
  border-bottom: 1px solid var(--border);
  cursor: grab;
  touch-action: none;
  user-select: none;
}

.header:active { cursor: grabbing; }

.header-text {
  flex: 1;
  min-width: 0;
}

.display-id {
  margin: 0;
  font-size: var(--type-meta);
  color: var(--text-muted);
  font-weight: 600;
}

.title {
  margin: 0.1rem 0 0;
  font-size: var(--type-section);
  font-weight: 700;
  line-height: 1.25;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.header-actions {
  display: flex;
  gap: 0.25rem;
  flex-shrink: 0;
}

.icon-btn {
  appearance: none;
  border: 1px solid var(--border);
  background: transparent;
  color: var(--text-primary);
  border-radius: calc(var(--radius) - 0.25rem);
  width: 1.75rem;
  height: 1.75rem;
  font: inherit;
  font-size: 0.85rem;
  line-height: 1;
  cursor: pointer;
  padding: 0;
}

.icon-btn:hover { background: var(--bg-surface); }

.body {
  overflow: auto;
  padding: 0.5rem;
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

.hint {
  margin: 0;
  font-size: var(--type-meta);
  color: var(--text-muted);
}

.list {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
  gap: 0.375rem;
}

.row {
  border: 1px solid var(--border);
  border-radius: calc(var(--radius) - 0.2rem);
  background: var(--bg-elevated);
  padding: 0.375rem;
}

.row.is-bugged { border-color: rgba(220, 80, 80, 0.45); }

.row-main {
  display: flex;
  gap: 0.35rem;
  align-items: flex-start;
}

.tick {
  appearance: none;
  border: 0;
  background: transparent;
  color: var(--text-primary);
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 0.15rem;
  cursor: pointer;
  padding: 0.15rem;
  font: inherit;
  font-size: var(--type-meta);
  min-width: 2.5rem;
}

.tick-mark {
  width: 1.1rem;
  height: 1.1rem;
  border-radius: 999px;
  border: 2px solid var(--text-muted);
  display: block;
}

.tick.is-checked .tick-mark {
  border-color: var(--accent);
  background: var(--accent);
  box-shadow: inset 0 0 0 2px var(--bg-elevated);
}

.expand {
  appearance: none;
  border: 0;
  background: transparent;
  color: var(--text-primary);
  text-align: left;
  flex: 1;
  min-width: 0;
  cursor: pointer;
  font: inherit;
  padding: 0.15rem 0;
}

.expand strong { font-weight: 650; }

.row-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 0.25rem;
  margin-top: 0.35rem;
}

.btn {
  appearance: none;
  border: 1px solid var(--border);
  background: var(--bg-surface);
  color: var(--text-primary);
  border-radius: calc(var(--radius) - 0.25rem);
  font: inherit;
  font-size: var(--type-meta);
  font-weight: 600;
  padding: 0.3rem 0.5rem;
  cursor: pointer;
}

.btn-primary {
  background: var(--accent);
  border-color: var(--accent);
  color: var(--accent-contrast);
}

.btn:disabled {
  opacity: 0.45;
  cursor: not-allowed;
}

.bug-form {
  display: flex;
  flex-direction: column;
  gap: 0.35rem;
  margin-top: 0.35rem;
}

.bug-form label {
  display: flex;
  flex-direction: column;
  gap: 0.2rem;
  font-size: var(--type-meta);
  color: var(--text-muted);
}

.bug-form textarea {
  resize: vertical;
  min-height: 3.5rem;
  border: 1px solid var(--border);
  border-radius: calc(var(--radius) - 0.25rem);
  background: var(--bg-surface);
  color: var(--text-primary);
  font: inherit;
  padding: 0.35rem;
}

.warning {
  margin: 0;
  font-size: var(--type-meta);
  color: var(--text-muted);
}

.error {
  margin: 0;
  font-size: var(--type-meta);
  color: #e07070;
}

.notes {
  margin: 0.25rem 0 0;
  padding-left: 1rem;
  font-size: var(--type-meta);
  color: var(--text-muted);
}

.section {
  display: flex;
  flex-direction: column;
  gap: 0.35rem;
  min-width: 0;
}

.section-toggle {
  appearance: none;
  display: flex;
  align-items: baseline;
  gap: 0.4rem;
  width: 100%;
  margin: 0;
  padding: 0.25rem 0;
  border: 0;
  background: transparent;
  color: var(--text-muted);
  font: inherit;
  font-size: var(--type-meta);
  font-weight: 700;
  letter-spacing: 0.02em;
  text-transform: uppercase;
  text-align: left;
  cursor: pointer;
}

.section-progress {
  font-weight: 650;
  color: var(--text-primary);
  text-transform: none;
  letter-spacing: 0;
}

.help {
  display: flex;
  flex-direction: column;
  gap: 0.4rem;
  min-width: 0;
}

.help h3,
.help h4 {
  margin: 0;
  font-size: var(--type-body);
  font-weight: 650;
  color: var(--text-primary);
}

.help p,
.help li {
  margin: 0;
  font-size: var(--type-meta);
  color: var(--text-muted);
}

.help ul {
  margin: 0;
  padding-left: 1.1rem;
}
`,g={itemDone:"Feito",itemOpen:"A fazer",flagAsBug:"Marcar como bug",motivo:"Motivo",motivoPlaceholder:"Descreva o problema encontrado",cancelFlag:"Cancelar",taskBugWarning:"Este card volta para To Do, inclusive as subtarefas.",noChecklist:"Esta tarefa não tem checklist.",collapseOverlay:"Recolher",expandOverlay:"Expandir",closeFloatingChecklist:"Fechar checklist flutuante",overlayDragHint:"Arraste pelo cabeçalho",instructionsHeading:"Instruções",checklistHeading:"Checklist",checklistChanged:"A checklist mudou. Recarregue e tente de novo.",motivoRequired:"O motivo do bug é obrigatório.",itemMotivoRequired:"O motivo do bug do item é obrigatório.",apiError:"Não foi possível falar com a API. Tente de novo.",sessionExpired:"Sessão expirada. Entre de novo no Arc Todo.",signInFirst:"Entre no Arc Todo primeiro"};let A=null,T=null,r=null,N=null;function Kt(e){return e.status==="expired"?g.sessionExpired:e.status==="not_signed_in"?g.signInFirst:e.error==="stale"?g.checklistChanged:e.error==="motivo"?g.motivoRequired:e.error==="api"||e.status==="error"?g.apiError:null}function Zt(){const e=document.getElementById(R);if(e&&T&&A===e)return{host:e,shadow:T};e==null||e.remove();const t=document.createElement("div");t.id=R,t.setAttribute("aria-hidden","false"),Object.assign(t.style,{position:"fixed",zIndex:String(tt),left:"0px",top:"0px"});const n=t.attachShadow({mode:"open"}),o=document.createElement("style");return o.textContent=Gt,n.appendChild(o),document.documentElement.appendChild(t),A=t,T=n,{host:t,shadow:n}}async function Qt(){try{const e=await x.storage.local.get(Z);return Xt(e[Z])}catch{return null}}async function Jt(e,t){try{await x.storage.local.set({[Z]:{left:e,top:t}})}catch{}}async function en(){try{const e=await x.storage.local.get(Q);return Vt(e[Q])??V}catch{return V}}async function Oe(){if(r)try{await x.storage.local.set({[Q]:{instructionsCollapsed:r.instructionsCollapsed,checklistCollapsed:r.checklistCollapsed}})}catch{}}function oe(e,t){if(!A)return;const n=A.getBoundingClientRect(),o=jt(e,t,{width:window.innerWidth,height:window.innerHeight},{width:n.width||420,height:Math.min(n.height||48,48)});A.style.left=`${o.left}px`,A.style.top=`${o.top}px`}function Be(){if(!A)return;const e=Number.parseFloat(A.style.left||"0"),t=Number.parseFloat(A.style.top||"0");oe(e,t)}async function tn(){if(!A)return;const e=await Qt(),t={width:420,height:320},n=e??qt({width:window.innerWidth,height:window.innerHeight},t);oe(n.left,n.top)}function nn(e){if(!A||e.button!==0)return;const t=e.target;if(t!=null&&t.closest("button"))return;const n=Number.parseFloat(A.style.left||"0"),o=Number.parseFloat(A.style.top||"0");N={pointerId:e.pointerId,startX:e.clientX,startY:e.clientY,originLeft:n,originTop:o},e.currentTarget.setPointerCapture(e.pointerId),e.preventDefault()}function rn(e){!N||e.pointerId!==N.pointerId||oe(N.originLeft+(e.clientX-N.startX),N.originTop+(e.clientY-N.startY))}function _e(e){if(!N||e.pointerId!==N.pointerId||!A)return;N=null;const t=Number.parseFloat(A.style.left||"0"),n=Number.parseFloat(A.style.top||"0");Jt(t,n)}function b(){if(!T||!r)return;const e=T.querySelector(".panel");if(!e)return;e.classList.toggle("is-collapsed",r.collapsed);const t=T.querySelector(".title"),n=T.querySelector(".display-id");t&&(t.textContent=r.task.title),n&&(n.textContent=r.task.displayId);const o=T.querySelector('[data-action="collapse"]');o&&(o.setAttribute("aria-label",r.collapsed?g.expandOverlay:g.collapseOverlay),o.textContent=r.collapsed?"▸":"▾");const i=T.querySelector(".body");if(!i)return;if(i.replaceChildren(),r.error){const d=document.createElement("p");d.className="error",d.setAttribute("role","alert"),d.textContent=r.error,i.appendChild(d)}const s=document.createElement("p");s.className="hint",s.textContent=g.overlayDragHint,i.appendChild(s),r.helpMarkdown&&i.appendChild(sn(r.helpMarkdown));const a=Re(r.items);if(a.length===0){const d=document.createElement("p");d.className="hint",d.textContent=g.noChecklist,i.appendChild(d)}else i.appendChild(an(a.map(d=>d.id)));if(r.taskBugOpen)i.appendChild(cn());else{const d=document.createElement("button");d.type="button",d.className="btn",d.textContent=g.flagAsBug,d.disabled=r.busy,d.addEventListener("click",()=>{r&&(r.taskBugOpen=!0,r.taskNote="",r.error=null,b())}),i.appendChild(d)}}function on(e){const t=r.items.find(f=>f.id===e),n=document.createElement("li");n.className=t.bugged?"row is-bugged":"row";const o=document.createElement("div");o.className="row-main";const i=document.createElement("button");i.type="button",i.className=t.checked?"tick is-checked":"tick",i.setAttribute("aria-pressed",String(t.checked)),i.disabled=r.busy;const s=document.createElement("span");s.className="tick-mark",s.setAttribute("aria-hidden","true");const a=document.createElement("span");a.textContent=t.checked?g.itemDone:g.itemOpen,i.append(s,a),i.addEventListener("click",()=>{dn(t.id)});const d=Re([t])[0],h=document.createElement("button");h.type="button",h.className="expand";const v=r.expandedId===t.id;if(h.setAttribute("aria-expanded",String(v)),v)h.textContent=d.full;else{const f=document.createElement("strong");f.textContent=d.short,h.appendChild(f)}if(h.addEventListener("click",()=>{r&&(r.expandedId=r.expandedId===t.id?null:t.id,b())}),o.append(i,h),n.appendChild(o),t.notes.length){const f=document.createElement("ul");f.className="notes";for(const w of t.notes){const j=document.createElement("li");j.innerHTML="";const _=document.createElement("strong");_.textContent=`${g.motivo}: `,j.append(_,document.createTextNode(w)),f.appendChild(j)}n.appendChild(f)}if(r.reportingItemId===t.id)n.appendChild(ln(t.id));else{const f=document.createElement("div");f.className="row-actions";const w=document.createElement("button");w.type="button",w.className="btn",w.textContent=g.flagAsBug,w.disabled=r.busy,w.addEventListener("click",()=>{r&&(r.reportingItemId=t.id,r.itemNote="",r.error=null,b())}),f.appendChild(w),n.appendChild(f)}return n}function Fe(e,t,n,o){const i=document.createElement("button");i.type="button",i.className="section-toggle",i.setAttribute("aria-expanded",String(t));const s=document.createTextNode(e);if(i.appendChild(s),o){i.appendChild(document.createTextNode(" "));const a=document.createElement("span");a.className="section-progress",a.textContent=o,i.appendChild(a)}return i.addEventListener("click",n),i}function sn(e){const t=document.createElement("section");t.className="section";const n=!r.instructionsCollapsed;if(t.appendChild(Fe(g.instructionsHeading,n,()=>{r&&(r.instructionsCollapsed=!r.instructionsCollapsed,Oe(),b())})),n){const o=document.createElement("div");o.className="help",Wt(o,e),t.appendChild(o)}return t}function an(e){const t=document.createElement("section");t.className="section";const n=!r.checklistCollapsed,o=r.items.filter(i=>i.checked).length;if(t.appendChild(Fe(g.checklistHeading,n,()=>{r&&(r.checklistCollapsed=!r.checklistCollapsed,Oe(),b())},`${o}/${r.items.length}`)),n){const i=document.createElement("ul");i.className="list";for(const s of e)i.appendChild(on(s));t.appendChild(i)}return t}function ln(e){const t=document.createElement("div");t.className="bug-form";const n=document.createElement("label");n.textContent=g.motivo;const o=document.createElement("textarea");o.value=r.itemNote,o.placeholder=g.motivoPlaceholder,o.rows=3,o.addEventListener("input",()=>{r&&(r.itemNote=o.value,s.disabled=r.busy||!r.itemNote.trim())}),n.appendChild(o);const i=document.createElement("div");i.className="row-actions";const s=document.createElement("button");s.type="button",s.className="btn btn-primary",s.textContent=g.flagAsBug,s.disabled=r.busy||!r.itemNote.trim(),s.addEventListener("click",()=>{un(e)});const a=document.createElement("button");return a.type="button",a.className="btn",a.textContent=g.cancelFlag,a.addEventListener("click",()=>{r&&(r.reportingItemId=null,r.itemNote="",b())}),i.append(s,a),t.append(n,i),t}function cn(){const e=document.createElement("div");e.className="bug-form";const t=document.createElement("p");t.className="warning",t.textContent=g.taskBugWarning;const n=document.createElement("label");n.textContent=g.motivo;const o=document.createElement("textarea");o.value=r.taskNote,o.placeholder=g.motivoPlaceholder,o.rows=3,o.addEventListener("input",()=>{r&&(r.taskNote=o.value,s.disabled=r.busy||!r.taskNote.trim())}),n.appendChild(o);const i=document.createElement("div");i.className="row-actions";const s=document.createElement("button");s.type="button",s.className="btn btn-primary",s.textContent=g.flagAsBug,s.disabled=r.busy||!r.taskNote.trim(),s.addEventListener("click",()=>{mn()});const a=document.createElement("button");return a.type="button",a.className="btn",a.textContent=g.cancelFlag,a.addEventListener("click",()=>{r&&(r.taskBugOpen=!1,r.taskNote="",b())}),i.append(s,a),e.append(t,n,i),e}function G(e){if(!r)return!1;const t=Kt(e);return t?(r.error=t,!1):(r.error=null,e.items&&(r.items=e.items),e.snapshot&&(r.snapshot=e.snapshot),e.helpMarkdown!==void 0&&(r.helpMarkdown=e.helpMarkdown??null),!0)}async function ze(){if(r){r.busy=!0,b();try{const e=await x.runtime.sendMessage({type:"task.get",task:r.task});G(e)}finally{r&&(r.busy=!1),b()}}}async function dn(e){if(!(!r||r.busy)){r.busy=!0,r.error=null,b();try{const t=await x.runtime.sendMessage({type:"checklist.tick",task:r.task,itemId:e,snapshot:r.snapshot,source:"overlay"});G(t)}finally{r&&(r.busy=!1),b()}}}async function un(e){if(!(!r||r.busy)){if(!r.itemNote.trim()){r.error=g.itemMotivoRequired,b();return}r.busy=!0,r.error=null,b();try{const t=await x.runtime.sendMessage({type:"checklist.flagItem",task:r.task,itemId:e,note:r.itemNote,snapshot:r.snapshot,source:"overlay"});G(t)&&(r.reportingItemId=null,r.itemNote="")}finally{r&&(r.busy=!1),b()}}}async function mn(){if(!(!r||r.busy)){if(!r.taskNote.trim()){r.error=g.motivoRequired,b();return}r.busy=!0,r.error=null,b();try{const e=await x.runtime.sendMessage({type:"task.flag",task:r.task,note:r.taskNote,source:"overlay"});G(e)&&(r.taskBugOpen=!1,r.taskNote="")}finally{r&&(r.busy=!1),b()}}}function gn(){const{shadow:e}=Zt();if(e.querySelector(".panel"))return;const n=document.createElement("div");n.className="panel",n.setAttribute("role","dialog"),n.setAttribute("aria-label","Checklist");const o=document.createElement("div");o.className="header",o.addEventListener("pointerdown",nn),o.addEventListener("pointermove",rn),o.addEventListener("pointerup",_e),o.addEventListener("pointercancel",_e);const i=document.createElement("div");i.className="header-text";const s=document.createElement("p");s.className="display-id";const a=document.createElement("h2");a.className="title",i.append(s,a);const d=document.createElement("div");d.className="header-actions";const h=document.createElement("button");h.type="button",h.className="icon-btn",h.dataset.action="collapse",h.addEventListener("click",()=>{r&&(r.collapsed=!r.collapsed,b())});const v=document.createElement("button");v.type="button",v.className="icon-btn",v.setAttribute("aria-label",g.closeFloatingChecklist),v.textContent="×",v.addEventListener("click",()=>{He()}),d.append(h,v),o.append(i,d);const f=document.createElement("div");f.className="body",n.append(o,f),e.appendChild(n),window.addEventListener("resize",Be)}function pn(e){window===window.top&&(gn(),r={task:e,items:[],snapshot:{items:[]},expandedId:null,reportingItemId:null,itemNote:"",taskBugOpen:!1,taskNote:"",collapsed:!1,instructionsCollapsed:V.instructionsCollapsed,checklistCollapsed:V.checklistCollapsed,helpMarkdown:null,busy:!1,error:null},A&&(A.style.display="block"),b(),Promise.all([tn(),en()]).then(([,t])=>{r&&(r.instructionsCollapsed=t.instructionsCollapsed,r.checklistCollapsed=t.checklistCollapsed,b(),ze())}))}function He(){N=null,r=null,window.removeEventListener("resize",Be),A==null||A.remove(),A=null,T=null}function fn(){window===window.top&&x.runtime.onMessage.addListener(e=>{if(!e||typeof e!="object"||!("type"in e))return;const t=e.type;if(t==="overlay.open"){const n=e.task;n!=null&&n.id&&pn(n)}if(t==="overlay.close"&&He(),t==="qa.checklistChanged"){if(!r||e.taskId!==r.task.id||!Ht("overlay",e.source))return;ze()}})}const hn=".task-card[data-task-id], .task-list-row[data-task-id]",D="arc-todo-card-highlight";function An(e){return e.length===0?null:[...e].reverse().find(n=>!n.className.split(/\s+/).includes("is-subtask"))??e[0]}function xn(e){var a,d,h,v,f;const t=(a=e.taskId)==null?void 0:a.trim(),n=(d=e.displayId)==null?void 0:d.trim(),o=(h=e.organizationId)==null?void 0:h.trim(),i=(v=e.projectId)==null?void 0:v.trim(),s=((f=e.taskTitle)==null?void 0:f.trim())||n;return!t||!n||!s||!o||!i?null:{id:t,displayId:n,title:s,organizationId:o,projectId:i}}let B=!1,je="";function qe(e){let t=e.getElementById(D);return t||(t=e.createElement("div"),t.id=D,t.setAttribute("aria-hidden","true"),Object.assign(t.style,{position:"fixed",pointerEvents:"none",zIndex:"2147483647",outline:"2px solid #4862ce",outlineOffset:"2px",background:"rgba(72, 98, 206, 0.14)",borderRadius:"18px",boxSizing:"border-box",display:"none"}),e.documentElement.appendChild(t),t)}function bn(e){const t=[];let n=e;for(;n;){const o=n.closest(hn);if(!(o instanceof HTMLElement))break;t.push(o),n=o.parentElement}return t}function De(e,t,n){const o=e.elementFromPoint(t,n);return!o||o.id===D||o.id===R||o.closest(`#${R}`)?null:An(bn(o))}function yn(e,t){const n=qe(e);if(!t){n.style.display="none";return}const o=t.getBoundingClientRect();n.style.display="block",n.style.left=`${o.left}px`,n.style.top=`${o.top}px`,n.style.width=`${o.width}px`,n.style.height=`${o.height}px`}function Ye(e){B&&yn(document,De(document,e.clientX,e.clientY))}function We(e){if(!B)return;const t=De(document,e.clientX,e.clientY);if(!t)return;const n=xn({taskId:t.dataset.taskId,displayId:t.dataset.displayId,taskTitle:t.dataset.taskTitle,organizationId:t.dataset.organizationId,projectId:t.dataset.projectId});n&&(e.preventDefault(),e.stopPropagation(),e.stopImmediatePropagation(),ie(),x.runtime.sendMessage({type:"card.picked",task:n}))}function Xe(e){!B||e.key!=="Escape"||(e.preventDefault(),ie(),x.runtime.sendMessage({type:"card.cancelled"}))}function vn(){window===window.top&&(B||(B=!0,je=document.documentElement.style.cursor,document.documentElement.style.cursor="pointer",qe(document),document.addEventListener("mousemove",Ye,!0),document.addEventListener("click",We,!0),document.addEventListener("keydown",Xe,!0)))}function ie(){var e;!B&&!document.getElementById(D)||(B=!1,document.documentElement.style.cursor=je,document.removeEventListener("mousemove",Ye,!0),document.removeEventListener("click",We,!0),document.removeEventListener("keydown",Xe,!0),(e=document.getElementById(D))==null||e.remove())}function kn(){window===window.top&&x.runtime.onMessage.addListener(e=>{if(!e||typeof e!="object"||!("type"in e))return;const t=e.type;t==="card.arm"&&vn(),t==="card.disarm"&&ie()})}const Ue=window;function wn(e){return!!(e&&typeof e=="object"&&e.type==="content.ping")}x.runtime.onMessage.addListener(e=>{if(wn(e))return Promise.resolve(!0)}),Ue.__arcTodoContentReady||(Ue.__arcTodoContentReady=!0,window.addEventListener(et,e=>{const t=e.detail;typeof t=="string"&&x.runtime.sendMessage({type:"capture.console",payload:t})}),x.runtime.sendMessage({type:"capture.pageReady"}),St(),zt(),kn(),fn())})();
