(function(){"use strict";function nt(e){return e&&e.__esModule&&Object.prototype.hasOwnProperty.call(e,"default")?e.default:e}var V={exports:{}},rt=V.exports,de;function ot(){return de||(de=1,(function(e,t){(function(n,o){o(e)})(typeof globalThis<"u"?globalThis:typeof self<"u"?self:rt,function(n){if(!(globalThis.chrome&&globalThis.chrome.runtime&&globalThis.chrome.runtime.id))throw new Error("This script should only be loaded in a browser extension.");if(globalThis.browser&&globalThis.browser.runtime&&globalThis.browser.runtime.id)n.exports=globalThis.browser;else{const o="The message port closed before a response was received.",i=s=>{const a={alarms:{clear:{minArgs:0,maxArgs:1},clearAll:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getAll:{minArgs:0,maxArgs:0}},bookmarks:{create:{minArgs:1,maxArgs:1},get:{minArgs:1,maxArgs:1},getChildren:{minArgs:1,maxArgs:1},getRecent:{minArgs:1,maxArgs:1},getSubTree:{minArgs:1,maxArgs:1},getTree:{minArgs:0,maxArgs:0},move:{minArgs:2,maxArgs:2},remove:{minArgs:1,maxArgs:1},removeTree:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1},update:{minArgs:2,maxArgs:2}},browserAction:{disable:{minArgs:0,maxArgs:1,fallbackToNoCallback:!0},enable:{minArgs:0,maxArgs:1,fallbackToNoCallback:!0},getBadgeBackgroundColor:{minArgs:1,maxArgs:1},getBadgeText:{minArgs:1,maxArgs:1},getPopup:{minArgs:1,maxArgs:1},getTitle:{minArgs:1,maxArgs:1},openPopup:{minArgs:0,maxArgs:0},setBadgeBackgroundColor:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setBadgeText:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setIcon:{minArgs:1,maxArgs:1},setPopup:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setTitle:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},browsingData:{remove:{minArgs:2,maxArgs:2},removeCache:{minArgs:1,maxArgs:1},removeCookies:{minArgs:1,maxArgs:1},removeDownloads:{minArgs:1,maxArgs:1},removeFormData:{minArgs:1,maxArgs:1},removeHistory:{minArgs:1,maxArgs:1},removeLocalStorage:{minArgs:1,maxArgs:1},removePasswords:{minArgs:1,maxArgs:1},removePluginData:{minArgs:1,maxArgs:1},settings:{minArgs:0,maxArgs:0}},commands:{getAll:{minArgs:0,maxArgs:0}},contextMenus:{remove:{minArgs:1,maxArgs:1},removeAll:{minArgs:0,maxArgs:0},update:{minArgs:2,maxArgs:2}},cookies:{get:{minArgs:1,maxArgs:1},getAll:{minArgs:1,maxArgs:1},getAllCookieStores:{minArgs:0,maxArgs:0},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}},devtools:{inspectedWindow:{eval:{minArgs:1,maxArgs:2,singleCallbackArg:!1}},panels:{create:{minArgs:3,maxArgs:3,singleCallbackArg:!0},elements:{createSidebarPane:{minArgs:1,maxArgs:1}}}},downloads:{cancel:{minArgs:1,maxArgs:1},download:{minArgs:1,maxArgs:1},erase:{minArgs:1,maxArgs:1},getFileIcon:{minArgs:1,maxArgs:2},open:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},pause:{minArgs:1,maxArgs:1},removeFile:{minArgs:1,maxArgs:1},resume:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1},show:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},extension:{isAllowedFileSchemeAccess:{minArgs:0,maxArgs:0},isAllowedIncognitoAccess:{minArgs:0,maxArgs:0}},history:{addUrl:{minArgs:1,maxArgs:1},deleteAll:{minArgs:0,maxArgs:0},deleteRange:{minArgs:1,maxArgs:1},deleteUrl:{minArgs:1,maxArgs:1},getVisits:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1}},i18n:{detectLanguage:{minArgs:1,maxArgs:1},getAcceptLanguages:{minArgs:0,maxArgs:0}},identity:{launchWebAuthFlow:{minArgs:1,maxArgs:1}},idle:{queryState:{minArgs:1,maxArgs:1}},management:{get:{minArgs:1,maxArgs:1},getAll:{minArgs:0,maxArgs:0},getSelf:{minArgs:0,maxArgs:0},setEnabled:{minArgs:2,maxArgs:2},uninstallSelf:{minArgs:0,maxArgs:1}},notifications:{clear:{minArgs:1,maxArgs:1},create:{minArgs:1,maxArgs:2},getAll:{minArgs:0,maxArgs:0},getPermissionLevel:{minArgs:0,maxArgs:0},update:{minArgs:2,maxArgs:2}},pageAction:{getPopup:{minArgs:1,maxArgs:1},getTitle:{minArgs:1,maxArgs:1},hide:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setIcon:{minArgs:1,maxArgs:1},setPopup:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setTitle:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},show:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},permissions:{contains:{minArgs:1,maxArgs:1},getAll:{minArgs:0,maxArgs:0},remove:{minArgs:1,maxArgs:1},request:{minArgs:1,maxArgs:1}},runtime:{getBackgroundPage:{minArgs:0,maxArgs:0},getPlatformInfo:{minArgs:0,maxArgs:0},openOptionsPage:{minArgs:0,maxArgs:0},requestUpdateCheck:{minArgs:0,maxArgs:0},sendMessage:{minArgs:1,maxArgs:3},sendNativeMessage:{minArgs:2,maxArgs:2},setUninstallURL:{minArgs:1,maxArgs:1}},sessions:{getDevices:{minArgs:0,maxArgs:1},getRecentlyClosed:{minArgs:0,maxArgs:1},restore:{minArgs:0,maxArgs:1}},storage:{local:{clear:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}},managed:{get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1}},sync:{clear:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}}},tabs:{captureVisibleTab:{minArgs:0,maxArgs:2},create:{minArgs:1,maxArgs:1},detectLanguage:{minArgs:0,maxArgs:1},discard:{minArgs:0,maxArgs:1},duplicate:{minArgs:1,maxArgs:1},executeScript:{minArgs:1,maxArgs:2},get:{minArgs:1,maxArgs:1},getCurrent:{minArgs:0,maxArgs:0},getZoom:{minArgs:0,maxArgs:1},getZoomSettings:{minArgs:0,maxArgs:1},goBack:{minArgs:0,maxArgs:1},goForward:{minArgs:0,maxArgs:1},highlight:{minArgs:1,maxArgs:1},insertCSS:{minArgs:1,maxArgs:2},move:{minArgs:2,maxArgs:2},query:{minArgs:1,maxArgs:1},reload:{minArgs:0,maxArgs:2},remove:{minArgs:1,maxArgs:1},removeCSS:{minArgs:1,maxArgs:2},sendMessage:{minArgs:2,maxArgs:3},setZoom:{minArgs:1,maxArgs:2},setZoomSettings:{minArgs:1,maxArgs:2},update:{minArgs:1,maxArgs:2}},topSites:{get:{minArgs:0,maxArgs:0}},webNavigation:{getAllFrames:{minArgs:1,maxArgs:1},getFrame:{minArgs:1,maxArgs:1}},webRequest:{handlerBehaviorChanged:{minArgs:0,maxArgs:0}},windows:{create:{minArgs:0,maxArgs:1},get:{minArgs:1,maxArgs:2},getAll:{minArgs:0,maxArgs:1},getCurrent:{minArgs:0,maxArgs:1},getLastFocused:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},update:{minArgs:2,maxArgs:2}}};if(Object.keys(a).length===0)throw new Error("api-metadata.json has not been included in browser-polyfill");class c extends WeakMap{constructor(d,f=void 0){super(f),this.createItem=d}get(d){return this.has(d)||this.set(d,this.createItem(d)),super.get(d)}}const m=l=>l&&typeof l=="object"&&typeof l.then=="function",g=(l,d)=>(...f)=>{s.runtime.lastError?l.reject(new Error(s.runtime.lastError.message)):d.singleCallbackArg||f.length<=1&&d.singleCallbackArg!==!1?l.resolve(f[0]):l.resolve(f)},u=l=>l==1?"argument":"arguments",k=(l,d)=>function(x,...E){if(E.length<d.minArgs)throw new Error(`Expected at least ${d.minArgs} ${u(d.minArgs)} for ${l}(), got ${E.length}`);if(E.length>d.maxArgs)throw new Error(`Expected at most ${d.maxArgs} ${u(d.maxArgs)} for ${l}(), got ${E.length}`);return new Promise((C,I)=>{if(d.fallbackToNoCallback)try{x[l](...E,g({resolve:C,reject:I},d))}catch(p){console.warn(`${l} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `,p),x[l](...E),d.fallbackToNoCallback=!1,d.noCallback=!0,C()}else d.noCallback?(x[l](...E),C()):x[l](...E,g({resolve:C,reject:I},d))})},w=(l,d,f)=>new Proxy(d,{apply(x,E,C){return f.call(E,l,...C)}});let P=Function.call.bind(Object.prototype.hasOwnProperty);const H=(l,d={},f={})=>{let x=Object.create(null),E={has(I,p){return p in l||p in x},get(I,p,N){if(p in x)return x[p];if(!(p in l))return;let v=l[p];if(typeof v=="function")if(typeof d[p]=="function")v=w(l,l[p],d[p]);else if(P(f,p)){let j=k(p,f[p]);v=w(l,l[p],j)}else v=v.bind(l);else if(typeof v=="object"&&v!==null&&(P(d,p)||P(f,p)))v=H(v,d[p],f[p]);else if(P(f,"*"))v=H(v,d[p],f["*"]);else return Object.defineProperty(x,p,{configurable:!0,enumerable:!0,get(){return l[p]},set(j){l[p]=j}}),v;return x[p]=v,v},set(I,p,N,v){return p in x?x[p]=N:l[p]=N,!0},defineProperty(I,p,N){return Reflect.defineProperty(x,p,N)},deleteProperty(I,p){return Reflect.deleteProperty(x,p)}},C=Object.create(l);return new Proxy(C,E)},O=l=>({addListener(d,f,...x){d.addListener(l.get(f),...x)},hasListener(d,f){return d.hasListener(l.get(f))},removeListener(d,f){d.removeListener(l.get(f))}}),zn=new c(l=>typeof l!="function"?l:function(f){const x=H(f,{},{getContent:{minArgs:0,maxArgs:0}});l(x)}),et=new c(l=>typeof l!="function"?l:function(f,x,E){let C=!1,I,p=new Promise(X=>{I=function($){C=!0,X($)}}),N;try{N=l(f,x,I)}catch(X){N=Promise.reject(X)}const v=N!==!0&&m(N);if(N!==!0&&!v&&!C)return!1;const j=X=>{X.then($=>{E($)},$=>{let ce;$&&($ instanceof Error||typeof $.message=="string")?ce=$.message:ce="An unexpected error occurred",E({__mozWebExtensionPolyfillReject__:!0,message:ce})}).catch($=>{console.error("Failed to send onMessage rejected reply",$)})};return j(v?N:p),!0}),Hn=({reject:l,resolve:d},f)=>{s.runtime.lastError?s.runtime.lastError.message===o?d():l(new Error(s.runtime.lastError.message)):f&&f.__mozWebExtensionPolyfillReject__?l(new Error(f.message)):d(f)},tt=(l,d,f,...x)=>{if(x.length<d.minArgs)throw new Error(`Expected at least ${d.minArgs} ${u(d.minArgs)} for ${l}(), got ${x.length}`);if(x.length>d.maxArgs)throw new Error(`Expected at most ${d.maxArgs} ${u(d.maxArgs)} for ${l}(), got ${x.length}`);return new Promise((E,C)=>{const I=Hn.bind(null,{resolve:E,reject:C});x.push(I),f.sendMessage(...x)})},qn={devtools:{network:{onRequestFinished:O(zn)}},runtime:{onMessage:O(et),onMessageExternal:O(et),sendMessage:tt.bind(null,"sendMessage",{minArgs:1,maxArgs:3})},tabs:{sendMessage:tt.bind(null,"sendMessage",{minArgs:2,maxArgs:3})}},le={clear:{minArgs:1,maxArgs:1},get:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}};return a.privacy={network:{"*":le},services:{"*":le},websites:{"*":le}},H(s,qn,a)};n.exports=i(chrome)}})})(V)),V.exports}var it=ot();const y=nt(it),ue="arc-todo-agent-overlay",me="arc-todo-agent-cursor",pe="arc-todo-agent-stop";function Q(){return document.getElementById(ue)}function st(e,t){var i;let n=Q();if(!n){n=document.createElement("div"),n.id=ue,n.setAttribute("data-arc-todo-agent","1");const s=n.attachShadow({mode:"open"}),a=document.createElement("style");a.textContent=`
      :host { all: initial; }
      .wrap {
        position: fixed; inset: 0; pointer-events: none; z-index: 2147483646;
      }
      .cursor {
        position: absolute; width: 22px; height: 22px; margin: -2px 0 0 -2px;
        filter: drop-shadow(0 0 6px var(--glow));
        transition: transform 80ms linear;
      }
      .stop {
        pointer-events: auto; position: fixed; top: 12px; right: 12px;
        font: 600 12px system-ui, sans-serif; color: #f7f8fc;
        background: #3d52b8; border: 0; border-radius: 6px; padding: 6px 10px;
        box-shadow: 0 0 16px var(--glow); cursor: pointer;
      }
    `;const c=document.createElement("div");c.className="wrap";const m=document.createElement("div");m.id=me,m.className="cursor",m.innerHTML='<svg viewBox="0 0 24 24" width="22" height="22" xmlns="http://www.w3.org/2000/svg"><path d="M4 2l16 12-7 1 4 8-4 1-4-8-5 4z" fill="#e8ecf4" stroke="#3d52b8" stroke-width="1.2"/></svg>';const g=document.createElement("button");g.id=pe,g.className="stop",g.type="button",g.textContent="Stop",c.append(m,g),s.append(a,c),document.documentElement.append(n),g.addEventListener("click",()=>{y.runtime.sendMessage({type:"agent.stop"})})}n.style.setProperty("--glow",e);const o=(i=n.shadowRoot)==null?void 0:i.getElementById(pe);return o&&o.setAttribute("title",`Arc AI · ${t}`),n}function at(e){var o,i;if(e.type==="agent.overlay.hide"){(o=Q())==null||o.remove();return}if(e.type==="agent.overlay.show"){st(e.color,e.clientName);return}const t=Q(),n=(i=t==null?void 0:t.shadowRoot)==null?void 0:i.getElementById(me);n&&(n.style.transform=`translate(${e.x}px, ${e.y}px)`)}function lt(){y.runtime.onMessage.addListener(e=>{if(!e||typeof e!="object")return;const t=e.type;if(t==="agent.overlay.show"||t==="agent.overlay.hide"||t==="agent.overlay.move")return at(e),Promise.resolve(!0)})}const ct="arc-todo-capture",_="arc-todo-qa-overlay",dt=2147483645,J="arcTodo.overlayPosition",ee="arcTodo.overlaySections";function ut(e,t,n,o,i,s){const a=Math.max(0,Math.min(e,n)),c=Math.max(0,Math.min(t,o)),m=Math.min(i,Math.max(e,n)),g=Math.min(s,Math.max(t,o)),u=m-a,k=g-c;return u<4||k<4?null:{x:a,y:c,width:u,height:k}}function mt(e,t,n,o,i){const s=ut(e,t,n,o,i.width,i.height);return s?{rect:s,viewport:i}:null}const D="arc-todo-region-overlay",W="arc-todo-region-marquee",ge=["pointerdown","mousedown","mouseup","auxclick","contextmenu","dblclick"];let B=!1,fe="",F=null;function pt(){return{position:"fixed",inset:"0",zIndex:"2147483646",cursor:"crosshair",background:"rgba(0, 0, 0, 0.35)",boxSizing:"border-box"}}function gt(){return{position:"fixed",pointerEvents:"none",zIndex:"2147483646",outline:"2px solid #ffffff",outlineOffset:"0",boxShadow:"0 0 0 99999px rgba(0, 0, 0, 0.35)",boxSizing:"border-box",display:"none",background:"transparent"}}function ft(e){let t=e.getElementById(D);return t||(t=e.createElement("div"),t.id=D,t.setAttribute("aria-hidden","true"),Object.assign(t.style,pt()),e.documentElement.appendChild(t),t)}function he(e){let t=e.getElementById(W);return t||(t=e.createElement("div"),t.id=W,t.setAttribute("aria-hidden","true"),Object.assign(t.style,gt()),e.documentElement.appendChild(t),t)}function ht(e){return e?e.id===_?!0:!!e.closest(`#${_}`):!1}function xt(e,t,n){const o=e.getElementById(D),i=e.getElementById(W);o&&(o.style.pointerEvents="none"),i&&(i.style.pointerEvents="none");const s=e.elementFromPoint(t,n);return o&&(o.style.pointerEvents="auto"),s}function xe(e){B&&(e.preventDefault(),e.stopPropagation(),e.stopImmediatePropagation())}function yt(e,t,n,o){const i=Math.min(e,n),s=Math.min(t,o),a=he(document);a.style.display="block",a.style.left=`${i}px`,a.style.top=`${s}px`,a.style.width=`${Math.abs(n-e)}px`,a.style.height=`${Math.abs(o-t)}px`}function ye(){const e=document.getElementById(W);e&&(e.style.display="none")}function bt(){return{width:window.innerWidth,height:window.innerHeight}}function be(e){if(!B||e.button!==0)return;const t=xt(document,e.clientX,e.clientY);ht(t)||(F={x:e.clientX,y:e.clientY},ye())}function Ae(e){!B||!F||yt(F.x,F.y,e.clientX,e.clientY)}function ve(e){if(!B||!F)return;const t=F;F=null;const n=mt(t.x,t.y,e.clientX,e.clientY,bt());ye(),n&&(y.runtime.sendMessage({type:"region.picked",rect:n.rect,viewport:n.viewport,devicePixelRatio:window.devicePixelRatio}),te())}function ke(e){!B||e.key!=="Escape"||(e.preventDefault(),te(),y.runtime.sendMessage({type:"region.cancelled"}))}function At(){if(window===window.top&&!B){B=!0,fe=document.documentElement.style.cursor,document.documentElement.style.cursor="crosshair",ft(document),he(document),document.addEventListener("pointerdown",be,!0),document.addEventListener("pointermove",Ae,!0),document.addEventListener("pointerup",ve,!0),document.addEventListener("keydown",ke,!0);for(const e of ge)document.addEventListener(e,xe,!0)}}function te(){var e,t;if(!(!B&&!document.getElementById(D))){B=!1,F=null,document.documentElement.style.cursor=fe,document.removeEventListener("pointerdown",be,!0),document.removeEventListener("pointermove",Ae,!0),document.removeEventListener("pointerup",ve,!0),document.removeEventListener("keydown",ke,!0);for(const n of ge)document.removeEventListener(n,xe,!0);(e=document.getElementById(D))==null||e.remove(),(t=document.getElementById(W))==null||t.remove()}}function vt(){window===window.top&&y.runtime.onMessage.addListener(e=>{if(!e||typeof e!="object"||!("type"in e))return;const t=e.type;t==="region.arm"&&At(),t==="region.disarm"&&te()})}function kt(e){var t;return((t=e.find(n=>!n.checked))==null?void 0:t.id)??null}function wt(e,t){var i;const n=e.findIndex(s=>s.id===t);return((i=(n>=0?e.slice(n+1):e).find(s=>!s.checked))==null?void 0:i.id)??kt(e)}function Et(e,t){if(t&&e.some(n=>n.id===t))return t}function Ct(e,t){return t==="panel"||t==="overlay"?t!==e:!0}function It(e,t,n,o,i=48){const s=i-o.width,a=n.width-i,c=0,m=Math.max(0,n.height-i);return{left:Math.min(a,Math.max(s,e)),top:Math.min(m,Math.max(c,t))}}function Nt(e,t,n=16){return{left:Math.max(n,e.width-t.width-n),top:Math.max(n,e.height-t.height-n)}}const we=/(\*\*[^*]+\*\*|\*[^*]+\*|`[^`]+`|\[[^\]]+\]\(https?:\/\/[^)\s]+\)|https?:\/\/[^\s<>"'`]+)/g;function St(e){const t=[];let n=0;we.lastIndex=0;let o;for(;o=we.exec(e);){o.index>n&&t.push({type:"text",text:e.slice(n,o.index)});const i=o[0];if(i.startsWith("**"))t.push({type:"strong",text:i.slice(2,-2)});else if(i.startsWith("*"))t.push({type:"em",text:i.slice(1,-1)});else if(i.startsWith("`"))t.push({type:"code",text:i.slice(1,-1)});else if(i.startsWith("[")){const s=i.match(/^\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)$/);s&&t.push({type:"a",text:s[1],href:s[2]})}else{const s=i.replace(/[),.;:!?]+$/,""),a=i.slice(s.length);s&&t.push({type:"a",text:s,href:s}),a&&t.push({type:"text",text:a})}n=o.index+i.length}return n<e.length&&t.push({type:"text",text:e.slice(n)}),t.length>0?t:[{type:"text",text:e}]}function Lt(e,t){const n=t.join(`
`).trim();n&&e.push({type:"p",text:n})}function Mt(e){return`h${Math.min(e.length,4)}`}function Tt(e){const t=[];let n=[],o=[],i=[],s=null;function a(){o.length!==0&&(t.push({type:"ul",items:o}),o=[])}function c(){i.length!==0&&(t.push({type:"ol",items:i}),i=[])}function m(){const u=n;n=[],Lt(t,u)}function g(){a(),c()}for(const u of e.split(`
`)){if(s){u.startsWith("```")?(t.push({type:"pre",text:s.join(`
`)}),s=null):s.push(u);continue}if(u.startsWith("```")){g(),m(),s=[];continue}if(/^(-{3,}|\*{3,}|_{3,})\s*$/.test(u.trim())){g(),m(),t.push({type:"hr"});continue}const k=u.match(/^>\s?(.*)$/);if(k){g(),m();const O=t[t.length-1];(O==null?void 0:O.type)==="blockquote"?O.text=`${O.text}
${k[1]}`:t.push({type:"blockquote",text:k[1]});continue}const w=u.match(/^(#{1,4})\s+(.*)$/),P=u.match(/^[-*]\s+(.*)$/),H=u.match(/^\d+\.\s+(.*)$/);if(w){g(),m(),t.push({type:Mt(w[1]),text:w[2]});continue}if(P){c(),m(),o.push(P[1]);continue}if(H){a(),m(),i.push(H[1]);continue}if(!u.trim()){g(),m();continue}g(),n.push(u)}return s&&t.push({type:"pre",text:s.join(`
`)}),g(),m(),t}function ne(e,t){for(const n of St(t)){if(n.type==="text"){e.appendChild(document.createTextNode(n.text));continue}if(n.type==="a"){const i=document.createElement("a");i.href=n.href,i.target="_blank",i.rel="noopener noreferrer",i.textContent=n.text,e.appendChild(i);continue}const o=document.createElement(n.type==="strong"?"strong":n.type==="em"?"em":"code");o.textContent=n.text,e.appendChild(o)}}function Pt(e,t){for(const n of Tt(t)){if(n.type==="ul"||n.type==="ol"){const i=document.createElement(n.type);for(const s of n.items){const a=document.createElement("li");ne(a,s),i.appendChild(a)}e.appendChild(i);continue}if(n.type==="pre"){const i=document.createElement("pre"),s=document.createElement("code");s.textContent=n.text,i.appendChild(s),e.appendChild(i);continue}if(n.type==="hr"){e.appendChild(document.createElement("hr"));continue}if(n.type==="blockquote"){const i=document.createElement("blockquote");ne(i,n.text),e.appendChild(i);continue}const o=document.createElement(n.type);ne(o,n.text),e.appendChild(o)}}function $t(e){if(!e||typeof e!="object"||Array.isArray(e))return null;const t=e;return typeof t.left!="number"||typeof t.top!="number"||!Number.isFinite(t.left)||!Number.isFinite(t.top)?null:{left:t.left,top:t.top}}const Ee=60;function Bt(e){const t=e.replace(/\*\*/g,"").trim(),n=e.match(/^\s*\*\*(.+?)\*\*/);if(n)return{short:n[1].replace(/\*\*/g,"").trim(),full:t,fromBold:!0};const o=t.indexOf(":");return o>0?{short:t.slice(0,o).trim(),full:t,fromBold:!1}:t.length>Ee?{short:`${t.slice(0,Ee)}…`,full:t,fromBold:!1}:{short:t,full:t,fromBold:!1}}function Ce(e){return e.map(t=>{const n=Bt(t.label);return{id:t.id,short:n.short,full:n.full,checked:t.checked,bugged:t.bugged,notes:t.notes}})}const G={instructionsCollapsed:!1,checklistCollapsed:!1};function Rt(e){if(!e||typeof e!="object"||Array.isArray(e))return null;const t=e;return typeof t.instructionsCollapsed!="boolean"||typeof t.checklistCollapsed!="boolean"?null:{instructionsCollapsed:t.instructionsCollapsed,checklistCollapsed:t.checklistCollapsed}}const Ot=`
:host {
  all: initial;
  position: fixed;
  z-index: 2147483645;
  font-family: system-ui, sans-serif;
  color-scheme: dark;
  --bg-surface: #1b2230;
  --bg-elevated: #252e3d;
  --text-primary: #e8ecf4;
  --text-muted: #9aa6bc;
  --border: rgba(142, 160, 188, 0.18);
  --accent: #4862ce;
  --accent-contrast: #f7f8fc;
  --radius: 0.75rem;
  --type-body: 0.8125rem;
  --type-meta: 0.7rem;
  --type-section: 0.9rem;
}

@media (prefers-color-scheme: light) {
  :host {
    color-scheme: light;
    --bg-surface: #fbfcfe;
    --bg-elevated: #eef1f6;
    --text-primary: #1b2230;
    --text-muted: #5a6578;
    --border: rgba(46, 53, 69, 0.16);
    --accent: #3d52b8;
  }
}

*, *::before, *::after { box-sizing: border-box; }

.panel {
  width: min(420px, calc(100vw - 24px));
  max-height: min(70vh, 520px);
  display: flex;
  flex-direction: column;
  background: var(--bg-surface);
  color: var(--text-primary);
  border: 1px solid var(--border);
  border-radius: var(--radius);
  box-shadow: 0 12px 40px rgba(0, 0, 0, 0.35);
  overflow: hidden;
  font-size: var(--type-body);
  line-height: 1.4;
}

.panel.is-collapsed .body { display: none; }

.header {
  display: flex;
  align-items: flex-start;
  gap: 0.5rem;
  padding: 0.55rem 0.65rem;
  background: var(--bg-elevated);
  border-bottom: 1px solid var(--border);
  cursor: grab;
  touch-action: none;
  user-select: none;
}

.header:active { cursor: grabbing; }

.header-text {
  flex: 1;
  min-width: 0;
}

.display-id {
  margin: 0;
  font-size: var(--type-meta);
  color: var(--text-muted);
  font-weight: 600;
}

.title {
  margin: 0.1rem 0 0;
  font-size: var(--type-section);
  font-weight: 700;
  line-height: 1.25;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.header-actions {
  display: flex;
  gap: 0.25rem;
  flex-shrink: 0;
}

.icon-btn {
  appearance: none;
  border: 1px solid var(--border);
  background: transparent;
  color: var(--text-primary);
  border-radius: calc(var(--radius) - 0.25rem);
  width: 1.75rem;
  height: 1.75rem;
  font: inherit;
  font-size: 0.85rem;
  line-height: 1;
  cursor: pointer;
  padding: 0;
}

.icon-btn:hover { background: var(--bg-surface); }

.body {
  overflow: auto;
  padding: 0.5rem;
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

.hint {
  margin: 0;
  font-size: var(--type-meta);
  color: var(--text-muted);
}

.list {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
  gap: 0.375rem;
}

.row {
  border: 1px solid var(--border);
  border-radius: calc(var(--radius) - 0.2rem);
  background: var(--bg-elevated);
  padding: 0.375rem;
}

.row.is-bugged { border-color: rgba(220, 80, 80, 0.45); }
.row.is-current { border-color: var(--accent); }

.row-main {
  display: flex;
  gap: 0.35rem;
  align-items: center;
}

.tick {
  appearance: none;
  border: 0;
  background: transparent;
  color: var(--text-primary);
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  padding: 0.1rem;
  font: inherit;
  min-width: 1.4rem;
}

.tick-mark {
  width: 1.1rem;
  height: 1.1rem;
  border-radius: 999px;
  border: 2px solid var(--text-muted);
  display: block;
}

.tick.is-checked .tick-mark {
  border-color: var(--accent);
  background: var(--accent);
  box-shadow: inset 0 0 0 2px var(--bg-elevated);
}

.expand {
  appearance: none;
  border: 0;
  background: transparent;
  color: var(--text-primary);
  text-align: left;
  flex: 1;
  min-width: 0;
  cursor: pointer;
  font: inherit;
  padding: 0.15rem 0;
}

.expand strong { font-weight: 650; }

.row-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 0.25rem;
  margin-top: 0.35rem;
}

.btn {
  appearance: none;
  border: 1px solid var(--border);
  background: var(--bg-surface);
  color: var(--text-primary);
  border-radius: calc(var(--radius) - 0.25rem);
  font: inherit;
  font-size: var(--type-meta);
  font-weight: 600;
  padding: 0.3rem 0.5rem;
  cursor: pointer;
}

.btn-primary {
  background: var(--accent);
  border-color: var(--accent);
  color: var(--accent-contrast);
}

.btn:disabled {
  opacity: 0.45;
  cursor: not-allowed;
}

.bug-form {
  display: flex;
  flex-direction: column;
  gap: 0.35rem;
  margin-top: 0.35rem;
}

.bug-form label {
  display: flex;
  flex-direction: column;
  gap: 0.2rem;
  font-size: var(--type-meta);
  color: var(--text-muted);
}

.bug-form textarea {
  resize: vertical;
  min-height: 3.5rem;
  border: 1px solid var(--border);
  border-radius: calc(var(--radius) - 0.25rem);
  background: var(--bg-surface);
  color: var(--text-primary);
  font: inherit;
  padding: 0.35rem;
}

.warning {
  margin: 0;
  font-size: var(--type-meta);
  color: var(--text-muted);
}

.error {
  margin: 0;
  font-size: var(--type-meta);
  color: #e07070;
}

.notes {
  margin: 0.25rem 0 0;
  padding-left: 1rem;
  font-size: var(--type-meta);
  color: var(--text-muted);
}

.section {
  display: flex;
  flex-direction: column;
  gap: 0.35rem;
  min-width: 0;
}

.section-toggle {
  appearance: none;
  display: flex;
  align-items: baseline;
  gap: 0.4rem;
  width: 100%;
  margin: 0;
  padding: 0.25rem 0;
  border: 0;
  background: transparent;
  color: var(--text-muted);
  font: inherit;
  font-size: var(--type-meta);
  font-weight: 700;
  letter-spacing: 0.02em;
  text-transform: uppercase;
  text-align: left;
  cursor: pointer;
}

.section-progress {
  font-weight: 650;
  color: var(--text-primary);
  text-transform: none;
  letter-spacing: 0;
}

.help {
  display: flex;
  flex-direction: column;
  gap: 0.4rem;
  min-width: 0;
}

.help p,
.help li {
  margin: 0;
  font-size: var(--type-meta);
  color: var(--text-muted);
}

.help ul,
.help ol {
  margin: 0;
  padding-left: 1.1rem;
}

.help h1,
.help h2,
.help h3,
.help h4 {
  margin: 0;
  font-size: var(--type-body);
  font-weight: 650;
  color: var(--text-primary);
}

.help strong { font-weight: 700; color: var(--text-primary); }
.help em { font-style: italic; }
.help code {
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  font-size: 0.88em;
  padding: 0.05em 0.3em;
  border-radius: 4px;
  border: 1px solid var(--border);
}
.help a { color: var(--accent); }
.help pre {
  margin: 0;
  padding: 0.45rem 0.55rem;
  overflow-x: auto;
  border: 1px solid var(--border);
  border-radius: 0.35rem;
  font-size: var(--type-meta);
}
.help pre code { padding: 0; border: none; }
.help hr {
  width: 100%;
  border: none;
  border-top: 1px solid var(--border);
  margin: 0.2rem 0;
}
.help blockquote {
  margin: 0;
  padding: 0.15rem 0 0.15rem 0.6rem;
  border-left: 2px solid var(--border);
  color: var(--text-muted);
}
`,h={itemDone:"Feito",itemOpen:"A fazer",flagAsBug:"Marcar como bug",solveBug:"Marcar como resolvido",solveItem:"Resolvido",motivo:"Motivo",motivoPlaceholder:"Descreva o problema encontrado",cancelFlag:"Cancelar",taskBugWarning:"Este card volta para To Do, inclusive as subtarefas.",noChecklist:"Esta tarefa não tem checklist.",collapseOverlay:"Recolher",expandOverlay:"Expandir",closeFloatingChecklist:"Fechar checklist flutuante",overlayDragHint:"Arraste pelo cabeçalho",instructionsHeading:"Instruções",checklistHeading:"Checklist",checklistChanged:"A checklist mudou. Recarregue e tente de novo.",motivoRequired:"O motivo do bug é obrigatório.",itemMotivoRequired:"O motivo do bug do item é obrigatório.",apiError:"Não foi possível falar com a API. Tente de novo.",sessionExpired:"Sessão expirada. Entre de novo no Arc Todo.",signInFirst:"Entre no Arc Todo primeiro"};let A=null,M=null,r=null,S=null;function _t(e){return e.status==="expired"?h.sessionExpired:e.status==="not_signed_in"?h.signInFirst:e.error==="stale"?h.checklistChanged:e.error==="motivo"?h.motivoRequired:e.error==="api"||e.status==="error"?h.apiError:null}function Ft(){const e=document.getElementById(_);if(e&&M&&A===e)return{host:e,shadow:M};e==null||e.remove();const t=document.createElement("div");t.id=_,t.setAttribute("aria-hidden","false"),Object.assign(t.style,{position:"fixed",zIndex:String(dt),left:"0px",top:"0px"});const n=t.attachShadow({mode:"open"}),o=document.createElement("style");return o.textContent=Ot,n.appendChild(o),document.documentElement.appendChild(t),A=t,M=n,{host:t,shadow:n}}async function zt(){try{const e=await y.storage.local.get(J);return $t(e[J])}catch{return null}}async function Ht(e,t){try{await y.storage.local.set({[J]:{left:e,top:t}})}catch{}}async function qt(){try{const e=await y.storage.local.get(ee);return Rt(e[ee])??G}catch{return G}}async function Ie(){if(r)try{await y.storage.local.set({[ee]:{instructionsCollapsed:r.instructionsCollapsed,checklistCollapsed:r.checklistCollapsed}})}catch{}}function re(e,t){if(!A)return;const n=A.getBoundingClientRect(),o=It(e,t,{width:window.innerWidth,height:window.innerHeight},{width:n.width||420,height:Math.min(n.height||48,48)});A.style.left=`${o.left}px`,A.style.top=`${o.top}px`}function Ne(){if(!A)return;const e=Number.parseFloat(A.style.left||"0"),t=Number.parseFloat(A.style.top||"0");re(e,t)}async function jt(){if(!A)return;const e=await zt(),t={width:420,height:320},n=e??Nt({width:window.innerWidth,height:window.innerHeight},t);re(n.left,n.top)}function Dt(e){if(!A||e.button!==0)return;const t=e.target;if(t!=null&&t.closest("button"))return;const n=Number.parseFloat(A.style.left||"0"),o=Number.parseFloat(A.style.top||"0");S={pointerId:e.pointerId,startX:e.clientX,startY:e.clientY,originLeft:n,originTop:o},e.currentTarget.setPointerCapture(e.pointerId),e.preventDefault()}function Wt(e){!S||e.pointerId!==S.pointerId||re(S.originLeft+(e.clientX-S.startX),S.originTop+(e.clientY-S.startY))}function Se(e){if(!S||e.pointerId!==S.pointerId||!A)return;S=null;const t=Number.parseFloat(A.style.left||"0"),n=Number.parseFloat(A.style.top||"0");Ht(t,n)}function b(){if(!M||!r)return;const e=M.querySelector(".panel");if(!e)return;e.classList.toggle("is-collapsed",r.collapsed);const t=M.querySelector(".title"),n=M.querySelector(".display-id");t&&(t.textContent=r.task.title),n&&(n.textContent=r.task.displayId);const o=M.querySelector('[data-action="collapse"]');o&&(o.setAttribute("aria-label",r.collapsed?h.expandOverlay:h.collapseOverlay),o.textContent=r.collapsed?"▸":"▾");const i=M.querySelector(".body");if(!i)return;if(i.replaceChildren(),r.error){const c=document.createElement("p");c.className="error",c.setAttribute("role","alert"),c.textContent=r.error,i.appendChild(c)}const s=document.createElement("p");s.className="hint",s.textContent=h.overlayDragHint,i.appendChild(s),r.helpMarkdown&&i.appendChild(Ut(r.helpMarkdown));const a=Ce(r.items);if(a.length===0){const c=document.createElement("p");c.className="hint",c.textContent=h.noChecklist,i.appendChild(c)}else i.appendChild(Xt(a.map(c=>c.id)));if(r.taskBugOpen)i.appendChild(Gt());else if(r.isBug){const c=document.createElement("button");c.type="button",c.className="btn",c.textContent=h.solveBug,c.disabled=r.busy,c.addEventListener("click",()=>{en()}),i.appendChild(c)}else{const c=document.createElement("button");c.type="button",c.className="btn",c.textContent=h.flagAsBug,c.disabled=r.busy,c.addEventListener("click",()=>{r&&(r.taskBugOpen=!0,r.taskNote="",r.error=null,b())}),i.appendChild(c)}}function Yt(e){const t=r.items.find(u=>u.id===e),n=document.createElement("li"),o=Et(r.items,r.expandedId);n.className=["row",t.bugged?"is-bugged":"",t.id===o?"is-current":""].filter(Boolean).join(" ");const i=document.createElement("div");i.className="row-main";const s=document.createElement("button");s.type="button",s.className=t.checked?"tick is-checked":"tick",s.setAttribute("aria-pressed",String(t.checked)),s.setAttribute("aria-label",t.checked?h.itemDone:h.itemOpen),s.disabled=r.busy;const a=document.createElement("span");a.className="tick-mark",a.setAttribute("aria-hidden","true"),s.append(a),s.addEventListener("click",()=>{Kt(t.id)});const c=Ce([t])[0],m=document.createElement("button");m.type="button",m.className="expand";const g=r.expandedId===t.id;if(m.setAttribute("aria-expanded",String(g)),g)m.textContent=c.full;else{const u=document.createElement("strong");u.textContent=c.short,m.appendChild(u)}if(m.addEventListener("click",()=>{r&&(r.expandedId=r.expandedId===t.id?null:t.id,b())}),i.append(s,m),n.appendChild(i),t.notes.length){const u=document.createElement("ul");u.className="notes";for(const k of t.notes){const w=document.createElement("li");w.innerHTML="";const P=document.createElement("strong");P.textContent=`${h.motivo}: `,w.append(P,document.createTextNode(k)),u.appendChild(w)}n.appendChild(u)}if(r.reportingItemId===t.id)n.appendChild(Vt(t.id));else if(g){const u=document.createElement("div");u.className="row-actions";const k=document.createElement("button");if(k.type="button",k.className="btn",k.textContent=h.flagAsBug,k.disabled=r.busy,k.addEventListener("click",()=>{r&&(r.reportingItemId=t.id,r.itemNote="",r.error=null,b())}),u.appendChild(k),t.bugged){const w=document.createElement("button");w.type="button",w.className="btn",w.textContent=h.solveItem,w.disabled=r.busy,w.addEventListener("click",()=>{Jt(t.id)}),u.appendChild(w)}n.appendChild(u)}return n}function Le(e,t,n,o){const i=document.createElement("button");i.type="button",i.className="section-toggle",i.setAttribute("aria-expanded",String(t));const s=document.createTextNode(e);if(i.appendChild(s),o){i.appendChild(document.createTextNode(" "));const a=document.createElement("span");a.className="section-progress",a.textContent=o,i.appendChild(a)}return i.addEventListener("click",n),i}function Ut(e){const t=document.createElement("section");t.className="section";const n=!r.instructionsCollapsed;if(t.appendChild(Le(h.instructionsHeading,n,()=>{r&&(r.instructionsCollapsed=!r.instructionsCollapsed,Ie(),b())})),n){const o=document.createElement("div");o.className="help markdown-content",Pt(o,e),t.appendChild(o)}return t}function Xt(e){const t=document.createElement("section");t.className="section";const n=!r.checklistCollapsed,o=r.items.filter(i=>i.checked).length;if(t.appendChild(Le(h.checklistHeading,n,()=>{r&&(r.checklistCollapsed=!r.checklistCollapsed,Ie(),b())},`${o}/${r.items.length}`)),n){const i=document.createElement("ul");i.className="list";for(const s of e)i.appendChild(Yt(s));t.appendChild(i)}return t}function Vt(e){const t=document.createElement("div");t.className="bug-form";const n=document.createElement("label");n.textContent=h.motivo;const o=document.createElement("textarea");o.value=r.itemNote,o.placeholder=h.motivoPlaceholder,o.rows=3,o.addEventListener("input",()=>{r&&(r.itemNote=o.value,s.disabled=r.busy||!r.itemNote.trim())}),n.appendChild(o);const i=document.createElement("div");i.className="row-actions";const s=document.createElement("button");s.type="button",s.className="btn btn-primary",s.textContent=h.flagAsBug,s.disabled=r.busy||!r.itemNote.trim(),s.addEventListener("click",()=>{Zt(e)});const a=document.createElement("button");return a.type="button",a.className="btn",a.textContent=h.cancelFlag,a.addEventListener("click",()=>{r&&(r.reportingItemId=null,r.itemNote="",b())}),i.append(s,a),t.append(n,i),t}function Gt(){const e=document.createElement("div");e.className="bug-form";const t=document.createElement("p");t.className="warning",t.textContent=h.taskBugWarning;const n=document.createElement("label");n.textContent=h.motivo;const o=document.createElement("textarea");o.value=r.taskNote,o.placeholder=h.motivoPlaceholder,o.rows=3,o.addEventListener("input",()=>{r&&(r.taskNote=o.value,s.disabled=r.busy||!r.taskNote.trim())}),n.appendChild(o);const i=document.createElement("div");i.className="row-actions";const s=document.createElement("button");s.type="button",s.className="btn btn-primary",s.textContent=h.flagAsBug,s.disabled=r.busy||!r.taskNote.trim(),s.addEventListener("click",()=>{Qt()});const a=document.createElement("button");return a.type="button",a.className="btn",a.textContent=h.cancelFlag,a.addEventListener("click",()=>{r&&(r.taskBugOpen=!1,r.taskNote="",b())}),i.append(s,a),e.append(t,n,i),e}function q(e){if(!r)return!1;const t=_t(e);if(t)return r.error=t,!1;if(r.error=null,e.items){r.items=e.items;const n=r.expandedId;n&&!e.items.some(o=>o.id===n)&&(r.expandedId=null)}return e.snapshot&&(r.snapshot=e.snapshot),e.helpMarkdown!==void 0&&(r.helpMarkdown=e.helpMarkdown??null),e.isBug!==void 0&&(r.isBug=e.isBug),!0}async function Me(){if(r){r.busy=!0,b();try{const e=await y.runtime.sendMessage({type:"task.get",task:r.task});q(e)}finally{r&&(r.busy=!1),b()}}}async function Kt(e){if(!(!r||r.busy)){r.busy=!0,r.error=null,b();try{const t=await y.runtime.sendMessage({type:"checklist.tick",task:r.task,itemId:e,snapshot:r.snapshot,source:"overlay"});if(q(t),r){const n=r.items.find(o=>o.id===e);n!=null&&n.checked?r.expandedId=wt(r.items,e):r.expandedId=e}}finally{r&&(r.busy=!1),b()}}}async function Zt(e){if(!(!r||r.busy)){if(!r.itemNote.trim()){r.error=h.itemMotivoRequired,b();return}r.busy=!0,r.error=null,b();try{const t=await y.runtime.sendMessage({type:"checklist.flagItem",task:r.task,itemId:e,note:r.itemNote,snapshot:r.snapshot,source:"overlay"});q(t)&&(r.reportingItemId=null,r.itemNote="")}finally{r&&(r.busy=!1),b()}}}async function Qt(){if(!(!r||r.busy)){if(!r.taskNote.trim()){r.error=h.motivoRequired,b();return}r.busy=!0,r.error=null,b();try{const e=await y.runtime.sendMessage({type:"task.flag",task:r.task,note:r.taskNote,source:"overlay"});q(e)&&(r.taskBugOpen=!1,r.taskNote="")}finally{r&&(r.busy=!1),b()}}}async function Jt(e){if(!(!r||r.busy)){r.busy=!0,r.error=null,b();try{const t=await y.runtime.sendMessage({type:"checklist.unflagItem",task:r.task,itemId:e,snapshot:r.snapshot,source:"overlay"});q(t)}finally{r&&(r.busy=!1),b()}}}async function en(){if(!(!r||r.busy)){r.busy=!0,r.error=null,b();try{const e=await y.runtime.sendMessage({type:"task.unflag",task:r.task,source:"overlay"});q(e)}finally{r&&(r.busy=!1),b()}}}function tn(){const{shadow:e}=Ft();if(e.querySelector(".panel"))return;const n=document.createElement("div");n.className="panel",n.setAttribute("role","dialog"),n.setAttribute("aria-label","Checklist");const o=document.createElement("div");o.className="header",o.addEventListener("pointerdown",Dt),o.addEventListener("pointermove",Wt),o.addEventListener("pointerup",Se),o.addEventListener("pointercancel",Se);const i=document.createElement("div");i.className="header-text";const s=document.createElement("p");s.className="display-id";const a=document.createElement("h2");a.className="title",i.append(s,a);const c=document.createElement("div");c.className="header-actions";const m=document.createElement("button");m.type="button",m.className="icon-btn",m.dataset.action="collapse",m.addEventListener("click",()=>{r&&(r.collapsed=!r.collapsed,b())});const g=document.createElement("button");g.type="button",g.className="icon-btn",g.setAttribute("aria-label",h.closeFloatingChecklist),g.textContent="×",g.addEventListener("click",()=>{Te()}),c.append(m,g),o.append(i,c);const u=document.createElement("div");u.className="body",n.append(o,u),e.appendChild(n),window.addEventListener("resize",Ne)}function nn(e){window===window.top&&(tn(),r={task:e,items:[],snapshot:{items:[]},expandedId:null,reportingItemId:null,itemNote:"",taskBugOpen:!1,taskNote:"",collapsed:!1,instructionsCollapsed:G.instructionsCollapsed,checklistCollapsed:G.checklistCollapsed,helpMarkdown:null,isBug:!1,busy:!1,error:null},A&&(A.style.display="block"),b(),Promise.all([jt(),qt()]).then(([,t])=>{r&&(r.instructionsCollapsed=t.instructionsCollapsed,r.checklistCollapsed=t.checklistCollapsed,b(),Me())}))}function Te(){S=null,r=null,window.removeEventListener("resize",Ne),A==null||A.remove(),A=null,M=null}function rn(){window===window.top&&y.runtime.onMessage.addListener(e=>{if(!e||typeof e!="object"||!("type"in e))return;const t=e.type;if(t==="overlay.open"){const n=e.task;n!=null&&n.id&&nn(n)}if(t==="overlay.close"&&Te(),t==="qa.checklistChanged"){if(!r||e.taskId!==r.task.id||!Ct("overlay",e.source))return;Me()}})}const on=".task-card[data-task-id], .task-list-row[data-task-id]",Y="arc-todo-card-highlight";function sn(e){return e.length===0?null:[...e].reverse().find(n=>!n.className.split(/\s+/).includes("is-subtask"))??e[0]}function an(e){var a,c,m,g,u;const t=(a=e.taskId)==null?void 0:a.trim(),n=(c=e.displayId)==null?void 0:c.trim(),o=(m=e.organizationId)==null?void 0:m.trim(),i=(g=e.projectId)==null?void 0:g.trim(),s=((u=e.taskTitle)==null?void 0:u.trim())||n;return!t||!n||!s||!o||!i?null:{id:t,displayId:n,title:s,organizationId:o,projectId:i}}let z=!1,Pe="";function $e(e){let t=e.getElementById(Y);return t||(t=e.createElement("div"),t.id=Y,t.setAttribute("aria-hidden","true"),Object.assign(t.style,{position:"fixed",pointerEvents:"none",zIndex:"2147483647",outline:"2px solid #4862ce",outlineOffset:"2px",background:"rgba(72, 98, 206, 0.14)",borderRadius:"18px",boxSizing:"border-box",display:"none"}),e.documentElement.appendChild(t),t)}function ln(e){const t=[];let n=e;for(;n;){const o=n.closest(on);if(!(o instanceof HTMLElement))break;t.push(o),n=o.parentElement}return t}function Be(e,t,n){const o=e.elementFromPoint(t,n);return!o||o.id===Y||o.id===_||o.closest(`#${_}`)?null:sn(ln(o))}function cn(e,t){const n=$e(e);if(!t){n.style.display="none";return}const o=t.getBoundingClientRect();n.style.display="block",n.style.left=`${o.left}px`,n.style.top=`${o.top}px`,n.style.width=`${o.width}px`,n.style.height=`${o.height}px`}function Re(e){z&&cn(document,Be(document,e.clientX,e.clientY))}function Oe(e){if(!z)return;const t=Be(document,e.clientX,e.clientY);if(!t)return;const n=an({taskId:t.dataset.taskId,displayId:t.dataset.displayId,taskTitle:t.dataset.taskTitle,organizationId:t.dataset.organizationId,projectId:t.dataset.projectId});n&&(e.preventDefault(),e.stopPropagation(),e.stopImmediatePropagation(),oe(),y.runtime.sendMessage({type:"card.picked",task:n}))}function _e(e){!z||e.key!=="Escape"||(e.preventDefault(),oe(),y.runtime.sendMessage({type:"card.cancelled"}))}function dn(){window===window.top&&(z||(z=!0,Pe=document.documentElement.style.cursor,document.documentElement.style.cursor="pointer",$e(document),document.addEventListener("mousemove",Re,!0),document.addEventListener("click",Oe,!0),document.addEventListener("keydown",_e,!0)))}function oe(){var e;!z&&!document.getElementById(Y)||(z=!1,document.documentElement.style.cursor=Pe,document.removeEventListener("mousemove",Re,!0),document.removeEventListener("click",Oe,!0),document.removeEventListener("keydown",_e,!0),(e=document.getElementById(Y))==null||e.remove())}function un(){window===window.top&&y.runtime.onMessage.addListener(e=>{if(!e||typeof e!="object"||!("type"in e))return;const t=e.type;t==="card.arm"&&dn(),t==="card.disarm"&&oe()})}const mn=6,pn=200,gn=3;function fn(e){return{color:(e==null?void 0:e.color)??"",fontSize:(e==null?void 0:e.fontSize)??"",display:(e==null?void 0:e.display)??""}}function Fe(e){const{x:t,y:n,width:o,height:i}=e.rect;return`${e.selector}@${Math.round(t)},${Math.round(n)},${Math.round(o)},${Math.round(i)}`}function K(e){return typeof CSS<"u"&&typeof CSS.escape=="function"?CSS.escape(e):e.replace(/([^\w-])/g,"\\$1")}function hn(e){return e.filter(t=>/^[A-Za-z_][\w-]*$/.test(t)).slice(0,gn)}function xn(e,t=pn){const n=(e??"").replace(/\s+/g," ").trim();return n.length<=t?n:n.slice(0,t)}function yn(e){const t=e.parentElement;return t?Array.from(t.children).indexOf(e)+1:1}function bn(e,t){if(!t)return!1;try{return e.querySelectorAll(`#${K(t)}`).length===1}catch{return!1}}function ze(e){return{tagName:e.tagName,id:e.id,classes:Array.from(e.classList),nthChild:yn(e),parent:e.parentElement?ze(e.parentElement):null}}function An(e){const t=e.tagName.toLowerCase();if(t==="html"||t==="body")return t;const n=hn(e.classes);let o=t;return n.length&&(o+=n.map(i=>`.${K(i)}`).join("")),e.nthChild>0&&(o+=`:nth-child(${e.nthChild})`),o}function vn(e,t,n=mn){if(e.id&&t(e.id))return`#${K(e.id)}`;const o=[];let i=e,s=0;for(;i&&s<n;){if(i.id&&t(i.id)){o.unshift(`#${K(i.id)}`);break}if(o.unshift(An(i)),i.tagName.toLowerCase()==="html")break;i=i.parent,s+=1}return o.join(" > ")}function kn(e,t){const n=e.getBoundingClientRect(),o=typeof getComputedStyle=="function"?getComputedStyle(e):void 0;return{tag:e.tagName.toLowerCase(),id:e.id,classes:Array.from(e.classList),text:xn(e.textContent),title:t.document.title??"",url:t.locationHref??(typeof location<"u"?location.href:""),selector:vn(ze(e),i=>bn(t.document,i)),rect:{x:n.left,y:n.top,width:n.width,height:n.height},viewport:{width:t.innerWidth,height:t.innerHeight},computed:fn(o)}}function wn(e,t){const n=e.classes.length?e.classes.join(", "):"(none)";return`\`\`\`markdown
${["## Element","",`- Selector: \`${e.selector}\``,`- Tag: ${e.tag}`,`- Id: ${e.id||"(none)"}`,`- Classes: ${n}`,`- Text: ${e.text||"(none)"}`,`- Title: ${e.title||"(none)"}`,`- URL: ${e.url}`,"- Screenshot: omitted"].join(`
`)}
\`\`\``}function En(e){if(!e||typeof e!="object")return"dev";const t=e.purpose;return t==="qa-crop"||t==="qa-record"||t==="design"?t:"dev"}function Cn(e){return e==="dev"}function In(e){return e!=="design"}function Nn(e,t,n){return e==="qa-crop"?{type:"capture.elementPicked",hit:t}:e==="qa-record"?{type:"capture.elementForRecord",hit:t}:{type:"picker.picked",hit:t,keepArmed:e==="design",removed:n==null?void 0:n.removed}}const U="arc-todo-picker-hover",He="arc-todo-picker-selected",qe=["pointerdown","mousedown","mouseup","auxclick","contextmenu","dblclick"];let R=!1,T="dev",je="",De=0;const L=new Map;function We(){return{position:"fixed",pointerEvents:"none",zIndex:"2147483647",outline:"2px solid #4862ce",outlineOffset:"1px",background:"rgba(72, 98, 206, 0.12)",boxSizing:"border-box",display:"none"}}function ie(e,t){e.style.display="block",e.style.left=`${t.left}px`,e.style.top=`${t.top}px`,e.style.width=`${t.width}px`,e.style.height=`${t.height}px`}function se(e){let t=e.getElementById(U);return t||(t=e.createElement("div"),t.id=U,t.setAttribute("aria-hidden","true"),Object.assign(t.style,We()),e.documentElement.appendChild(t),t)}function Sn(e){const t=e.createElement("div");return t.className=He,t.id=`arc-todo-picker-selected-${De}`,De+=1,t.setAttribute("aria-hidden","true"),Object.assign(t.style,We(),{display:"block"}),e.documentElement.appendChild(t),t}function Ln(e){return e?e.id===_?!0:!!e.closest(`#${_}`):!1}function Mn(e){return e?e.id===U||e.classList.contains(He)||Ln(e):!1}function Ye(e,t,n){const o=e.elementFromPoint(t,n);return!o||Mn(o)?null:o}function Ue(e){R&&(e.preventDefault(),e.stopPropagation(),e.stopImmediatePropagation())}function Tn(e,t){const n=se(e);if(!t){n.style.display="none";return}ie(n,t.getBoundingClientRect())}function Xe(e){return kn(e,{document,innerWidth:window.innerWidth,innerHeight:window.innerHeight,locationHref:location.href})}function Pn(e){if(L.has(e))return e;for(const t of L.keys())if(Fe(L.get(t).hit)===Fe(Xe(e)))return t;return null}function $n(e,t){const n=Sn(document);ie(n,e.getBoundingClientRect()),L.set(e,{hit:t,box:n})}function Ve(e){const t=L.get(e);return t==null||t.box.remove(),L.delete(e),t==null?void 0:t.hit}function Ge(){for(const e of L.values())e.box.remove();L.clear()}function Bn(){for(const[e,t]of L){if(!e.isConnected){Ve(e);continue}ie(t.box,e.getBoundingClientRect())}}function Ke(e){R&&Tn(document,Ye(document,e.clientX,e.clientY))}function Z(){!R||T!=="design"||Bn()}async function Rn(){return{error:"idle"}}async function Ze(e){if(!R)return;const t=Ye(document,e.clientX,e.clientY);if(!t)return;e.preventDefault(),e.stopPropagation(),e.stopImmediatePropagation();const n=Pn(t),o=T==="design"&&(!!n||e.shiftKey),i=o&&n?L.get(n).hit:Xe(t);if(T==="design")if(o&&n)Ve(n);else if(!o)$n(t,i);else return;if(Cn(T)){const a=wn(i);try{await navigator.clipboard.writeText(a)}catch{}}const s=Nn(T,i,{removed:o});In(T)&&ae(),y.runtime.sendMessage(s)}function Qe(e){!R||e.key!=="Escape"||(e.preventDefault(),ae(),y.runtime.sendMessage({type:"picker.cancelled"}))}function On(e="dev"){if(window===window.top){if(R){T!==e&&(Ge(),se(document).style.display="none"),T=e;return}R=!0,T=e,je=document.documentElement.style.cursor,document.documentElement.style.cursor="crosshair",se(document),document.addEventListener("mousemove",Ke,!0),document.addEventListener("click",Ze,!0),document.addEventListener("keydown",Qe,!0);for(const t of qe)document.addEventListener(t,Ue,!0);window.addEventListener("scroll",Z,!0),window.addEventListener("resize",Z)}}function ae(){var e;if(!(!R&&!document.getElementById(U)&&L.size===0)){R=!1,T="dev",document.documentElement.style.cursor=je,document.removeEventListener("mousemove",Ke,!0),document.removeEventListener("click",Ze,!0),document.removeEventListener("keydown",Qe,!0);for(const t of qe)document.removeEventListener(t,Ue,!0);window.removeEventListener("scroll",Z,!0),window.removeEventListener("resize",Z),(e=document.getElementById(U))==null||e.remove(),Ge()}}function _n(){window===window.top&&y.runtime.onMessage.addListener(e=>{if(!e||typeof e!="object"||!("type"in e))return;const t=e.type;if(t==="picker.arm"&&On(En(e)),t==="picker.disarm"&&ae(),t==="capture.stopElementRecord")return Rn()})}const Je=window;function Fn(e){return!!(e&&typeof e=="object"&&e.type==="content.ping")}y.runtime.onMessage.addListener(e=>{if(Fn(e))return Promise.resolve(!0)}),Je.__arcTodoContentReady||(Je.__arcTodoContentReady=!0,window.addEventListener(ct,e=>{const t=e.detail;typeof t=="string"&&y.runtime.sendMessage({type:"capture.console",payload:t})}),y.runtime.sendMessage({type:"capture.pageReady"}),_n(),vt(),un(),rn(),lt())})();
