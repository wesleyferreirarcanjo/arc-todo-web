(function(){"use strict";function Qe(e){return e&&e.__esModule&&Object.prototype.hasOwnProperty.call(e,"default")?e.default:e}var V={exports:{}},Je=V.exports,ce;function et(){return ce||(ce=1,(function(e,t){(function(n,o){o(e)})(typeof globalThis<"u"?globalThis:typeof self<"u"?self:Je,function(n){if(!(globalThis.chrome&&globalThis.chrome.runtime&&globalThis.chrome.runtime.id))throw new Error("This script should only be loaded in a browser extension.");if(globalThis.browser&&globalThis.browser.runtime&&globalThis.browser.runtime.id)n.exports=globalThis.browser;else{const o="The message port closed before a response was received.",i=s=>{const a={alarms:{clear:{minArgs:0,maxArgs:1},clearAll:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getAll:{minArgs:0,maxArgs:0}},bookmarks:{create:{minArgs:1,maxArgs:1},get:{minArgs:1,maxArgs:1},getChildren:{minArgs:1,maxArgs:1},getRecent:{minArgs:1,maxArgs:1},getSubTree:{minArgs:1,maxArgs:1},getTree:{minArgs:0,maxArgs:0},move:{minArgs:2,maxArgs:2},remove:{minArgs:1,maxArgs:1},removeTree:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1},update:{minArgs:2,maxArgs:2}},browserAction:{disable:{minArgs:0,maxArgs:1,fallbackToNoCallback:!0},enable:{minArgs:0,maxArgs:1,fallbackToNoCallback:!0},getBadgeBackgroundColor:{minArgs:1,maxArgs:1},getBadgeText:{minArgs:1,maxArgs:1},getPopup:{minArgs:1,maxArgs:1},getTitle:{minArgs:1,maxArgs:1},openPopup:{minArgs:0,maxArgs:0},setBadgeBackgroundColor:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setBadgeText:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setIcon:{minArgs:1,maxArgs:1},setPopup:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setTitle:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},browsingData:{remove:{minArgs:2,maxArgs:2},removeCache:{minArgs:1,maxArgs:1},removeCookies:{minArgs:1,maxArgs:1},removeDownloads:{minArgs:1,maxArgs:1},removeFormData:{minArgs:1,maxArgs:1},removeHistory:{minArgs:1,maxArgs:1},removeLocalStorage:{minArgs:1,maxArgs:1},removePasswords:{minArgs:1,maxArgs:1},removePluginData:{minArgs:1,maxArgs:1},settings:{minArgs:0,maxArgs:0}},commands:{getAll:{minArgs:0,maxArgs:0}},contextMenus:{remove:{minArgs:1,maxArgs:1},removeAll:{minArgs:0,maxArgs:0},update:{minArgs:2,maxArgs:2}},cookies:{get:{minArgs:1,maxArgs:1},getAll:{minArgs:1,maxArgs:1},getAllCookieStores:{minArgs:0,maxArgs:0},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}},devtools:{inspectedWindow:{eval:{minArgs:1,maxArgs:2,singleCallbackArg:!1}},panels:{create:{minArgs:3,maxArgs:3,singleCallbackArg:!0},elements:{createSidebarPane:{minArgs:1,maxArgs:1}}}},downloads:{cancel:{minArgs:1,maxArgs:1},download:{minArgs:1,maxArgs:1},erase:{minArgs:1,maxArgs:1},getFileIcon:{minArgs:1,maxArgs:2},open:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},pause:{minArgs:1,maxArgs:1},removeFile:{minArgs:1,maxArgs:1},resume:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1},show:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},extension:{isAllowedFileSchemeAccess:{minArgs:0,maxArgs:0},isAllowedIncognitoAccess:{minArgs:0,maxArgs:0}},history:{addUrl:{minArgs:1,maxArgs:1},deleteAll:{minArgs:0,maxArgs:0},deleteRange:{minArgs:1,maxArgs:1},deleteUrl:{minArgs:1,maxArgs:1},getVisits:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1}},i18n:{detectLanguage:{minArgs:1,maxArgs:1},getAcceptLanguages:{minArgs:0,maxArgs:0}},identity:{launchWebAuthFlow:{minArgs:1,maxArgs:1}},idle:{queryState:{minArgs:1,maxArgs:1}},management:{get:{minArgs:1,maxArgs:1},getAll:{minArgs:0,maxArgs:0},getSelf:{minArgs:0,maxArgs:0},setEnabled:{minArgs:2,maxArgs:2},uninstallSelf:{minArgs:0,maxArgs:1}},notifications:{clear:{minArgs:1,maxArgs:1},create:{minArgs:1,maxArgs:2},getAll:{minArgs:0,maxArgs:0},getPermissionLevel:{minArgs:0,maxArgs:0},update:{minArgs:2,maxArgs:2}},pageAction:{getPopup:{minArgs:1,maxArgs:1},getTitle:{minArgs:1,maxArgs:1},hide:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setIcon:{minArgs:1,maxArgs:1},setPopup:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setTitle:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},show:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},permissions:{contains:{minArgs:1,maxArgs:1},getAll:{minArgs:0,maxArgs:0},remove:{minArgs:1,maxArgs:1},request:{minArgs:1,maxArgs:1}},runtime:{getBackgroundPage:{minArgs:0,maxArgs:0},getPlatformInfo:{minArgs:0,maxArgs:0},openOptionsPage:{minArgs:0,maxArgs:0},requestUpdateCheck:{minArgs:0,maxArgs:0},sendMessage:{minArgs:1,maxArgs:3},sendNativeMessage:{minArgs:2,maxArgs:2},setUninstallURL:{minArgs:1,maxArgs:1}},sessions:{getDevices:{minArgs:0,maxArgs:1},getRecentlyClosed:{minArgs:0,maxArgs:1},restore:{minArgs:0,maxArgs:1}},storage:{local:{clear:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}},managed:{get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1}},sync:{clear:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}}},tabs:{captureVisibleTab:{minArgs:0,maxArgs:2},create:{minArgs:1,maxArgs:1},detectLanguage:{minArgs:0,maxArgs:1},discard:{minArgs:0,maxArgs:1},duplicate:{minArgs:1,maxArgs:1},executeScript:{minArgs:1,maxArgs:2},get:{minArgs:1,maxArgs:1},getCurrent:{minArgs:0,maxArgs:0},getZoom:{minArgs:0,maxArgs:1},getZoomSettings:{minArgs:0,maxArgs:1},goBack:{minArgs:0,maxArgs:1},goForward:{minArgs:0,maxArgs:1},highlight:{minArgs:1,maxArgs:1},insertCSS:{minArgs:1,maxArgs:2},move:{minArgs:2,maxArgs:2},query:{minArgs:1,maxArgs:1},reload:{minArgs:0,maxArgs:2},remove:{minArgs:1,maxArgs:1},removeCSS:{minArgs:1,maxArgs:2},sendMessage:{minArgs:2,maxArgs:3},setZoom:{minArgs:1,maxArgs:2},setZoomSettings:{minArgs:1,maxArgs:2},update:{minArgs:1,maxArgs:2}},topSites:{get:{minArgs:0,maxArgs:0}},webNavigation:{getAllFrames:{minArgs:1,maxArgs:1},getFrame:{minArgs:1,maxArgs:1}},webRequest:{handlerBehaviorChanged:{minArgs:0,maxArgs:0}},windows:{create:{minArgs:0,maxArgs:1},get:{minArgs:1,maxArgs:2},getAll:{minArgs:0,maxArgs:1},getCurrent:{minArgs:0,maxArgs:1},getLastFocused:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},update:{minArgs:2,maxArgs:2}}};if(Object.keys(a).length===0)throw new Error("api-metadata.json has not been included in browser-polyfill");class d extends WeakMap{constructor(c,g=void 0){super(g),this.createItem=c}get(c){return this.has(c)||this.set(c,this.createItem(c)),super.get(c)}}const p=l=>l&&typeof l=="object"&&typeof l.then=="function",x=(l,c)=>(...g)=>{s.runtime.lastError?l.reject(new Error(s.runtime.lastError.message)):c.singleCallbackArg||g.length<=1&&c.singleCallbackArg!==!1?l.resolve(g[0]):l.resolve(g)},u=l=>l==1?"argument":"arguments",k=(l,c)=>function(h,...E){if(E.length<c.minArgs)throw new Error(`Expected at least ${c.minArgs} ${u(c.minArgs)} for ${l}(), got ${E.length}`);if(E.length>c.maxArgs)throw new Error(`Expected at most ${c.maxArgs} ${u(c.maxArgs)} for ${l}(), got ${E.length}`);return new Promise((C,I)=>{if(c.fallbackToNoCallback)try{h[l](...E,x({resolve:C,reject:I},c))}catch(m){console.warn(`${l} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `,m),h[l](...E),c.fallbackToNoCallback=!1,c.noCallback=!0,C()}else c.noCallback?(h[l](...E),C()):h[l](...E,x({resolve:C,reject:I},c))})},w=(l,c,g)=>new Proxy(c,{apply(h,E,C){return g.call(E,l,...C)}});let P=Function.call.bind(Object.prototype.hasOwnProperty);const q=(l,c={},g={})=>{let h=Object.create(null),E={has(I,m){return m in l||m in h},get(I,m,N){if(m in h)return h[m];if(!(m in l))return;let v=l[m];if(typeof v=="function")if(typeof c[m]=="function")v=w(l,l[m],c[m]);else if(P(g,m)){let j=k(m,g[m]);v=w(l,l[m],j)}else v=v.bind(l);else if(typeof v=="object"&&v!==null&&(P(c,m)||P(g,m)))v=q(v,c[m],g[m]);else if(P(g,"*"))v=q(v,c[m],g["*"]);else return Object.defineProperty(h,m,{configurable:!0,enumerable:!0,get(){return l[m]},set(j){l[m]=j}}),v;return h[m]=v,v},set(I,m,N,v){return m in h?h[m]=N:l[m]=N,!0},defineProperty(I,m,N){return Reflect.defineProperty(h,m,N)},deleteProperty(I,m){return Reflect.deleteProperty(h,m)}},C=Object.create(l);return new Proxy(C,E)},O=l=>({addListener(c,g,...h){c.addListener(l.get(g),...h)},hasListener(c,g){return c.hasListener(l.get(g))},removeListener(c,g){c.removeListener(l.get(g))}}),Pn=new d(l=>typeof l!="function"?l:function(g){const h=q(g,{},{getContent:{minArgs:0,maxArgs:0}});l(h)}),Ke=new d(l=>typeof l!="function"?l:function(g,h,E){let C=!1,I,m=new Promise(X=>{I=function($){C=!0,X($)}}),N;try{N=l(g,h,I)}catch(X){N=Promise.reject(X)}const v=N!==!0&&p(N);if(N!==!0&&!v&&!C)return!1;const j=X=>{X.then($=>{E($)},$=>{let le;$&&($ instanceof Error||typeof $.message=="string")?le=$.message:le="An unexpected error occurred",E({__mozWebExtensionPolyfillReject__:!0,message:le})}).catch($=>{console.error("Failed to send onMessage rejected reply",$)})};return j(v?N:m),!0}),$n=({reject:l,resolve:c},g)=>{s.runtime.lastError?s.runtime.lastError.message===o?c():l(new Error(s.runtime.lastError.message)):g&&g.__mozWebExtensionPolyfillReject__?l(new Error(g.message)):c(g)},Ze=(l,c,g,...h)=>{if(h.length<c.minArgs)throw new Error(`Expected at least ${c.minArgs} ${u(c.minArgs)} for ${l}(), got ${h.length}`);if(h.length>c.maxArgs)throw new Error(`Expected at most ${c.maxArgs} ${u(c.maxArgs)} for ${l}(), got ${h.length}`);return new Promise((E,C)=>{const I=$n.bind(null,{resolve:E,reject:C});h.push(I),g.sendMessage(...h)})},Bn={devtools:{network:{onRequestFinished:O(Pn)}},runtime:{onMessage:O(Ke),onMessageExternal:O(Ke),sendMessage:Ze.bind(null,"sendMessage",{minArgs:1,maxArgs:3})},tabs:{sendMessage:Ze.bind(null,"sendMessage",{minArgs:2,maxArgs:3})}},ae={clear:{minArgs:1,maxArgs:1},get:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}};return a.privacy={network:{"*":ae},services:{"*":ae},websites:{"*":ae}},q(s,Bn,a)};n.exports=i(chrome)}})})(V)),V.exports}var tt=et();const b=Qe(tt),nt="arc-todo-capture",_="arc-todo-qa-overlay",rt=2147483645,Q="arcTodo.overlayPosition",J="arcTodo.overlaySections";function ot(e,t,n,o,i,s){const a=Math.max(0,Math.min(e,n)),d=Math.max(0,Math.min(t,o)),p=Math.min(i,Math.max(e,n)),x=Math.min(s,Math.max(t,o)),u=p-a,k=x-d;return u<4||k<4?null:{x:a,y:d,width:u,height:k}}function it(e,t,n,o,i){const s=ot(e,t,n,o,i.width,i.height);return s?{rect:s,viewport:i}:null}const D="arc-todo-region-overlay",W="arc-todo-region-marquee",de=["pointerdown","mousedown","mouseup","auxclick","contextmenu","dblclick"];let B=!1,ue="",F=null;function st(){return{position:"fixed",inset:"0",zIndex:"2147483646",cursor:"crosshair",background:"rgba(0, 0, 0, 0.35)",boxSizing:"border-box"}}function at(){return{position:"fixed",pointerEvents:"none",zIndex:"2147483646",outline:"2px solid #ffffff",outlineOffset:"0",boxShadow:"0 0 0 99999px rgba(0, 0, 0, 0.35)",boxSizing:"border-box",display:"none",background:"transparent"}}function lt(e){let t=e.getElementById(D);return t||(t=e.createElement("div"),t.id=D,t.setAttribute("aria-hidden","true"),Object.assign(t.style,st()),e.documentElement.appendChild(t),t)}function me(e){let t=e.getElementById(W);return t||(t=e.createElement("div"),t.id=W,t.setAttribute("aria-hidden","true"),Object.assign(t.style,at()),e.documentElement.appendChild(t),t)}function ct(e){return e?e.id===_?!0:!!e.closest(`#${_}`):!1}function dt(e,t,n){const o=e.getElementById(D),i=e.getElementById(W);o&&(o.style.pointerEvents="none"),i&&(i.style.pointerEvents="none");const s=e.elementFromPoint(t,n);return o&&(o.style.pointerEvents="auto"),s}function ge(e){B&&(e.preventDefault(),e.stopPropagation(),e.stopImmediatePropagation())}function ut(e,t,n,o){const i=Math.min(e,n),s=Math.min(t,o),a=me(document);a.style.display="block",a.style.left=`${i}px`,a.style.top=`${s}px`,a.style.width=`${Math.abs(n-e)}px`,a.style.height=`${Math.abs(o-t)}px`}function pe(){const e=document.getElementById(W);e&&(e.style.display="none")}function mt(){return{width:window.innerWidth,height:window.innerHeight}}function fe(e){if(!B||e.button!==0)return;const t=dt(document,e.clientX,e.clientY);ct(t)||(F={x:e.clientX,y:e.clientY},pe())}function he(e){!B||!F||ut(F.x,F.y,e.clientX,e.clientY)}function xe(e){if(!B||!F)return;const t=F;F=null;const n=it(t.x,t.y,e.clientX,e.clientY,mt());pe(),n&&(b.runtime.sendMessage({type:"region.picked",rect:n.rect,viewport:n.viewport,devicePixelRatio:window.devicePixelRatio}),ee())}function ye(e){!B||e.key!=="Escape"||(e.preventDefault(),ee(),b.runtime.sendMessage({type:"region.cancelled"}))}function gt(){if(window===window.top&&!B){B=!0,ue=document.documentElement.style.cursor,document.documentElement.style.cursor="crosshair",lt(document),me(document),document.addEventListener("pointerdown",fe,!0),document.addEventListener("pointermove",he,!0),document.addEventListener("pointerup",xe,!0),document.addEventListener("keydown",ye,!0);for(const e of de)document.addEventListener(e,ge,!0)}}function ee(){var e,t;if(!(!B&&!document.getElementById(D))){B=!1,F=null,document.documentElement.style.cursor=ue,document.removeEventListener("pointerdown",fe,!0),document.removeEventListener("pointermove",he,!0),document.removeEventListener("pointerup",xe,!0),document.removeEventListener("keydown",ye,!0);for(const n of de)document.removeEventListener(n,ge,!0);(e=document.getElementById(D))==null||e.remove(),(t=document.getElementById(W))==null||t.remove()}}function pt(){window===window.top&&b.runtime.onMessage.addListener(e=>{if(!e||typeof e!="object"||!("type"in e))return;const t=e.type;t==="region.arm"&&gt(),t==="region.disarm"&&ee()})}function ft(e){var t;return((t=e.find(n=>!n.checked))==null?void 0:t.id)??null}function ht(e,t){var i;const n=e.findIndex(s=>s.id===t);return((i=(n>=0?e.slice(n+1):e).find(s=>!s.checked))==null?void 0:i.id)??ft(e)}function xt(e,t){if(t&&e.some(n=>n.id===t))return t}function yt(e,t){return t==="panel"||t==="overlay"?t!==e:!0}function bt(e,t,n,o,i=48){const s=i-o.width,a=n.width-i,d=0,p=Math.max(0,n.height-i);return{left:Math.min(a,Math.max(s,e)),top:Math.min(p,Math.max(d,t))}}function At(e,t,n=16){return{left:Math.max(n,e.width-t.width-n),top:Math.max(n,e.height-t.height-n)}}const be=/(\*\*[^*]+\*\*|\*[^*]+\*|`[^`]+`|\[[^\]]+\]\(https?:\/\/[^)\s]+\)|https?:\/\/[^\s<>"'`]+)/g;function vt(e){const t=[];let n=0;be.lastIndex=0;let o;for(;o=be.exec(e);){o.index>n&&t.push({type:"text",text:e.slice(n,o.index)});const i=o[0];if(i.startsWith("**"))t.push({type:"strong",text:i.slice(2,-2)});else if(i.startsWith("*"))t.push({type:"em",text:i.slice(1,-1)});else if(i.startsWith("`"))t.push({type:"code",text:i.slice(1,-1)});else if(i.startsWith("[")){const s=i.match(/^\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)$/);s&&t.push({type:"a",text:s[1],href:s[2]})}else{const s=i.replace(/[),.;:!?]+$/,""),a=i.slice(s.length);s&&t.push({type:"a",text:s,href:s}),a&&t.push({type:"text",text:a})}n=o.index+i.length}return n<e.length&&t.push({type:"text",text:e.slice(n)}),t.length>0?t:[{type:"text",text:e}]}function kt(e,t){const n=t.join(`
`).trim();n&&e.push({type:"p",text:n})}function wt(e){return`h${Math.min(e.length,4)}`}function Et(e){const t=[];let n=[],o=[],i=[],s=null;function a(){o.length!==0&&(t.push({type:"ul",items:o}),o=[])}function d(){i.length!==0&&(t.push({type:"ol",items:i}),i=[])}function p(){const u=n;n=[],kt(t,u)}function x(){a(),d()}for(const u of e.split(`
`)){if(s){u.startsWith("```")?(t.push({type:"pre",text:s.join(`
`)}),s=null):s.push(u);continue}if(u.startsWith("```")){x(),p(),s=[];continue}if(/^(-{3,}|\*{3,}|_{3,})\s*$/.test(u.trim())){x(),p(),t.push({type:"hr"});continue}const k=u.match(/^>\s?(.*)$/);if(k){x(),p();const O=t[t.length-1];(O==null?void 0:O.type)==="blockquote"?O.text=`${O.text}
${k[1]}`:t.push({type:"blockquote",text:k[1]});continue}const w=u.match(/^(#{1,4})\s+(.*)$/),P=u.match(/^[-*]\s+(.*)$/),q=u.match(/^\d+\.\s+(.*)$/);if(w){x(),p(),t.push({type:wt(w[1]),text:w[2]});continue}if(P){d(),p(),o.push(P[1]);continue}if(q){a(),p(),i.push(q[1]);continue}if(!u.trim()){x(),p();continue}x(),n.push(u)}return s&&t.push({type:"pre",text:s.join(`
`)}),x(),p(),t}function te(e,t){for(const n of vt(t)){if(n.type==="text"){e.appendChild(document.createTextNode(n.text));continue}if(n.type==="a"){const i=document.createElement("a");i.href=n.href,i.target="_blank",i.rel="noopener noreferrer",i.textContent=n.text,e.appendChild(i);continue}const o=document.createElement(n.type==="strong"?"strong":n.type==="em"?"em":"code");o.textContent=n.text,e.appendChild(o)}}function Ct(e,t){for(const n of Et(t)){if(n.type==="ul"||n.type==="ol"){const i=document.createElement(n.type);for(const s of n.items){const a=document.createElement("li");te(a,s),i.appendChild(a)}e.appendChild(i);continue}if(n.type==="pre"){const i=document.createElement("pre"),s=document.createElement("code");s.textContent=n.text,i.appendChild(s),e.appendChild(i);continue}if(n.type==="hr"){e.appendChild(document.createElement("hr"));continue}if(n.type==="blockquote"){const i=document.createElement("blockquote");te(i,n.text),e.appendChild(i);continue}const o=document.createElement(n.type);te(o,n.text),e.appendChild(o)}}function It(e){if(!e||typeof e!="object"||Array.isArray(e))return null;const t=e;return typeof t.left!="number"||typeof t.top!="number"||!Number.isFinite(t.left)||!Number.isFinite(t.top)?null:{left:t.left,top:t.top}}const Ae=60;function Nt(e){const t=e.replace(/\*\*/g,"").trim(),n=e.match(/^\s*\*\*(.+?)\*\*/);if(n)return{short:n[1].replace(/\*\*/g,"").trim(),full:t,fromBold:!0};const o=t.indexOf(":");return o>0?{short:t.slice(0,o).trim(),full:t,fromBold:!1}:t.length>Ae?{short:`${t.slice(0,Ae)}…`,full:t,fromBold:!1}:{short:t,full:t,fromBold:!1}}function ve(e){return e.map(t=>{const n=Nt(t.label);return{id:t.id,short:n.short,full:n.full,checked:t.checked,bugged:t.bugged,notes:t.notes}})}const G={instructionsCollapsed:!1,checklistCollapsed:!1};function St(e){if(!e||typeof e!="object"||Array.isArray(e))return null;const t=e;return typeof t.instructionsCollapsed!="boolean"||typeof t.checklistCollapsed!="boolean"?null:{instructionsCollapsed:t.instructionsCollapsed,checklistCollapsed:t.checklistCollapsed}}const Lt=`
:host {
  all: initial;
  position: fixed;
  z-index: 2147483645;
  font-family: system-ui, sans-serif;
  color-scheme: dark;
  --bg-surface: #1b2230;
  --bg-elevated: #252e3d;
  --text-primary: #e8ecf4;
  --text-muted: #9aa6bc;
  --border: rgba(142, 160, 188, 0.18);
  --accent: #4862ce;
  --accent-contrast: #f7f8fc;
  --radius: 0.75rem;
  --type-body: 0.8125rem;
  --type-meta: 0.7rem;
  --type-section: 0.9rem;
}

@media (prefers-color-scheme: light) {
  :host {
    color-scheme: light;
    --bg-surface: #fbfcfe;
    --bg-elevated: #eef1f6;
    --text-primary: #1b2230;
    --text-muted: #5a6578;
    --border: rgba(46, 53, 69, 0.16);
    --accent: #3d52b8;
  }
}

*, *::before, *::after { box-sizing: border-box; }

.panel {
  width: min(420px, calc(100vw - 24px));
  max-height: min(70vh, 520px);
  display: flex;
  flex-direction: column;
  background: var(--bg-surface);
  color: var(--text-primary);
  border: 1px solid var(--border);
  border-radius: var(--radius);
  box-shadow: 0 12px 40px rgba(0, 0, 0, 0.35);
  overflow: hidden;
  font-size: var(--type-body);
  line-height: 1.4;
}

.panel.is-collapsed .body { display: none; }

.header {
  display: flex;
  align-items: flex-start;
  gap: 0.5rem;
  padding: 0.55rem 0.65rem;
  background: var(--bg-elevated);
  border-bottom: 1px solid var(--border);
  cursor: grab;
  touch-action: none;
  user-select: none;
}

.header:active { cursor: grabbing; }

.header-text {
  flex: 1;
  min-width: 0;
}

.display-id {
  margin: 0;
  font-size: var(--type-meta);
  color: var(--text-muted);
  font-weight: 600;
}

.title {
  margin: 0.1rem 0 0;
  font-size: var(--type-section);
  font-weight: 700;
  line-height: 1.25;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.header-actions {
  display: flex;
  gap: 0.25rem;
  flex-shrink: 0;
}

.icon-btn {
  appearance: none;
  border: 1px solid var(--border);
  background: transparent;
  color: var(--text-primary);
  border-radius: calc(var(--radius) - 0.25rem);
  width: 1.75rem;
  height: 1.75rem;
  font: inherit;
  font-size: 0.85rem;
  line-height: 1;
  cursor: pointer;
  padding: 0;
}

.icon-btn:hover { background: var(--bg-surface); }

.body {
  overflow: auto;
  padding: 0.5rem;
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

.hint {
  margin: 0;
  font-size: var(--type-meta);
  color: var(--text-muted);
}

.list {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
  gap: 0.375rem;
}

.row {
  border: 1px solid var(--border);
  border-radius: calc(var(--radius) - 0.2rem);
  background: var(--bg-elevated);
  padding: 0.375rem;
}

.row.is-bugged { border-color: rgba(220, 80, 80, 0.45); }
.row.is-current { border-color: var(--accent); }

.row-main {
  display: flex;
  gap: 0.35rem;
  align-items: center;
}

.tick {
  appearance: none;
  border: 0;
  background: transparent;
  color: var(--text-primary);
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  padding: 0.1rem;
  font: inherit;
  min-width: 1.4rem;
}

.tick-mark {
  width: 1.1rem;
  height: 1.1rem;
  border-radius: 999px;
  border: 2px solid var(--text-muted);
  display: block;
}

.tick.is-checked .tick-mark {
  border-color: var(--accent);
  background: var(--accent);
  box-shadow: inset 0 0 0 2px var(--bg-elevated);
}

.expand {
  appearance: none;
  border: 0;
  background: transparent;
  color: var(--text-primary);
  text-align: left;
  flex: 1;
  min-width: 0;
  cursor: pointer;
  font: inherit;
  padding: 0.15rem 0;
}

.expand strong { font-weight: 650; }

.row-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 0.25rem;
  margin-top: 0.35rem;
}

.btn {
  appearance: none;
  border: 1px solid var(--border);
  background: var(--bg-surface);
  color: var(--text-primary);
  border-radius: calc(var(--radius) - 0.25rem);
  font: inherit;
  font-size: var(--type-meta);
  font-weight: 600;
  padding: 0.3rem 0.5rem;
  cursor: pointer;
}

.btn-primary {
  background: var(--accent);
  border-color: var(--accent);
  color: var(--accent-contrast);
}

.btn:disabled {
  opacity: 0.45;
  cursor: not-allowed;
}

.bug-form {
  display: flex;
  flex-direction: column;
  gap: 0.35rem;
  margin-top: 0.35rem;
}

.bug-form label {
  display: flex;
  flex-direction: column;
  gap: 0.2rem;
  font-size: var(--type-meta);
  color: var(--text-muted);
}

.bug-form textarea {
  resize: vertical;
  min-height: 3.5rem;
  border: 1px solid var(--border);
  border-radius: calc(var(--radius) - 0.25rem);
  background: var(--bg-surface);
  color: var(--text-primary);
  font: inherit;
  padding: 0.35rem;
}

.warning {
  margin: 0;
  font-size: var(--type-meta);
  color: var(--text-muted);
}

.error {
  margin: 0;
  font-size: var(--type-meta);
  color: #e07070;
}

.notes {
  margin: 0.25rem 0 0;
  padding-left: 1rem;
  font-size: var(--type-meta);
  color: var(--text-muted);
}

.section {
  display: flex;
  flex-direction: column;
  gap: 0.35rem;
  min-width: 0;
}

.section-toggle {
  appearance: none;
  display: flex;
  align-items: baseline;
  gap: 0.4rem;
  width: 100%;
  margin: 0;
  padding: 0.25rem 0;
  border: 0;
  background: transparent;
  color: var(--text-muted);
  font: inherit;
  font-size: var(--type-meta);
  font-weight: 700;
  letter-spacing: 0.02em;
  text-transform: uppercase;
  text-align: left;
  cursor: pointer;
}

.section-progress {
  font-weight: 650;
  color: var(--text-primary);
  text-transform: none;
  letter-spacing: 0;
}

.help {
  display: flex;
  flex-direction: column;
  gap: 0.4rem;
  min-width: 0;
}

.help p,
.help li {
  margin: 0;
  font-size: var(--type-meta);
  color: var(--text-muted);
}

.help ul,
.help ol {
  margin: 0;
  padding-left: 1.1rem;
}

.help h1,
.help h2,
.help h3,
.help h4 {
  margin: 0;
  font-size: var(--type-body);
  font-weight: 650;
  color: var(--text-primary);
}

.help strong { font-weight: 700; color: var(--text-primary); }
.help em { font-style: italic; }
.help code {
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  font-size: 0.88em;
  padding: 0.05em 0.3em;
  border-radius: 4px;
  border: 1px solid var(--border);
}
.help a { color: var(--accent); }
.help pre {
  margin: 0;
  padding: 0.45rem 0.55rem;
  overflow-x: auto;
  border: 1px solid var(--border);
  border-radius: 0.35rem;
  font-size: var(--type-meta);
}
.help pre code { padding: 0; border: none; }
.help hr {
  width: 100%;
  border: none;
  border-top: 1px solid var(--border);
  margin: 0.2rem 0;
}
.help blockquote {
  margin: 0;
  padding: 0.15rem 0 0.15rem 0.6rem;
  border-left: 2px solid var(--border);
  color: var(--text-muted);
}
`,f={itemDone:"Feito",itemOpen:"A fazer",flagAsBug:"Marcar como bug",solveBug:"Marcar como resolvido",solveItem:"Resolvido",motivo:"Motivo",motivoPlaceholder:"Descreva o problema encontrado",cancelFlag:"Cancelar",taskBugWarning:"Este card volta para To Do, inclusive as subtarefas.",noChecklist:"Esta tarefa não tem checklist.",collapseOverlay:"Recolher",expandOverlay:"Expandir",closeFloatingChecklist:"Fechar checklist flutuante",overlayDragHint:"Arraste pelo cabeçalho",instructionsHeading:"Instruções",checklistHeading:"Checklist",checklistChanged:"A checklist mudou. Recarregue e tente de novo.",motivoRequired:"O motivo do bug é obrigatório.",itemMotivoRequired:"O motivo do bug do item é obrigatório.",apiError:"Não foi possível falar com a API. Tente de novo.",sessionExpired:"Sessão expirada. Entre de novo no Arc Todo.",signInFirst:"Entre no Arc Todo primeiro"};let A=null,T=null,r=null,S=null;function Tt(e){return e.status==="expired"?f.sessionExpired:e.status==="not_signed_in"?f.signInFirst:e.error==="stale"?f.checklistChanged:e.error==="motivo"?f.motivoRequired:e.error==="api"||e.status==="error"?f.apiError:null}function Mt(){const e=document.getElementById(_);if(e&&T&&A===e)return{host:e,shadow:T};e==null||e.remove();const t=document.createElement("div");t.id=_,t.setAttribute("aria-hidden","false"),Object.assign(t.style,{position:"fixed",zIndex:String(rt),left:"0px",top:"0px"});const n=t.attachShadow({mode:"open"}),o=document.createElement("style");return o.textContent=Lt,n.appendChild(o),document.documentElement.appendChild(t),A=t,T=n,{host:t,shadow:n}}async function Pt(){try{const e=await b.storage.local.get(Q);return It(e[Q])}catch{return null}}async function $t(e,t){try{await b.storage.local.set({[Q]:{left:e,top:t}})}catch{}}async function Bt(){try{const e=await b.storage.local.get(J);return St(e[J])??G}catch{return G}}async function ke(){if(r)try{await b.storage.local.set({[J]:{instructionsCollapsed:r.instructionsCollapsed,checklistCollapsed:r.checklistCollapsed}})}catch{}}function ne(e,t){if(!A)return;const n=A.getBoundingClientRect(),o=bt(e,t,{width:window.innerWidth,height:window.innerHeight},{width:n.width||420,height:Math.min(n.height||48,48)});A.style.left=`${o.left}px`,A.style.top=`${o.top}px`}function we(){if(!A)return;const e=Number.parseFloat(A.style.left||"0"),t=Number.parseFloat(A.style.top||"0");ne(e,t)}async function Rt(){if(!A)return;const e=await Pt(),t={width:420,height:320},n=e??At({width:window.innerWidth,height:window.innerHeight},t);ne(n.left,n.top)}function Ot(e){if(!A||e.button!==0)return;const t=e.target;if(t!=null&&t.closest("button"))return;const n=Number.parseFloat(A.style.left||"0"),o=Number.parseFloat(A.style.top||"0");S={pointerId:e.pointerId,startX:e.clientX,startY:e.clientY,originLeft:n,originTop:o},e.currentTarget.setPointerCapture(e.pointerId),e.preventDefault()}function _t(e){!S||e.pointerId!==S.pointerId||ne(S.originLeft+(e.clientX-S.startX),S.originTop+(e.clientY-S.startY))}function Ee(e){if(!S||e.pointerId!==S.pointerId||!A)return;S=null;const t=Number.parseFloat(A.style.left||"0"),n=Number.parseFloat(A.style.top||"0");$t(t,n)}function y(){if(!T||!r)return;const e=T.querySelector(".panel");if(!e)return;e.classList.toggle("is-collapsed",r.collapsed);const t=T.querySelector(".title"),n=T.querySelector(".display-id");t&&(t.textContent=r.task.title),n&&(n.textContent=r.task.displayId);const o=T.querySelector('[data-action="collapse"]');o&&(o.setAttribute("aria-label",r.collapsed?f.expandOverlay:f.collapseOverlay),o.textContent=r.collapsed?"▸":"▾");const i=T.querySelector(".body");if(!i)return;if(i.replaceChildren(),r.error){const d=document.createElement("p");d.className="error",d.setAttribute("role","alert"),d.textContent=r.error,i.appendChild(d)}const s=document.createElement("p");s.className="hint",s.textContent=f.overlayDragHint,i.appendChild(s),r.helpMarkdown&&i.appendChild(zt(r.helpMarkdown));const a=ve(r.items);if(a.length===0){const d=document.createElement("p");d.className="hint",d.textContent=f.noChecklist,i.appendChild(d)}else i.appendChild(qt(a.map(d=>d.id)));if(r.taskBugOpen)i.appendChild(jt());else if(r.isBug){const d=document.createElement("button");d.type="button",d.className="btn",d.textContent=f.solveBug,d.disabled=r.busy,d.addEventListener("click",()=>{Xt()}),i.appendChild(d)}else{const d=document.createElement("button");d.type="button",d.className="btn",d.textContent=f.flagAsBug,d.disabled=r.busy,d.addEventListener("click",()=>{r&&(r.taskBugOpen=!0,r.taskNote="",r.error=null,y())}),i.appendChild(d)}}function Ft(e){const t=r.items.find(u=>u.id===e),n=document.createElement("li"),o=xt(r.items,r.expandedId);n.className=["row",t.bugged?"is-bugged":"",t.id===o?"is-current":""].filter(Boolean).join(" ");const i=document.createElement("div");i.className="row-main";const s=document.createElement("button");s.type="button",s.className=t.checked?"tick is-checked":"tick",s.setAttribute("aria-pressed",String(t.checked)),s.setAttribute("aria-label",t.checked?f.itemDone:f.itemOpen),s.disabled=r.busy;const a=document.createElement("span");a.className="tick-mark",a.setAttribute("aria-hidden","true"),s.append(a),s.addEventListener("click",()=>{Dt(t.id)});const d=ve([t])[0],p=document.createElement("button");p.type="button",p.className="expand";const x=r.expandedId===t.id;if(p.setAttribute("aria-expanded",String(x)),x)p.textContent=d.full;else{const u=document.createElement("strong");u.textContent=d.short,p.appendChild(u)}if(p.addEventListener("click",()=>{r&&(r.expandedId=r.expandedId===t.id?null:t.id,y())}),i.append(s,p),n.appendChild(i),t.notes.length){const u=document.createElement("ul");u.className="notes";for(const k of t.notes){const w=document.createElement("li");w.innerHTML="";const P=document.createElement("strong");P.textContent=`${f.motivo}: `,w.append(P,document.createTextNode(k)),u.appendChild(w)}n.appendChild(u)}if(r.reportingItemId===t.id)n.appendChild(Ht(t.id));else if(x){const u=document.createElement("div");u.className="row-actions";const k=document.createElement("button");if(k.type="button",k.className="btn",k.textContent=f.flagAsBug,k.disabled=r.busy,k.addEventListener("click",()=>{r&&(r.reportingItemId=t.id,r.itemNote="",r.error=null,y())}),u.appendChild(k),t.bugged){const w=document.createElement("button");w.type="button",w.className="btn",w.textContent=f.solveItem,w.disabled=r.busy,w.addEventListener("click",()=>{Ut(t.id)}),u.appendChild(w)}n.appendChild(u)}return n}function Ce(e,t,n,o){const i=document.createElement("button");i.type="button",i.className="section-toggle",i.setAttribute("aria-expanded",String(t));const s=document.createTextNode(e);if(i.appendChild(s),o){i.appendChild(document.createTextNode(" "));const a=document.createElement("span");a.className="section-progress",a.textContent=o,i.appendChild(a)}return i.addEventListener("click",n),i}function zt(e){const t=document.createElement("section");t.className="section";const n=!r.instructionsCollapsed;if(t.appendChild(Ce(f.instructionsHeading,n,()=>{r&&(r.instructionsCollapsed=!r.instructionsCollapsed,ke(),y())})),n){const o=document.createElement("div");o.className="help markdown-content",Ct(o,e),t.appendChild(o)}return t}function qt(e){const t=document.createElement("section");t.className="section";const n=!r.checklistCollapsed,o=r.items.filter(i=>i.checked).length;if(t.appendChild(Ce(f.checklistHeading,n,()=>{r&&(r.checklistCollapsed=!r.checklistCollapsed,ke(),y())},`${o}/${r.items.length}`)),n){const i=document.createElement("ul");i.className="list";for(const s of e)i.appendChild(Ft(s));t.appendChild(i)}return t}function Ht(e){const t=document.createElement("div");t.className="bug-form";const n=document.createElement("label");n.textContent=f.motivo;const o=document.createElement("textarea");o.value=r.itemNote,o.placeholder=f.motivoPlaceholder,o.rows=3,o.addEventListener("input",()=>{r&&(r.itemNote=o.value,s.disabled=r.busy||!r.itemNote.trim())}),n.appendChild(o);const i=document.createElement("div");i.className="row-actions";const s=document.createElement("button");s.type="button",s.className="btn btn-primary",s.textContent=f.flagAsBug,s.disabled=r.busy||!r.itemNote.trim(),s.addEventListener("click",()=>{Wt(e)});const a=document.createElement("button");return a.type="button",a.className="btn",a.textContent=f.cancelFlag,a.addEventListener("click",()=>{r&&(r.reportingItemId=null,r.itemNote="",y())}),i.append(s,a),t.append(n,i),t}function jt(){const e=document.createElement("div");e.className="bug-form";const t=document.createElement("p");t.className="warning",t.textContent=f.taskBugWarning;const n=document.createElement("label");n.textContent=f.motivo;const o=document.createElement("textarea");o.value=r.taskNote,o.placeholder=f.motivoPlaceholder,o.rows=3,o.addEventListener("input",()=>{r&&(r.taskNote=o.value,s.disabled=r.busy||!r.taskNote.trim())}),n.appendChild(o);const i=document.createElement("div");i.className="row-actions";const s=document.createElement("button");s.type="button",s.className="btn btn-primary",s.textContent=f.flagAsBug,s.disabled=r.busy||!r.taskNote.trim(),s.addEventListener("click",()=>{Yt()});const a=document.createElement("button");return a.type="button",a.className="btn",a.textContent=f.cancelFlag,a.addEventListener("click",()=>{r&&(r.taskBugOpen=!1,r.taskNote="",y())}),i.append(s,a),e.append(t,n,i),e}function H(e){if(!r)return!1;const t=Tt(e);if(t)return r.error=t,!1;if(r.error=null,e.items){r.items=e.items;const n=r.expandedId;n&&!e.items.some(o=>o.id===n)&&(r.expandedId=null)}return e.snapshot&&(r.snapshot=e.snapshot),e.helpMarkdown!==void 0&&(r.helpMarkdown=e.helpMarkdown??null),e.isBug!==void 0&&(r.isBug=e.isBug),!0}async function Ie(){if(r){r.busy=!0,y();try{const e=await b.runtime.sendMessage({type:"task.get",task:r.task});H(e)}finally{r&&(r.busy=!1),y()}}}async function Dt(e){if(!(!r||r.busy)){r.busy=!0,r.error=null,y();try{const t=await b.runtime.sendMessage({type:"checklist.tick",task:r.task,itemId:e,snapshot:r.snapshot,source:"overlay"});if(H(t),r){const n=r.items.find(o=>o.id===e);n!=null&&n.checked?r.expandedId=ht(r.items,e):r.expandedId=e}}finally{r&&(r.busy=!1),y()}}}async function Wt(e){if(!(!r||r.busy)){if(!r.itemNote.trim()){r.error=f.itemMotivoRequired,y();return}r.busy=!0,r.error=null,y();try{const t=await b.runtime.sendMessage({type:"checklist.flagItem",task:r.task,itemId:e,note:r.itemNote,snapshot:r.snapshot,source:"overlay"});H(t)&&(r.reportingItemId=null,r.itemNote="")}finally{r&&(r.busy=!1),y()}}}async function Yt(){if(!(!r||r.busy)){if(!r.taskNote.trim()){r.error=f.motivoRequired,y();return}r.busy=!0,r.error=null,y();try{const e=await b.runtime.sendMessage({type:"task.flag",task:r.task,note:r.taskNote,source:"overlay"});H(e)&&(r.taskBugOpen=!1,r.taskNote="")}finally{r&&(r.busy=!1),y()}}}async function Ut(e){if(!(!r||r.busy)){r.busy=!0,r.error=null,y();try{const t=await b.runtime.sendMessage({type:"checklist.unflagItem",task:r.task,itemId:e,snapshot:r.snapshot,source:"overlay"});H(t)}finally{r&&(r.busy=!1),y()}}}async function Xt(){if(!(!r||r.busy)){r.busy=!0,r.error=null,y();try{const e=await b.runtime.sendMessage({type:"task.unflag",task:r.task,source:"overlay"});H(e)}finally{r&&(r.busy=!1),y()}}}function Vt(){const{shadow:e}=Mt();if(e.querySelector(".panel"))return;const n=document.createElement("div");n.className="panel",n.setAttribute("role","dialog"),n.setAttribute("aria-label","Checklist");const o=document.createElement("div");o.className="header",o.addEventListener("pointerdown",Ot),o.addEventListener("pointermove",_t),o.addEventListener("pointerup",Ee),o.addEventListener("pointercancel",Ee);const i=document.createElement("div");i.className="header-text";const s=document.createElement("p");s.className="display-id";const a=document.createElement("h2");a.className="title",i.append(s,a);const d=document.createElement("div");d.className="header-actions";const p=document.createElement("button");p.type="button",p.className="icon-btn",p.dataset.action="collapse",p.addEventListener("click",()=>{r&&(r.collapsed=!r.collapsed,y())});const x=document.createElement("button");x.type="button",x.className="icon-btn",x.setAttribute("aria-label",f.closeFloatingChecklist),x.textContent="×",x.addEventListener("click",()=>{Ne()}),d.append(p,x),o.append(i,d);const u=document.createElement("div");u.className="body",n.append(o,u),e.appendChild(n),window.addEventListener("resize",we)}function Gt(e){window===window.top&&(Vt(),r={task:e,items:[],snapshot:{items:[]},expandedId:null,reportingItemId:null,itemNote:"",taskBugOpen:!1,taskNote:"",collapsed:!1,instructionsCollapsed:G.instructionsCollapsed,checklistCollapsed:G.checklistCollapsed,helpMarkdown:null,isBug:!1,busy:!1,error:null},A&&(A.style.display="block"),y(),Promise.all([Rt(),Bt()]).then(([,t])=>{r&&(r.instructionsCollapsed=t.instructionsCollapsed,r.checklistCollapsed=t.checklistCollapsed,y(),Ie())}))}function Ne(){S=null,r=null,window.removeEventListener("resize",we),A==null||A.remove(),A=null,T=null}function Kt(){window===window.top&&b.runtime.onMessage.addListener(e=>{if(!e||typeof e!="object"||!("type"in e))return;const t=e.type;if(t==="overlay.open"){const n=e.task;n!=null&&n.id&&Gt(n)}if(t==="overlay.close"&&Ne(),t==="qa.checklistChanged"){if(!r||e.taskId!==r.task.id||!yt("overlay",e.source))return;Ie()}})}const Zt=".task-card[data-task-id], .task-list-row[data-task-id]",Y="arc-todo-card-highlight";function Qt(e){return e.length===0?null:[...e].reverse().find(n=>!n.className.split(/\s+/).includes("is-subtask"))??e[0]}function Jt(e){var a,d,p,x,u;const t=(a=e.taskId)==null?void 0:a.trim(),n=(d=e.displayId)==null?void 0:d.trim(),o=(p=e.organizationId)==null?void 0:p.trim(),i=(x=e.projectId)==null?void 0:x.trim(),s=((u=e.taskTitle)==null?void 0:u.trim())||n;return!t||!n||!s||!o||!i?null:{id:t,displayId:n,title:s,organizationId:o,projectId:i}}let z=!1,Se="";function Le(e){let t=e.getElementById(Y);return t||(t=e.createElement("div"),t.id=Y,t.setAttribute("aria-hidden","true"),Object.assign(t.style,{position:"fixed",pointerEvents:"none",zIndex:"2147483647",outline:"2px solid #4862ce",outlineOffset:"2px",background:"rgba(72, 98, 206, 0.14)",borderRadius:"18px",boxSizing:"border-box",display:"none"}),e.documentElement.appendChild(t),t)}function en(e){const t=[];let n=e;for(;n;){const o=n.closest(Zt);if(!(o instanceof HTMLElement))break;t.push(o),n=o.parentElement}return t}function Te(e,t,n){const o=e.elementFromPoint(t,n);return!o||o.id===Y||o.id===_||o.closest(`#${_}`)?null:Qt(en(o))}function tn(e,t){const n=Le(e);if(!t){n.style.display="none";return}const o=t.getBoundingClientRect();n.style.display="block",n.style.left=`${o.left}px`,n.style.top=`${o.top}px`,n.style.width=`${o.width}px`,n.style.height=`${o.height}px`}function Me(e){z&&tn(document,Te(document,e.clientX,e.clientY))}function Pe(e){if(!z)return;const t=Te(document,e.clientX,e.clientY);if(!t)return;const n=Jt({taskId:t.dataset.taskId,displayId:t.dataset.displayId,taskTitle:t.dataset.taskTitle,organizationId:t.dataset.organizationId,projectId:t.dataset.projectId});n&&(e.preventDefault(),e.stopPropagation(),e.stopImmediatePropagation(),re(),b.runtime.sendMessage({type:"card.picked",task:n}))}function $e(e){!z||e.key!=="Escape"||(e.preventDefault(),re(),b.runtime.sendMessage({type:"card.cancelled"}))}function nn(){window===window.top&&(z||(z=!0,Se=document.documentElement.style.cursor,document.documentElement.style.cursor="pointer",Le(document),document.addEventListener("mousemove",Me,!0),document.addEventListener("click",Pe,!0),document.addEventListener("keydown",$e,!0)))}function re(){var e;!z&&!document.getElementById(Y)||(z=!1,document.documentElement.style.cursor=Se,document.removeEventListener("mousemove",Me,!0),document.removeEventListener("click",Pe,!0),document.removeEventListener("keydown",$e,!0),(e=document.getElementById(Y))==null||e.remove())}function rn(){window===window.top&&b.runtime.onMessage.addListener(e=>{if(!e||typeof e!="object"||!("type"in e))return;const t=e.type;t==="card.arm"&&nn(),t==="card.disarm"&&re()})}const on=6,sn=200,an=3;function ln(e){return{color:(e==null?void 0:e.color)??"",fontSize:(e==null?void 0:e.fontSize)??"",display:(e==null?void 0:e.display)??""}}function Be(e){const{x:t,y:n,width:o,height:i}=e.rect;return`${e.selector}@${Math.round(t)},${Math.round(n)},${Math.round(o)},${Math.round(i)}`}function K(e){return typeof CSS<"u"&&typeof CSS.escape=="function"?CSS.escape(e):e.replace(/([^\w-])/g,"\\$1")}function cn(e){return e.filter(t=>/^[A-Za-z_][\w-]*$/.test(t)).slice(0,an)}function dn(e,t=sn){const n=(e??"").replace(/\s+/g," ").trim();return n.length<=t?n:n.slice(0,t)}function un(e){const t=e.parentElement;return t?Array.from(t.children).indexOf(e)+1:1}function mn(e,t){if(!t)return!1;try{return e.querySelectorAll(`#${K(t)}`).length===1}catch{return!1}}function Re(e){return{tagName:e.tagName,id:e.id,classes:Array.from(e.classList),nthChild:un(e),parent:e.parentElement?Re(e.parentElement):null}}function gn(e){const t=e.tagName.toLowerCase();if(t==="html"||t==="body")return t;const n=cn(e.classes);let o=t;return n.length&&(o+=n.map(i=>`.${K(i)}`).join("")),e.nthChild>0&&(o+=`:nth-child(${e.nthChild})`),o}function pn(e,t,n=on){if(e.id&&t(e.id))return`#${K(e.id)}`;const o=[];let i=e,s=0;for(;i&&s<n;){if(i.id&&t(i.id)){o.unshift(`#${K(i.id)}`);break}if(o.unshift(gn(i)),i.tagName.toLowerCase()==="html")break;i=i.parent,s+=1}return o.join(" > ")}function fn(e,t){const n=e.getBoundingClientRect(),o=typeof getComputedStyle=="function"?getComputedStyle(e):void 0;return{tag:e.tagName.toLowerCase(),id:e.id,classes:Array.from(e.classList),text:dn(e.textContent),title:t.document.title??"",url:t.locationHref??(typeof location<"u"?location.href:""),selector:pn(Re(e),i=>mn(t.document,i)),rect:{x:n.left,y:n.top,width:n.width,height:n.height},viewport:{width:t.innerWidth,height:t.innerHeight},computed:ln(o)}}function hn(e,t){const n=e.classes.length?e.classes.join(", "):"(none)";return`\`\`\`markdown
${["## Element","",`- Selector: \`${e.selector}\``,`- Tag: ${e.tag}`,`- Id: ${e.id||"(none)"}`,`- Classes: ${n}`,`- Text: ${e.text||"(none)"}`,`- Title: ${e.title||"(none)"}`,`- URL: ${e.url}`,"- Screenshot: omitted"].join(`
`)}
\`\`\``}function xn(e){if(!e||typeof e!="object")return"dev";const t=e.purpose;return t==="qa-crop"||t==="qa-record"||t==="design"?t:"dev"}function yn(e){return e==="dev"}function bn(e){return e!=="design"}function An(e,t,n){return e==="qa-crop"?{type:"capture.elementPicked",hit:t}:e==="qa-record"?{type:"capture.elementForRecord",hit:t}:{type:"picker.picked",hit:t,keepArmed:e==="design",removed:n==null?void 0:n.removed}}const U="arc-todo-picker-hover",Oe="arc-todo-picker-selected",_e=["pointerdown","mousedown","mouseup","auxclick","contextmenu","dblclick"];let R=!1,M="dev",Fe="",ze=0;const L=new Map;function qe(){return{position:"fixed",pointerEvents:"none",zIndex:"2147483647",outline:"2px solid #4862ce",outlineOffset:"1px",background:"rgba(72, 98, 206, 0.12)",boxSizing:"border-box",display:"none"}}function oe(e,t){e.style.display="block",e.style.left=`${t.left}px`,e.style.top=`${t.top}px`,e.style.width=`${t.width}px`,e.style.height=`${t.height}px`}function ie(e){let t=e.getElementById(U);return t||(t=e.createElement("div"),t.id=U,t.setAttribute("aria-hidden","true"),Object.assign(t.style,qe()),e.documentElement.appendChild(t),t)}function vn(e){const t=e.createElement("div");return t.className=Oe,t.id=`arc-todo-picker-selected-${ze}`,ze+=1,t.setAttribute("aria-hidden","true"),Object.assign(t.style,qe(),{display:"block"}),e.documentElement.appendChild(t),t}function kn(e){return e?e.id===_?!0:!!e.closest(`#${_}`):!1}function wn(e){return e?e.id===U||e.classList.contains(Oe)||kn(e):!1}function He(e,t,n){const o=e.elementFromPoint(t,n);return!o||wn(o)?null:o}function je(e){R&&(e.preventDefault(),e.stopPropagation(),e.stopImmediatePropagation())}function En(e,t){const n=ie(e);if(!t){n.style.display="none";return}oe(n,t.getBoundingClientRect())}function De(e){return fn(e,{document,innerWidth:window.innerWidth,innerHeight:window.innerHeight,locationHref:location.href})}function Cn(e){if(L.has(e))return e;for(const t of L.keys())if(Be(L.get(t).hit)===Be(De(e)))return t;return null}function In(e,t){const n=vn(document);oe(n,e.getBoundingClientRect()),L.set(e,{hit:t,box:n})}function We(e){const t=L.get(e);return t==null||t.box.remove(),L.delete(e),t==null?void 0:t.hit}function Ye(){for(const e of L.values())e.box.remove();L.clear()}function Nn(){for(const[e,t]of L){if(!e.isConnected){We(e);continue}oe(t.box,e.getBoundingClientRect())}}function Ue(e){R&&En(document,He(document,e.clientX,e.clientY))}function Z(){!R||M!=="design"||Nn()}async function Sn(){return{error:"idle"}}async function Xe(e){if(!R)return;const t=He(document,e.clientX,e.clientY);if(!t)return;e.preventDefault(),e.stopPropagation(),e.stopImmediatePropagation();const n=Cn(t),o=M==="design"&&(!!n||e.shiftKey),i=o&&n?L.get(n).hit:De(t);if(M==="design")if(o&&n)We(n);else if(!o)In(t,i);else return;if(yn(M)){const a=hn(i);try{await navigator.clipboard.writeText(a)}catch{}}const s=An(M,i,{removed:o});bn(M)&&se(),b.runtime.sendMessage(s)}function Ve(e){!R||e.key!=="Escape"||(e.preventDefault(),se(),b.runtime.sendMessage({type:"picker.cancelled"}))}function Ln(e="dev"){if(window===window.top){if(R){M!==e&&(Ye(),ie(document).style.display="none"),M=e;return}R=!0,M=e,Fe=document.documentElement.style.cursor,document.documentElement.style.cursor="crosshair",ie(document),document.addEventListener("mousemove",Ue,!0),document.addEventListener("click",Xe,!0),document.addEventListener("keydown",Ve,!0);for(const t of _e)document.addEventListener(t,je,!0);window.addEventListener("scroll",Z,!0),window.addEventListener("resize",Z)}}function se(){var e;if(!(!R&&!document.getElementById(U)&&L.size===0)){R=!1,M="dev",document.documentElement.style.cursor=Fe,document.removeEventListener("mousemove",Ue,!0),document.removeEventListener("click",Xe,!0),document.removeEventListener("keydown",Ve,!0);for(const t of _e)document.removeEventListener(t,je,!0);window.removeEventListener("scroll",Z,!0),window.removeEventListener("resize",Z),(e=document.getElementById(U))==null||e.remove(),Ye()}}function Tn(){window===window.top&&b.runtime.onMessage.addListener(e=>{if(!e||typeof e!="object"||!("type"in e))return;const t=e.type;if(t==="picker.arm"&&Ln(xn(e)),t==="picker.disarm"&&se(),t==="capture.stopElementRecord")return Sn()})}const Ge=window;function Mn(e){return!!(e&&typeof e=="object"&&e.type==="content.ping")}b.runtime.onMessage.addListener(e=>{if(Mn(e))return Promise.resolve(!0)}),Ge.__arcTodoContentReady||(Ge.__arcTodoContentReady=!0,window.addEventListener(nt,e=>{const t=e.detail;typeof t=="string"&&b.runtime.sendMessage({type:"capture.console",payload:t})}),b.runtime.sendMessage({type:"capture.pageReady"}),Tn(),pt(),rn(),Kt())})();
