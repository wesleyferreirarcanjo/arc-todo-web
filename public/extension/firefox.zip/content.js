(function(){"use strict";function gn(e){return e&&e.__esModule&&Object.prototype.hasOwnProperty.call(e,"default")?e.default:e}var ce={exports:{}},fn=ce.exports,Ze;function hn(){return Ze||(Ze=1,(function(e,t){(function(n,r){r(e)})(typeof globalThis<"u"?globalThis:typeof self<"u"?self:fn,function(n){if(!(globalThis.chrome&&globalThis.chrome.runtime&&globalThis.chrome.runtime.id))throw new Error("This script should only be loaded in a browser extension.");if(globalThis.browser&&globalThis.browser.runtime&&globalThis.browser.runtime.id)n.exports=globalThis.browser;else{const r="The message port closed before a response was received.",o=i=>{const s={alarms:{clear:{minArgs:0,maxArgs:1},clearAll:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getAll:{minArgs:0,maxArgs:0}},bookmarks:{create:{minArgs:1,maxArgs:1},get:{minArgs:1,maxArgs:1},getChildren:{minArgs:1,maxArgs:1},getRecent:{minArgs:1,maxArgs:1},getSubTree:{minArgs:1,maxArgs:1},getTree:{minArgs:0,maxArgs:0},move:{minArgs:2,maxArgs:2},remove:{minArgs:1,maxArgs:1},removeTree:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1},update:{minArgs:2,maxArgs:2}},browserAction:{disable:{minArgs:0,maxArgs:1,fallbackToNoCallback:!0},enable:{minArgs:0,maxArgs:1,fallbackToNoCallback:!0},getBadgeBackgroundColor:{minArgs:1,maxArgs:1},getBadgeText:{minArgs:1,maxArgs:1},getPopup:{minArgs:1,maxArgs:1},getTitle:{minArgs:1,maxArgs:1},openPopup:{minArgs:0,maxArgs:0},setBadgeBackgroundColor:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setBadgeText:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setIcon:{minArgs:1,maxArgs:1},setPopup:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setTitle:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},browsingData:{remove:{minArgs:2,maxArgs:2},removeCache:{minArgs:1,maxArgs:1},removeCookies:{minArgs:1,maxArgs:1},removeDownloads:{minArgs:1,maxArgs:1},removeFormData:{minArgs:1,maxArgs:1},removeHistory:{minArgs:1,maxArgs:1},removeLocalStorage:{minArgs:1,maxArgs:1},removePasswords:{minArgs:1,maxArgs:1},removePluginData:{minArgs:1,maxArgs:1},settings:{minArgs:0,maxArgs:0}},commands:{getAll:{minArgs:0,maxArgs:0}},contextMenus:{remove:{minArgs:1,maxArgs:1},removeAll:{minArgs:0,maxArgs:0},update:{minArgs:2,maxArgs:2}},cookies:{get:{minArgs:1,maxArgs:1},getAll:{minArgs:1,maxArgs:1},getAllCookieStores:{minArgs:0,maxArgs:0},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}},devtools:{inspectedWindow:{eval:{minArgs:1,maxArgs:2,singleCallbackArg:!1}},panels:{create:{minArgs:3,maxArgs:3,singleCallbackArg:!0},elements:{createSidebarPane:{minArgs:1,maxArgs:1}}}},downloads:{cancel:{minArgs:1,maxArgs:1},download:{minArgs:1,maxArgs:1},erase:{minArgs:1,maxArgs:1},getFileIcon:{minArgs:1,maxArgs:2},open:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},pause:{minArgs:1,maxArgs:1},removeFile:{minArgs:1,maxArgs:1},resume:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1},show:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},extension:{isAllowedFileSchemeAccess:{minArgs:0,maxArgs:0},isAllowedIncognitoAccess:{minArgs:0,maxArgs:0}},history:{addUrl:{minArgs:1,maxArgs:1},deleteAll:{minArgs:0,maxArgs:0},deleteRange:{minArgs:1,maxArgs:1},deleteUrl:{minArgs:1,maxArgs:1},getVisits:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1}},i18n:{detectLanguage:{minArgs:1,maxArgs:1},getAcceptLanguages:{minArgs:0,maxArgs:0}},identity:{launchWebAuthFlow:{minArgs:1,maxArgs:1}},idle:{queryState:{minArgs:1,maxArgs:1}},management:{get:{minArgs:1,maxArgs:1},getAll:{minArgs:0,maxArgs:0},getSelf:{minArgs:0,maxArgs:0},setEnabled:{minArgs:2,maxArgs:2},uninstallSelf:{minArgs:0,maxArgs:1}},notifications:{clear:{minArgs:1,maxArgs:1},create:{minArgs:1,maxArgs:2},getAll:{minArgs:0,maxArgs:0},getPermissionLevel:{minArgs:0,maxArgs:0},update:{minArgs:2,maxArgs:2}},pageAction:{getPopup:{minArgs:1,maxArgs:1},getTitle:{minArgs:1,maxArgs:1},hide:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setIcon:{minArgs:1,maxArgs:1},setPopup:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setTitle:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},show:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},permissions:{contains:{minArgs:1,maxArgs:1},getAll:{minArgs:0,maxArgs:0},remove:{minArgs:1,maxArgs:1},request:{minArgs:1,maxArgs:1}},runtime:{getBackgroundPage:{minArgs:0,maxArgs:0},getPlatformInfo:{minArgs:0,maxArgs:0},openOptionsPage:{minArgs:0,maxArgs:0},requestUpdateCheck:{minArgs:0,maxArgs:0},sendMessage:{minArgs:1,maxArgs:3},sendNativeMessage:{minArgs:2,maxArgs:2},setUninstallURL:{minArgs:1,maxArgs:1}},sessions:{getDevices:{minArgs:0,maxArgs:1},getRecentlyClosed:{minArgs:0,maxArgs:1},restore:{minArgs:0,maxArgs:1}},storage:{local:{clear:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}},managed:{get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1}},sync:{clear:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}}},tabs:{captureVisibleTab:{minArgs:0,maxArgs:2},create:{minArgs:1,maxArgs:1},detectLanguage:{minArgs:0,maxArgs:1},discard:{minArgs:0,maxArgs:1},duplicate:{minArgs:1,maxArgs:1},executeScript:{minArgs:1,maxArgs:2},get:{minArgs:1,maxArgs:1},getCurrent:{minArgs:0,maxArgs:0},getZoom:{minArgs:0,maxArgs:1},getZoomSettings:{minArgs:0,maxArgs:1},goBack:{minArgs:0,maxArgs:1},goForward:{minArgs:0,maxArgs:1},highlight:{minArgs:1,maxArgs:1},insertCSS:{minArgs:1,maxArgs:2},move:{minArgs:2,maxArgs:2},query:{minArgs:1,maxArgs:1},reload:{minArgs:0,maxArgs:2},remove:{minArgs:1,maxArgs:1},removeCSS:{minArgs:1,maxArgs:2},sendMessage:{minArgs:2,maxArgs:3},setZoom:{minArgs:1,maxArgs:2},setZoomSettings:{minArgs:1,maxArgs:2},update:{minArgs:1,maxArgs:2}},topSites:{get:{minArgs:0,maxArgs:0}},webNavigation:{getAllFrames:{minArgs:1,maxArgs:1},getFrame:{minArgs:1,maxArgs:1}},webRequest:{handlerBehaviorChanged:{minArgs:0,maxArgs:0}},windows:{create:{minArgs:0,maxArgs:1},get:{minArgs:1,maxArgs:2},getAll:{minArgs:0,maxArgs:1},getCurrent:{minArgs:0,maxArgs:1},getLastFocused:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},update:{minArgs:2,maxArgs:2}}};if(Object.keys(s).length===0)throw new Error("api-metadata.json has not been included in browser-polyfill");class c extends WeakMap{constructor(g,x=void 0){super(x),this.createItem=g}get(g){return this.has(g)||this.set(g,this.createItem(g)),super.get(g)}}const d=m=>m&&typeof m=="object"&&typeof m.then=="function",p=(m,g)=>(...x)=>{i.runtime.lastError?m.reject(new Error(i.runtime.lastError.message)):g.singleCallbackArg||x.length<=1&&g.singleCallbackArg!==!1?m.resolve(x[0]):m.resolve(x)},u=m=>m==1?"argument":"arguments",f=(m,g)=>function(y,...L){if(L.length<g.minArgs)throw new Error(`Expected at least ${g.minArgs} ${u(g.minArgs)} for ${m}(), got ${L.length}`);if(L.length>g.maxArgs)throw new Error(`Expected at most ${g.maxArgs} ${u(g.maxArgs)} for ${m}(), got ${L.length}`);return new Promise((I,B)=>{if(g.fallbackToNoCallback)try{y[m](...L,p({resolve:I,reject:B},g))}catch(h){console.warn(`${m} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `,h),y[m](...L),g.fallbackToNoCallback=!1,g.noCallback=!0,I()}else g.noCallback?(y[m](...L),I()):y[m](...L,p({resolve:I,reject:B},g))})},k=(m,g,x)=>new Proxy(g,{apply(y,L,I){return x.call(L,m,...I)}});let D=Function.call.bind(Object.prototype.hasOwnProperty);const Q=(m,g={},x={})=>{let y=Object.create(null),L={has(B,h){return h in m||h in y},get(B,h,O){if(h in y)return y[h];if(!(h in m))return;let S=m[h];if(typeof S=="function")if(typeof g[h]=="function")S=k(m,m[h],g[h]);else if(D(x,h)){let re=f(h,x[h]);S=k(m,m[h],re)}else S=S.bind(m);else if(typeof S=="object"&&S!==null&&(D(g,h)||D(x,h)))S=Q(S,g[h],x[h]);else if(D(x,"*"))S=Q(S,g[h],x["*"]);else return Object.defineProperty(y,h,{configurable:!0,enumerable:!0,get(){return m[h]},set(re){m[h]=re}}),S;return y[h]=S,S},set(B,h,O,S){return h in y?y[h]=O:m[h]=O,!0},defineProperty(B,h,O){return Reflect.defineProperty(y,h,O)},deleteProperty(B,h){return Reflect.deleteProperty(y,h)}},I=Object.create(m);return new Proxy(I,L)},H=m=>({addListener(g,x,...y){g.addListener(m.get(x),...y)},hasListener(g,x){return g.hasListener(m.get(x))},removeListener(g,x){g.removeListener(m.get(x))}}),zo=new c(m=>typeof m!="function"?m:function(x){const y=Q(x,{},{getContent:{minArgs:0,maxArgs:0}});m(y)}),mn=new c(m=>typeof m!="function"?m:function(x,y,L){let I=!1,B,h=new Promise(se=>{B=function(j){I=!0,se(j)}}),O;try{O=m(x,y,B)}catch(se){O=Promise.reject(se)}const S=O!==!0&&d(O);if(O!==!0&&!S&&!I)return!1;const re=se=>{se.then(j=>{L(j)},j=>{let Ke;j&&(j instanceof Error||typeof j.message=="string")?Ke=j.message:Ke="An unexpected error occurred",L({__mozWebExtensionPolyfillReject__:!0,message:Ke})}).catch(j=>{console.error("Failed to send onMessage rejected reply",j)})};return re(S?O:h),!0}),_o=({reject:m,resolve:g},x)=>{i.runtime.lastError?i.runtime.lastError.message===r?g():m(new Error(i.runtime.lastError.message)):x&&x.__mozWebExtensionPolyfillReject__?m(new Error(x.message)):g(x)},pn=(m,g,x,...y)=>{if(y.length<g.minArgs)throw new Error(`Expected at least ${g.minArgs} ${u(g.minArgs)} for ${m}(), got ${y.length}`);if(y.length>g.maxArgs)throw new Error(`Expected at most ${g.maxArgs} ${u(g.maxArgs)} for ${m}(), got ${y.length}`);return new Promise((L,I)=>{const B=_o.bind(null,{resolve:L,reject:I});y.push(B),x.sendMessage(...y)})},Do={devtools:{network:{onRequestFinished:H(zo)}},runtime:{onMessage:H(mn),onMessageExternal:H(mn),sendMessage:pn.bind(null,"sendMessage",{minArgs:1,maxArgs:3})},tabs:{sendMessage:pn.bind(null,"sendMessage",{minArgs:2,maxArgs:3})}},Ve={clear:{minArgs:1,maxArgs:1},get:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}};return s.privacy={network:{"*":Ve},services:{"*":Ve},websites:{"*":Ve}},Q(i,Do,s)};n.exports=o(chrome)}})})(ce)),ce.exports}var bn=hn();const A=gn(bn),v={appName:"Arc Todo",modeToggleLabel:"Modo do painel",modeQa:"Modo QA",modeDev:"Modo desenvolvedor",modeDesign:"Modo design",modeSettings:"Settings",skipToContent:"Pular para o conteúdo",designHeading:"Notas de design",designPick:"Escolher elementos",designNote:"O que deve mudar",designNotePlaceholder:"Descreva o que a IA deve alterar neste elemento",designEmpty:"Toque nos elementos da página para comentar.",designRemove:"Remover",designExit:"Sair",designClear:"Limpar",designCopyEmpty:"Escolha um elemento para copiar.",designCaptureFailed:"Não foi possível capturar a imagem.",designLiveCss:"CSS ao vivo",designCssInvalid:"Este CSS não pôde ser aplicado. Corrija o texto e tente de novo.",designRemoveCss:"Remover CSS",designCopyLive:"Copiar ao vivo",designPasteCss:"Colar CSS",designCopyLiveEmpty:"Escreva o CSS ao vivo para copiar.",designPasteCssFailed:"Não foi possível colar o CSS. Cole com Ctrl+V no campo.",designPasteCssEmpty:"A área de transferência não tem CSS.",signInFirst:"Entre no Arc Todo para usar este painel.",sessionExpired:"Sessão expirada. Entre de novo no Arc Todo.",apiError:"Não foi possível falar com a API. Tente de novo.",loading:"Carregando…",openArcTodo:"Abrir Arc Todo e entrar",retry:"Tentar de novo",qaQueue:"Fila de QA",viewToggleLabel:"Como ver a fila",viewCards:"Cards",viewChecklist:"Checklist",emptyQueue:"Nenhum card na fila de QA. Adicione pais da lista abaixo.",addAllParents:"Adicionar todos os pais",removeFromQueue:"Remover",switchQaProject:"Trocar o projeto de QA",switchQaProjectConfirm:"Trocar de projeto",switchQaProjectHint:"Sua fila de QA já tem cards de outro projeto. Confirme a troca para substituir esse lote, ou mantenha a fila atual.",queueAlreadyQueued:"Esse card já está na sua fila de QA.",projectLabel:"Projeto",projectHint:"Sigla ou nome",statusLabel:"Status",assigneeLabel:"Responsável",startSession:"Iniciar sessão de teste",stopSession:"Encerrar sessão de teste",discardSession:"Descartar sessão",captureRegion:"Capturar região",captureElement:"Capturar elemento",freeArea:"Área livre",sessionBadge:"Sessão",captureHeading:"Captura",capturedErrors:"erros capturados",emptyCapture:"Nenhum erro capturado ainda.",captureWindow:"Janela",captureWindow30s:"Últimos 30 s",captureWindow60s:"Últimos 60 s",captureWindow2m:"Últimos 2 min",captureWindowSession:"Sessão inteira",frozenHint:"Sessão encerrada. Os eventos ficam congelados até você descartar.",needWebPage:"Abra uma página web para capturar.",pageBlocked:"Esta página do navegador não permite seleção de elementos. Abra uma página normal.",needQueue:"Capture só com um card na fila de QA.",needSelectedTask:"Escolha um card da fila de QA para marcar o bug.",captureFailed:"Não foi possível capturar a região.",annotateRect:"Retângulo",annotateArrow:"Seta",annotateFreehand:"Traço",saveCapture:"Guardar",discardCapture:"Descartar captura",cancelCrop:"Cancelar",openInArcTodo:"Abrir no Arc Todo",reloadChecklist:"Recarregar",flagAsBug:"Marcar como bug",motivo:"Motivo",motivoPlaceholder:"Descreva o problema encontrado",motivoRequired:"O motivo do bug é obrigatório.",itemMotivoRequired:"O motivo do bug do item é obrigatório.",taskBugWarning:"Este card volta para To Do, inclusive as subtarefas.",checklistChanged:"A checklist mudou. Recarregue e tente de novo.",noChecklist:"Esta tarefa não tem checklist.",logsUnavailable:"Não foi possível guardar o log da sessão. O bug foi marcado, mas o log não chegou ao card.",evidenceFailed:"Não foi possível enviar a captura. O bug foi marcado mesmo assim.",cancelFlag:"Cancelar",pickElement:"Escolher elemento",pickerEmpty:"Escolha um elemento da página para copiar os detalhes.",copy:"Copiar",copied:"Copiado",copyWithScreenshot:"Copiar com captura",copyImage:"Copiar imagem",copyBusy:"Copiando…",itemDone:"Feito",itemOpen:"A fazer",startRecord:"Gravar tela",recordElement:"Gravar elemento",recordElementHint:"A gravação fica só no elemento escolhido. O Chrome pede para compartilhar esta aba.",stopRecord:"Parar gravação",recordingLabel:"Gravando",recordWarning:"Fechar o painel perde a gravação",recordFailed:"Não foi possível gravar a tela.",recordUploadFailed:"Não foi possível enviar o clipe.",recordUploaded:"Clipe enviado.",copyForAi:"Copiar para IA",openEnvironment:"Abrir ambiente",openFloatingChecklist:"Abrir checklist flutuante",closeFloatingChecklist:"Fechar checklist flutuante",collapseOverlay:"Recolher",expandOverlay:"Expandir",overlayDragHint:"Arraste pelo cabeçalho",overlayLoading:"Carregando a checklist…",retestHeading:"Retestar",lastMotivo:"Último Motivo",previousEvidence:"Evidências anteriores",previousLogs:"Logs anteriores",noPreviousEvidence:"Sem evidências anteriores.",backToQueue:"Voltar para a fila",focusedStepEyebrow:"Passo em foco",instructionsHeading:"Instruções",checklistHeading:"Checklist",attachEvidence:"Anexar evidência",evidenceAttached:"Evidência anexada.",attachFailed:"Não foi possível anexar a evidência.",evidenceGoesHere:"Capturas e clipes deste passo anexam neste item.",composeHeading:"Nota e evidências",composeNote:"Nota",composePlaceholder:"Escreva o que aconteceu",composeSend:"Enviar",composeSending:"Enviando…",composeEdit:"Editar",composeRemove:"Remover",composeWillAttachBug:"Estas evidências vão juntas no próximo Marcar como bug.",composeWillFlag:"Enviar anexa neste passo e marca como bug.",composeToTask:"Foco neste card.",needFocusedItem:"Foque um passo da checklist para capturar ou gravar.",solveBug:"Marcar como resolvido",solveItem:"Resolvido",focusTask:"Focar neste card",focusItem:"Focar neste passo",updateAvailable:"Nova versão disponível",updateHint:"Escolha a pasta descompactada que você carregou no navegador. Da próxima vez, um clique basta.",updateFirefoxHint:"Baixe o zip e carregue de novo em about:debugging. A extensão temporária some ao fechar o Firefox.",updateAction:"Atualizar",updateDownload:"Baixar zip",updateDismiss:"Agora não",updateBusy:"Atualizando…",updateFailed:"Não foi possível atualizar. Baixe o zip e carregue de novo.",updateWrongFolder:"Essa pasta não é a extensão Arc Todo. Escolha a pasta descompactada com manifest.json.",agentHeading:"Agente do navegador",agentEnable:"Permitir que esta Chrome seja operada",agentEnabled:"Modo agente ligado",agentConsent:"Quando uma IA pedir para operar",agentConsentOff:"Desligado",agentConsentAlways:"Sempre",agentConsentAsk:"Perguntar",agentAskPrompt:"Permitir esta ferramenta de IA?",agentAllow:"Permitir",agentDeny:"Recusar",agentStop:"Parar",agentConnected:"Conectado ao Arc Browser.",agentDisconnected:"Desconectado.",agentNeedSignIn:"Entre no Arc Todo primeiro para registrar este navegador.",agentSessionLive:"Sessão ao vivo"},Je="arc-todo-agent-overlay",et="arc-todo-agent-cursor",tt="arc-todo-agent-stop";function xe(){return document.getElementById(Je)}function xn(e,t){var o;let n=xe();if(!n){n=document.createElement("div"),n.id=Je,n.setAttribute("data-arc-todo-agent","1");const i=n.attachShadow({mode:"open"}),s=document.createElement("style");s.textContent=`
      :host {
        all: initial;
        --text-primary: #e8ecf4;
        --accent: #3d52b8;
        --accent-contrast: #f7f8fc;
        --z-overlay: 2147483646;
      }
      .wrap {
        position: fixed; inset: 0; pointer-events: none;
        z-index: var(--z-overlay);
      }
      .cursor {
        position: absolute; width: 22px; height: 22px; margin: -2px 0 0 -2px;
        filter: drop-shadow(0 0 6px var(--glow));
      }
      .cursor-path { fill: var(--text-primary); stroke: var(--accent); }
      .stop {
        pointer-events: auto; position: fixed; top: 12px; right: 12px;
        font: 600 12px system-ui, sans-serif; color: var(--accent-contrast);
        background: var(--accent); border: 0; border-radius: 6px;
        padding: 6px 10px;
        box-shadow: 0 0 16px var(--glow); cursor: pointer;
      }
      @media (prefers-reduced-motion: no-preference) {
        .cursor { transition: transform 80ms linear; }
      }
    `;const c=document.createElement("div");c.className="wrap";const d=document.createElement("div");d.id=et,d.className="cursor",d.setAttribute("aria-hidden","true"),d.innerHTML='<svg viewBox="0 0 24 24" width="22" height="22" xmlns="http://www.w3.org/2000/svg"><path class="cursor-path" d="M4 2l16 12-7 1 4 8-4 1-4-8-5 4z" stroke-width="1.2"/></svg>';const p=document.createElement("button");p.id=tt,p.className="stop",p.type="button",p.textContent=v.agentStop,c.append(d,p),i.append(s,c),document.documentElement.append(n),p.addEventListener("click",()=>{A.runtime.sendMessage({type:"agent.stop"})})}n.style.setProperty("--glow",e);const r=(o=n.shadowRoot)==null?void 0:o.getElementById(tt);return r&&r.setAttribute("title",`Arc AI · ${t}`),n}function vn(e){var r,o;if(e.type==="agent.overlay.hide"){(r=xe())==null||r.remove();return}if(e.type==="agent.overlay.show"){xn(e.color,e.clientName);return}const t=xe(),n=(o=t==null?void 0:t.shadowRoot)==null?void 0:o.getElementById(et);n&&(n.style.transform=`translate(${e.x}px, ${e.y}px)`)}function yn(){A.runtime.onMessage.addListener(e=>{if(!e||typeof e!="object")return;const t=e.type;if(t==="agent.overlay.show"||t==="agent.overlay.hide"||t==="agent.overlay.move")return vn(e),Promise.resolve(!0)})}const An="arc-todo-capture",U="arc-todo-qa-overlay",wn=2147483645,ve="arcTodo.overlayPosition",ye="arcTodo.overlaySections";function nt(e,t,n,r,o,i){const s=Math.max(0,Math.min(e,n)),c=Math.max(0,Math.min(t,r)),d=Math.min(o,Math.max(e,n)),p=Math.min(i,Math.max(t,r)),u=d-s,f=p-c;return u<4||f<4?null:{x:s,y:c,width:u,height:f}}function rt(e,t,n){return t.width===0||t.height===0?{x:0,y:0}:{x:e.x/t.width*n.width,y:e.y/t.height*n.height}}function En(e,t,n){const r=rt({x:e.x,y:e.y},t,n),o=rt({x:e.x+e.width,y:e.y+e.height},t,n);return nt(r.x,r.y,o.x,o.y,n.width,n.height)}function Cn(e,t,n,r,o){const i=nt(e,t,n,r,o.width,o.height);return i?{rect:i,viewport:o}:null}const oe="arc-todo-region-overlay",ie="arc-todo-region-marquee",ot="2147483646",kn="rgba(0, 0, 0, 0.35)",Sn="#ffffff";function it(e){e.style.setProperty("--arc-region-scrim",kn),e.style.setProperty("--arc-region-line",Sn)}const at=["pointerdown","mousedown","mouseup","auxclick","contextmenu","dblclick"];let q=!1,st="",W=null;function Ln(){return{position:"fixed",inset:"0",zIndex:ot,cursor:"crosshair",background:"var(--arc-region-scrim)",boxSizing:"border-box"}}function Nn(){return{position:"fixed",pointerEvents:"none",zIndex:ot,outline:"2px solid var(--arc-region-line)",outlineOffset:"0",boxShadow:"0 0 0 99999px var(--arc-region-scrim)",boxSizing:"border-box",display:"none",background:"transparent"}}function Tn(e){let t=e.getElementById(oe);return t||(t=e.createElement("div"),t.id=oe,t.setAttribute("aria-hidden","true"),it(t),Object.assign(t.style,Ln()),e.documentElement.appendChild(t),t)}function ct(e){let t=e.getElementById(ie);return t||(t=e.createElement("div"),t.id=ie,t.setAttribute("aria-hidden","true"),it(t),Object.assign(t.style,Nn()),e.documentElement.appendChild(t),t)}function $n(e){return e?e.id===U?!0:!!e.closest(`#${U}`):!1}function Mn(e,t,n){const r=e.getElementById(oe),o=e.getElementById(ie);r&&(r.style.pointerEvents="none"),o&&(o.style.pointerEvents="none");const i=e.elementFromPoint(t,n);return r&&(r.style.pointerEvents="auto"),i}function lt(e){q&&(e.preventDefault(),e.stopPropagation(),e.stopImmediatePropagation())}function In(e,t,n,r){const o=Math.min(e,n),i=Math.min(t,r),s=ct(document);s.style.display="block",s.style.left=`${o}px`,s.style.top=`${i}px`,s.style.width=`${Math.abs(n-e)}px`,s.style.height=`${Math.abs(r-t)}px`}function dt(){const e=document.getElementById(ie);e&&(e.style.display="none")}function Pn(){return{width:window.innerWidth,height:window.innerHeight}}function ut(e){if(!q||e.button!==0)return;const t=Mn(document,e.clientX,e.clientY);$n(t)||(W={x:e.clientX,y:e.clientY},dt())}function mt(e){!q||!W||In(W.x,W.y,e.clientX,e.clientY)}function pt(e){if(!q||!W)return;const t=W;W=null;const n=Cn(t.x,t.y,e.clientX,e.clientY,Pn());dt(),n&&(A.runtime.sendMessage({type:"region.picked",rect:n.rect,viewport:n.viewport,devicePixelRatio:window.devicePixelRatio}),Ae())}function gt(e){!q||e.key!=="Escape"||(e.preventDefault(),Ae(),A.runtime.sendMessage({type:"region.cancelled"}))}function Rn(){if(window===window.top&&!q){q=!0,st=document.documentElement.style.cursor,document.documentElement.style.cursor="crosshair",Tn(document),ct(document),document.addEventListener("pointerdown",ut,!0),document.addEventListener("pointermove",mt,!0),document.addEventListener("pointerup",pt,!0),document.addEventListener("keydown",gt,!0);for(const e of at)document.addEventListener(e,lt,!0)}}function Ae(){var e,t;if(!(!q&&!document.getElementById(oe))){q=!1,W=null,document.documentElement.style.cursor=st,document.removeEventListener("pointerdown",ut,!0),document.removeEventListener("pointermove",mt,!0),document.removeEventListener("pointerup",pt,!0),document.removeEventListener("keydown",gt,!0);for(const n of at)document.removeEventListener(n,lt,!0);(e=document.getElementById(oe))==null||e.remove(),(t=document.getElementById(ie))==null||t.remove()}}function Bn(){window===window.top&&A.runtime.onMessage.addListener(e=>{if(!e||typeof e!="object"||!("type"in e))return;const t=e.type;t==="region.arm"&&Rn(),t==="region.disarm"&&Ae()})}function On(e){var t;return((t=e.find(n=>!n.checked))==null?void 0:t.id)??null}function Fn(e,t){var o;const n=e.findIndex(i=>i.id===t);return((o=(n>=0?e.slice(n+1):e).find(i=>!i.checked))==null?void 0:o.id)??On(e)}function zn(e,t){if(t&&e.some(n=>n.id===t))return t}function _n(e,t){return t==="panel"||t==="overlay"?t!==e:!0}function Dn(e,t,n,r,o=48){const i=o-r.width,s=n.width-o,c=0,d=Math.max(0,n.height-o);return{left:Math.min(s,Math.max(i,e)),top:Math.min(d,Math.max(c,t))}}function jn(e,t,n=16){return{left:Math.max(n,e.width-t.width-n),top:Math.max(n,e.height-t.height-n)}}const ft=/(\*\*[^*]+\*\*|\*[^*]+\*|`[^`]+`|\[[^\]]+\]\(https?:\/\/[^)\s]+\)|https?:\/\/[^\s<>"'`]+)/g;function qn(e){const t=[];let n=0;ft.lastIndex=0;let r;for(;r=ft.exec(e);){r.index>n&&t.push({type:"text",text:e.slice(n,r.index)});const o=r[0];if(o.startsWith("**"))t.push({type:"strong",text:o.slice(2,-2)});else if(o.startsWith("*"))t.push({type:"em",text:o.slice(1,-1)});else if(o.startsWith("`"))t.push({type:"code",text:o.slice(1,-1)});else if(o.startsWith("[")){const i=o.match(/^\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)$/);i&&t.push({type:"a",text:i[1],href:i[2]})}else{const i=o.replace(/[),.;:!?]+$/,""),s=o.slice(i.length);i&&t.push({type:"a",text:i,href:i}),s&&t.push({type:"text",text:s})}n=r.index+o.length}return n<e.length&&t.push({type:"text",text:e.slice(n)}),t.length>0?t:[{type:"text",text:e}]}function Hn(e,t){const n=t.join(`
`).trim();n&&e.push({type:"p",text:n})}function Wn(e){return`h${Math.min(e.length,4)}`}function Yn(e){const t=[];let n=[],r=[],o=[],i=null;function s(){r.length!==0&&(t.push({type:"ul",items:r}),r=[])}function c(){o.length!==0&&(t.push({type:"ol",items:o}),o=[])}function d(){const u=n;n=[],Hn(t,u)}function p(){s(),c()}for(const u of e.split(`
`)){if(i){u.startsWith("```")?(t.push({type:"pre",text:i.join(`
`)}),i=null):i.push(u);continue}if(u.startsWith("```")){p(),d(),i=[];continue}if(/^(-{3,}|\*{3,}|_{3,})\s*$/.test(u.trim())){p(),d(),t.push({type:"hr"});continue}const f=u.match(/^>\s?(.*)$/);if(f){p(),d();const H=t[t.length-1];(H==null?void 0:H.type)==="blockquote"?H.text=`${H.text}
${f[1]}`:t.push({type:"blockquote",text:f[1]});continue}const k=u.match(/^(#{1,4})\s+(.*)$/),D=u.match(/^[-*]\s+(.*)$/),Q=u.match(/^\d+\.\s+(.*)$/);if(k){p(),d(),t.push({type:Wn(k[1]),text:k[2]});continue}if(D){c(),d(),r.push(D[1]);continue}if(Q){s(),d(),o.push(Q[1]);continue}if(!u.trim()){p(),d();continue}p(),n.push(u)}return i&&t.push({type:"pre",text:i.join(`
`)}),p(),d(),t}function we(e,t){for(const n of qn(t)){if(n.type==="text"){e.appendChild(document.createTextNode(n.text));continue}if(n.type==="a"){const o=document.createElement("a");o.href=n.href,o.target="_blank",o.rel="noopener noreferrer",o.textContent=n.text,e.appendChild(o);continue}const r=document.createElement(n.type==="strong"?"strong":n.type==="em"?"em":"code");r.textContent=n.text,e.appendChild(r)}}function Un(e,t){for(const n of Yn(t)){if(n.type==="ul"||n.type==="ol"){const o=document.createElement(n.type);for(const i of n.items){const s=document.createElement("li");we(s,i),o.appendChild(s)}e.appendChild(o);continue}if(n.type==="pre"){const o=document.createElement("pre"),i=document.createElement("code");i.textContent=n.text,o.appendChild(i),e.appendChild(o);continue}if(n.type==="hr"){e.appendChild(document.createElement("hr"));continue}if(n.type==="blockquote"){const o=document.createElement("blockquote");we(o,n.text),e.appendChild(o);continue}const r=document.createElement(n.type);we(r,n.text),e.appendChild(r)}}function Gn(e){if(!e||typeof e!="object"||Array.isArray(e))return null;const t=e;return typeof t.left!="number"||typeof t.top!="number"||!Number.isFinite(t.left)||!Number.isFinite(t.top)?null:{left:t.left,top:t.top}}const ht=60;function Xn(e){const t=e.replace(/\*\*/g,"").trim(),n=e.match(/^\s*\*\*(.+?)\*\*/);if(n)return{short:n[1].replace(/\*\*/g,"").trim(),full:t,fromBold:!0};const r=t.indexOf(":");return r>0?{short:t.slice(0,r).trim(),full:t,fromBold:!1}:t.length>ht?{short:`${t.slice(0,ht)}…`,full:t,fromBold:!1}:{short:t,full:t,fromBold:!1}}function bt(e){return e.map(t=>{const n=Xn(t.label);return{id:t.id,short:n.short,full:n.full,checked:t.checked,bugged:t.bugged,notes:t.notes}})}const le={instructionsCollapsed:!1,checklistCollapsed:!1};function Qn(e){if(!e||typeof e!="object"||Array.isArray(e))return null;const t=e;return typeof t.instructionsCollapsed!="boolean"||typeof t.checklistCollapsed!="boolean"?null:{instructionsCollapsed:t.instructionsCollapsed,checklistCollapsed:t.checklistCollapsed}}const xt=':root,[data-theme=dark]{--font-display: "Newsreader", Georgia, serif;--font-body: "Figtree", system-ui, sans-serif;--type-page: 1.75rem;--type-kpi: 2.25rem;--type-section: 1.05rem;--type-card: 1rem;--type-body: .875rem;--type-meta: .75rem;font-family:var(--font-body);line-height:1.5;font-weight:400;--bg-page: #0d1119;--bg-shell: #131924;--bg-surface: #1b2230;--bg-elevated: #252e3d;--text-primary: #e8ecf4;--text-muted: #9aa6bc;--text: var(--text-primary);--text-secondary: var(--text-muted);--border: rgba(142, 160, 188, .18);--border-strong: rgba(142, 160, 188, .34);--border-subtle: var(--border);--accent: #4862ce;--accent-secondary: #6846b8;--accent-tertiary: #4a5d9c;--accent-contrast: #f7f8fc;--danger-bg: #342027;--danger-text: #e38a90;--danger: var(--danger-text);--info-bg: #142a34;--info-text: #7fc8dd;--success-bg: #173027;--success-text: #7fc19b;--warning-bg: #33291a;--warning-text: #d5aa63;--smart-copy: #f5a524;--bug-badge: #f13a48;--bug-resolved-badge: #129b56;--color-success: var(--success-text);--color-danger: var(--danger-text);--link: #8cb4ff;--surface-muted: color-mix(in srgb, var(--bg-elevated) 78%, var(--bg-page));--entity-rail-width: 6px;--entity-mix-fill: 14%;--entity-mix-badge: 26%;--entity-mix-header: 22%;--entity-corner-opacity: .28;--entity-rail-card-width: 3px;--entity-rail-card-mix: 80%;--entity-corner-glow-mix: 40%;--entity-rail-glow-out-mix: 34%;--entity-rail-glow-in-mix: 14%;--shadow: rgba(6, 10, 18, .48);--shadow-soft: 0 4px 18px rgba(6, 10, 18, .36);--shadow-card: 0 8px 28px rgba(6, 10, 18, .4), 0 0 0 1px rgba(142, 160, 188, .1);--shadow-neon: var(--shadow-card);--shadow-lift: 0 12px 32px rgba(6, 10, 18, .46);--ring: rgba(140, 180, 255, .42);--ring-strong: rgba(104, 70, 184, .38);--drop-glow: 0 0 0 2px rgba(140, 180, 255, .24);--gradient-page: radial-gradient(ellipse 70% 42% at 12% -8%, rgba(72, 98, 206, .08), transparent 55%), radial-gradient(ellipse 50% 36% at 92% 8%, rgba(104, 70, 184, .07), transparent 52%);--gradient-accent: linear-gradient(135deg, #4862ce 0%, #6846b8 100%);--gradient-header: linear-gradient(90deg, rgba(72, 98, 206, .24), rgba(104, 70, 184, .14));--radius-sm: 10px;--radius-md: 16px;--radius-lg: 22px;--radius-xl: 28px;--radius-blob: 28px 8px 28px 8px;--radius-blob-alt: 8px 28px 8px 28px;--radius-control: 16px 6px 16px 6px;--radius-control-alt: 6px 16px 6px 16px;--radius-pill: 999px;--button-height: 2.65rem;--button-height-sm: 2.15rem;--sidebar-expanded-width: 260px;--sidebar-collapsed-width: 72px;--sidebar-width: var(--sidebar-collapsed-width);--board-column-min-width: 280px;--transition-fast: .15s ease;--transition-base: .22s ease;--icon-nav: 1.25rem;--icon-duotone-fill: .22;--z-banner: 40;--z-fab: 41;--z-toast: 80;--z-modal: 900;--z-chat: 950;--criticity-low-bg: rgba(154, 166, 188, .16);--criticity-low-text: #9aa6bc;--criticity-medium-bg: rgba(213, 170, 99, .16);--criticity-medium-text: #d5aa63;--criticity-high-bg: rgba(104, 70, 184, .18);--criticity-high-text: #c4b4ee;--criticity-critical-bg: rgba(227, 138, 144, .16);--criticity-critical-text: #e38a90;color:var(--text-primary);background:var(--bg-page)}[data-theme=light]{--bg-page: #e6eaf2;--bg-shell: #f3f5f9;--bg-surface: #fbfcfe;--bg-elevated: #eef1f6;--text-primary: #1b2230;--text-muted: #5a6578;--text: var(--text-primary);--border: rgba(46, 53, 69, .16);--border-strong: rgba(46, 53, 69, .28);--border-subtle: var(--border);--accent: #3d52b8;--accent-secondary: #5a3ea8;--accent-tertiary: #4a5d9c;--accent-contrast: #f7f8fc;--danger-bg: rgba(180, 83, 90, .12);--danger-text: #b4535a;--danger: var(--danger-text);--info-bg: rgba(42, 122, 144, .12);--info-text: #2a7a90;--success-bg: rgba(47, 122, 88, .12);--success-text: #2f7a58;--warning-bg: rgba(138, 106, 40, .12);--warning-text: #8a6a28;--smart-copy: #c47d0a;--bug-badge: #e11d32;--bug-resolved-badge: #0d8a4b;--color-success: var(--success-text);--color-danger: var(--danger-text);--link: #3d52b8;--surface-muted: color-mix(in srgb, var(--bg-elevated) 70%, var(--bg-page));--shadow: rgba(27, 34, 48, .12);--shadow-soft: 0 4px 16px rgba(27, 34, 48, .08);--shadow-card: 0 8px 24px rgba(27, 34, 48, .1), 0 0 0 1px rgba(46, 53, 69, .1);--shadow-neon: var(--shadow-card);--shadow-lift: 0 12px 28px rgba(27, 34, 48, .12);--ring: rgba(61, 82, 184, .38);--ring-strong: rgba(90, 62, 168, .32);--drop-glow: 0 0 0 2px rgba(61, 82, 184, .2);--gradient-page: radial-gradient(ellipse 70% 42% at 12% -8%, rgba(61, 82, 184, .06), transparent 55%), radial-gradient(ellipse 50% 36% at 92% 8%, rgba(90, 62, 168, .05), transparent 52%);--gradient-accent: linear-gradient(135deg, #3d52b8 0%, #5a3ea8 100%);--gradient-header: linear-gradient(90deg, rgba(61, 82, 184, .16), rgba(90, 62, 168, .1));--criticity-low-bg: rgba(90, 101, 120, .14);--criticity-low-text: #5a6578;--criticity-medium-bg: rgba(138, 106, 40, .14);--criticity-medium-text: #8a6a28;--criticity-high-bg: rgba(90, 62, 168, .12);--criticity-high-text: #5a3ea8;--criticity-critical-bg: rgba(180, 83, 90, .12);--criticity-critical-text: #b4535a}*{box-sizing:border-box}body{margin:0;min-height:100vh;background:var(--bg-page);color:var(--text-primary)}h1,h2,h3,h4,p{margin:0}button,input,select,textarea{font:inherit}button:focus-visible,a:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible{outline:2px solid var(--ring);outline-offset:2px}',vt=xt.replace(/:root/g,":host").replace(/\[data-theme(=[^\]]+)\]/g,":host([data-theme$1])"),Vn=`
:host {
  all: initial;
  position: fixed;
  z-index: 2147483645;
}

${vt}

:host {
  color-scheme: dark;
  background: transparent;
}
:host([data-theme='light']) {
  color-scheme: light;
}

*, *::before, *::after { box-sizing: border-box; }

.panel {
  width: min(420px, calc(100vw - 24px));
  max-height: min(70vh, 520px);
  display: flex;
  flex-direction: column;
  background: var(--bg-surface);
  color: var(--text-primary);
  border: 1px solid var(--border);
  border-radius: var(--radius-md);
  box-shadow: var(--shadow-lift);
  overflow: hidden;
  font-size: var(--type-body);
  line-height: 1.4;
}

.panel.is-collapsed .body { display: none; }
.panel:focus-visible { outline: 2px solid var(--ring); outline-offset: 2px; }

.header {
  display: flex;
  align-items: flex-start;
  gap: 0.5rem;
  padding: 0.55rem 0.65rem;
  background: var(--bg-elevated);
  border-bottom: 1px solid var(--border);
  cursor: grab;
  touch-action: none;
  user-select: none;
}

.header:active { cursor: grabbing; }

.header-text {
  flex: 1;
  min-width: 0;
}

.display-id {
  margin: 0;
  font-size: var(--type-meta);
  color: var(--text-muted);
  font-weight: 600;
}

.title {
  margin: 0.1rem 0 0;
  font-size: var(--type-section);
  font-weight: 700;
  line-height: 1.25;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.header-actions {
  display: flex;
  gap: 0.25rem;
  flex-shrink: 0;
}

.icon-btn {
  appearance: none;
  border: 1px solid var(--border);
  background: transparent;
  color: var(--text-primary);
  border-radius: var(--radius-sm);
  min-width: 1.75rem;
  min-height: 1.75rem;
  font: inherit;
  font-size: var(--type-body);
  line-height: 1;
  cursor: pointer;
  padding: 0;
}

@media (hover: hover) and (pointer: fine) {
  .icon-btn:hover { background: var(--bg-surface); }
}

@media (pointer: coarse) {
  .icon-btn { min-width: 2.75rem; min-height: 2.75rem; }
}

.body {
  overflow: auto;
  padding: 0.5rem;
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

.hint {
  margin: 0;
  font-size: var(--type-meta);
  color: var(--text-muted);
}

.list {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
  gap: 0.375rem;
}

.row {
  border: 1px solid var(--border);
  border-radius: var(--radius-sm);
  background: var(--bg-elevated);
  padding: 0.375rem;
}

.row.is-bugged { border-color: var(--danger); }
.row.is-current {
  border-color: var(--accent);
  box-shadow: inset 0.2rem 0 0 var(--accent);
}

.row-main {
  display: flex;
  gap: 0.35rem;
  align-items: center;
}

.tick {
  appearance: none;
  border: 0;
  background: transparent;
  color: var(--text-primary);
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  padding: 0.1rem;
  font: inherit;
  min-width: 1.5rem;
  min-height: 1.5rem;
}

.tick-mark {
  width: 1.1rem;
  height: 1.1rem;
  border-radius: 999px;
  border: 2px solid var(--text-muted);
  display: flex;
  align-items: center;
  justify-content: center;
}

.tick.is-checked .tick-mark {
  border-color: var(--accent);
  background: var(--accent);
}

.tick.is-checked .tick-mark::after {
  content: '✓';
  color: var(--accent-contrast);
  font-size: var(--type-meta);
  font-weight: 700;
  line-height: 1;
}

.expand {
  appearance: none;
  border: 0;
  background: transparent;
  color: var(--text-primary);
  text-align: left;
  flex: 1;
  min-width: 0;
  cursor: pointer;
  font: inherit;
  padding: 0.15rem 0;
}

.expand strong { font-weight: 650; }

.row-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 0.25rem;
  margin-top: 0.35rem;
}

.btn {
  appearance: none;
  border: 1px solid var(--border);
  background: var(--bg-surface);
  color: var(--text-primary);
  border-radius: var(--radius-control);
  font: inherit;
  font-size: var(--type-meta);
  font-weight: 600;
  min-height: 1.5rem;
  padding: 0.3rem 0.5rem;
  cursor: pointer;
}

.btn-primary {
  background: var(--accent);
  border-color: var(--accent);
  color: var(--accent-contrast);
}

.btn:disabled {
  opacity: 0.45;
  cursor: not-allowed;
}

.bug-form {
  display: flex;
  flex-direction: column;
  gap: 0.35rem;
  margin-top: 0.35rem;
}

.bug-form label {
  display: flex;
  flex-direction: column;
  gap: 0.2rem;
  font-size: var(--type-meta);
  color: var(--text-muted);
}

.bug-form textarea {
  resize: vertical;
  min-height: 3.5rem;
  border: 1px solid var(--border);
  border-radius: var(--radius-sm);
  background: var(--bg-surface);
  color: var(--text-primary);
  font: inherit;
  padding: 0.35rem;
}

.warning {
  margin: 0;
  font-size: var(--type-meta);
  color: var(--text-muted);
}

.error {
  margin: 0;
  font-size: var(--type-meta);
  color: var(--danger);
}

.notes {
  margin: 0.25rem 0 0;
  padding-left: 1rem;
  font-size: var(--type-meta);
  color: var(--text-muted);
}

.section {
  display: flex;
  flex-direction: column;
  gap: 0.35rem;
  min-width: 0;
}

.section-heading {
  margin: 0;
  font-size: var(--type-meta);
}

.section-toggle {
  appearance: none;
  display: flex;
  align-items: baseline;
  gap: 0.4rem;
  width: 100%;
  margin: 0;
  min-height: 1.5rem;
  padding: 0.25rem 0;
  border: 0;
  background: transparent;
  color: var(--text-muted);
  font: inherit;
  font-size: var(--type-meta);
  font-weight: 700;
  letter-spacing: 0.02em;
  text-transform: uppercase;
  text-align: left;
  cursor: pointer;
}

.section-progress {
  font-weight: 650;
  color: var(--text-primary);
  text-transform: none;
  letter-spacing: 0;
}

.help {
  display: flex;
  flex-direction: column;
  gap: 0.4rem;
  min-width: 0;
}

.help p,
.help li {
  margin: 0;
  font-size: var(--type-meta);
  color: var(--text-muted);
}

.help ul,
.help ol {
  margin: 0;
  padding-left: 1.1rem;
}

.help h1,
.help h2,
.help h3,
.help h4 {
  margin: 0;
  font-size: var(--type-body);
  font-weight: 650;
  color: var(--text-primary);
}

.help strong { font-weight: 700; color: var(--text-primary); }
.help em { font-style: italic; }
.help code {
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  font-size: 0.88em;
  padding: 0.05em 0.3em;
  border-radius: var(--radius-sm);
  border: 1px solid var(--border);
}
.help a { color: var(--link); }
.help pre {
  margin: 0;
  padding: 0.45rem 0.55rem;
  overflow-x: auto;
  border: 1px solid var(--border);
  border-radius: var(--radius-sm);
  font-size: var(--type-meta);
}
.help pre code { padding: 0; border: none; }
.help hr {
  width: 100%;
  border: none;
  border-top: 1px solid var(--border);
  margin: 0.2rem 0;
}
.help blockquote {
  margin: 0;
  padding: 0.15rem 0 0.15rem 0.6rem;
  border-left: 2px solid var(--border);
  color: var(--text-muted);
}
`,b=v;let w=null,M=null,a=null,Ee=null,F=null;function Kn(e){return e.status==="expired"?b.sessionExpired:e.status==="not_signed_in"?b.signInFirst:e.error==="stale"?b.checklistChanged:e.error==="motivo"?b.motivoRequired:e.error==="api"||e.status==="error"?b.apiError:null}function Zn(){const e=document.getElementById(U);if(e&&M&&w===e)return{host:e,shadow:M};e==null||e.remove();const t=document.createElement("div");t.id=U,Object.assign(t.style,{position:"fixed",zIndex:String(wn),left:"0px",top:"0px"});const n=t.attachShadow({mode:"open"}),r=document.createElement("style");return r.textContent=xt.replace(/:root/g,":host")+Vn,n.appendChild(r),document.documentElement.appendChild(t),w=t,M=n,{host:t,shadow:n}}async function Jn(){try{const e=await A.storage.local.get(ve);return Gn(e[ve])}catch{return null}}async function er(e,t){try{await A.storage.local.set({[ve]:{left:e,top:t}})}catch{}}async function tr(){try{const e=await A.storage.local.get(ye);return Qn(e[ye])??le}catch{return le}}async function yt(){if(a)try{await A.storage.local.set({[ye]:{instructionsCollapsed:a.instructionsCollapsed,checklistCollapsed:a.checklistCollapsed}})}catch{}}function Ce(e,t){if(!w)return;const n=w.getBoundingClientRect(),r=Dn(e,t,{width:window.innerWidth,height:window.innerHeight},{width:n.width||420,height:Math.min(n.height||48,48)});w.style.left=`${r.left}px`,w.style.top=`${r.top}px`}function At(){if(!w)return;const e=Number.parseFloat(w.style.left||"0"),t=Number.parseFloat(w.style.top||"0");Ce(e,t)}async function nr(){if(!w)return;const e=await Jn(),t={width:420,height:320},n=e??jn({width:window.innerWidth,height:window.innerHeight},t);Ce(n.left,n.top)}function rr(e){if(!w||e.button!==0)return;const t=e.target;if(t!=null&&t.closest("button"))return;const n=Number.parseFloat(w.style.left||"0"),r=Number.parseFloat(w.style.top||"0");F={pointerId:e.pointerId,startX:e.clientX,startY:e.clientY,originLeft:n,originTop:r},e.currentTarget.setPointerCapture(e.pointerId),e.preventDefault()}function or(e){!F||e.pointerId!==F.pointerId||Ce(F.originLeft+(e.clientX-F.startX),F.originTop+(e.clientY-F.startY))}function wt(e){if(!F||e.pointerId!==F.pointerId||!w)return;F=null;const t=Number.parseFloat(w.style.left||"0"),n=Number.parseFloat(w.style.top||"0");er(t,n)}function E(){if(!M||!a)return;const e=M.querySelector(".panel");if(!e)return;e.classList.toggle("is-collapsed",a.collapsed);const t=M.querySelector(".title"),n=M.querySelector(".display-id");t&&(t.textContent=a.task.title),n&&(n.textContent=a.task.displayId);const r=M.querySelector('[data-action="collapse"]');r&&(r.setAttribute("aria-label",a.collapsed?b.expandOverlay:b.collapseOverlay),r.setAttribute("aria-expanded",String(!a.collapsed)),r.textContent=a.collapsed?"▸":"▾");const o=M.querySelector(".body");if(!o)return;if(o.replaceChildren(),a.error){const c=document.createElement("p");c.className="error",c.setAttribute("role","alert"),c.textContent=a.error,o.appendChild(c)}const i=document.createElement("p");i.className="hint",i.textContent=b.overlayDragHint,o.appendChild(i),a.helpMarkdown&&o.appendChild(ar(a.helpMarkdown));const s=bt(a.items);if(s.length===0){const c=document.createElement("p");c.className="hint",c.textContent=a.loading?b.overlayLoading:b.noChecklist,o.appendChild(c)}else o.appendChild(sr(s.map(c=>c.id)));if(a.taskBugOpen)o.appendChild(lr());else if(a.isBug){const c=document.createElement("button");c.type="button",c.className="btn",c.textContent=b.solveBug,c.disabled=a.busy,c.addEventListener("click",()=>{gr()}),o.appendChild(c)}else{const c=document.createElement("button");c.type="button",c.className="btn",c.textContent=b.flagAsBug,c.disabled=a.busy,c.addEventListener("click",()=>{a&&(a.taskBugOpen=!0,a.taskNote="",a.error=null,E())}),o.appendChild(c)}}function ir(e){const t=a.items.find(u=>u.id===e),n=document.createElement("li"),r=zn(a.items,a.expandedId);n.className=["row",t.bugged?"is-bugged":"",t.id===r?"is-current":""].filter(Boolean).join(" ");const o=document.createElement("div");o.className="row-main";const i=document.createElement("button");i.type="button",i.className=t.checked?"tick is-checked":"tick",i.setAttribute("aria-pressed",String(t.checked)),i.setAttribute("aria-label",t.checked?b.itemDone:b.itemOpen),i.disabled=a.busy;const s=document.createElement("span");s.className="tick-mark",s.setAttribute("aria-hidden","true"),i.append(s),i.addEventListener("click",()=>{dr(t.id)});const c=bt([t])[0],d=document.createElement("button");d.type="button",d.className="expand";const p=a.expandedId===t.id;if(d.setAttribute("aria-expanded",String(p)),p)d.textContent=c.full;else{const u=document.createElement("strong");u.textContent=c.short,d.appendChild(u)}if(d.addEventListener("click",()=>{a&&(a.expandedId=a.expandedId===t.id?null:t.id,E())}),o.append(i,d),n.appendChild(o),t.notes.length){const u=document.createElement("ul");u.className="notes";for(const f of t.notes){const k=document.createElement("li");k.innerHTML="";const D=document.createElement("strong");D.textContent=`${b.motivo}: `,k.append(D,document.createTextNode(f)),u.appendChild(k)}n.appendChild(u)}if(a.reportingItemId===t.id)n.appendChild(cr(t.id));else if(p){const u=document.createElement("div");u.className="row-actions";const f=document.createElement("button");if(f.type="button",f.className="btn",f.textContent=b.flagAsBug,f.disabled=a.busy,f.addEventListener("click",()=>{a&&(a.reportingItemId=t.id,a.itemNote="",a.error=null,E())}),u.appendChild(f),t.bugged){const k=document.createElement("button");k.type="button",k.className="btn",k.textContent=b.solveItem,k.disabled=a.busy,k.addEventListener("click",()=>{pr(t.id)}),u.appendChild(k)}n.appendChild(u)}return n}function Et(e,t,n,r){const o=document.createElement("button");o.type="button",o.className="section-toggle",o.setAttribute("aria-expanded",String(t));const i=document.createTextNode(e);if(o.appendChild(i),r){o.appendChild(document.createTextNode(" "));const c=document.createElement("span");c.className="section-progress",c.textContent=r,o.appendChild(c)}o.addEventListener("click",n);const s=document.createElement("h3");return s.className="section-heading",s.appendChild(o),s}function ar(e){const t=document.createElement("section");t.className="section";const n=!a.instructionsCollapsed;if(t.appendChild(Et(b.instructionsHeading,n,()=>{a&&(a.instructionsCollapsed=!a.instructionsCollapsed,yt(),E())})),n){const r=document.createElement("div");r.className="help markdown-content",Un(r,e),t.appendChild(r)}return t}function sr(e){const t=document.createElement("section");t.className="section";const n=!a.checklistCollapsed,r=a.items.filter(o=>o.checked).length;if(t.appendChild(Et(b.checklistHeading,n,()=>{a&&(a.checklistCollapsed=!a.checklistCollapsed,yt(),E())},`${r}/${a.items.length}`)),n){const o=document.createElement("ul");o.className="list";for(const i of e)o.appendChild(ir(i));t.appendChild(o)}return t}function cr(e){const t=document.createElement("div");t.className="bug-form";const n=document.createElement("label");n.textContent=b.motivo;const r=document.createElement("textarea");r.value=a.itemNote,r.placeholder=b.motivoPlaceholder,r.rows=3,r.addEventListener("input",()=>{a&&(a.itemNote=r.value,i.disabled=a.busy||!a.itemNote.trim())}),n.appendChild(r);const o=document.createElement("div");o.className="row-actions";const i=document.createElement("button");i.type="button",i.className="btn btn-primary",i.textContent=b.flagAsBug,i.disabled=a.busy||!a.itemNote.trim(),i.addEventListener("click",()=>{ur(e)});const s=document.createElement("button");return s.type="button",s.className="btn",s.textContent=b.cancelFlag,s.addEventListener("click",()=>{a&&(a.reportingItemId=null,a.itemNote="",E())}),o.append(i,s),t.append(n,o),t}function lr(){const e=document.createElement("div");e.className="bug-form";const t=document.createElement("p");t.className="warning",t.textContent=b.taskBugWarning;const n=document.createElement("label");n.textContent=b.motivo;const r=document.createElement("textarea");r.value=a.taskNote,r.placeholder=b.motivoPlaceholder,r.rows=3,r.addEventListener("input",()=>{a&&(a.taskNote=r.value,i.disabled=a.busy||!a.taskNote.trim())}),n.appendChild(r);const o=document.createElement("div");o.className="row-actions";const i=document.createElement("button");i.type="button",i.className="btn btn-primary",i.textContent=b.flagAsBug,i.disabled=a.busy||!a.taskNote.trim(),i.addEventListener("click",()=>{mr()});const s=document.createElement("button");return s.type="button",s.className="btn",s.textContent=b.cancelFlag,s.addEventListener("click",()=>{a&&(a.taskBugOpen=!1,a.taskNote="",E())}),o.append(i,s),e.append(t,n,o),e}function V(e){if(!a)return!1;const t=Kn(e);if(t)return a.error=t,!1;if(a.error=null,e.items){a.items=e.items;const n=a.expandedId;n&&!e.items.some(r=>r.id===n)&&(a.expandedId=null)}return e.snapshot&&(a.snapshot=e.snapshot),e.helpMarkdown!==void 0&&(a.helpMarkdown=e.helpMarkdown??null),e.isBug!==void 0&&(a.isBug=e.isBug),!0}async function Ct(){if(a){a.busy=!0,E();try{const e=await A.runtime.sendMessage({type:"task.get",task:a.task});V(e)}finally{a&&(a.busy=!1,a.loading=!1),E()}}}async function dr(e){if(!(!a||a.busy)){a.busy=!0,a.error=null,E();try{const t=await A.runtime.sendMessage({type:"checklist.tick",task:a.task,itemId:e,snapshot:a.snapshot,source:"overlay"});if(V(t),a){const n=a.items.find(r=>r.id===e);n!=null&&n.checked?a.expandedId=Fn(a.items,e):a.expandedId=e}}finally{a&&(a.busy=!1),E()}}}async function ur(e){if(!(!a||a.busy)){if(!a.itemNote.trim()){a.error=b.itemMotivoRequired,E();return}a.busy=!0,a.error=null,E();try{const t=await A.runtime.sendMessage({type:"checklist.flagItem",task:a.task,itemId:e,note:a.itemNote,snapshot:a.snapshot,source:"overlay"});V(t)&&(a.reportingItemId=null,a.itemNote="")}finally{a&&(a.busy=!1),E()}}}async function mr(){if(!(!a||a.busy)){if(!a.taskNote.trim()){a.error=b.motivoRequired,E();return}a.busy=!0,a.error=null,E();try{const e=await A.runtime.sendMessage({type:"task.flag",task:a.task,note:a.taskNote,source:"overlay"});V(e)&&(a.taskBugOpen=!1,a.taskNote="")}finally{a&&(a.busy=!1),E()}}}async function pr(e){if(!(!a||a.busy)){a.busy=!0,a.error=null,E();try{const t=await A.runtime.sendMessage({type:"checklist.unflagItem",task:a.task,itemId:e,snapshot:a.snapshot,source:"overlay"});V(t)}finally{a&&(a.busy=!1),E()}}}async function gr(){if(!(!a||a.busy)){a.busy=!0,a.error=null,E();try{const e=await A.runtime.sendMessage({type:"task.unflag",task:a.task,source:"overlay"});V(e)}finally{a&&(a.busy=!1),E()}}}function fr(){const{shadow:e}=Zn();if(e.querySelector(".panel"))return;const n=document.createElement("div");n.className="panel",n.setAttribute("role","dialog"),n.setAttribute("aria-label",b.checklistHeading),n.tabIndex=-1,n.addEventListener("keydown",f=>{f.key==="Escape"&&(f.preventDefault(),f.stopPropagation(),ke())});const r=document.createElement("div");r.className="header",r.addEventListener("pointerdown",rr),r.addEventListener("pointermove",or),r.addEventListener("pointerup",wt),r.addEventListener("pointercancel",wt);const o=document.createElement("div");o.className="header-text";const i=document.createElement("p");i.className="display-id";const s=document.createElement("h2");s.className="title",o.append(i,s);const c=document.createElement("div");c.className="header-actions";const d=document.createElement("button");d.type="button",d.className="icon-btn",d.dataset.action="collapse",d.addEventListener("click",()=>{a&&(a.collapsed=!a.collapsed,E())});const p=document.createElement("button");p.type="button",p.className="icon-btn",p.setAttribute("aria-label",b.closeFloatingChecklist),p.textContent="×",p.addEventListener("click",()=>{ke()}),c.append(d,p),r.append(o,c);const u=document.createElement("div");u.className="body",n.append(r,u),e.appendChild(n),window.addEventListener("resize",At)}function hr(e){var n;if(window!==window.top)return;fr(),w&&(w.dataset.theme=window.matchMedia("(prefers-color-scheme: light)").matches?"light":"dark");const t=document.activeElement;Ee=t&&t!==w&&t!==document.body?t:null,a={task:e,items:[],snapshot:{items:[]},expandedId:null,reportingItemId:null,itemNote:"",taskBugOpen:!1,taskNote:"",collapsed:!1,instructionsCollapsed:le.instructionsCollapsed,checklistCollapsed:le.checklistCollapsed,helpMarkdown:null,isBug:!1,busy:!1,loading:!0,error:null},w&&(w.style.display="block"),E(),(n=M==null?void 0:M.querySelector(".panel"))==null||n.focus(),Promise.all([nr(),tr()]).then(([,r])=>{a&&(a.instructionsCollapsed=r.instructionsCollapsed,a.checklistCollapsed=r.checklistCollapsed,E(),Ct())})}function ke(){F=null,a=null,window.removeEventListener("resize",At),w==null||w.remove(),w=null,M=null;const e=Ee;Ee=null,e instanceof HTMLElement&&e.isConnected&&e.focus({preventScroll:!0})}function br(){window===window.top&&A.runtime.onMessage.addListener(e=>{if(!e||typeof e!="object"||!("type"in e))return;const t=e.type;if(t==="overlay.open"){const n=e.task;n!=null&&n.id&&hr(n)}if(t==="overlay.close"&&ke(),t==="qa.checklistChanged"){if(!a||e.taskId!==a.task.id||!_n("overlay",e.source))return;Ct()}})}function xr(e){return new Promise((t,n)=>{const r=new Image;r.onload=()=>t(r),r.onerror=()=>n(new Error("image")),r.src=e})}async function vr(e,t,n){const r=await xr(e),o=En(t,n,{width:r.naturalWidth||r.width,height:r.naturalHeight||r.height});if(!o)throw new Error("empty");const i=document.createElement("canvas");i.width=Math.max(1,Math.round(o.width)),i.height=Math.max(1,Math.round(o.height));const s=i.getContext("2d");if(!s)throw new Error("canvas");return s.drawImage(r,o.x,o.y,o.width,o.height,0,0,i.width,i.height),i.toDataURL("image/png")}async function kt(e,t){{await navigator.clipboard.writeText(e);return}}async function yr(e){const t=await(await fetch(e)).blob();await navigator.clipboard.write([new ClipboardItem({"image/png":t})])}function Ar(e){return e.reduce((t,n)=>Math.max(t,n.n),0)+1}function wr(e,t){if(t<1)return null;const n=e.slice(0,t),r=n.lastIndexOf("@");if(r<0)return null;const o=n.slice(r+1);return/[\s]/.test(o)?null:{start:r,query:o}}function Er(e,t,n){const r=n.toLowerCase();return e.filter(o=>o.n!==t).filter(o=>r?String(o.n).startsWith(r)||o.hit.selector.toLowerCase().includes(r):!0).map(o=>({n:o.n,label:o.hit.selector}))}function Cr(e,t,n,r){const o=`@${r}`;return{note:`${e.slice(0,t)}${o}${e.slice(n)}`,caret:t+o.length}}function kr(e,t){const n=/^@(\d+)$/.exec(e);return n?t.some(r=>r.n===Number(n[1])):!1}function Sr(e){const t=[],n=/@(\d+)\b/g;let r;for(;r=n.exec(e);){const o=Number(r[1]);t.includes(o)||t.push(o)}return t}function St(e,t,n,r,o,i,s=4){return{x:Math.min(Math.max(e,s),Math.max(s,o-n-s)),y:Math.min(Math.max(t,s),Math.max(s,i-r-s))}}const Se=4;function Lt(e){return{left:e.x,top:e.y,right:e.x+e.width,bottom:e.y+e.height,centerY:e.y+e.height/2}}function Nt(e,t){return e.left>t.left&&e.right<t.right&&e.top>t.top&&e.bottom<t.bottom}function Lr(e,t){const n=Math.min(e.right,t.right)-Math.max(e.left,t.left),r=Math.min(e.bottom,t.bottom)-Math.max(e.top,t.top);return n<=0||r<=0?0:n*r}function Nr(e,t){const n=Lt(e.rect),r=Lt(t.rect),o=[];return Nt(n,r)?o.push(`#${e.n} is inside #${t.n}`):Nt(r,n)?o.push(`#${e.n} contains #${t.n}`):Lr(n,r)>0?o.push(`#${e.n} overlaps #${t.n}`):(n.right<=r.left?o.push(`#${e.n} is ${Math.round(r.left-n.right)}px to the left of #${t.n}`):n.left>=r.right&&o.push(`#${e.n} is ${Math.round(n.left-r.right)}px to the right of #${t.n}`),n.bottom<=r.top?o.push(`#${e.n} is ${Math.round(r.top-n.bottom)}px above #${t.n}`):n.top>=r.bottom&&o.push(`#${e.n} is ${Math.round(n.top-r.bottom)}px below #${t.n}`)),Math.abs(n.top-r.top)<=Se?o.push("top edges aligned"):Math.abs(n.centerY-r.centerY)<=Se&&o.push("center edges aligned"),Math.abs(n.left-r.left)<=Se&&o.push("left edges aligned"),o}const Tr=6,Tt=200,$r=3,Le=new Set(["main","nav","aside","header","footer","dialog","form"]),$t='h1,h2,h3,h4,h5,h6,[role="heading"]';function Mt(e,t,n,r){if(!e&&!t&&!n&&!r)return"";const o=e||"0px",i=t||"0px",s=n||"0px",c=r||"0px";return o===i&&i===s&&s===c?o:o===s&&i===c?`${o} ${i}`:i===c?`${o} ${i} ${s}`:`${o} ${i} ${s} ${c}`}function Mr(e){const t=(e==null?void 0:e.borderTopWidth)??"";return!t||t==="0px"?"":[t,(e==null?void 0:e.borderTopStyle)??"",(e==null?void 0:e.borderTopColor)??""].filter(Boolean).join(" ")}function Ir(e){return{color:(e==null?void 0:e.color)??"",fontSize:(e==null?void 0:e.fontSize)??"",display:(e==null?void 0:e.display)??"",padding:Mt(e==null?void 0:e.paddingTop,e==null?void 0:e.paddingRight,e==null?void 0:e.paddingBottom,e==null?void 0:e.paddingLeft),margin:Mt(e==null?void 0:e.marginTop,e==null?void 0:e.marginRight,e==null?void 0:e.marginBottom,e==null?void 0:e.marginLeft),gap:(e==null?void 0:e.gap)||(e==null?void 0:e.rowGap)||"",border:Mr(e),background:(e==null?void 0:e.backgroundColor)??"",fontWeight:(e==null?void 0:e.fontWeight)??""}}function Ne(e){const{x:t,y:n,width:r,height:o}=e.rect;return`${e.selector}@${Math.round(t)},${Math.round(n)},${Math.round(r)},${Math.round(o)}`}function K(e){return typeof CSS<"u"&&typeof CSS.escape=="function"?CSS.escape(e):e.replace(/([^\w-])/g,"\\$1")}function Pr(e){return e.filter(t=>/^[A-Za-z_][\w-]*$/.test(t)).slice(0,$r)}function T(e,t=Tt){const n=(e??"").replace(/\s+/g," ").trim();return n.length<=t?n:n.slice(0,t)}function Rr(e){const t=e.parentElement;return t?Array.from(t.children).indexOf(e)+1:1}function Br(e,t){if(!t)return!1;try{return e.querySelectorAll(`#${K(t)}`).length===1}catch{return!1}}function It(e){return{tagName:e.tagName,id:e.id,classes:Array.from(e.classList),nthChild:Rr(e),parent:e.parentElement?It(e.parentElement):null}}function Or(e){const t=e.tagName.toLowerCase();if(t==="html"||t==="body")return t;const n=Pr(e.classes);let r=t;return n.length&&(r+=n.map(o=>`.${K(o)}`).join("")),e.nthChild>0&&(r+=`:nth-child(${e.nthChild})`),r}function Fr(e,t,n=Tr){if(e.id&&t(e.id))return`#${K(e.id)}`;const r=[];let o=e,i=0;for(;o&&i<n;){if(o.id&&t(o.id)){r.unshift(`#${K(o.id)}`);break}if(r.unshift(Or(o)),o.tagName.toLowerCase()==="html")break;o=o.parent,i+=1}return r.join(" > ")}function Te(e){const t=(e.getAttribute("role")||"").trim();if(t)return t;const n=e.tagName.toLowerCase();if(n==="a")return"link";if(n==="button")return"button";if(n==="input"){const r=(e.getAttribute("type")||"").toLowerCase();if(r==="button"||r==="submit")return"button"}return/^h[1-6]$/.test(n)?"heading":Le.has(n)?n:n==="img"?"image":n}function Pt(e,t){const n=(e.getAttribute("aria-labelledby")||"").trim();if(!n)return"";const r=n.split(/\s+/).map(o=>{var i;try{const s=(i=t.querySelector)==null?void 0:i.call(t,`#${K(o)}`);return T(s==null?void 0:s.textContent)}catch{return""}}).filter(Boolean);return T(r.join(" "))}function $e(e,t,n=!0){var p,u;const r=(e.getAttribute("aria-label")||"").trim();if(r)return T(r);const o=Pt(e,t);if(o)return o;if(e.id)try{const f=(p=t.querySelector)==null?void 0:p.call(t,`label[for="${K(e.id)}"]`),k=T(f==null?void 0:f.textContent);if(k)return k}catch{}const i=(u=e.closest)==null?void 0:u.call(e,"label");if(i&&i!==e){const f=T(i.textContent);if(f)return f}const s=(e.getAttribute("alt")||"").trim();if(s)return T(s);const c=(e.getAttribute("placeholder")||"").trim();if(c)return T(c);const d=(e.getAttribute("title")||"").trim();return d?T(d):n?T(e.textContent):""}function Rt(e,t){return $e(e,t)||T(e.textContent)}function zr(e,t){var r;const n=(r=e.parentElement)==null?void 0:r.closest($t);return n?Rt(n,t):""}function Bt(e,t){const n=(e.getAttribute("aria-label")||"").trim();if(n)return T(n);const r=Pt(e,t);if(r)return r;const o=e.querySelector($t);return o?Rt(o,t):""}function Ot(e){const t=e.tagName.toLowerCase();if(Le.has(t))return!0;const n=(e.getAttribute("role")||"").trim().toLowerCase();return Le.has(n)}function _r(e,t){let n=e.parentElement;for(;n;){const r=n.tagName.toLowerCase();if(r==="html"||r==="body")break;if(Ot(n)){const o=Bt(n,t);if(o)return{role:Te(n),name:o}}n=n.parentElement}return null}function Dr(e,t){const n=[];let r=e.parentElement;for(;r&&n.length<3;){const o=r.tagName.toLowerCase();if(o==="html"||o==="body")break;const i=Te(r),s=$e(r,t,!1)||(Ot(r)?Bt(r,t):"");n.push(s?`${i} "${s}"`:i),r=r.parentElement}return n.join(" > ")}function Ft(e,t){const n=e.getBoundingClientRect(),r=typeof getComputedStyle=="function"?getComputedStyle(e):void 0,o=t.document;return{tag:e.tagName.toLowerCase(),id:e.id,classes:Array.from(e.classList),text:T(e.textContent),title:t.document.title??"",url:t.locationHref??(typeof location<"u"?location.href:""),selector:Fr(It(e),i=>Br(t.document,i)),rect:{x:n.left,y:n.top,width:n.width,height:n.height},viewport:{width:t.innerWidth,height:t.innerHeight},role:Te(e),accessibleName:$e(e,o),nearestHeading:zr(e,o),nearestLandmark:_r(e,o),parentChain:Dr(e,o),computed:Ir(r)}}function jr(e,t){const n=e.classes.length?e.classes.join(", "):"(none)";return`\`\`\`markdown
${["## Element","",`- Selector: \`${e.selector}\``,`- Tag: ${e.tag}`,`- Id: ${e.id||"(none)"}`,`- Classes: ${n}`,`- Text: ${e.text||"(none)"}`,`- Title: ${e.title||"(none)"}`,`- URL: ${e.url}`,"- Screenshot: omitted"].join(`
`)}
\`\`\``}function Me(e){return e?e.split(/\s+/).every(t=>t==="0px"||t==="0"):!0}function qr(e){return!e||/\bnone\b/i.test(e)?!0:/^0px\b/.test(e)}function Hr(e){if(!e)return!0;const t=e.replace(/\s+/g,"").toLowerCase();return t==="transparent"||t==="rgba(0,0,0,0)"||t==="rgb(0,0,0,0)"}function Wr(e){return e?e==="400"||e.toLowerCase()==="normal":!0}function Yr(e){const t=e.role||e.tag,n=e.accessibleName;let r=n?`${t} "${n}"`:t;const o=e.nearestLandmark;return o!=null&&o.name&&(e.role!==o.role||e.accessibleName!==o.name)&&(r+=` in ${o.role} "${o.name}"`),r}function Ur(e){var n;const t=[];return e.nearestHeading&&t.push(`heading "${e.nearestHeading}"`),(n=e.nearestLandmark)!=null&&n.name&&t.push(`landmark ${e.nearestLandmark.role} "${e.nearestLandmark.name}"`),e.parentChain&&t.push(`parents ${e.parentChain}`),t.length?`- Location: ${t.join("; ")}`:null}function Gr(e){const t=[],n=(r,o,i=!o)=>{i||t.push(`- ${r}: ${o}`)};return n("Color",e.color),n("Font-size",e.fontSize),n("Display",e.display),n("Padding",e.padding,Me(e.padding)),n("Margin",e.margin,Me(e.margin)),n("Gap",e.gap,Me(e.gap)),n("Border",e.border,qr(e.border)),n("Background",e.background,Hr(e.background)),n("Font-weight",e.fontWeight,Wr(e.fontWeight)),t}function Xr(e,t,n){const r=Sr(e.note??""),o=[];for(const i of r){if(i===t||!kr(`@${i}`,n.map(c=>({n:c.n??0}))))continue;const s=n.find(c=>c.n===i);s&&o.push(...Nr({n:t,rect:e.rect},{n:i,rect:s.rect}))}return o.length?`- Relations: ${o.join("; ")}`:null}function Qr(e,t,n){const r=[`### ${t}. ${Yr(e)}`,"",Ur(e),`- Selector: \`${e.selector}\``,`- Tag: ${e.tag}`];e.id&&r.push(`- Id: ${e.id}`),e.classes.length&&r.push(`- Classes: ${e.classes.join(", ")}`),r.push(`- Text: ${T(e.text,Tt)||"(none)"}`,`- Href: ${e.url}`,`- Rect: ${Math.round(e.rect.x)}, ${Math.round(e.rect.y)}, ${Math.round(e.rect.width)} × ${Math.round(e.rect.height)}`,...Gr(e.computed),`- Note: ${(e.note??"").trim()||"(none)"}`);const o=Xr(e,t,n);return o&&r.push(o),r.filter(i=>i!==null).join(`
`)}function Vr(e,t){const r=e.map(c=>"hit"in c?{...c.hit,note:c.note,n:c.n}:c).map((c,d)=>({...c,n:c.n??d+1}));return`\`\`\`markdown
${["## Design notes","",...r.map(c=>Qr(c,c.n,r)),"","- Screenshot: omitted"].join(`
`)}
\`\`\``}function zt(e){const t=["## Live CSS","","```css",e.css.trim(),"```","","## Computed changes",""];if(e.diffs.length===0)t.push("- (none)");else for(const n of e.diffs){t.push(`### \`${n.selector}\` — ${n.description}`,"");for(const r of n.changes)t.push(`- ${r.property}: ${r.before} -> ${r.after}`);t.push("")}return`${t.join(`
`).trimEnd()}
`}function Kr(e){const t=["Apply this live CSS in the real source so the page matches the preview. Do not leave it as an injected stylesheet.","",`Page: ${e.pageUrl}`,""];return e.rejected&&t.push("The browser rejected this CSS. Implement the intended change in source anyway.",""),t.push(zt(e).trimEnd()),`${t.join(`
`)}
`}let Z=null;function _t(e){Z=e}const G="arc-todo-live-css",Ie="	";let J=!1,ee=null,te="";function Zr(e,t,n){return`${e}${Ie}${t}${Ie}${n}`}function Jr(e){const[t="",n="",r=""]=e.split(Ie);return{selector:t,description:n,identity:r}}function Pe(e){try{return Be(e),{ok:!0}}catch{return{ok:!1}}}function eo(e){const t=Be(e),n=[];return Oe(t.cssRules,r=>{r.selectorText&&n.push(r.selectorText)}),n}function to(e){const t=Be(e),n=new Set;return Oe(t.cssRules,r=>{const o=r.style;if(o)for(let i=0;i<o.length;i++){const s=o.item(i);s&&n.add(s)}}),[...n]}function no(e,t,n){const r=new Map,o=co();for(const i of t){let s;try{s=e.querySelectorAll(i)}catch{continue}for(const c of s){if(!(c instanceof Element)||lo(c))continue;const d=Ft(c,o),p=d.selector||Ne(d),u=ao(c),f=Zr(i,u,p);r.set(f,so(c,n))}}return r}function Dt(e,t){const n=[];for(const[r,o]of e){const i=t.get(r);if(!i)continue;const s=[],c=new Set([...Object.keys(o),...Object.keys(i)]);for(const p of c){const u=o[p]??"",f=i[p]??"";u!==f&&s.push({property:p,before:u,after:f})}if(s.length===0)continue;const d=Jr(r);n.push({selector:d.selector,description:d.description,changes:s})}return n}function jt(){return ee??new Map}function ro(){return te}function Re(e,t=document){return!e.trim()||!Pe(e).ok?new Map:no(t,eo(e),to(e))}function qt(){return J?!0:!!(typeof document<"u"&&document.getElementById(G))}async function oo(e){if(!e.trim())return de(),{applied:"none"};if(!Pe(e).ok)return{applied:ue(),error:!0};const t=Re(e),n=uo();if(n.textContent=e,n.sheet)return Ht(t),te=e,J=!1,{applied:"dom"};if(!Z)return Fe(n),{applied:ue(),error:!0};try{const r=await Z.insertCss(e);return r!=null&&r.error?(Fe(n),{applied:ue(),error:!0}):(Ht(t),te=e,J=!0,{applied:"extension"})}catch{return Fe(n),{applied:ue(),error:!0}}}function de(){var e;typeof document<"u"&&((e=document.getElementById(G))==null||e.remove()),J&&(Z==null||Z.removeCss()),J=!1,ee=null,te=""}function Be(e){const t=new CSSStyleSheet;return t.replaceSync(e),t}function Oe(e,t){for(const n of e){const r=io(n);r!=null&&r.selectorText&&t(r);const o=n.cssRules;o&&Oe(o,t)}}function io(e){return"selectorText"in e&&"style"in e?e:null}function ao(e){const t=T(e.textContent,48);return t||e.tagName.toLowerCase()}function so(e,t){const n={};if(typeof getComputedStyle!="function")return n;const r=getComputedStyle(e);for(const o of t)n[o]=r.getPropertyValue(o).trim();return n}function co(){return{document,innerWidth:window.innerWidth,innerHeight:window.innerHeight,locationHref:location.href}}function lo(e){return e.id===G||e.id==="arc-todo-picker-hover"||e.id==="arc-todo-design-tray"||e.id===U||e.classList.contains("arc-todo-picker-selected")||e.classList.contains("arc-todo-picker-badge")}function Ht(e){if(!ee){ee=e;return}for(const[t,n]of e)ee.has(t)||ee.set(t,n)}function Fe(e){if(te){e.textContent=te;return}e.remove()}function uo(){const e=document.getElementById(G);if(e instanceof HTMLStyleElement)return e;const t=document.createElement("style");return t.id=G,document.documentElement.appendChild(t),t}function ue(){return J?"extension":typeof document<"u"&&document.getElementById(G)?"dom":"none"}function mo(e){if(!e||typeof e!="object")return"dev";const t=e.purpose;return t==="qa-crop"||t==="qa-record"||t==="design"?t:"dev"}function po(e){return e==="dev"}function go(e){return e!=="design"}function fo(e,t,n){return e==="qa-crop"?{type:"capture.elementPicked",hit:t}:e==="qa-record"?{type:"capture.elementForRecord",hit:t}:{type:"picker.picked",hit:t,keepArmed:e==="design",removed:n==null?void 0:n.removed}}const ho=`
:host {
  all: initial;
  position: fixed;
  z-index: 2147483647;
}
`,bo=`
:host {
  color-scheme: dark;
  background: transparent;
}
:host([data-theme='light']) {
  color-scheme: light;
}
.tray {
  width: min(340px, calc(100vw - 24px));
  max-height: 60vh;
  display: flex;
  flex-direction: column;
  gap: 0.375rem;
  padding: 0.625rem;
  background: var(--bg-surface);
  color: var(--text-primary);
  border: 1px solid var(--border);
  border-radius: var(--radius-md);
  box-shadow: var(--shadow-lift);
  font-size: var(--type-body);
  line-height: 1.4;
}
.head {
  display: flex;
  align-items: baseline;
  cursor: grab;
  user-select: none;
  touch-action: none;
}
.tray.is-dragging .head { cursor: grabbing; }
.title {
  font-size: var(--type-meta);
  text-transform: uppercase;
  letter-spacing: 0.08em;
  color: var(--text-muted);
}
.empty { margin: 0; color: var(--text-muted); }
.list {
  list-style: none;
  margin: 0;
  padding: 0;
  overflow-y: auto;
  min-height: 0;
  display: flex;
  flex-direction: column;
  gap: 0.375rem;
}
.pin {
  display: flex;
  flex-direction: column;
  gap: 0.25rem;
  border: 1px solid var(--border);
  border-radius: var(--radius-sm);
  padding: 0.375rem;
  position: relative;
}
.pin-head { display: flex; align-items: center; gap: 0.375rem; }
.n {
  min-width: 1rem;
  height: 1rem;
  padding: 0 0.25rem;
  border-radius: 999px;
  background: var(--accent);
  color: var(--accent-contrast);
  font-size: var(--type-meta);
  font-weight: 600;
  line-height: 1rem;
  text-align: center;
  flex: none;
}
.label {
  flex: 1;
  min-width: 0;
  font-family: ui-monospace, monospace;
  font-size: var(--type-meta);
  color: var(--text-muted);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.remove {
  border: 0;
  background: transparent;
  color: var(--text-muted);
  cursor: pointer;
  font: inherit;
  font-size: var(--type-body);
  line-height: 1;
  padding: 0;
  min-width: 1.5rem;
  min-height: 1.5rem;
}
.note-label {
  display: flex;
  flex-direction: column;
  gap: 0.25rem;
  color: var(--text-muted);
  font-size: var(--type-meta);
}
textarea {
  width: 100%;
  resize: vertical;
  min-height: 2rem;
  font: inherit;
  color: var(--text-primary);
  background: var(--bg-elevated);
  border: 1px solid var(--border);
  border-radius: var(--radius-sm);
  padding: 0.25rem 0.375rem;
}
textarea:focus-visible,
.foot button:focus-visible,
.css-block summary:focus-visible,
.css-actions button:focus-visible {
  outline: 2px solid var(--ring);
  outline-offset: 2px;
}
.css-block { display: block; }
.css-block[open] {
  display: flex;
  flex-direction: column;
  gap: 0.25rem;
}
.css-block summary {
  cursor: pointer;
  color: var(--text-muted);
  font-size: var(--type-meta);
  min-height: 1.5rem;
}
.css-block textarea {
  min-height: 4.5rem;
  font-family: ui-monospace, monospace;
  font-size: var(--type-meta);
}
.css-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 0.375rem;
  align-items: center;
}
.css-actions button {
  border: 1px solid var(--border);
  background: var(--bg-elevated);
  color: var(--text-primary);
  border-radius: var(--radius-control);
  min-height: 1.5rem;
  padding: 0.3rem 0.625rem;
  font: inherit;
  font-size: var(--type-meta);
  cursor: pointer;
}
.css-actions button:disabled { opacity: 0.5; cursor: default; }
.css-error {
  margin: 0;
  color: var(--danger);
  font-size: var(--type-meta);
}
.css-actions .css-remove {
  border: 0;
  background: transparent;
  color: var(--text-muted);
  padding: 0.25rem 0;
}
.mentions {
  position: absolute;
  left: 0.375rem;
  right: 0.375rem;
  z-index: 2;
  margin: 0;
  padding: 0.25rem;
  list-style: none;
  background: var(--bg-elevated);
  border: 1px solid var(--border);
  border-radius: var(--radius-sm);
  max-height: 8.75rem;
  overflow-y: auto;
}
.mentions button {
  display: block;
  width: 100%;
  min-height: 1.5rem;
  text-align: left;
  border: 0;
  background: transparent;
  color: var(--text-primary);
  font: inherit;
  padding: 0.25rem 0.375rem;
  cursor: pointer;
  border-radius: var(--radius-sm);
}
@media (hover: hover) and (pointer: fine) {
  .mentions button:hover { background: var(--accent); color: var(--accent-contrast); }
}
.foot { display: grid; grid-template-columns: 1fr 1fr; gap: 0.375rem; }
.foot button {
  width: 100%;
  border: 1px solid var(--border);
  background: var(--bg-elevated);
  color: var(--text-primary);
  border-radius: var(--radius-control);
  min-height: 1.5rem;
  padding: 0.3rem 0.625rem;
  font: inherit;
  cursor: pointer;
}
.foot button:disabled { opacity: 0.5; cursor: default; }
.foot .primary { background: var(--accent); color: var(--accent-contrast); border-color: transparent; }
.status {
  margin: 0;
  color: var(--text-muted);
  font-size: var(--type-meta);
}
`,ae="arc-todo-picker-hover",Wt="arc-todo-picker-selected",Yt="arc-todo-design-tray",Ut="arc-todo-picker-badge",Gt=["pointerdown","mousedown","mouseup","auxclick","contextmenu","dblclick"];let $=!1,N="dev",Xt="",Qt=0,C=[],l=null,Y=null,ze=null,z=null,me=null,_="",X=!1;function Vt(){return{position:"fixed",pointerEvents:"none",zIndex:"2147483647",outline:"2px solid #4862ce",outlineOffset:"1px",background:"rgba(72, 98, 206, 0.12)",boxSizing:"border-box",display:"none"}}function pe(e,t){e.style.display="block",e.style.left=`${t.left}px`,e.style.top=`${t.top}px`,e.style.width=`${t.width}px`,e.style.height=`${t.height}px`}function _e(e){let t=e.getElementById(ae);return t||(t=e.createElement("div"),t.id=ae,t.setAttribute("aria-hidden","true"),Object.assign(t.style,Vt()),e.documentElement.appendChild(t),t)}function Kt(e,t){const n=e.createElement("div");return n.className=Wt,n.id=`arc-todo-picker-selected-${Qt}`,Qt+=1,n.setAttribute("aria-hidden","true"),Object.assign(n.style,Vt(),{display:"block",outline:"2px dashed #4862ce",background:"transparent"}),e.documentElement.appendChild(n),n}function Zt(e,t,n){const r=e.createElement("span");return r.className=Ut,r.setAttribute("aria-hidden","true"),r.textContent=String(t),Object.assign(r.style,{position:"fixed",pointerEvents:"none",zIndex:"2147483647",minWidth:"16px",height:"16px",padding:"0 4px",borderRadius:"999px",background:"#4862ce",color:"#f7f8fc",fontSize:"11px",fontWeight:"600",lineHeight:"16px",textAlign:"center",fontFamily:"system-ui, sans-serif",boxSizing:"border-box"}),De(r,n),e.documentElement.appendChild(r),r}function De(e,t){e.style.top=`${t.top-9}px`,e.style.left=`${t.left-9}px`}function xo(e){return e?e.id===U?!0:!!e.closest(`#${U}`):!1}function vo(e){return e?e.id===ae||e.id===Yt||e.id===G||e.classList.contains(Wt)||e.classList.contains(Ut)||xo(e):!1}function je(e){return!!(l&&e.composedPath().includes(l))}function Jt(e,t,n){const r=e.elementFromPoint(t,n);return!r||vo(r)?null:r}function en(e){$&&(je(e)||(e.preventDefault(),e.stopPropagation(),e.stopImmediatePropagation()))}function qe(e,t){const n=_e(e);if(!t){n.style.display="none";return}pe(n,t.getBoundingClientRect())}function He(e){return Ft(e,{document,innerWidth:window.innerWidth,innerHeight:window.innerHeight,locationHref:location.href})}function tn(){return C.map(({n:e,hit:t,note:n})=>({n:e,hit:t,note:n}))}function We(){var e,t;ne(),de(),_t(null),_="",X=!1;for(const n of C)(e=n.box)==null||e.remove(),(t=n.badge)==null||t.remove(),n.box=null,n.badge=null;l==null||l.remove(),l=null}function nn(){var e,t;ne();for(const n of C)(e=n.box)==null||e.remove(),(t=n.badge)==null||t.remove(),n.box=null,n.badge=null;C=[],z=null,me=null}function yo(){for(const e of C){if(!e.el.isConnected)continue;const t=e.el.getBoundingClientRect();e.box||(e.box=Kt(document)),pe(e.box,t),e.badge?De(e.badge,t):e.badge=Zt(document,e.n,t)}rn(),fe(),P(),Xe()}function Ye(){var e,t;for(const n of C){if(!n.el.isConnected){(e=n.box)==null||e.remove(),(t=n.badge)==null||t.remove(),n.box=null,n.badge=null;continue}n.hit=He(n.el);const r=n.el.getBoundingClientRect();n.box&&pe(n.box,r),n.badge&&De(n.badge,r)}}function rn(){if(l!=null&&l.isConnected){l.style.display="",ge();return}l=document.createElement("div"),l.id=Yt,l.dataset.theme=window.matchMedia("(prefers-color-scheme: light)").matches?"light":"dark";const e=l.attachShadow({mode:"open"}),t=document.createElement("style");t.textContent=`${ho}
${vt}
${bo}`;const n=document.createElement("aside");n.className="tray",n.setAttribute("aria-label",v.designHeading);const r=document.createElement("div");r.className="head";const o=document.createElement("span");o.className="title",o.textContent=v.designHeading,r.appendChild(o),r.addEventListener("pointerdown",Ao);const i=document.createElement("ul");i.className="list";const s=wo(),c=document.createElement("div");c.className="foot";const d=document.createElement("p");d.className="status",d.hidden=!0,n.append(r,i,s,c,d),e.append(t,n),document.documentElement.appendChild(l),ge()}function ge(){if(l){if(!Y){l.style.right="12px",l.style.bottom="12px",l.style.left="auto",l.style.top="auto";return}l.style.left=`${Y.x}px`,l.style.top=`${Y.y}px`,l.style.right="auto",l.style.bottom="auto"}}function Ao(e){var c,d;if(e.button!==0||!l)return;const t=e.currentTarget,n=l.getBoundingClientRect(),r=e.clientX-n.left,o=e.clientY-n.top;try{t.setPointerCapture(e.pointerId)}catch{}(d=(c=l.shadowRoot)==null?void 0:c.querySelector(".tray"))==null||d.classList.add("is-dragging");const i=p=>{l&&(Y=St(p.clientX-r,p.clientY-o,n.width,n.height,window.innerWidth,window.innerHeight),ge())},s=()=>{var p,u;(u=(p=l==null?void 0:l.shadowRoot)==null?void 0:p.querySelector(".tray"))==null||u.classList.remove("is-dragging"),t.removeEventListener("pointermove",i),t.removeEventListener("pointerup",s),t.removeEventListener("pointercancel",s)};t.addEventListener("pointermove",i),t.addEventListener("pointerup",s),t.addEventListener("pointercancel",s)}function wo(){const e=document.createElement("details");e.className="css-block",e.open=_.trim().length>0;const t=document.createElement("summary");t.textContent=v.designLiveCss;const n=document.createElement("textarea");n.rows=6,n.value=_,n.setAttribute("aria-label",v.designLiveCss),n.setAttribute("aria-invalid",X?"true":"false"),n.addEventListener("input",()=>{_=n.value,on(n)});const r=document.createElement("p");r.className="css-error",Ue(r,n,X);const o=document.createElement("div");o.className="css-actions";const i=document.createElement("button");i.type="button",i.className="css-copy-live",i.textContent=v.designCopyLive,i.addEventListener("click",()=>void Co());const s=document.createElement("button");s.type="button",s.textContent=v.designPasteCss,s.addEventListener("click",()=>void ko(n));const c=document.createElement("button");return c.type="button",c.className="css-remove",c.textContent=v.designRemoveCss,c.disabled=!qt(),c.addEventListener("click",()=>{de(),X=!1,Ue(r,n,!1),c.disabled=!0,P()}),o.append(i,s,c),e.append(t,n,r,o),e}function Eo(){var t;const e=(t=l==null?void 0:l.shadowRoot)==null?void 0:t.querySelector(".css-copy-live");e&&(e.textContent=z==="live"?v.copied:v.designCopyLive)}async function Co(){const e=_.trim();if(z=null,!e){R(v.designCopyLiveEmpty),P();return}R(null),await kt(Kr({css:_,pageUrl:location.href,rejected:!Pe(e).ok,diffs:Dt(jt(),Re(e))})),z="live",P()}async function ko(e){z=null;let t="";try{t=await navigator.clipboard.readText()}catch{R(v.designPasteCssFailed),P();return}if(!t.trim()){R(v.designPasteCssEmpty),P();return}_=t,e.value=t,R(null),await on(e)}async function on(e){var o,i;X=!!(await oo(_)).error;const n=(o=l==null?void 0:l.shadowRoot)==null?void 0:o.querySelector(".css-error");Ue(n,e,X);const r=(i=l==null?void 0:l.shadowRoot)==null?void 0:i.querySelector(".css-remove");r instanceof HTMLButtonElement&&(r.disabled=!qt()),P()}function Ue(e,t,n){if(e){if(n){e.textContent=v.designCssInvalid,e.setAttribute("role","alert"),t.setAttribute("aria-invalid","true");return}e.textContent="",e.removeAttribute("role"),t.setAttribute("aria-invalid","false")}}function ne(){var e,t;ze=null,(t=(e=l==null?void 0:l.shadowRoot)==null?void 0:e.querySelector(".mentions"))==null||t.remove()}function fe(){var t;const e=(t=l==null?void 0:l.shadowRoot)==null?void 0:t.querySelector(".list");if(e){if(e.replaceChildren(),C.length===0){const n=document.createElement("p");n.className="empty",n.textContent=v.designEmpty,e.appendChild(n);return}for(const n of C)e.appendChild(So(n))}}function So(e){const t=document.createElement("li");t.className="pin";const n=document.createElement("div");n.className="pin-head";const r=document.createElement("span");r.className="n",r.textContent=String(e.n);const o=document.createElement("span");o.className="label",o.title=e.hit.selector,o.textContent=e.hit.selector;const i=document.createElement("button");i.type="button",i.className="remove",i.setAttribute("aria-label",v.designRemove),i.textContent="×",i.addEventListener("click",()=>{No(e.n)}),n.append(r,o,i);const s=document.createElement("label");s.className="note-label",s.append(v.designNote);const c=document.createElement("textarea");return c.rows=2,c.placeholder=v.designNotePlaceholder,c.value=e.note,c.addEventListener("input",()=>{e.note=c.value,Ge(e,c)}),c.addEventListener("click",()=>Ge(e,c)),c.addEventListener("keyup",d=>{d.key!=="Escape"&&Ge(e,c)}),s.appendChild(c),t.append(n,s),t}function Ge(e,t){var s,c;const n=t.selectionStart??t.value.length,r=wr(t.value,n);if(ne(),!r)return;const o=Er(tn(),e.n,r.query);if(o.length===0)return;ze={n:e.n,start:r.start,caret:n};const i=document.createElement("ul");i.className="mentions",i.setAttribute("aria-label",v.designNote);for(const d of o){const p=document.createElement("li"),u=document.createElement("button");u.type="button",u.textContent=`@${d.n}  ${d.label}`,u.addEventListener("click",()=>{const f=Cr(t.value,r.start,n,d.n);e.note=f.note,t.value=f.note,t.focus(),t.setSelectionRange(f.caret,f.caret),ne()}),p.appendChild(u),i.appendChild(p)}(c=(s=t.parentElement)==null?void 0:s.parentElement)==null||c.appendChild(i)}function P(){var s;const e=(s=l==null?void 0:l.shadowRoot)==null?void 0:s.querySelector(".foot");if(!e)return;e.replaceChildren();const t=C.length>0,n=document.createElement("button");n.type="button",n.textContent=z==="text"?v.copied:v.copy,n.addEventListener("click",()=>void Mo());const r=document.createElement("button");r.type="button",r.textContent=z==="png"?v.copied:v.copyImage,r.addEventListener("click",()=>void Io());const o=document.createElement("button");o.type="button",o.textContent=v.designClear,o.disabled=!t,o.addEventListener("click",()=>{nn(),rn(),fe(),P(),Xe()});const i=document.createElement("button");i.type="button",i.className="primary",i.textContent=v.designExit,i.addEventListener("click",()=>Qe()),e.append(n,r,o,i),Eo()}function R(e){me=e,Xe()}function Xe(){var t;const e=(t=l==null?void 0:l.shadowRoot)==null?void 0:t.querySelector(".status");if(e instanceof HTMLElement){if(!me){e.hidden=!0,e.removeAttribute("role"),e.textContent="";return}e.hidden=!1,e.setAttribute("role","alert"),e.textContent=me}}function Lo(e){let t=1/0,n=1/0,r=-1/0,o=-1/0;for(const i of e){if(!i.el.isConnected)continue;const s=i.el.getBoundingClientRect();t=Math.min(t,s.left),n=Math.min(n,s.top),r=Math.max(r,s.right),o=Math.max(o,s.bottom)}return!Number.isFinite(t)||r<=t||o<=n?null:{x:t,y:n,width:r-t,height:o-n}}function No(e){var n,r;const t=C.find(o=>o.n===e);(n=t==null?void 0:t.box)==null||n.remove(),(r=t==null?void 0:t.badge)==null||r.remove(),C=C.filter(o=>o.n!==e),ne(),fe(),P()}function To(e,t){if(C.some(i=>i.el===e||Ne(i.hit)===Ne(t)))return;const n=e.getBoundingClientRect(),r=Ar(C);C.push({n:r,el:e,hit:t,note:"",box:Kt(document),badge:Zt(document,r,n)});const o=C[C.length-1];o!=null&&o.box&&pe(o.box,n),fe(),P()}function $o(e){const t=[],n=ro()||_;return n.trim()&&t.push(zt({css:n,diffs:Dt(jt(),Re(n))}).trimEnd()),C.length>0&&t.push(Vr(tn())),t.join(`

`)}async function Mo(){if(Ye(),z=null,C.length===0&&!_.trim()){R(v.designCopyEmpty);return}R(null),await kt($o()),z="text",P()}async function Io(){if(Ye(),z=null,C.length===0){R(v.designCopyEmpty);return}R(null),l&&(l.style.display="none"),qe(document,null),await new Promise(e=>{window.setTimeout(e,50)});try{const e=await A.runtime.sendMessage({type:"picker.screenshot"});if(!e.draftScreenshot){R(v.designCaptureFailed);return}const t=Lo(C);if(!t){R(v.designCaptureFailed);return}const n=await vr(e.draftScreenshot,t,{width:window.innerWidth,height:window.innerHeight});await yr(n),z="png",P()}catch{R(v.designCaptureFailed)}finally{l&&(l.style.display="")}}function an(e){if($){if(je(e)){qe(document,null);return}qe(document,Jt(document,e.clientX,e.clientY))}}function he(){if($&&N==="design"&&(Ye(),Y&&l)){const e=l.getBoundingClientRect();Y=St(Y.x,Y.y,e.width,e.height,window.innerWidth,window.innerHeight),ge()}}async function Po(){return{error:"idle"}}async function sn(e){if(!$||je(e))return;const t=Jt(document,e.clientX,e.clientY);if(!t)return;if(e.preventDefault(),e.stopPropagation(),e.stopImmediatePropagation(),N==="design"){To(t,He(t));return}const n=He(t);if(po(N)){const o=jr(n);try{await navigator.clipboard.writeText(o)}catch{}}const r=fo(N,n);go(N)&&be(),A.runtime.sendMessage(r)}function Ro(e){if(!(!((e.ctrlKey||e.metaKey)&&!e.altKey&&!e.shiftKey)||!(e.key==="d"||e.key==="D"))){if(e.preventDefault(),e.stopPropagation(),e.stopImmediatePropagation(),$&&N==="design"){Qe();return}A.runtime.sendMessage({type:"design.start"})}}function cn(e){if(!(!$||e.key!=="Escape")){if(e.preventDefault(),N==="design"){if(e.stopPropagation(),e.stopImmediatePropagation(),ze){ne();return}Qe();return}e.stopPropagation(),e.stopImmediatePropagation(),be(),A.runtime.sendMessage({type:"picker.cancelled"})}}function ln(){Xt=document.documentElement.style.cursor,document.documentElement.style.cursor="crosshair",_e(document),document.addEventListener("mousemove",an,!0),document.addEventListener("click",sn,!0),document.addEventListener("keydown",cn,!0);for(const e of Gt)document.addEventListener(e,en,!0);window.addEventListener("scroll",he,!0),window.addEventListener("resize",he)}function dn(){var e;document.documentElement.style.cursor=Xt,document.removeEventListener("mousemove",an,!0),document.removeEventListener("click",sn,!0),document.removeEventListener("keydown",cn,!0);for(const t of Gt)document.removeEventListener(t,en,!0);window.removeEventListener("scroll",he,!0),window.removeEventListener("resize",he),(e=document.getElementById(ae))==null||e.remove()}function Qe(){de(),_="",X=!1,be(),A.runtime.sendMessage({type:"design.exited"})}function Bo(e="dev"){if(window===window.top){if(e==="design"){$&&N!=="design"&&(dn(),$=!1),N="design",_t({insertCss:t=>A.runtime.sendMessage({type:"design.insertCss",css:t}),removeCss:()=>{A.runtime.sendMessage({type:"design.removeCss"})}}),$||(ln(),$=!0),yo();return}if((N==="design"||C.some(t=>t.box))&&We(),$){N!==e&&(_e(document).style.display="none"),N=e;return}$=!0,N=e,ln()}}function be(){const e=N==="design"||C.length>0;if(!$&&!document.getElementById(ae)&&!l){e&&We();return}if($=!1,N="dev",dn(),e){We();return}nn()}function Oo(){window===window.top&&(document.addEventListener("keydown",Ro,!0),A.runtime.onMessage.addListener(e=>{if(!e||typeof e!="object"||!("type"in e))return;const t=e.type;if(t==="picker.arm"&&Bo(mo(e)),t==="picker.disarm"&&be(),t==="capture.stopElementRecord")return Po()}))}const un=window;function Fo(e){return!!(e&&typeof e=="object"&&e.type==="content.ping")}A.runtime.onMessage.addListener(e=>{if(Fo(e))return Promise.resolve(!0)}),un.__arcTodoContentReady||(un.__arcTodoContentReady=!0,window.addEventListener(An,e=>{const t=e.detail;typeof t=="string"&&A.runtime.sendMessage({type:"capture.console",payload:t})}),A.runtime.sendMessage({type:"capture.pageReady"}),Oo(),Bn(),br(),yn())})();
