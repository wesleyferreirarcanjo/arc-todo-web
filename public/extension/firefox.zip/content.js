(function(){"use strict";function Nt(e){return e&&e.__esModule&&Object.prototype.hasOwnProperty.call(e,"default")?e.default:e}var Q={exports:{}},St=Q.exports,ke;function Lt(){return ke||(ke=1,(function(e,t){(function(n,r){r(e)})(typeof globalThis<"u"?globalThis:typeof self<"u"?self:St,function(n){if(!(globalThis.chrome&&globalThis.chrome.runtime&&globalThis.chrome.runtime.id))throw new Error("This script should only be loaded in a browser extension.");if(globalThis.browser&&globalThis.browser.runtime&&globalThis.browser.runtime.id)n.exports=globalThis.browser;else{const r="The message port closed before a response was received.",o=a=>{const s={alarms:{clear:{minArgs:0,maxArgs:1},clearAll:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getAll:{minArgs:0,maxArgs:0}},bookmarks:{create:{minArgs:1,maxArgs:1},get:{minArgs:1,maxArgs:1},getChildren:{minArgs:1,maxArgs:1},getRecent:{minArgs:1,maxArgs:1},getSubTree:{minArgs:1,maxArgs:1},getTree:{minArgs:0,maxArgs:0},move:{minArgs:2,maxArgs:2},remove:{minArgs:1,maxArgs:1},removeTree:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1},update:{minArgs:2,maxArgs:2}},browserAction:{disable:{minArgs:0,maxArgs:1,fallbackToNoCallback:!0},enable:{minArgs:0,maxArgs:1,fallbackToNoCallback:!0},getBadgeBackgroundColor:{minArgs:1,maxArgs:1},getBadgeText:{minArgs:1,maxArgs:1},getPopup:{minArgs:1,maxArgs:1},getTitle:{minArgs:1,maxArgs:1},openPopup:{minArgs:0,maxArgs:0},setBadgeBackgroundColor:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setBadgeText:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setIcon:{minArgs:1,maxArgs:1},setPopup:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setTitle:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},browsingData:{remove:{minArgs:2,maxArgs:2},removeCache:{minArgs:1,maxArgs:1},removeCookies:{minArgs:1,maxArgs:1},removeDownloads:{minArgs:1,maxArgs:1},removeFormData:{minArgs:1,maxArgs:1},removeHistory:{minArgs:1,maxArgs:1},removeLocalStorage:{minArgs:1,maxArgs:1},removePasswords:{minArgs:1,maxArgs:1},removePluginData:{minArgs:1,maxArgs:1},settings:{minArgs:0,maxArgs:0}},commands:{getAll:{minArgs:0,maxArgs:0}},contextMenus:{remove:{minArgs:1,maxArgs:1},removeAll:{minArgs:0,maxArgs:0},update:{minArgs:2,maxArgs:2}},cookies:{get:{minArgs:1,maxArgs:1},getAll:{minArgs:1,maxArgs:1},getAllCookieStores:{minArgs:0,maxArgs:0},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}},devtools:{inspectedWindow:{eval:{minArgs:1,maxArgs:2,singleCallbackArg:!1}},panels:{create:{minArgs:3,maxArgs:3,singleCallbackArg:!0},elements:{createSidebarPane:{minArgs:1,maxArgs:1}}}},downloads:{cancel:{minArgs:1,maxArgs:1},download:{minArgs:1,maxArgs:1},erase:{minArgs:1,maxArgs:1},getFileIcon:{minArgs:1,maxArgs:2},open:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},pause:{minArgs:1,maxArgs:1},removeFile:{minArgs:1,maxArgs:1},resume:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1},show:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},extension:{isAllowedFileSchemeAccess:{minArgs:0,maxArgs:0},isAllowedIncognitoAccess:{minArgs:0,maxArgs:0}},history:{addUrl:{minArgs:1,maxArgs:1},deleteAll:{minArgs:0,maxArgs:0},deleteRange:{minArgs:1,maxArgs:1},deleteUrl:{minArgs:1,maxArgs:1},getVisits:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1}},i18n:{detectLanguage:{minArgs:1,maxArgs:1},getAcceptLanguages:{minArgs:0,maxArgs:0}},identity:{launchWebAuthFlow:{minArgs:1,maxArgs:1}},idle:{queryState:{minArgs:1,maxArgs:1}},management:{get:{minArgs:1,maxArgs:1},getAll:{minArgs:0,maxArgs:0},getSelf:{minArgs:0,maxArgs:0},setEnabled:{minArgs:2,maxArgs:2},uninstallSelf:{minArgs:0,maxArgs:1}},notifications:{clear:{minArgs:1,maxArgs:1},create:{minArgs:1,maxArgs:2},getAll:{minArgs:0,maxArgs:0},getPermissionLevel:{minArgs:0,maxArgs:0},update:{minArgs:2,maxArgs:2}},pageAction:{getPopup:{minArgs:1,maxArgs:1},getTitle:{minArgs:1,maxArgs:1},hide:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setIcon:{minArgs:1,maxArgs:1},setPopup:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setTitle:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},show:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},permissions:{contains:{minArgs:1,maxArgs:1},getAll:{minArgs:0,maxArgs:0},remove:{minArgs:1,maxArgs:1},request:{minArgs:1,maxArgs:1}},runtime:{getBackgroundPage:{minArgs:0,maxArgs:0},getPlatformInfo:{minArgs:0,maxArgs:0},openOptionsPage:{minArgs:0,maxArgs:0},requestUpdateCheck:{minArgs:0,maxArgs:0},sendMessage:{minArgs:1,maxArgs:3},sendNativeMessage:{minArgs:2,maxArgs:2},setUninstallURL:{minArgs:1,maxArgs:1}},sessions:{getDevices:{minArgs:0,maxArgs:1},getRecentlyClosed:{minArgs:0,maxArgs:1},restore:{minArgs:0,maxArgs:1}},storage:{local:{clear:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}},managed:{get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1}},sync:{clear:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}}},tabs:{captureVisibleTab:{minArgs:0,maxArgs:2},create:{minArgs:1,maxArgs:1},detectLanguage:{minArgs:0,maxArgs:1},discard:{minArgs:0,maxArgs:1},duplicate:{minArgs:1,maxArgs:1},executeScript:{minArgs:1,maxArgs:2},get:{minArgs:1,maxArgs:1},getCurrent:{minArgs:0,maxArgs:0},getZoom:{minArgs:0,maxArgs:1},getZoomSettings:{minArgs:0,maxArgs:1},goBack:{minArgs:0,maxArgs:1},goForward:{minArgs:0,maxArgs:1},highlight:{minArgs:1,maxArgs:1},insertCSS:{minArgs:1,maxArgs:2},move:{minArgs:2,maxArgs:2},query:{minArgs:1,maxArgs:1},reload:{minArgs:0,maxArgs:2},remove:{minArgs:1,maxArgs:1},removeCSS:{minArgs:1,maxArgs:2},sendMessage:{minArgs:2,maxArgs:3},setZoom:{minArgs:1,maxArgs:2},setZoomSettings:{minArgs:1,maxArgs:2},update:{minArgs:1,maxArgs:2}},topSites:{get:{minArgs:0,maxArgs:0}},webNavigation:{getAllFrames:{minArgs:1,maxArgs:1},getFrame:{minArgs:1,maxArgs:1}},webRequest:{handlerBehaviorChanged:{minArgs:0,maxArgs:0}},windows:{create:{minArgs:0,maxArgs:1},get:{minArgs:1,maxArgs:2},getAll:{minArgs:0,maxArgs:1},getCurrent:{minArgs:0,maxArgs:1},getLastFocused:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},update:{minArgs:2,maxArgs:2}}};if(Object.keys(s).length===0)throw new Error("api-metadata.json has not been included in browser-polyfill");class c extends WeakMap{constructor(u,b=void 0){super(b),this.createItem=u}get(u){return this.has(u)||this.set(u,this.createItem(u)),super.get(u)}}const g=l=>l&&typeof l=="object"&&typeof l.then=="function",p=(l,u)=>(...b)=>{a.runtime.lastError?l.reject(new Error(a.runtime.lastError.message)):u.singleCallbackArg||b.length<=1&&u.singleCallbackArg!==!1?l.resolve(b[0]):l.resolve(b)},m=l=>l==1?"argument":"arguments",y=(l,u)=>function(x,...N){if(N.length<u.minArgs)throw new Error(`Expected at least ${u.minArgs} ${m(u.minArgs)} for ${l}(), got ${N.length}`);if(N.length>u.maxArgs)throw new Error(`Expected at most ${u.maxArgs} ${m(u.maxArgs)} for ${l}(), got ${N.length}`);return new Promise((I,P)=>{if(u.fallbackToNoCallback)try{x[l](...N,p({resolve:I,reject:P},u))}catch(f){console.warn(`${l} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `,f),x[l](...N),u.fallbackToNoCallback=!1,u.noCallback=!0,I()}else u.noCallback?(x[l](...N),I()):x[l](...N,p({resolve:I,reject:P},u))})},C=(l,u,b)=>new Proxy(u,{apply(x,N,I){return b.call(N,l,...I)}});let O=Function.call.bind(Object.prototype.hasOwnProperty);const F=(l,u={},b={})=>{let x=Object.create(null),N={has(P,f){return f in l||f in x},get(P,f,$){if(f in x)return x[f];if(!(f in l))return;let k=l[f];if(typeof k=="function")if(typeof u[f]=="function")k=C(l,l[f],u[f]);else if(O(b,f)){let X=y(f,b[f]);k=C(l,l[f],X)}else k=k.bind(l);else if(typeof k=="object"&&k!==null&&(O(u,f)||O(b,f)))k=F(k,u[f],b[f]);else if(O(b,"*"))k=F(k,u[f],b["*"]);else return Object.defineProperty(x,f,{configurable:!0,enumerable:!0,get(){return l[f]},set(X){l[f]=X}}),k;return x[f]=k,k},set(P,f,$,k){return f in x?x[f]=$:l[f]=$,!0},defineProperty(P,f,$){return Reflect.defineProperty(x,f,$)},deleteProperty(P,f){return Reflect.deleteProperty(x,f)}},I=Object.create(l);return new Proxy(I,N)},z=l=>({addListener(u,b,...x){u.addListener(l.get(b),...x)},hasListener(u,b){return u.hasListener(l.get(b))},removeListener(u,b){u.removeListener(l.get(b))}}),dr=new c(l=>typeof l!="function"?l:function(b){const x=F(b,{},{getContent:{minArgs:0,maxArgs:0}});l(x)}),kt=new c(l=>typeof l!="function"?l:function(b,x,N){let I=!1,P,f=new Promise(Z=>{P=function(B){I=!0,Z(B)}}),$;try{$=l(b,x,P)}catch(Z){$=Promise.reject(Z)}const k=$!==!0&&g($);if($!==!0&&!k&&!I)return!1;const X=Z=>{Z.then(B=>{N(B)},B=>{let Ee;B&&(B instanceof Error||typeof B.message=="string")?Ee=B.message:Ee="An unexpected error occurred",N({__mozWebExtensionPolyfillReject__:!0,message:Ee})}).catch(B=>{console.error("Failed to send onMessage rejected reply",B)})};return X(k?$:f),!0}),ur=({reject:l,resolve:u},b)=>{a.runtime.lastError?a.runtime.lastError.message===r?u():l(new Error(a.runtime.lastError.message)):b&&b.__mozWebExtensionPolyfillReject__?l(new Error(b.message)):u(b)},Ct=(l,u,b,...x)=>{if(x.length<u.minArgs)throw new Error(`Expected at least ${u.minArgs} ${m(u.minArgs)} for ${l}(), got ${x.length}`);if(x.length>u.maxArgs)throw new Error(`Expected at most ${u.maxArgs} ${m(u.maxArgs)} for ${l}(), got ${x.length}`);return new Promise((N,I)=>{const P=ur.bind(null,{resolve:N,reject:I});x.push(P),b.sendMessage(...x)})},mr={devtools:{network:{onRequestFinished:z(dr)}},runtime:{onMessage:z(kt),onMessageExternal:z(kt),sendMessage:Ct.bind(null,"sendMessage",{minArgs:1,maxArgs:3})},tabs:{sendMessage:Ct.bind(null,"sendMessage",{minArgs:2,maxArgs:3})}},we={clear:{minArgs:1,maxArgs:1},get:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}};return s.privacy={network:{"*":we},services:{"*":we},websites:{"*":we}},F(a,mr,s)};n.exports=o(chrome)}})})(Q)),Q.exports}var Mt=Lt();const A=Nt(Mt),S={designHeading:"Notas de design",designNote:"O que deve mudar",designNotePlaceholder:"Descreva o que a IA deve alterar neste elemento",designEmpty:"Toque nos elementos da página para comentar.",designRemove:"Remover",designExit:"Sair",designClear:"Limpar",signInFirst:"Entre no Arc Todo para usar este painel.",sessionExpired:"Sessão expirada. Entre de novo no Arc Todo.",apiError:"Não foi possível falar com a API. Tente de novo.",flagAsBug:"Marcar como bug",motivo:"Motivo",motivoPlaceholder:"Descreva o problema encontrado",motivoRequired:"O motivo do bug é obrigatório.",itemMotivoRequired:"O motivo do bug do item é obrigatório.",taskBugWarning:"Este card volta para To Do, inclusive as subtarefas.",checklistChanged:"A checklist mudou. Recarregue e tente de novo.",noChecklist:"Esta tarefa não tem checklist.",cancelFlag:"Cancelar",copy:"Copiar",copied:"Copiado",copyWithScreenshot:"Copiar com captura",itemDone:"Feito",itemOpen:"A fazer",closeFloatingChecklist:"Fechar checklist flutuante",collapseOverlay:"Recolher",expandOverlay:"Expandir",overlayDragHint:"Arraste pelo cabeçalho",overlayLoading:"Carregando a checklist…",instructionsHeading:"Instruções",checklistHeading:"Checklist",solveBug:"Marcar como resolvido",solveItem:"Resolvido",agentStop:"Parar"},Ce="arc-todo-agent-overlay",Ne="arc-todo-agent-cursor",Se="arc-todo-agent-stop";function se(){return document.getElementById(Ce)}function Tt(e,t){var o;let n=se();if(!n){n=document.createElement("div"),n.id=Ce,n.setAttribute("data-arc-todo-agent","1");const a=n.attachShadow({mode:"open"}),s=document.createElement("style");s.textContent=`
      :host {
        all: initial;
        --text-primary: #e8ecf4;
        --accent: #3d52b8;
        --accent-contrast: #f7f8fc;
        --z-overlay: 2147483646;
      }
      .wrap {
        position: fixed; inset: 0; pointer-events: none;
        z-index: var(--z-overlay);
      }
      .cursor {
        position: absolute; width: 22px; height: 22px; margin: -2px 0 0 -2px;
        filter: drop-shadow(0 0 6px var(--glow));
      }
      .cursor-path { fill: var(--text-primary); stroke: var(--accent); }
      .stop {
        pointer-events: auto; position: fixed; top: 12px; right: 12px;
        font: 600 12px system-ui, sans-serif; color: var(--accent-contrast);
        background: var(--accent); border: 0; border-radius: 6px;
        padding: 6px 10px;
        box-shadow: 0 0 16px var(--glow); cursor: pointer;
      }
      @media (prefers-reduced-motion: no-preference) {
        .cursor { transition: transform 80ms linear; }
      }
    `;const c=document.createElement("div");c.className="wrap";const g=document.createElement("div");g.id=Ne,g.className="cursor",g.setAttribute("aria-hidden","true"),g.innerHTML='<svg viewBox="0 0 24 24" width="22" height="22" xmlns="http://www.w3.org/2000/svg"><path class="cursor-path" d="M4 2l16 12-7 1 4 8-4 1-4-8-5 4z" stroke-width="1.2"/></svg>';const p=document.createElement("button");p.id=Se,p.className="stop",p.type="button",p.textContent=S.agentStop,c.append(g,p),a.append(s,c),document.documentElement.append(n),p.addEventListener("click",()=>{A.runtime.sendMessage({type:"agent.stop"})})}n.style.setProperty("--glow",e);const r=(o=n.shadowRoot)==null?void 0:o.getElementById(Se);return r&&r.setAttribute("title",`Arc AI · ${t}`),n}function It(e){var r,o;if(e.type==="agent.overlay.hide"){(r=se())==null||r.remove();return}if(e.type==="agent.overlay.show"){Tt(e.color,e.clientName);return}const t=se(),n=(o=t==null?void 0:t.shadowRoot)==null?void 0:o.getElementById(Ne);n&&(n.style.transform=`translate(${e.x}px, ${e.y}px)`)}function Pt(){A.runtime.onMessage.addListener(e=>{if(!e||typeof e!="object")return;const t=e.type;if(t==="agent.overlay.show"||t==="agent.overlay.hide"||t==="agent.overlay.move")return It(e),Promise.resolve(!0)})}const $t="arc-todo-capture",H="arc-todo-qa-overlay",Rt=2147483645,ce="arcTodo.overlayPosition",le="arcTodo.overlaySections";function Ot(e,t,n,r,o,a){const s=Math.max(0,Math.min(e,n)),c=Math.max(0,Math.min(t,r)),g=Math.min(o,Math.max(e,n)),p=Math.min(a,Math.max(t,r)),m=g-s,y=p-c;return m<4||y<4?null:{x:s,y:c,width:m,height:y}}function Bt(e,t,n,r,o){const a=Ot(e,t,n,r,o.width,o.height);return a?{rect:a,viewport:o}:null}const U="arc-todo-region-overlay",G="arc-todo-region-marquee",Le="2147483646",_t="rgba(0, 0, 0, 0.35)",zt="#ffffff";function Me(e){e.style.setProperty("--arc-region-scrim",_t),e.style.setProperty("--arc-region-line",zt)}const Te=["pointerdown","mousedown","mouseup","auxclick","contextmenu","dblclick"];let _=!1,Ie="",q=null;function qt(){return{position:"fixed",inset:"0",zIndex:Le,cursor:"crosshair",background:"var(--arc-region-scrim)",boxSizing:"border-box"}}function Dt(){return{position:"fixed",pointerEvents:"none",zIndex:Le,outline:"2px solid var(--arc-region-line)",outlineOffset:"0",boxShadow:"0 0 0 99999px var(--arc-region-scrim)",boxSizing:"border-box",display:"none",background:"transparent"}}function Ft(e){let t=e.getElementById(U);return t||(t=e.createElement("div"),t.id=U,t.setAttribute("aria-hidden","true"),Me(t),Object.assign(t.style,qt()),e.documentElement.appendChild(t),t)}function Pe(e){let t=e.getElementById(G);return t||(t=e.createElement("div"),t.id=G,t.setAttribute("aria-hidden","true"),Me(t),Object.assign(t.style,Dt()),e.documentElement.appendChild(t),t)}function Ht(e){return e?e.id===H?!0:!!e.closest(`#${H}`):!1}function jt(e,t,n){const r=e.getElementById(U),o=e.getElementById(G);r&&(r.style.pointerEvents="none"),o&&(o.style.pointerEvents="none");const a=e.elementFromPoint(t,n);return r&&(r.style.pointerEvents="auto"),a}function $e(e){_&&(e.preventDefault(),e.stopPropagation(),e.stopImmediatePropagation())}function Wt(e,t,n,r){const o=Math.min(e,n),a=Math.min(t,r),s=Pe(document);s.style.display="block",s.style.left=`${o}px`,s.style.top=`${a}px`,s.style.width=`${Math.abs(n-e)}px`,s.style.height=`${Math.abs(r-t)}px`}function Re(){const e=document.getElementById(G);e&&(e.style.display="none")}function Yt(){return{width:window.innerWidth,height:window.innerHeight}}function Oe(e){if(!_||e.button!==0)return;const t=jt(document,e.clientX,e.clientY);Ht(t)||(q={x:e.clientX,y:e.clientY},Re())}function Be(e){!_||!q||Wt(q.x,q.y,e.clientX,e.clientY)}function _e(e){if(!_||!q)return;const t=q;q=null;const n=Bt(t.x,t.y,e.clientX,e.clientY,Yt());Re(),n&&(A.runtime.sendMessage({type:"region.picked",rect:n.rect,viewport:n.viewport,devicePixelRatio:window.devicePixelRatio}),de())}function ze(e){!_||e.key!=="Escape"||(e.preventDefault(),de(),A.runtime.sendMessage({type:"region.cancelled"}))}function Xt(){if(window===window.top&&!_){_=!0,Ie=document.documentElement.style.cursor,document.documentElement.style.cursor="crosshair",Ft(document),Pe(document),document.addEventListener("pointerdown",Oe,!0),document.addEventListener("pointermove",Be,!0),document.addEventListener("pointerup",_e,!0),document.addEventListener("keydown",ze,!0);for(const e of Te)document.addEventListener(e,$e,!0)}}function de(){var e,t;if(!(!_&&!document.getElementById(U))){_=!1,q=null,document.documentElement.style.cursor=Ie,document.removeEventListener("pointerdown",Oe,!0),document.removeEventListener("pointermove",Be,!0),document.removeEventListener("pointerup",_e,!0),document.removeEventListener("keydown",ze,!0);for(const n of Te)document.removeEventListener(n,$e,!0);(e=document.getElementById(U))==null||e.remove(),(t=document.getElementById(G))==null||t.remove()}}function Ut(){window===window.top&&A.runtime.onMessage.addListener(e=>{if(!e||typeof e!="object"||!("type"in e))return;const t=e.type;t==="region.arm"&&Xt(),t==="region.disarm"&&de()})}function Gt(e){var t;return((t=e.find(n=>!n.checked))==null?void 0:t.id)??null}function Vt(e,t){var o;const n=e.findIndex(a=>a.id===t);return((o=(n>=0?e.slice(n+1):e).find(a=>!a.checked))==null?void 0:o.id)??Gt(e)}function Kt(e,t){if(t&&e.some(n=>n.id===t))return t}function Zt(e,t){return t==="panel"||t==="overlay"?t!==e:!0}function Qt(e,t,n,r,o=48){const a=o-r.width,s=n.width-o,c=0,g=Math.max(0,n.height-o);return{left:Math.min(s,Math.max(a,e)),top:Math.min(g,Math.max(c,t))}}function Jt(e,t,n=16){return{left:Math.max(n,e.width-t.width-n),top:Math.max(n,e.height-t.height-n)}}const qe=/(\*\*[^*]+\*\*|\*[^*]+\*|`[^`]+`|\[[^\]]+\]\(https?:\/\/[^)\s]+\)|https?:\/\/[^\s<>"'`]+)/g;function en(e){const t=[];let n=0;qe.lastIndex=0;let r;for(;r=qe.exec(e);){r.index>n&&t.push({type:"text",text:e.slice(n,r.index)});const o=r[0];if(o.startsWith("**"))t.push({type:"strong",text:o.slice(2,-2)});else if(o.startsWith("*"))t.push({type:"em",text:o.slice(1,-1)});else if(o.startsWith("`"))t.push({type:"code",text:o.slice(1,-1)});else if(o.startsWith("[")){const a=o.match(/^\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)$/);a&&t.push({type:"a",text:a[1],href:a[2]})}else{const a=o.replace(/[),.;:!?]+$/,""),s=o.slice(a.length);a&&t.push({type:"a",text:a,href:a}),s&&t.push({type:"text",text:s})}n=r.index+o.length}return n<e.length&&t.push({type:"text",text:e.slice(n)}),t.length>0?t:[{type:"text",text:e}]}function tn(e,t){const n=t.join(`
`).trim();n&&e.push({type:"p",text:n})}function nn(e){return`h${Math.min(e.length,4)}`}function rn(e){const t=[];let n=[],r=[],o=[],a=null;function s(){r.length!==0&&(t.push({type:"ul",items:r}),r=[])}function c(){o.length!==0&&(t.push({type:"ol",items:o}),o=[])}function g(){const m=n;n=[],tn(t,m)}function p(){s(),c()}for(const m of e.split(`
`)){if(a){m.startsWith("```")?(t.push({type:"pre",text:a.join(`
`)}),a=null):a.push(m);continue}if(m.startsWith("```")){p(),g(),a=[];continue}if(/^(-{3,}|\*{3,}|_{3,})\s*$/.test(m.trim())){p(),g(),t.push({type:"hr"});continue}const y=m.match(/^>\s?(.*)$/);if(y){p(),g();const z=t[t.length-1];(z==null?void 0:z.type)==="blockquote"?z.text=`${z.text}
${y[1]}`:t.push({type:"blockquote",text:y[1]});continue}const C=m.match(/^(#{1,4})\s+(.*)$/),O=m.match(/^[-*]\s+(.*)$/),F=m.match(/^\d+\.\s+(.*)$/);if(C){p(),g(),t.push({type:nn(C[1]),text:C[2]});continue}if(O){c(),g(),r.push(O[1]);continue}if(F){s(),g(),o.push(F[1]);continue}if(!m.trim()){p(),g();continue}p(),n.push(m)}return a&&t.push({type:"pre",text:a.join(`
`)}),p(),g(),t}function ue(e,t){for(const n of en(t)){if(n.type==="text"){e.appendChild(document.createTextNode(n.text));continue}if(n.type==="a"){const o=document.createElement("a");o.href=n.href,o.target="_blank",o.rel="noopener noreferrer",o.textContent=n.text,e.appendChild(o);continue}const r=document.createElement(n.type==="strong"?"strong":n.type==="em"?"em":"code");r.textContent=n.text,e.appendChild(r)}}function on(e,t){for(const n of rn(t)){if(n.type==="ul"||n.type==="ol"){const o=document.createElement(n.type);for(const a of n.items){const s=document.createElement("li");ue(s,a),o.appendChild(s)}e.appendChild(o);continue}if(n.type==="pre"){const o=document.createElement("pre"),a=document.createElement("code");a.textContent=n.text,o.appendChild(a),e.appendChild(o);continue}if(n.type==="hr"){e.appendChild(document.createElement("hr"));continue}if(n.type==="blockquote"){const o=document.createElement("blockquote");ue(o,n.text),e.appendChild(o);continue}const r=document.createElement(n.type);ue(r,n.text),e.appendChild(r)}}function an(e){if(!e||typeof e!="object"||Array.isArray(e))return null;const t=e;return typeof t.left!="number"||typeof t.top!="number"||!Number.isFinite(t.left)||!Number.isFinite(t.top)?null:{left:t.left,top:t.top}}const De=60;function sn(e){const t=e.replace(/\*\*/g,"").trim(),n=e.match(/^\s*\*\*(.+?)\*\*/);if(n)return{short:n[1].replace(/\*\*/g,"").trim(),full:t,fromBold:!0};const r=t.indexOf(":");return r>0?{short:t.slice(0,r).trim(),full:t,fromBold:!1}:t.length>De?{short:`${t.slice(0,De)}…`,full:t,fromBold:!1}:{short:t,full:t,fromBold:!1}}function Fe(e){return e.map(t=>{const n=sn(t.label);return{id:t.id,short:n.short,full:n.full,checked:t.checked,bugged:t.bugged,notes:t.notes}})}const J={instructionsCollapsed:!1,checklistCollapsed:!1};function cn(e){if(!e||typeof e!="object"||Array.isArray(e))return null;const t=e;return typeof t.instructionsCollapsed!="boolean"||typeof t.checklistCollapsed!="boolean"?null:{instructionsCollapsed:t.instructionsCollapsed,checklistCollapsed:t.checklistCollapsed}}const He=':root,[data-theme=dark]{--font-display: "Newsreader", Georgia, serif;--font-body: "Figtree", system-ui, sans-serif;--type-page: 1.75rem;--type-kpi: 2.25rem;--type-section: 1.05rem;--type-card: 1rem;--type-body: .875rem;--type-meta: .75rem;font-family:var(--font-body);line-height:1.5;font-weight:400;--bg-page: #0d1119;--bg-shell: #131924;--bg-surface: #1b2230;--bg-elevated: #252e3d;--text-primary: #e8ecf4;--text-muted: #9aa6bc;--text: var(--text-primary);--text-secondary: var(--text-muted);--border: rgba(142, 160, 188, .18);--border-strong: rgba(142, 160, 188, .34);--border-subtle: var(--border);--accent: #4862ce;--accent-secondary: #6846b8;--accent-tertiary: #4a5d9c;--accent-contrast: #f7f8fc;--danger-bg: #342027;--danger-text: #e38a90;--danger: var(--danger-text);--info-bg: #142a34;--info-text: #7fc8dd;--success-bg: #173027;--success-text: #7fc19b;--warning-bg: #33291a;--warning-text: #d5aa63;--smart-copy: #f5a524;--bug-badge: #f13a48;--bug-resolved-badge: #129b56;--color-success: var(--success-text);--color-danger: var(--danger-text);--link: #8cb4ff;--surface-muted: color-mix(in srgb, var(--bg-elevated) 78%, var(--bg-page));--entity-rail-width: 6px;--entity-mix-fill: 14%;--entity-mix-badge: 26%;--entity-mix-header: 22%;--entity-corner-opacity: .28;--entity-rail-card-width: 3px;--entity-rail-card-mix: 80%;--entity-corner-glow-mix: 40%;--entity-rail-glow-out-mix: 34%;--entity-rail-glow-in-mix: 14%;--shadow: rgba(6, 10, 18, .48);--shadow-soft: 0 4px 18px rgba(6, 10, 18, .36);--shadow-card: 0 8px 28px rgba(6, 10, 18, .4), 0 0 0 1px rgba(142, 160, 188, .1);--shadow-neon: var(--shadow-card);--shadow-lift: 0 12px 32px rgba(6, 10, 18, .46);--ring: rgba(140, 180, 255, .42);--ring-strong: rgba(104, 70, 184, .38);--drop-glow: 0 0 0 2px rgba(140, 180, 255, .24);--gradient-page: radial-gradient(ellipse 70% 42% at 12% -8%, rgba(72, 98, 206, .08), transparent 55%), radial-gradient(ellipse 50% 36% at 92% 8%, rgba(104, 70, 184, .07), transparent 52%);--gradient-accent: linear-gradient(135deg, #4862ce 0%, #6846b8 100%);--gradient-header: linear-gradient(90deg, rgba(72, 98, 206, .24), rgba(104, 70, 184, .14));--radius-sm: 10px;--radius-md: 16px;--radius-lg: 22px;--radius-xl: 28px;--radius-blob: 28px 8px 28px 8px;--radius-blob-alt: 8px 28px 8px 28px;--radius-control: 16px 6px 16px 6px;--radius-control-alt: 6px 16px 6px 16px;--radius-pill: 999px;--button-height: 2.65rem;--button-height-sm: 2.15rem;--sidebar-expanded-width: 260px;--sidebar-collapsed-width: 72px;--sidebar-width: var(--sidebar-collapsed-width);--board-column-min-width: 280px;--transition-fast: .15s ease;--transition-base: .22s ease;--icon-nav: 1.25rem;--icon-duotone-fill: .22;--z-banner: 40;--z-fab: 41;--z-toast: 80;--z-modal: 900;--z-chat: 950;--criticity-low-bg: rgba(154, 166, 188, .16);--criticity-low-text: #9aa6bc;--criticity-medium-bg: rgba(213, 170, 99, .16);--criticity-medium-text: #d5aa63;--criticity-high-bg: rgba(104, 70, 184, .18);--criticity-high-text: #c4b4ee;--criticity-critical-bg: rgba(227, 138, 144, .16);--criticity-critical-text: #e38a90;color:var(--text-primary);background:var(--bg-page)}[data-theme=light]{--bg-page: #e6eaf2;--bg-shell: #f3f5f9;--bg-surface: #fbfcfe;--bg-elevated: #eef1f6;--text-primary: #1b2230;--text-muted: #5a6578;--text: var(--text-primary);--border: rgba(46, 53, 69, .16);--border-strong: rgba(46, 53, 69, .28);--border-subtle: var(--border);--accent: #3d52b8;--accent-secondary: #5a3ea8;--accent-tertiary: #4a5d9c;--accent-contrast: #f7f8fc;--danger-bg: rgba(180, 83, 90, .12);--danger-text: #b4535a;--danger: var(--danger-text);--info-bg: rgba(42, 122, 144, .12);--info-text: #2a7a90;--success-bg: rgba(47, 122, 88, .12);--success-text: #2f7a58;--warning-bg: rgba(138, 106, 40, .12);--warning-text: #8a6a28;--smart-copy: #c47d0a;--bug-badge: #e11d32;--bug-resolved-badge: #0d8a4b;--color-success: var(--success-text);--color-danger: var(--danger-text);--link: #3d52b8;--surface-muted: color-mix(in srgb, var(--bg-elevated) 70%, var(--bg-page));--shadow: rgba(27, 34, 48, .12);--shadow-soft: 0 4px 16px rgba(27, 34, 48, .08);--shadow-card: 0 8px 24px rgba(27, 34, 48, .1), 0 0 0 1px rgba(46, 53, 69, .1);--shadow-neon: var(--shadow-card);--shadow-lift: 0 12px 28px rgba(27, 34, 48, .12);--ring: rgba(61, 82, 184, .38);--ring-strong: rgba(90, 62, 168, .32);--drop-glow: 0 0 0 2px rgba(61, 82, 184, .2);--gradient-page: radial-gradient(ellipse 70% 42% at 12% -8%, rgba(61, 82, 184, .06), transparent 55%), radial-gradient(ellipse 50% 36% at 92% 8%, rgba(90, 62, 168, .05), transparent 52%);--gradient-accent: linear-gradient(135deg, #3d52b8 0%, #5a3ea8 100%);--gradient-header: linear-gradient(90deg, rgba(61, 82, 184, .16), rgba(90, 62, 168, .1));--criticity-low-bg: rgba(90, 101, 120, .14);--criticity-low-text: #5a6578;--criticity-medium-bg: rgba(138, 106, 40, .14);--criticity-medium-text: #8a6a28;--criticity-high-bg: rgba(90, 62, 168, .12);--criticity-high-text: #5a3ea8;--criticity-critical-bg: rgba(180, 83, 90, .12);--criticity-critical-text: #b4535a}*{box-sizing:border-box}body{margin:0;min-height:100vh;background:var(--bg-page);color:var(--text-primary)}h1,h2,h3,h4,p{margin:0}button,input,select,textarea{font:inherit}button:focus-visible,a:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible{outline:2px solid var(--ring);outline-offset:2px}',je=He.replace(/:root/g,":host").replace(/\[data-theme(=[^\]]+)\]/g,":host([data-theme$1])"),ln=`
:host {
  all: initial;
  position: fixed;
  z-index: 2147483645;
}

${je}

:host {
  color-scheme: dark;
  background: transparent;
}
:host([data-theme='light']) {
  color-scheme: light;
}

*, *::before, *::after { box-sizing: border-box; }

.panel {
  width: min(420px, calc(100vw - 24px));
  max-height: min(70vh, 520px);
  display: flex;
  flex-direction: column;
  background: var(--bg-surface);
  color: var(--text-primary);
  border: 1px solid var(--border);
  border-radius: var(--radius-md);
  box-shadow: var(--shadow-lift);
  overflow: hidden;
  font-size: var(--type-body);
  line-height: 1.4;
}

.panel.is-collapsed .body { display: none; }
.panel:focus-visible { outline: 2px solid var(--ring); outline-offset: 2px; }

.header {
  display: flex;
  align-items: flex-start;
  gap: 0.5rem;
  padding: 0.55rem 0.65rem;
  background: var(--bg-elevated);
  border-bottom: 1px solid var(--border);
  cursor: grab;
  touch-action: none;
  user-select: none;
}

.header:active { cursor: grabbing; }

.header-text {
  flex: 1;
  min-width: 0;
}

.display-id {
  margin: 0;
  font-size: var(--type-meta);
  color: var(--text-muted);
  font-weight: 600;
}

.title {
  margin: 0.1rem 0 0;
  font-size: var(--type-section);
  font-weight: 700;
  line-height: 1.25;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.header-actions {
  display: flex;
  gap: 0.25rem;
  flex-shrink: 0;
}

.icon-btn {
  appearance: none;
  border: 1px solid var(--border);
  background: transparent;
  color: var(--text-primary);
  border-radius: var(--radius-sm);
  min-width: 1.75rem;
  min-height: 1.75rem;
  font: inherit;
  font-size: var(--type-body);
  line-height: 1;
  cursor: pointer;
  padding: 0;
}

@media (hover: hover) and (pointer: fine) {
  .icon-btn:hover { background: var(--bg-surface); }
}

@media (pointer: coarse) {
  .icon-btn { min-width: 2.75rem; min-height: 2.75rem; }
}

.body {
  overflow: auto;
  padding: 0.5rem;
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

.hint {
  margin: 0;
  font-size: var(--type-meta);
  color: var(--text-muted);
}

.list {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
  gap: 0.375rem;
}

.row {
  border: 1px solid var(--border);
  border-radius: var(--radius-sm);
  background: var(--bg-elevated);
  padding: 0.375rem;
}

.row.is-bugged { border-color: var(--danger); }
.row.is-current {
  border-color: var(--accent);
  box-shadow: inset 0.2rem 0 0 var(--accent);
}

.row-main {
  display: flex;
  gap: 0.35rem;
  align-items: center;
}

.tick {
  appearance: none;
  border: 0;
  background: transparent;
  color: var(--text-primary);
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  padding: 0.1rem;
  font: inherit;
  min-width: 1.5rem;
  min-height: 1.5rem;
}

.tick-mark {
  width: 1.1rem;
  height: 1.1rem;
  border-radius: 999px;
  border: 2px solid var(--text-muted);
  display: flex;
  align-items: center;
  justify-content: center;
}

.tick.is-checked .tick-mark {
  border-color: var(--accent);
  background: var(--accent);
}

.tick.is-checked .tick-mark::after {
  content: '✓';
  color: var(--accent-contrast);
  font-size: var(--type-meta);
  font-weight: 700;
  line-height: 1;
}

.expand {
  appearance: none;
  border: 0;
  background: transparent;
  color: var(--text-primary);
  text-align: left;
  flex: 1;
  min-width: 0;
  cursor: pointer;
  font: inherit;
  padding: 0.15rem 0;
}

.expand strong { font-weight: 650; }

.row-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 0.25rem;
  margin-top: 0.35rem;
}

.btn {
  appearance: none;
  border: 1px solid var(--border);
  background: var(--bg-surface);
  color: var(--text-primary);
  border-radius: var(--radius-control);
  font: inherit;
  font-size: var(--type-meta);
  font-weight: 600;
  min-height: 1.5rem;
  padding: 0.3rem 0.5rem;
  cursor: pointer;
}

.btn-primary {
  background: var(--accent);
  border-color: var(--accent);
  color: var(--accent-contrast);
}

.btn:disabled {
  opacity: 0.45;
  cursor: not-allowed;
}

.bug-form {
  display: flex;
  flex-direction: column;
  gap: 0.35rem;
  margin-top: 0.35rem;
}

.bug-form label {
  display: flex;
  flex-direction: column;
  gap: 0.2rem;
  font-size: var(--type-meta);
  color: var(--text-muted);
}

.bug-form textarea {
  resize: vertical;
  min-height: 3.5rem;
  border: 1px solid var(--border);
  border-radius: var(--radius-sm);
  background: var(--bg-surface);
  color: var(--text-primary);
  font: inherit;
  padding: 0.35rem;
}

.warning {
  margin: 0;
  font-size: var(--type-meta);
  color: var(--text-muted);
}

.error {
  margin: 0;
  font-size: var(--type-meta);
  color: var(--danger);
}

.notes {
  margin: 0.25rem 0 0;
  padding-left: 1rem;
  font-size: var(--type-meta);
  color: var(--text-muted);
}

.section {
  display: flex;
  flex-direction: column;
  gap: 0.35rem;
  min-width: 0;
}

.section-heading {
  margin: 0;
  font-size: var(--type-meta);
}

.section-toggle {
  appearance: none;
  display: flex;
  align-items: baseline;
  gap: 0.4rem;
  width: 100%;
  margin: 0;
  min-height: 1.5rem;
  padding: 0.25rem 0;
  border: 0;
  background: transparent;
  color: var(--text-muted);
  font: inherit;
  font-size: var(--type-meta);
  font-weight: 700;
  letter-spacing: 0.02em;
  text-transform: uppercase;
  text-align: left;
  cursor: pointer;
}

.section-progress {
  font-weight: 650;
  color: var(--text-primary);
  text-transform: none;
  letter-spacing: 0;
}

.help {
  display: flex;
  flex-direction: column;
  gap: 0.4rem;
  min-width: 0;
}

.help p,
.help li {
  margin: 0;
  font-size: var(--type-meta);
  color: var(--text-muted);
}

.help ul,
.help ol {
  margin: 0;
  padding-left: 1.1rem;
}

.help h1,
.help h2,
.help h3,
.help h4 {
  margin: 0;
  font-size: var(--type-body);
  font-weight: 650;
  color: var(--text-primary);
}

.help strong { font-weight: 700; color: var(--text-primary); }
.help em { font-style: italic; }
.help code {
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  font-size: 0.88em;
  padding: 0.05em 0.3em;
  border-radius: var(--radius-sm);
  border: 1px solid var(--border);
}
.help a { color: var(--link); }
.help pre {
  margin: 0;
  padding: 0.45rem 0.55rem;
  overflow-x: auto;
  border: 1px solid var(--border);
  border-radius: var(--radius-sm);
  font-size: var(--type-meta);
}
.help pre code { padding: 0; border: none; }
.help hr {
  width: 100%;
  border: none;
  border-top: 1px solid var(--border);
  margin: 0.2rem 0;
}
.help blockquote {
  margin: 0;
  padding: 0.15rem 0 0.15rem 0.6rem;
  border-left: 2px solid var(--border);
  color: var(--text-muted);
}
`,h=S;let v=null,M=null,i=null,me=null,R=null;function dn(e){return e.status==="expired"?h.sessionExpired:e.status==="not_signed_in"?h.signInFirst:e.error==="stale"?h.checklistChanged:e.error==="motivo"?h.motivoRequired:e.error==="api"||e.status==="error"?h.apiError:null}function un(){const e=document.getElementById(H);if(e&&M&&v===e)return{host:e,shadow:M};e==null||e.remove();const t=document.createElement("div");t.id=H,Object.assign(t.style,{position:"fixed",zIndex:String(Rt),left:"0px",top:"0px"});const n=t.attachShadow({mode:"open"}),r=document.createElement("style");return r.textContent=He.replace(/:root/g,":host")+ln,n.appendChild(r),document.documentElement.appendChild(t),v=t,M=n,{host:t,shadow:n}}async function mn(){try{const e=await A.storage.local.get(ce);return an(e[ce])}catch{return null}}async function gn(e,t){try{await A.storage.local.set({[ce]:{left:e,top:t}})}catch{}}async function pn(){try{const e=await A.storage.local.get(le);return cn(e[le])??J}catch{return J}}async function We(){if(i)try{await A.storage.local.set({[le]:{instructionsCollapsed:i.instructionsCollapsed,checklistCollapsed:i.checklistCollapsed}})}catch{}}function ge(e,t){if(!v)return;const n=v.getBoundingClientRect(),r=Qt(e,t,{width:window.innerWidth,height:window.innerHeight},{width:n.width||420,height:Math.min(n.height||48,48)});v.style.left=`${r.left}px`,v.style.top=`${r.top}px`}function Ye(){if(!v)return;const e=Number.parseFloat(v.style.left||"0"),t=Number.parseFloat(v.style.top||"0");ge(e,t)}async function fn(){if(!v)return;const e=await mn(),t={width:420,height:320},n=e??Jt({width:window.innerWidth,height:window.innerHeight},t);ge(n.left,n.top)}function hn(e){if(!v||e.button!==0)return;const t=e.target;if(t!=null&&t.closest("button"))return;const n=Number.parseFloat(v.style.left||"0"),r=Number.parseFloat(v.style.top||"0");R={pointerId:e.pointerId,startX:e.clientX,startY:e.clientY,originLeft:n,originTop:r},e.currentTarget.setPointerCapture(e.pointerId),e.preventDefault()}function bn(e){!R||e.pointerId!==R.pointerId||ge(R.originLeft+(e.clientX-R.startX),R.originTop+(e.clientY-R.startY))}function Xe(e){if(!R||e.pointerId!==R.pointerId||!v)return;R=null;const t=Number.parseFloat(v.style.left||"0"),n=Number.parseFloat(v.style.top||"0");gn(t,n)}function w(){if(!M||!i)return;const e=M.querySelector(".panel");if(!e)return;e.classList.toggle("is-collapsed",i.collapsed);const t=M.querySelector(".title"),n=M.querySelector(".display-id");t&&(t.textContent=i.task.title),n&&(n.textContent=i.task.displayId);const r=M.querySelector('[data-action="collapse"]');r&&(r.setAttribute("aria-label",i.collapsed?h.expandOverlay:h.collapseOverlay),r.setAttribute("aria-expanded",String(!i.collapsed)),r.textContent=i.collapsed?"▸":"▾");const o=M.querySelector(".body");if(!o)return;if(o.replaceChildren(),i.error){const c=document.createElement("p");c.className="error",c.setAttribute("role","alert"),c.textContent=i.error,o.appendChild(c)}const a=document.createElement("p");a.className="hint",a.textContent=h.overlayDragHint,o.appendChild(a),i.helpMarkdown&&o.appendChild(yn(i.helpMarkdown));const s=Fe(i.items);if(s.length===0){const c=document.createElement("p");c.className="hint",c.textContent=i.loading?h.overlayLoading:h.noChecklist,o.appendChild(c)}else o.appendChild(vn(s.map(c=>c.id)));if(i.taskBugOpen)o.appendChild(wn());else if(i.isBug){const c=document.createElement("button");c.type="button",c.className="btn",c.textContent=h.solveBug,c.disabled=i.busy,c.addEventListener("click",()=>{Sn()}),o.appendChild(c)}else{const c=document.createElement("button");c.type="button",c.className="btn",c.textContent=h.flagAsBug,c.disabled=i.busy,c.addEventListener("click",()=>{i&&(i.taskBugOpen=!0,i.taskNote="",i.error=null,w())}),o.appendChild(c)}}function xn(e){const t=i.items.find(m=>m.id===e),n=document.createElement("li"),r=Kt(i.items,i.expandedId);n.className=["row",t.bugged?"is-bugged":"",t.id===r?"is-current":""].filter(Boolean).join(" ");const o=document.createElement("div");o.className="row-main";const a=document.createElement("button");a.type="button",a.className=t.checked?"tick is-checked":"tick",a.setAttribute("aria-pressed",String(t.checked)),a.setAttribute("aria-label",t.checked?h.itemDone:h.itemOpen),a.disabled=i.busy;const s=document.createElement("span");s.className="tick-mark",s.setAttribute("aria-hidden","true"),a.append(s),a.addEventListener("click",()=>{En(t.id)});const c=Fe([t])[0],g=document.createElement("button");g.type="button",g.className="expand";const p=i.expandedId===t.id;if(g.setAttribute("aria-expanded",String(p)),p)g.textContent=c.full;else{const m=document.createElement("strong");m.textContent=c.short,g.appendChild(m)}if(g.addEventListener("click",()=>{i&&(i.expandedId=i.expandedId===t.id?null:t.id,w())}),o.append(a,g),n.appendChild(o),t.notes.length){const m=document.createElement("ul");m.className="notes";for(const y of t.notes){const C=document.createElement("li");C.innerHTML="";const O=document.createElement("strong");O.textContent=`${h.motivo}: `,C.append(O,document.createTextNode(y)),m.appendChild(C)}n.appendChild(m)}if(i.reportingItemId===t.id)n.appendChild(An(t.id));else if(p){const m=document.createElement("div");m.className="row-actions";const y=document.createElement("button");if(y.type="button",y.className="btn",y.textContent=h.flagAsBug,y.disabled=i.busy,y.addEventListener("click",()=>{i&&(i.reportingItemId=t.id,i.itemNote="",i.error=null,w())}),m.appendChild(y),t.bugged){const C=document.createElement("button");C.type="button",C.className="btn",C.textContent=h.solveItem,C.disabled=i.busy,C.addEventListener("click",()=>{Nn(t.id)}),m.appendChild(C)}n.appendChild(m)}return n}function Ue(e,t,n,r){const o=document.createElement("button");o.type="button",o.className="section-toggle",o.setAttribute("aria-expanded",String(t));const a=document.createTextNode(e);if(o.appendChild(a),r){o.appendChild(document.createTextNode(" "));const c=document.createElement("span");c.className="section-progress",c.textContent=r,o.appendChild(c)}o.addEventListener("click",n);const s=document.createElement("h3");return s.className="section-heading",s.appendChild(o),s}function yn(e){const t=document.createElement("section");t.className="section";const n=!i.instructionsCollapsed;if(t.appendChild(Ue(h.instructionsHeading,n,()=>{i&&(i.instructionsCollapsed=!i.instructionsCollapsed,We(),w())})),n){const r=document.createElement("div");r.className="help markdown-content",on(r,e),t.appendChild(r)}return t}function vn(e){const t=document.createElement("section");t.className="section";const n=!i.checklistCollapsed,r=i.items.filter(o=>o.checked).length;if(t.appendChild(Ue(h.checklistHeading,n,()=>{i&&(i.checklistCollapsed=!i.checklistCollapsed,We(),w())},`${r}/${i.items.length}`)),n){const o=document.createElement("ul");o.className="list";for(const a of e)o.appendChild(xn(a));t.appendChild(o)}return t}function An(e){const t=document.createElement("div");t.className="bug-form";const n=document.createElement("label");n.textContent=h.motivo;const r=document.createElement("textarea");r.value=i.itemNote,r.placeholder=h.motivoPlaceholder,r.rows=3,r.addEventListener("input",()=>{i&&(i.itemNote=r.value,a.disabled=i.busy||!i.itemNote.trim())}),n.appendChild(r);const o=document.createElement("div");o.className="row-actions";const a=document.createElement("button");a.type="button",a.className="btn btn-primary",a.textContent=h.flagAsBug,a.disabled=i.busy||!i.itemNote.trim(),a.addEventListener("click",()=>{kn(e)});const s=document.createElement("button");return s.type="button",s.className="btn",s.textContent=h.cancelFlag,s.addEventListener("click",()=>{i&&(i.reportingItemId=null,i.itemNote="",w())}),o.append(a,s),t.append(n,o),t}function wn(){const e=document.createElement("div");e.className="bug-form";const t=document.createElement("p");t.className="warning",t.textContent=h.taskBugWarning;const n=document.createElement("label");n.textContent=h.motivo;const r=document.createElement("textarea");r.value=i.taskNote,r.placeholder=h.motivoPlaceholder,r.rows=3,r.addEventListener("input",()=>{i&&(i.taskNote=r.value,a.disabled=i.busy||!i.taskNote.trim())}),n.appendChild(r);const o=document.createElement("div");o.className="row-actions";const a=document.createElement("button");a.type="button",a.className="btn btn-primary",a.textContent=h.flagAsBug,a.disabled=i.busy||!i.taskNote.trim(),a.addEventListener("click",()=>{Cn()});const s=document.createElement("button");return s.type="button",s.className="btn",s.textContent=h.cancelFlag,s.addEventListener("click",()=>{i&&(i.taskBugOpen=!1,i.taskNote="",w())}),o.append(a,s),e.append(t,n,o),e}function j(e){if(!i)return!1;const t=dn(e);if(t)return i.error=t,!1;if(i.error=null,e.items){i.items=e.items;const n=i.expandedId;n&&!e.items.some(r=>r.id===n)&&(i.expandedId=null)}return e.snapshot&&(i.snapshot=e.snapshot),e.helpMarkdown!==void 0&&(i.helpMarkdown=e.helpMarkdown??null),e.isBug!==void 0&&(i.isBug=e.isBug),!0}async function Ge(){if(i){i.busy=!0,w();try{const e=await A.runtime.sendMessage({type:"task.get",task:i.task});j(e)}finally{i&&(i.busy=!1,i.loading=!1),w()}}}async function En(e){if(!(!i||i.busy)){i.busy=!0,i.error=null,w();try{const t=await A.runtime.sendMessage({type:"checklist.tick",task:i.task,itemId:e,snapshot:i.snapshot,source:"overlay"});if(j(t),i){const n=i.items.find(r=>r.id===e);n!=null&&n.checked?i.expandedId=Vt(i.items,e):i.expandedId=e}}finally{i&&(i.busy=!1),w()}}}async function kn(e){if(!(!i||i.busy)){if(!i.itemNote.trim()){i.error=h.itemMotivoRequired,w();return}i.busy=!0,i.error=null,w();try{const t=await A.runtime.sendMessage({type:"checklist.flagItem",task:i.task,itemId:e,note:i.itemNote,snapshot:i.snapshot,source:"overlay"});j(t)&&(i.reportingItemId=null,i.itemNote="")}finally{i&&(i.busy=!1),w()}}}async function Cn(){if(!(!i||i.busy)){if(!i.taskNote.trim()){i.error=h.motivoRequired,w();return}i.busy=!0,i.error=null,w();try{const e=await A.runtime.sendMessage({type:"task.flag",task:i.task,note:i.taskNote,source:"overlay"});j(e)&&(i.taskBugOpen=!1,i.taskNote="")}finally{i&&(i.busy=!1),w()}}}async function Nn(e){if(!(!i||i.busy)){i.busy=!0,i.error=null,w();try{const t=await A.runtime.sendMessage({type:"checklist.unflagItem",task:i.task,itemId:e,snapshot:i.snapshot,source:"overlay"});j(t)}finally{i&&(i.busy=!1),w()}}}async function Sn(){if(!(!i||i.busy)){i.busy=!0,i.error=null,w();try{const e=await A.runtime.sendMessage({type:"task.unflag",task:i.task,source:"overlay"});j(e)}finally{i&&(i.busy=!1),w()}}}function Ln(){const{shadow:e}=un();if(e.querySelector(".panel"))return;const n=document.createElement("div");n.className="panel",n.setAttribute("role","dialog"),n.setAttribute("aria-label",h.checklistHeading),n.tabIndex=-1,n.addEventListener("keydown",y=>{y.key==="Escape"&&(y.preventDefault(),y.stopPropagation(),pe())});const r=document.createElement("div");r.className="header",r.addEventListener("pointerdown",hn),r.addEventListener("pointermove",bn),r.addEventListener("pointerup",Xe),r.addEventListener("pointercancel",Xe);const o=document.createElement("div");o.className="header-text";const a=document.createElement("p");a.className="display-id";const s=document.createElement("h2");s.className="title",o.append(a,s);const c=document.createElement("div");c.className="header-actions";const g=document.createElement("button");g.type="button",g.className="icon-btn",g.dataset.action="collapse",g.addEventListener("click",()=>{i&&(i.collapsed=!i.collapsed,w())});const p=document.createElement("button");p.type="button",p.className="icon-btn",p.setAttribute("aria-label",h.closeFloatingChecklist),p.textContent="×",p.addEventListener("click",()=>{pe()}),c.append(g,p),r.append(o,c);const m=document.createElement("div");m.className="body",n.append(r,m),e.appendChild(n),window.addEventListener("resize",Ye)}function Mn(e){var n;if(window!==window.top)return;Ln(),v&&(v.dataset.theme=window.matchMedia("(prefers-color-scheme: light)").matches?"light":"dark");const t=document.activeElement;me=t&&t!==v&&t!==document.body?t:null,i={task:e,items:[],snapshot:{items:[]},expandedId:null,reportingItemId:null,itemNote:"",taskBugOpen:!1,taskNote:"",collapsed:!1,instructionsCollapsed:J.instructionsCollapsed,checklistCollapsed:J.checklistCollapsed,helpMarkdown:null,isBug:!1,busy:!1,loading:!0,error:null},v&&(v.style.display="block"),w(),(n=M==null?void 0:M.querySelector(".panel"))==null||n.focus(),Promise.all([fn(),pn()]).then(([,r])=>{i&&(i.instructionsCollapsed=r.instructionsCollapsed,i.checklistCollapsed=r.checklistCollapsed,w(),Ge())})}function pe(){R=null,i=null,window.removeEventListener("resize",Ye),v==null||v.remove(),v=null,M=null;const e=me;me=null,e instanceof HTMLElement&&e.isConnected&&e.focus({preventScroll:!0})}function Tn(){window===window.top&&A.runtime.onMessage.addListener(e=>{if(!e||typeof e!="object"||!("type"in e))return;const t=e.type;if(t==="overlay.open"){const n=e.task;n!=null&&n.id&&Mn(n)}if(t==="overlay.close"&&pe(),t==="qa.checklistChanged"){if(!i||e.taskId!==i.task.id||!Zt("overlay",e.source))return;Ge()}})}async function Ve(e,t){if(!t){await navigator.clipboard.writeText(e);return}const n=await(await fetch(t)).blob();try{await navigator.clipboard.write([new ClipboardItem({"text/plain":new Blob([e],{type:"text/plain"}),[n.type||"image/png"]:n})])}catch{await navigator.clipboard.writeText(e)}}function In(e){return e.reduce((t,n)=>Math.max(t,n.n),0)+1}function Pn(e,t){if(t<1)return null;const n=e.slice(0,t),r=n.lastIndexOf("@");if(r<0)return null;const o=n.slice(r+1);return/[\s]/.test(o)?null:{start:r,query:o}}function $n(e,t,n){const r=n.toLowerCase();return e.filter(o=>o.n!==t).filter(o=>r?String(o.n).startsWith(r)||o.hit.selector.toLowerCase().includes(r):!0).map(o=>({n:o.n,label:o.hit.selector}))}function Rn(e,t,n,r){const o=`@${r}`;return{note:`${e.slice(0,t)}${o}${e.slice(n)}`,caret:t+o.length}}function Ke(e,t,n,r,o,a,s=4){return{x:Math.min(Math.max(e,s),Math.max(s,o-n-s)),y:Math.min(Math.max(t,s),Math.max(s,a-r-s))}}const On=6,Ze=200,Bn=3;function _n(e){return{color:(e==null?void 0:e.color)??"",fontSize:(e==null?void 0:e.fontSize)??"",display:(e==null?void 0:e.display)??""}}function Qe(e){const{x:t,y:n,width:r,height:o}=e.rect;return`${e.selector}@${Math.round(t)},${Math.round(n)},${Math.round(r)},${Math.round(o)}`}function ee(e){return typeof CSS<"u"&&typeof CSS.escape=="function"?CSS.escape(e):e.replace(/([^\w-])/g,"\\$1")}function zn(e){return e.filter(t=>/^[A-Za-z_][\w-]*$/.test(t)).slice(0,Bn)}function Je(e,t=Ze){const n=(e??"").replace(/\s+/g," ").trim();return n.length<=t?n:n.slice(0,t)}function qn(e){const t=e.parentElement;return t?Array.from(t.children).indexOf(e)+1:1}function Dn(e,t){if(!t)return!1;try{return e.querySelectorAll(`#${ee(t)}`).length===1}catch{return!1}}function et(e){return{tagName:e.tagName,id:e.id,classes:Array.from(e.classList),nthChild:qn(e),parent:e.parentElement?et(e.parentElement):null}}function Fn(e){const t=e.tagName.toLowerCase();if(t==="html"||t==="body")return t;const n=zn(e.classes);let r=t;return n.length&&(r+=n.map(o=>`.${ee(o)}`).join("")),e.nthChild>0&&(r+=`:nth-child(${e.nthChild})`),r}function Hn(e,t,n=On){if(e.id&&t(e.id))return`#${ee(e.id)}`;const r=[];let o=e,a=0;for(;o&&a<n;){if(o.id&&t(o.id)){r.unshift(`#${ee(o.id)}`);break}if(r.unshift(Fn(o)),o.tagName.toLowerCase()==="html")break;o=o.parent,a+=1}return r.join(" > ")}function jn(e,t){const n=e.getBoundingClientRect(),r=typeof getComputedStyle=="function"?getComputedStyle(e):void 0;return{tag:e.tagName.toLowerCase(),id:e.id,classes:Array.from(e.classList),text:Je(e.textContent),title:t.document.title??"",url:t.locationHref??(typeof location<"u"?location.href:""),selector:Hn(et(e),o=>Dn(t.document,o)),rect:{x:n.left,y:n.top,width:n.width,height:n.height},viewport:{width:t.innerWidth,height:t.innerHeight},computed:_n(r)}}function Wn(e,t){const n=e.classes.length?e.classes.join(", "):"(none)";return`\`\`\`markdown
${["## Element","",`- Selector: \`${e.selector}\``,`- Tag: ${e.tag}`,`- Id: ${e.id||"(none)"}`,`- Classes: ${n}`,`- Text: ${e.text||"(none)"}`,`- Title: ${e.title||"(none)"}`,`- URL: ${e.url}`,"- Screenshot: omitted"].join(`
`)}
\`\`\``}function Yn(e,t){const n=e.classes.length?e.classes.join(", "):"(none)",{x:r,y:o,width:a,height:s}=e.rect,c=(e.note??"").trim()||"(none)";return[`### ${t}. \`${e.selector}\``,"",`- Tag: ${e.tag}`,`- Id: ${e.id||"(none)"}`,`- Classes: ${n}`,`- Text: ${Je(e.text,Ze)||"(none)"}`,`- Href: ${e.url}`,`- Rect: ${Math.round(r)}, ${Math.round(o)}, ${Math.round(a)} × ${Math.round(s)}`,`- Color: ${e.computed.color||"(none)"}`,`- Font-size: ${e.computed.fontSize||"(none)"}`,`- Display: ${e.computed.display||"(none)"}`,`- Note: ${c}`].join(`
`)}function tt(e,t){const n=e.map(s=>"hit"in s?{...s.hit,note:s.note,n:s.n}:s),r=t==="omitted"?"omitted":"PNG of the viewport";return`\`\`\`markdown
${["## Design notes","",...n.map((s,c)=>Yn(s,s.n??c+1)),"",`- Screenshot: ${r}`].join(`
`)}
\`\`\``}function Xn(e){if(!e||typeof e!="object")return"dev";const t=e.purpose;return t==="qa-crop"||t==="qa-record"||t==="design"?t:"dev"}function Un(e){return e==="dev"}function Gn(e){return e!=="design"}function Vn(e,t,n){return e==="qa-crop"?{type:"capture.elementPicked",hit:t}:e==="qa-record"?{type:"capture.elementForRecord",hit:t}:{type:"picker.picked",hit:t,keepArmed:e==="design",removed:n==null?void 0:n.removed}}const V="arc-todo-picker-hover",nt="arc-todo-picker-selected",rt="arc-todo-design-tray",ot="arc-todo-picker-badge",it=["pointerdown","mousedown","mouseup","auxclick","contextmenu","dblclick"],Kn=`
:host {
  all: initial;
  position: fixed;
  z-index: 2147483647;
}
`,Zn=`
:host {
  color-scheme: dark;
  background: transparent;
}
:host([data-theme='light']) {
  color-scheme: light;
}
.tray {
  width: min(340px, 44vw);
  max-height: 60vh;
  display: flex;
  flex-direction: column;
  gap: 0.375rem;
  padding: 0.625rem;
  background: var(--bg-surface);
  color: var(--text-primary);
  border: 1px solid var(--border);
  border-radius: var(--radius-md);
  box-shadow: var(--shadow-lift);
  font-size: var(--type-body);
  line-height: 1.4;
}
.head {
  display: flex;
  align-items: baseline;
  cursor: grab;
  user-select: none;
  touch-action: none;
}
.tray.is-dragging .head { cursor: grabbing; }
.title {
  font-size: var(--type-meta);
  text-transform: uppercase;
  letter-spacing: 0.08em;
  color: var(--text-muted);
}
.empty { margin: 0; color: var(--text-muted); }
.list {
  list-style: none;
  margin: 0;
  padding: 0;
  overflow-y: auto;
  min-height: 0;
  display: flex;
  flex-direction: column;
  gap: 0.375rem;
}
.pin {
  display: flex;
  flex-direction: column;
  gap: 0.25rem;
  border: 1px solid var(--border);
  border-radius: var(--radius-sm);
  padding: 0.375rem;
  position: relative;
}
.pin-head { display: flex; align-items: center; gap: 0.375rem; }
.n {
  min-width: 1rem;
  height: 1rem;
  padding: 0 0.25rem;
  border-radius: 999px;
  background: var(--accent);
  color: var(--accent-contrast);
  font-size: var(--type-meta);
  font-weight: 600;
  line-height: 1rem;
  text-align: center;
  flex: none;
}
.label {
  flex: 1;
  min-width: 0;
  font-family: ui-monospace, monospace;
  font-size: var(--type-meta);
  color: var(--text-muted);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.remove {
  border: 0;
  background: transparent;
  color: var(--text-muted);
  cursor: pointer;
  font: inherit;
  font-size: var(--type-body);
  line-height: 1;
  padding: 0;
  min-width: 1.5rem;
  min-height: 1.5rem;
}
.note-label {
  display: flex;
  flex-direction: column;
  gap: 0.25rem;
  color: var(--text-muted);
  font-size: var(--type-meta);
}
textarea {
  width: 100%;
  resize: vertical;
  min-height: 2rem;
  font: inherit;
  color: var(--text-primary);
  background: var(--bg-elevated);
  border: 1px solid var(--border);
  border-radius: var(--radius-sm);
  padding: 0.25rem 0.375rem;
}
.mentions {
  position: absolute;
  left: 0.375rem;
  right: 0.375rem;
  z-index: 2;
  margin: 0;
  padding: 0.25rem;
  list-style: none;
  background: var(--bg-elevated);
  border: 1px solid var(--border);
  border-radius: var(--radius-sm);
  max-height: 8.75rem;
  overflow-y: auto;
}
.mentions button {
  display: block;
  width: 100%;
  min-height: 1.5rem;
  text-align: left;
  border: 0;
  background: transparent;
  color: var(--text-primary);
  font: inherit;
  padding: 0.25rem 0.375rem;
  cursor: pointer;
  border-radius: var(--radius-sm);
}
@media (hover: hover) and (pointer: fine) {
  .mentions button:hover { background: var(--accent); color: var(--accent-contrast); }
}
.foot { display: flex; flex-wrap: wrap; gap: 0.375rem; }
.foot button {
  border: 1px solid var(--border);
  background: var(--bg-elevated);
  color: var(--text-primary);
  border-radius: var(--radius-control);
  min-height: 1.5rem;
  padding: 0.3rem 0.625rem;
  font: inherit;
  cursor: pointer;
}
.foot button:disabled { opacity: 0.5; cursor: default; }
.foot .primary { background: var(--accent); color: var(--accent-contrast); border-color: transparent; }
`;let T=!1,L="dev",at="",st=0,E=[],d=null,D=null,fe=null,W=null;function ct(){return{position:"fixed",pointerEvents:"none",zIndex:"2147483647",outline:"2px solid #4862ce",outlineOffset:"1px",background:"rgba(72, 98, 206, 0.12)",boxSizing:"border-box",display:"none"}}function te(e,t){e.style.display="block",e.style.left=`${t.left}px`,e.style.top=`${t.top}px`,e.style.width=`${t.width}px`,e.style.height=`${t.height}px`}function he(e){let t=e.getElementById(V);return t||(t=e.createElement("div"),t.id=V,t.setAttribute("aria-hidden","true"),Object.assign(t.style,ct()),e.documentElement.appendChild(t),t)}function lt(e,t){const n=e.createElement("div");return n.className=nt,n.id=`arc-todo-picker-selected-${st}`,st+=1,n.setAttribute("aria-hidden","true"),Object.assign(n.style,ct(),{display:"block",outline:"2px dashed #4862ce",background:"transparent"}),e.documentElement.appendChild(n),n}function dt(e,t,n){const r=e.createElement("span");return r.className=ot,r.setAttribute("aria-hidden","true"),r.textContent=String(t),Object.assign(r.style,{position:"fixed",pointerEvents:"none",zIndex:"2147483647",minWidth:"16px",height:"16px",padding:"0 4px",borderRadius:"999px",background:"#4862ce",color:"#f7f8fc",fontSize:"11px",fontWeight:"600",lineHeight:"16px",textAlign:"center",fontFamily:"system-ui, sans-serif",boxSizing:"border-box"}),be(r,n),e.documentElement.appendChild(r),r}function be(e,t){e.style.top=`${t.top-9}px`,e.style.left=`${t.left-9}px`}function Qn(e){return e?e.id===H?!0:!!e.closest(`#${H}`):!1}function Jn(e){return e?e.id===V||e.id===rt||e.classList.contains(nt)||e.classList.contains(ot)||Qn(e):!1}function xe(e){return!!(d&&e.composedPath().includes(d))}function ut(e,t,n){const r=e.elementFromPoint(t,n);return!r||Jn(r)?null:r}function mt(e){T&&(xe(e)||(e.preventDefault(),e.stopPropagation(),e.stopImmediatePropagation()))}function ye(e,t){const n=he(e);if(!t){n.style.display="none";return}te(n,t.getBoundingClientRect())}function gt(e){return jn(e,{document,innerWidth:window.innerWidth,innerHeight:window.innerHeight,locationHref:location.href})}function ve(){return E.map(({n:e,hit:t,note:n})=>({n:e,hit:t,note:n}))}function ne(){var e,t;K();for(const n of E)(e=n.box)==null||e.remove(),(t=n.badge)==null||t.remove(),n.box=null,n.badge=null;d==null||d.remove(),d=null}function pt(){ne(),E=[],W=null}function er(){for(const e of E){if(!e.el.isConnected)continue;const t=e.el.getBoundingClientRect();e.box||(e.box=lt(document)),te(e.box,t),e.badge?be(e.badge,t):e.badge=dt(document,e.n,t)}ft(),oe(),Y()}function tr(){var e,t;for(const n of E){if(!n.el.isConnected){(e=n.box)==null||e.remove(),(t=n.badge)==null||t.remove(),n.box=null,n.badge=null;continue}const r=n.el.getBoundingClientRect();n.box&&te(n.box,r),n.badge&&be(n.badge,r)}}function ft(){if(d!=null&&d.isConnected){d.style.display="",re();return}d=document.createElement("div"),d.id=rt,d.dataset.theme=window.matchMedia("(prefers-color-scheme: light)").matches?"light":"dark";const e=d.attachShadow({mode:"open"}),t=document.createElement("style");t.textContent=`${Kn}
${je}
${Zn}`;const n=document.createElement("aside");n.className="tray",n.setAttribute("aria-label",S.designHeading);const r=document.createElement("div");r.className="head";const o=document.createElement("span");o.className="title",o.textContent=S.designHeading,r.appendChild(o),r.addEventListener("pointerdown",nr);const a=document.createElement("ul");a.className="list";const s=document.createElement("div");s.className="foot",n.append(r,a,s),e.append(t,n),document.documentElement.appendChild(d),re()}function re(){if(d){if(!D){d.style.right="12px",d.style.bottom="12px",d.style.left="auto",d.style.top="auto";return}d.style.left=`${D.x}px`,d.style.top=`${D.y}px`,d.style.right="auto",d.style.bottom="auto"}}function nr(e){var c,g;if(e.button!==0||!d)return;const t=e.currentTarget,n=d.getBoundingClientRect(),r=e.clientX-n.left,o=e.clientY-n.top;try{t.setPointerCapture(e.pointerId)}catch{}(g=(c=d.shadowRoot)==null?void 0:c.querySelector(".tray"))==null||g.classList.add("is-dragging");const a=p=>{d&&(D=Ke(p.clientX-r,p.clientY-o,n.width,n.height,window.innerWidth,window.innerHeight),re())},s=()=>{var p,m;(m=(p=d==null?void 0:d.shadowRoot)==null?void 0:p.querySelector(".tray"))==null||m.classList.remove("is-dragging"),t.removeEventListener("pointermove",a),t.removeEventListener("pointerup",s),t.removeEventListener("pointercancel",s)};t.addEventListener("pointermove",a),t.addEventListener("pointerup",s),t.addEventListener("pointercancel",s)}function K(){var e,t;fe=null,(t=(e=d==null?void 0:d.shadowRoot)==null?void 0:e.querySelector(".mentions"))==null||t.remove()}function oe(){var t;const e=(t=d==null?void 0:d.shadowRoot)==null?void 0:t.querySelector(".list");if(e){if(e.replaceChildren(),E.length===0){const n=document.createElement("p");n.className="empty",n.textContent=S.designEmpty,e.appendChild(n);return}for(const n of E)e.appendChild(rr(n))}}function rr(e){const t=document.createElement("li");t.className="pin";const n=document.createElement("div");n.className="pin-head";const r=document.createElement("span");r.className="n",r.textContent=String(e.n);const o=document.createElement("span");o.className="label",o.title=e.hit.selector,o.textContent=e.hit.selector;const a=document.createElement("button");a.type="button",a.className="remove",a.setAttribute("aria-label",S.designRemove),a.textContent="×",a.addEventListener("click",()=>{or(e.n)}),n.append(r,o,a);const s=document.createElement("label");s.className="note-label",s.append(S.designNote);const c=document.createElement("textarea");return c.rows=2,c.placeholder=S.designNotePlaceholder,c.value=e.note,c.addEventListener("input",()=>{e.note=c.value,Ae(e,c)}),c.addEventListener("click",()=>Ae(e,c)),c.addEventListener("keyup",g=>{g.key!=="Escape"&&Ae(e,c)}),s.appendChild(c),t.append(n,s),t}function Ae(e,t){var s,c;const n=t.selectionStart??t.value.length,r=Pn(t.value,n);if(K(),!r)return;const o=$n(ve(),e.n,r.query);if(o.length===0)return;fe={n:e.n,start:r.start,caret:n};const a=document.createElement("ul");a.className="mentions",a.setAttribute("aria-label",S.designNote);for(const g of o){const p=document.createElement("li"),m=document.createElement("button");m.type="button",m.textContent=`@${g.n}  ${g.label}`,m.addEventListener("click",()=>{const y=Rn(t.value,r.start,n,g.n);e.note=y.note,t.value=y.note,t.focus(),t.setSelectionRange(y.caret,y.caret),K()}),p.appendChild(m),a.appendChild(p)}(c=(s=t.parentElement)==null?void 0:s.parentElement)==null||c.appendChild(a)}function Y(){var s;const e=(s=d==null?void 0:d.shadowRoot)==null?void 0:s.querySelector(".foot");if(!e)return;e.replaceChildren();const t=E.length>0,n=document.createElement("button");n.type="button",n.textContent=W==="text"?S.copied:S.copy,n.disabled=!t,n.addEventListener("click",()=>void ht(!1));const r=document.createElement("button");r.type="button",r.textContent=W==="png"?S.copied:S.copyWithScreenshot,r.disabled=!t,r.addEventListener("click",()=>void ht(!0));const o=document.createElement("button");o.type="button",o.textContent=S.designClear,o.disabled=!t,o.addEventListener("click",()=>{pt(),ft(),oe(),Y()});const a=document.createElement("button");a.type="button",a.className="primary",a.textContent=S.designExit,a.addEventListener("click",()=>wt()),e.append(n,r,o,a)}function or(e){var n,r;const t=E.find(o=>o.n===e);(n=t==null?void 0:t.box)==null||n.remove(),(r=t==null?void 0:t.badge)==null||r.remove(),E=E.filter(o=>o.n!==e),K(),oe(),Y()}function ir(e,t){if(E.some(a=>a.el===e||Qe(a.hit)===Qe(t)))return;const n=e.getBoundingClientRect(),r=In(E);E.push({n:r,el:e,hit:t,note:"",box:lt(document),badge:dt(document,r,n)});const o=E[E.length-1];o!=null&&o.box&&te(o.box,n),oe(),Y()}async function ht(e){if(E.length!==0){if(W=null,!e){await Ve(tt(ve(),"omitted")),W="text",Y();return}d&&(d.style.display="none"),ye(document,null),await new Promise(t=>{window.setTimeout(t,50)});try{const t=await A.runtime.sendMessage({type:"picker.screenshot"});if(d&&(d.style.display=""),!t.draftScreenshot)return;await Ve(tt(ve(),"viewport"),t.draftScreenshot),W="png",Y()}catch{d&&(d.style.display="")}}}function bt(e){if(T){if(xe(e)){ye(document,null);return}ye(document,ut(document,e.clientX,e.clientY))}}function ie(){if(T&&L==="design"&&(tr(),D&&d)){const e=d.getBoundingClientRect();D=Ke(D.x,D.y,e.width,e.height,window.innerWidth,window.innerHeight),re()}}async function ar(){return{error:"idle"}}async function xt(e){if(!T||xe(e))return;const t=ut(document,e.clientX,e.clientY);if(!t)return;if(e.preventDefault(),e.stopPropagation(),e.stopImmediatePropagation(),L==="design"){ir(t,gt(t));return}const n=gt(t);if(Un(L)){const o=Wn(n);try{await navigator.clipboard.writeText(o)}catch{}}const r=Vn(L,n);Gn(L)&&ae(),A.runtime.sendMessage(r)}function yt(e){if(!(!T||e.key!=="Escape")){if(e.preventDefault(),L==="design"){if(e.stopPropagation(),e.stopImmediatePropagation(),fe){K();return}wt();return}e.stopPropagation(),e.stopImmediatePropagation(),ae(),A.runtime.sendMessage({type:"picker.cancelled"})}}function vt(){at=document.documentElement.style.cursor,document.documentElement.style.cursor="crosshair",he(document),document.addEventListener("mousemove",bt,!0),document.addEventListener("click",xt,!0),document.addEventListener("keydown",yt,!0);for(const e of it)document.addEventListener(e,mt,!0);window.addEventListener("scroll",ie,!0),window.addEventListener("resize",ie)}function At(){var e;document.documentElement.style.cursor=at,document.removeEventListener("mousemove",bt,!0),document.removeEventListener("click",xt,!0),document.removeEventListener("keydown",yt,!0);for(const t of it)document.removeEventListener(t,mt,!0);window.removeEventListener("scroll",ie,!0),window.removeEventListener("resize",ie),(e=document.getElementById(V))==null||e.remove()}function wt(){ae(),A.runtime.sendMessage({type:"design.exited"})}function sr(e="dev"){if(window===window.top){if(e==="design"){T&&L!=="design"&&(At(),T=!1),L="design",T||(vt(),T=!0),er();return}if((L==="design"||E.some(t=>t.box))&&ne(),T){L!==e&&(he(document).style.display="none"),L=e;return}T=!0,L=e,vt()}}function ae(){const e=L==="design"||E.length>0;if(!T&&!document.getElementById(V)&&!d){e&&ne();return}if(T=!1,L="dev",At(),e){ne();return}pt()}function cr(){window===window.top&&A.runtime.onMessage.addListener(e=>{if(!e||typeof e!="object"||!("type"in e))return;const t=e.type;if(t==="picker.arm"&&sr(Xn(e)),t==="picker.disarm"&&ae(),t==="capture.stopElementRecord")return ar()})}const Et=window;function lr(e){return!!(e&&typeof e=="object"&&e.type==="content.ping")}A.runtime.onMessage.addListener(e=>{if(lr(e))return Promise.resolve(!0)}),Et.__arcTodoContentReady||(Et.__arcTodoContentReady=!0,window.addEventListener($t,e=>{const t=e.detail;typeof t=="string"&&A.runtime.sendMessage({type:"capture.console",payload:t})}),A.runtime.sendMessage({type:"capture.pageReady"}),cr(),Ut(),Tn(),Pt())})();
