(function(){"use strict";function dt(e){return e&&e.__esModule&&Object.prototype.hasOwnProperty.call(e,"default")?e.default:e}var K={exports:{}},ut=K.exports,Ae;function mt(){return Ae||(Ae=1,(function(e,t){(function(n,r){r(e)})(typeof globalThis<"u"?globalThis:typeof self<"u"?self:ut,function(n){if(!(globalThis.chrome&&globalThis.chrome.runtime&&globalThis.chrome.runtime.id))throw new Error("This script should only be loaded in a browser extension.");if(globalThis.browser&&globalThis.browser.runtime&&globalThis.browser.runtime.id)n.exports=globalThis.browser;else{const r="The message port closed before a response was received.",i=s=>{const a={alarms:{clear:{minArgs:0,maxArgs:1},clearAll:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getAll:{minArgs:0,maxArgs:0}},bookmarks:{create:{minArgs:1,maxArgs:1},get:{minArgs:1,maxArgs:1},getChildren:{minArgs:1,maxArgs:1},getRecent:{minArgs:1,maxArgs:1},getSubTree:{minArgs:1,maxArgs:1},getTree:{minArgs:0,maxArgs:0},move:{minArgs:2,maxArgs:2},remove:{minArgs:1,maxArgs:1},removeTree:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1},update:{minArgs:2,maxArgs:2}},browserAction:{disable:{minArgs:0,maxArgs:1,fallbackToNoCallback:!0},enable:{minArgs:0,maxArgs:1,fallbackToNoCallback:!0},getBadgeBackgroundColor:{minArgs:1,maxArgs:1},getBadgeText:{minArgs:1,maxArgs:1},getPopup:{minArgs:1,maxArgs:1},getTitle:{minArgs:1,maxArgs:1},openPopup:{minArgs:0,maxArgs:0},setBadgeBackgroundColor:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setBadgeText:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setIcon:{minArgs:1,maxArgs:1},setPopup:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setTitle:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},browsingData:{remove:{minArgs:2,maxArgs:2},removeCache:{minArgs:1,maxArgs:1},removeCookies:{minArgs:1,maxArgs:1},removeDownloads:{minArgs:1,maxArgs:1},removeFormData:{minArgs:1,maxArgs:1},removeHistory:{minArgs:1,maxArgs:1},removeLocalStorage:{minArgs:1,maxArgs:1},removePasswords:{minArgs:1,maxArgs:1},removePluginData:{minArgs:1,maxArgs:1},settings:{minArgs:0,maxArgs:0}},commands:{getAll:{minArgs:0,maxArgs:0}},contextMenus:{remove:{minArgs:1,maxArgs:1},removeAll:{minArgs:0,maxArgs:0},update:{minArgs:2,maxArgs:2}},cookies:{get:{minArgs:1,maxArgs:1},getAll:{minArgs:1,maxArgs:1},getAllCookieStores:{minArgs:0,maxArgs:0},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}},devtools:{inspectedWindow:{eval:{minArgs:1,maxArgs:2,singleCallbackArg:!1}},panels:{create:{minArgs:3,maxArgs:3,singleCallbackArg:!0},elements:{createSidebarPane:{minArgs:1,maxArgs:1}}}},downloads:{cancel:{minArgs:1,maxArgs:1},download:{minArgs:1,maxArgs:1},erase:{minArgs:1,maxArgs:1},getFileIcon:{minArgs:1,maxArgs:2},open:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},pause:{minArgs:1,maxArgs:1},removeFile:{minArgs:1,maxArgs:1},resume:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1},show:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},extension:{isAllowedFileSchemeAccess:{minArgs:0,maxArgs:0},isAllowedIncognitoAccess:{minArgs:0,maxArgs:0}},history:{addUrl:{minArgs:1,maxArgs:1},deleteAll:{minArgs:0,maxArgs:0},deleteRange:{minArgs:1,maxArgs:1},deleteUrl:{minArgs:1,maxArgs:1},getVisits:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1}},i18n:{detectLanguage:{minArgs:1,maxArgs:1},getAcceptLanguages:{minArgs:0,maxArgs:0}},identity:{launchWebAuthFlow:{minArgs:1,maxArgs:1}},idle:{queryState:{minArgs:1,maxArgs:1}},management:{get:{minArgs:1,maxArgs:1},getAll:{minArgs:0,maxArgs:0},getSelf:{minArgs:0,maxArgs:0},setEnabled:{minArgs:2,maxArgs:2},uninstallSelf:{minArgs:0,maxArgs:1}},notifications:{clear:{minArgs:1,maxArgs:1},create:{minArgs:1,maxArgs:2},getAll:{minArgs:0,maxArgs:0},getPermissionLevel:{minArgs:0,maxArgs:0},update:{minArgs:2,maxArgs:2}},pageAction:{getPopup:{minArgs:1,maxArgs:1},getTitle:{minArgs:1,maxArgs:1},hide:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setIcon:{minArgs:1,maxArgs:1},setPopup:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setTitle:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},show:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},permissions:{contains:{minArgs:1,maxArgs:1},getAll:{minArgs:0,maxArgs:0},remove:{minArgs:1,maxArgs:1},request:{minArgs:1,maxArgs:1}},runtime:{getBackgroundPage:{minArgs:0,maxArgs:0},getPlatformInfo:{minArgs:0,maxArgs:0},openOptionsPage:{minArgs:0,maxArgs:0},requestUpdateCheck:{minArgs:0,maxArgs:0},sendMessage:{minArgs:1,maxArgs:3},sendNativeMessage:{minArgs:2,maxArgs:2},setUninstallURL:{minArgs:1,maxArgs:1}},sessions:{getDevices:{minArgs:0,maxArgs:1},getRecentlyClosed:{minArgs:0,maxArgs:1},restore:{minArgs:0,maxArgs:1}},storage:{local:{clear:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}},managed:{get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1}},sync:{clear:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}}},tabs:{captureVisibleTab:{minArgs:0,maxArgs:2},create:{minArgs:1,maxArgs:1},detectLanguage:{minArgs:0,maxArgs:1},discard:{minArgs:0,maxArgs:1},duplicate:{minArgs:1,maxArgs:1},executeScript:{minArgs:1,maxArgs:2},get:{minArgs:1,maxArgs:1},getCurrent:{minArgs:0,maxArgs:0},getZoom:{minArgs:0,maxArgs:1},getZoomSettings:{minArgs:0,maxArgs:1},goBack:{minArgs:0,maxArgs:1},goForward:{minArgs:0,maxArgs:1},highlight:{minArgs:1,maxArgs:1},insertCSS:{minArgs:1,maxArgs:2},move:{minArgs:2,maxArgs:2},query:{minArgs:1,maxArgs:1},reload:{minArgs:0,maxArgs:2},remove:{minArgs:1,maxArgs:1},removeCSS:{minArgs:1,maxArgs:2},sendMessage:{minArgs:2,maxArgs:3},setZoom:{minArgs:1,maxArgs:2},setZoomSettings:{minArgs:1,maxArgs:2},update:{minArgs:1,maxArgs:2}},topSites:{get:{minArgs:0,maxArgs:0}},webNavigation:{getAllFrames:{minArgs:1,maxArgs:1},getFrame:{minArgs:1,maxArgs:1}},webRequest:{handlerBehaviorChanged:{minArgs:0,maxArgs:0}},windows:{create:{minArgs:0,maxArgs:1},get:{minArgs:1,maxArgs:2},getAll:{minArgs:0,maxArgs:1},getCurrent:{minArgs:0,maxArgs:1},getLastFocused:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},update:{minArgs:2,maxArgs:2}}};if(Object.keys(a).length===0)throw new Error("api-metadata.json has not been included in browser-polyfill");class d extends WeakMap{constructor(l,g=void 0){super(g),this.createItem=l}get(l){return this.has(l)||this.set(l,this.createItem(l)),super.get(l)}}const f=c=>c&&typeof c=="object"&&typeof c.then=="function",y=(c,l)=>(...g)=>{s.runtime.lastError?c.reject(new Error(s.runtime.lastError.message)):l.singleCallbackArg||g.length<=1&&l.singleCallbackArg!==!1?c.resolve(g[0]):c.resolve(g)},u=c=>c==1?"argument":"arguments",b=(c,l)=>function(h,...E){if(E.length<l.minArgs)throw new Error(`Expected at least ${l.minArgs} ${u(l.minArgs)} for ${c}(), got ${E.length}`);if(E.length>l.maxArgs)throw new Error(`Expected at most ${l.maxArgs} ${u(l.maxArgs)} for ${c}(), got ${E.length}`);return new Promise((C,S)=>{if(l.fallbackToNoCallback)try{h[c](...E,y({resolve:C,reject:S},l))}catch(m){console.warn(`${c} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `,m),h[c](...E),l.fallbackToNoCallback=!1,l.noCallback=!0,C()}else l.noCallback?(h[c](...E),C()):h[c](...E,y({resolve:C,reject:S},l))})},T=(c,l,g)=>new Proxy(l,{apply(h,E,C){return g.call(E,c,...C)}});let R=Function.call.bind(Object.prototype.hasOwnProperty);const z=(c,l={},g={})=>{let h=Object.create(null),E={has(S,m){return m in c||m in h},get(S,m,M){if(m in h)return h[m];if(!(m in c))return;let k=c[m];if(typeof k=="function")if(typeof l[m]=="function")k=T(c,c[m],l[m]);else if(R(g,m)){let W=b(m,g[m]);k=T(c,c[m],W)}else k=k.bind(c);else if(typeof k=="object"&&k!==null&&(R(l,m)||R(g,m)))k=z(k,l[m],g[m]);else if(R(g,"*"))k=z(k,l[m],g["*"]);else return Object.defineProperty(h,m,{configurable:!0,enumerable:!0,get(){return c[m]},set(W){c[m]=W}}),k;return h[m]=k,k},set(S,m,M,k){return m in h?h[m]=M:c[m]=M,!0},defineProperty(S,m,M){return Reflect.defineProperty(h,m,M)},deleteProperty(S,m){return Reflect.deleteProperty(h,m)}},C=Object.create(c);return new Proxy(C,E)},V=c=>({addListener(l,g,...h){l.addListener(c.get(g),...h)},hasListener(l,g){return l.hasListener(c.get(g))},removeListener(l,g){l.removeListener(c.get(g))}}),re=new d(c=>typeof c!="function"?c:function(g){const h=z(g,{},{getContent:{minArgs:0,maxArgs:0}});c(h)}),Y=new d(c=>typeof c!="function"?c:function(g,h,E){let C=!1,S,m=new Promise(G=>{S=function(O){C=!0,G(O)}}),M;try{M=c(g,h,S)}catch(G){M=Promise.reject(G)}const k=M!==!0&&f(M);if(M!==!0&&!k&&!C)return!1;const W=G=>{G.then(O=>{E(O)},O=>{let he;O&&(O instanceof Error||typeof O.message=="string")?he=O.message:he="An unexpected error occurred",E({__mozWebExtensionPolyfillReject__:!0,message:he})}).catch(O=>{console.error("Failed to send onMessage rejected reply",O)})};return W(k?M:m),!0}),ge=({reject:c,resolve:l},g)=>{s.runtime.lastError?s.runtime.lastError.message===r?l():c(new Error(s.runtime.lastError.message)):g&&g.__mozWebExtensionPolyfillReject__?c(new Error(g.message)):l(g)},v=(c,l,g,...h)=>{if(h.length<l.minArgs)throw new Error(`Expected at least ${l.minArgs} ${u(l.minArgs)} for ${c}(), got ${h.length}`);if(h.length>l.maxArgs)throw new Error(`Expected at most ${l.maxArgs} ${u(l.maxArgs)} for ${c}(), got ${h.length}`);return new Promise((E,C)=>{const S=ge.bind(null,{resolve:E,reject:C});h.push(S),g.sendMessage(...h)})},fe={devtools:{network:{onRequestFinished:V(re)}},runtime:{onMessage:V(Y),onMessageExternal:V(Y),sendMessage:v.bind(null,"sendMessage",{minArgs:1,maxArgs:3})},tabs:{sendMessage:v.bind(null,"sendMessage",{minArgs:2,maxArgs:3})}},pe={clear:{minArgs:1,maxArgs:1},get:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}};return a.privacy={network:{"*":pe},services:{"*":pe},websites:{"*":pe}},z(s,fe,a)};n.exports=i(chrome)}})})(K)),K.exports}var gt=mt();const A=dt(gt),ft="arc-todo-capture",_="arc-todo-qa-overlay",pt=2147483646,oe="arcTodo.overlayPosition",ie="arcTodo.overlaySections";function ye(e,t,n,r,i,s){const a=Math.max(0,Math.min(e,n)),d=Math.max(0,Math.min(t,r)),f=Math.min(i,Math.max(e,n)),y=Math.min(s,Math.max(t,r)),u=f-a,b=y-d;return u<4||b<4?null:{x:a,y:d,width:u,height:b}}function xe(e,t,n){return t.width===0||t.height===0?{x:0,y:0}:{x:e.x/t.width*n.width,y:e.y/t.height*n.height}}function ht(e,t,n){const r=xe({x:e.x,y:e.y},t,n),i=xe({x:e.x+e.width,y:e.y+e.height},t,n);return ye(r.x,r.y,i.x,i.y,n.width,n.height)}function At(e,t,n,r,i){const s=ye(e,t,n,r,i.width,i.height);return s?{rect:s,viewport:i}:null}function yt(e,t,n){return ht(e,t,n)}const xt=["video/webm;codecs=vp9","video/webm;codecs=vp8"];function bt(e){return xt.find(t=>e(t))}const vt=12e4,wt=12e5,kt=1e3,be={video:{width:{max:1280},frameRate:{ideal:15,max:15}},audio:!1};function Et(){return{getDisplayMedia:e=>navigator.mediaDevices.getDisplayMedia(e),createRecorder:(e,t)=>new MediaRecorder(e,t),isTypeSupported:e=>typeof MediaRecorder<"u"&&MediaRecorder.isTypeSupported(e)}}function ve(e){if(!e||typeof e!="object")return!1;const t=e.name;return t==="NotAllowedError"||t==="AbortError"}function we(e){for(const t of e.getTracks())t.stop()}function ke(e,t,n){const r=bt(t.isTypeSupported),i={bitsPerSecond:wt};r&&(i.mimeType=r);const s=t.createRecorder(e,i),a=[],d=(t.now??Date.now)(),f=t.setTimeoutFn??setTimeout,y=t.clearTimeoutFn??clearTimeout;let u,b=!1,T,R;const z=new Promise((v,fe)=>{T=v,R=fe});function V(v){b||(b=!0,u!==void 0&&y(u),n==null||n(),we(e),T(v))}function re(v){b||(b=!0,u!==void 0&&y(u),n==null||n(),we(e),R(v))}s.ondataavailable=v=>{v.data&&v.data.size>0&&a.push(v.data)},s.onerror=v=>{re(v)},s.onstop=()=>{const v=(r==null?void 0:r.split(";")[0])??"video/webm";V(new Blob(a,{type:v}))};function Y(){return!b&&s.state!=="inactive"&&s.stop(),z}const ge=()=>{Y()};for(const v of e.getTracks())v.addEventListener("ended",ge);u=f(()=>{Y()},vt);try{s.start(kt)}catch(v){throw re(v),v}return{startedAt:d,mimeType:r??"video/webm",stop:Y,done:z}}const Ct={...be,preferCurrentTab:!0,selfBrowserSurface:"include",surfaceSwitching:"exclude",systemAudio:"exclude",monitorTypeSurfaces:"exclude"};async function Ee(e,t,n=globalThis){try{if(n.RestrictionTarget&&typeof e.restrictTo=="function"){const r=await n.RestrictionTarget.fromElement(t);return await e.restrictTo(r),!0}if(n.CropTarget&&typeof e.cropTo=="function"){const r=await n.CropTarget.fromElement(t);return await e.cropTo(r),!0}}catch{return!1}return!1}function Tt(e,t,n){const r=document.createElement("canvas"),i=t();r.width=Math.max(1,Math.round((i==null?void 0:i.width)??1)),r.height=Math.max(1,Math.round((i==null?void 0:i.height)??1));const s=r.getContext("2d");let a=0,d=!0;const f=()=>{if(!d||!s)return;const u=t();if(u){const b=Math.max(1,Math.round(u.width)),T=Math.max(1,Math.round(u.height));r.width!==b&&(r.width=b),r.height!==T&&(r.height=T),s.drawImage(e.source,u.x,u.y,u.width,u.height,0,0,r.width,r.height)}a=requestAnimationFrame(f)};f();const y=r.captureStream(n);return{stream:y,stop:()=>{d=!1,cancelAnimationFrame(a);for(const u of y.getTracks())u.stop()}}}function Ce(e){for(const t of e.getTracks())t.stop()}async function St(e){try{return await e(Ct)}catch(t){if(ve(t))throw t;return e(be)}}function Mt(){return{...Et(),isolateTrack:(e,t)=>Ee(e,t),attachDisplay:async e=>{const t=document.createElement("video");return t.muted=!0,t.playsInline=!0,t.srcObject=e,await t.play(),(!t.videoWidth||!t.videoHeight)&&await new Promise(n=>{t.onloadedmetadata=()=>n()}),{width:t.videoWidth,height:t.videoHeight,source:t}},captureLive:Tt}}function It(e,t,n={width:window.innerWidth,height:window.innerHeight}){const r=e.getBoundingClientRect();return yt({x:r.left,y:r.top,width:r.width,height:r.height},n,t)}async function Lt(e,t){const n=await St(t.getDisplayMedia);try{const r=n.getTracks()[0];if(r?await(t.isolateTrack??Ee)(r,e):!1)return ke(n,t);const s=await t.attachDisplay(n),a=t.captureLive(s,()=>It(e,{width:s.width,height:s.height}),15);return ke(a.stream,t,()=>{a.stop(),Ce(n)})}catch(r){throw Ce(n),r}}const Nt=6,Pt=200,Rt=3;function Ot(e){return{color:(e==null?void 0:e.color)??"",fontSize:(e==null?void 0:e.fontSize)??"",display:(e==null?void 0:e.display)??""}}function Te(e){const{x:t,y:n,width:r,height:i}=e.rect;return`${e.selector}@${Math.round(t)},${Math.round(n)},${Math.round(r)},${Math.round(i)}`}function Z(e){return typeof CSS<"u"&&typeof CSS.escape=="function"?CSS.escape(e):e.replace(/([^\w-])/g,"\\$1")}function $t(e){return e.filter(t=>/^[A-Za-z_][\w-]*$/.test(t)).slice(0,Rt)}function Bt(e,t=Pt){const n=(e??"").replace(/\s+/g," ").trim();return n.length<=t?n:n.slice(0,t)}function _t(e){const t=e.parentElement;return t?Array.from(t.children).indexOf(e)+1:1}function Dt(e,t){if(!t)return!1;try{return e.querySelectorAll(`#${Z(t)}`).length===1}catch{return!1}}function Se(e){return{tagName:e.tagName,id:e.id,classes:Array.from(e.classList),nthChild:_t(e),parent:e.parentElement?Se(e.parentElement):null}}function Ft(e){const t=e.tagName.toLowerCase();if(t==="html"||t==="body")return t;const n=$t(e.classes);let r=t;return n.length&&(r+=n.map(i=>`.${Z(i)}`).join("")),e.nthChild>0&&(r+=`:nth-child(${e.nthChild})`),r}function zt(e,t,n=Nt){if(e.id&&t(e.id))return`#${Z(e.id)}`;const r=[];let i=e,s=0;for(;i&&s<n;){if(i.id&&t(i.id)){r.unshift(`#${Z(i.id)}`);break}if(r.unshift(Ft(i)),i.tagName.toLowerCase()==="html")break;i=i.parent,s+=1}return r.join(" > ")}function Ht(e,t){const n=e.getBoundingClientRect(),r=typeof getComputedStyle=="function"?getComputedStyle(e):void 0;return{tag:e.tagName.toLowerCase(),id:e.id,classes:Array.from(e.classList),text:Bt(e.textContent),title:t.document.title??"",url:t.locationHref??(typeof location<"u"?location.href:""),selector:zt(Se(e),i=>Dt(t.document,i)),rect:{x:n.left,y:n.top,width:n.width,height:n.height},viewport:{width:t.innerWidth,height:t.innerHeight},computed:Ot(r)}}function jt(e,t){const n=e.classes.length?e.classes.join(", "):"(none)";return`\`\`\`markdown
${["## Element","",`- Selector: \`${e.selector}\``,`- Tag: ${e.tag}`,`- Id: ${e.id||"(none)"}`,`- Classes: ${n}`,`- Text: ${e.text||"(none)"}`,`- Title: ${e.title||"(none)"}`,`- URL: ${e.url}`,"- Screenshot: omitted"].join(`
`)}
\`\`\``}function qt(e){if(!e||typeof e!="object")return"dev";const t=e.purpose;return t==="qa-crop"||t==="qa-record"||t==="design"?t:"dev"}function Yt(e){return e==="dev"}function Wt(e){return e!=="design"}function Xt(e,t,n){return e==="qa-crop"?{type:"capture.elementPicked",hit:t}:e==="qa-record"?{type:"capture.elementForRecord",hit:t}:{type:"picker.picked",hit:t,keepArmed:e==="design",removed:n==null?void 0:n.removed}}let X=null,Q=!1;const H="arc-todo-picker-hover",se="arc-todo-picker-selected",Me=["pointerdown","mousedown","mouseup","auxclick","contextmenu","dblclick"];let $=!1,I="dev",Ie="",Le=0;const L=new Map;function Ne(){return{position:"fixed",pointerEvents:"none",zIndex:"2147483647",outline:"2px solid #4862ce",outlineOffset:"1px",background:"rgba(72, 98, 206, 0.12)",boxSizing:"border-box",display:"none"}}function ae(e,t){e.style.display="block",e.style.left=`${t.left}px`,e.style.top=`${t.top}px`,e.style.width=`${t.width}px`,e.style.height=`${t.height}px`}function ce(e){let t=e.getElementById(H);return t||(t=e.createElement("div"),t.id=H,t.setAttribute("aria-hidden","true"),Object.assign(t.style,Ne()),e.documentElement.appendChild(t),t)}function Ut(e){const t=e.createElement("div");return t.className=se,t.id=`arc-todo-picker-selected-${Le}`,Le+=1,t.setAttribute("aria-hidden","true"),Object.assign(t.style,Ne(),{display:"block"}),e.documentElement.appendChild(t),t}function Vt(e){return e?e.id===_?!0:!!e.closest(`#${_}`):!1}function Gt(e){return e?e.id===H||e.classList.contains(se)||Vt(e):!1}function Pe(e,t,n){const r=e.elementFromPoint(t,n);return!r||Gt(r)?null:r}function Re(e){$&&(e.preventDefault(),e.stopPropagation(),e.stopImmediatePropagation())}function Kt(e,t){const n=ce(e);if(!t){n.style.display="none";return}ae(n,t.getBoundingClientRect())}function Oe(e){return Ht(e,{document,innerWidth:window.innerWidth,innerHeight:window.innerHeight,locationHref:location.href})}function Zt(e){if(L.has(e))return e;for(const t of L.keys())if(Te(L.get(t).hit)===Te(Oe(e)))return t;return null}function Qt(e,t){const n=Ut(document);ae(n,e.getBoundingClientRect()),L.set(e,{hit:t,box:n})}function $e(e){const t=L.get(e);return t==null||t.box.remove(),L.delete(e),t==null?void 0:t.hit}function Be(){for(const e of L.values())e.box.remove();L.clear()}function Jt(){for(const[e,t]of L){if(!e.isConnected){$e(e);continue}ae(t.box,e.getBoundingClientRect())}}function _e(e){$&&Kt(document,Pe(document,e.clientX,e.clientY))}function J(){!$||I!=="design"||Jt()}async function en(e,t){try{const n=await Lt(e,Mt());X=n,Q=!1,A.runtime.sendMessage({type:"capture.pageElementRecordStarted",hit:t,startedAt:n.startedAt}),n.done.then(async r=>{if(Q||X!==n)return;X=null;const i=await r.arrayBuffer();A.runtime.sendMessage({type:"capture.pageElementRecordFinished",mimeType:n.mimeType,buffer:i,startedAt:n.startedAt})})}catch(n){if(ve(n)){A.runtime.sendMessage({type:"picker.cancelled"});return}A.runtime.sendMessage({type:"capture.elementForRecord",hit:t})}}async function tn(){const e=X;if(!e)return{error:"idle"};Q=!0,X=null;try{const t=await e.stop();return{mimeType:e.mimeType,buffer:await t.arrayBuffer(),startedAt:e.startedAt}}catch{return Q=!1,{error:"failed"}}}async function De(e){if(!$)return;const t=Pe(document,e.clientX,e.clientY);if(!t)return;e.preventDefault(),e.stopPropagation(),e.stopImmediatePropagation();const n=Zt(t),r=I==="design"&&(!!n||e.shiftKey),i=r&&n?L.get(n).hit:Oe(t);if(I==="qa-record"){ee(),en(t,i);return}if(I==="design")if(r&&n)$e(n);else if(!r)Qt(t,i);else return;if(Yt(I)){const a=jt(i);try{await navigator.clipboard.writeText(a)}catch{}}const s=Xt(I,i,{removed:r});Wt(I)&&ee(),A.runtime.sendMessage(s)}function Fe(e){!$||e.key!=="Escape"||(e.preventDefault(),ee(),A.runtime.sendMessage({type:"picker.cancelled"}))}function nn(e="dev"){if(window===window.top){if($){I!==e&&(Be(),ce(document).style.display="none"),I=e;return}$=!0,I=e,Ie=document.documentElement.style.cursor,document.documentElement.style.cursor="crosshair",ce(document),document.addEventListener("mousemove",_e,!0),document.addEventListener("click",De,!0),document.addEventListener("keydown",Fe,!0);for(const t of Me)document.addEventListener(t,Re,!0);window.addEventListener("scroll",J,!0),window.addEventListener("resize",J)}}function ee(){var e;if(!(!$&&!document.getElementById(H)&&L.size===0)){$=!1,I="dev",document.documentElement.style.cursor=Ie,document.removeEventListener("mousemove",_e,!0),document.removeEventListener("click",De,!0),document.removeEventListener("keydown",Fe,!0);for(const t of Me)document.removeEventListener(t,Re,!0);window.removeEventListener("scroll",J,!0),window.removeEventListener("resize",J),(e=document.getElementById(H))==null||e.remove(),Be()}}function rn(){window===window.top&&A.runtime.onMessage.addListener(e=>{if(!e||typeof e!="object"||!("type"in e))return;const t=e.type;if(t==="picker.arm"&&nn(qt(e)),t==="picker.disarm"&&ee(),t==="capture.stopElementRecord")return tn()})}const j="arc-todo-region-overlay",q="arc-todo-region-marquee",ze=["pointerdown","mousedown","mouseup","auxclick","contextmenu","dblclick"];let B=!1,He="",D=null;function on(){return{position:"fixed",inset:"0",zIndex:"2147483645",cursor:"crosshair",background:"rgba(0, 0, 0, 0.35)",boxSizing:"border-box"}}function sn(){return{position:"fixed",pointerEvents:"none",zIndex:"2147483645",outline:"2px solid #ffffff",outlineOffset:"0",boxShadow:"0 0 0 99999px rgba(0, 0, 0, 0.35)",boxSizing:"border-box",display:"none",background:"transparent"}}function an(e){let t=e.getElementById(j);return t||(t=e.createElement("div"),t.id=j,t.setAttribute("aria-hidden","true"),Object.assign(t.style,on()),e.documentElement.appendChild(t),t)}function je(e){let t=e.getElementById(q);return t||(t=e.createElement("div"),t.id=q,t.setAttribute("aria-hidden","true"),Object.assign(t.style,sn()),e.documentElement.appendChild(t),t)}function cn(e){return e?e.id===_?!0:!!e.closest(`#${_}`):!1}function ln(e){return e?e.id===j||e.id===q:!1}function dn(e){return e?e.id===H||e.classList.contains(se)||cn(e):!1}function un(e,t,n){const r=e.getElementById(j),i=e.getElementById(q);r&&(r.style.pointerEvents="none"),i&&(i.style.pointerEvents="none");const s=e.elementFromPoint(t,n);return r&&(r.style.pointerEvents="auto"),s}function qe(e){B&&(e.preventDefault(),e.stopPropagation(),e.stopImmediatePropagation())}function mn(e,t,n,r){const i=Math.min(e,n),s=Math.min(t,r),a=je(document);a.style.display="block",a.style.left=`${i}px`,a.style.top=`${s}px`,a.style.width=`${Math.abs(n-e)}px`,a.style.height=`${Math.abs(r-t)}px`}function Ye(){const e=document.getElementById(q);e&&(e.style.display="none")}function gn(){return{width:window.innerWidth,height:window.innerHeight}}function We(e){if(!B||e.button!==0)return;const t=un(document,e.clientX,e.clientY);dn(t)||ln(t)||(D={x:e.clientX,y:e.clientY},Ye())}function Xe(e){!B||!D||mn(D.x,D.y,e.clientX,e.clientY)}function Ue(e){if(!B||!D)return;const t=D;D=null;const n=At(t.x,t.y,e.clientX,e.clientY,gn());Ye(),n&&(A.runtime.sendMessage({type:"region.picked",rect:n.rect,viewport:n.viewport,devicePixelRatio:window.devicePixelRatio}),le())}function Ve(e){!B||e.key!=="Escape"||(e.preventDefault(),le(),A.runtime.sendMessage({type:"region.cancelled"}))}function fn(){if(window===window.top&&!B){B=!0,He=document.documentElement.style.cursor,document.documentElement.style.cursor="crosshair",an(document),je(document),document.addEventListener("pointerdown",We,!0),document.addEventListener("pointermove",Xe,!0),document.addEventListener("pointerup",Ue,!0),document.addEventListener("keydown",Ve,!0);for(const e of ze)document.addEventListener(e,qe,!0)}}function le(){var e,t;if(!(!B&&!document.getElementById(j))){B=!1,D=null,document.documentElement.style.cursor=He,document.removeEventListener("pointerdown",We,!0),document.removeEventListener("pointermove",Xe,!0),document.removeEventListener("pointerup",Ue,!0),document.removeEventListener("keydown",Ve,!0);for(const n of ze)document.removeEventListener(n,qe,!0);(e=document.getElementById(j))==null||e.remove(),(t=document.getElementById(q))==null||t.remove()}}function pn(){window===window.top&&A.runtime.onMessage.addListener(e=>{if(!e||typeof e!="object"||!("type"in e))return;const t=e.type;t==="region.arm"&&fn(),t==="region.disarm"&&le()})}function de(e){var t;return((t=e.find(n=>!n.checked))==null?void 0:t.id)??null}function hn(e,t){var i;const n=e.findIndex(s=>s.id===t);return((i=(n>=0?e.slice(n+1):e).find(s=>!s.checked))==null?void 0:i.id)??de(e)}function An(e,t){return t&&e.some(n=>n.id===t)?t:de(e)??void 0}function yn(e,t){return t==="panel"||t==="overlay"?t!==e:!0}function xn(e,t,n,r,i=48){const s=i-r.width,a=n.width-i,d=0,f=Math.max(0,n.height-i);return{left:Math.min(a,Math.max(s,e)),top:Math.min(f,Math.max(d,t))}}function bn(e,t,n=16){return{left:Math.max(n,e.width-t.width-n),top:Math.max(n,e.height-t.height-n)}}function vn(e,t){const n=t.join(`
`).trim();n&&e.push({type:"p",text:n})}function wn(e){const t=[];let n=[],r=[];function i(){r.length!==0&&(t.push({type:"ul",items:r}),r=[])}function s(){const a=n;n=[],vn(t,a)}for(const a of e.split(`
`)){const d=a.match(/^(#{1,3})\s+(.*)$/),f=a.match(/^[-*]\s+(.*)$/);if(d){i(),s(),t.push({type:d[1].length===1?"h3":"h4",text:d[2]});continue}if(f){s(),r.push(f[1]);continue}if(!a.trim()){i(),s();continue}i(),n.push(a)}return i(),s(),t}function kn(e,t){for(const n of wn(t)){if(n.type==="ul"){const i=document.createElement("ul");for(const s of n.items){const a=document.createElement("li");a.textContent=s,i.appendChild(a)}e.appendChild(i);continue}const r=document.createElement(n.type);r.textContent=n.text,e.appendChild(r)}}function En(e){if(!e||typeof e!="object"||Array.isArray(e))return null;const t=e;return typeof t.left!="number"||typeof t.top!="number"||!Number.isFinite(t.left)||!Number.isFinite(t.top)?null:{left:t.left,top:t.top}}const Ge=60;function Cn(e){const t=e.replace(/\*\*/g,"").trim(),n=e.match(/^\s*\*\*(.+?)\*\*/);if(n)return{short:n[1].replace(/\*\*/g,"").trim(),full:t,fromBold:!0};const r=t.indexOf(":");return r>0?{short:t.slice(0,r).trim(),full:t,fromBold:!1}:t.length>Ge?{short:`${t.slice(0,Ge)}…`,full:t,fromBold:!1}:{short:t,full:t,fromBold:!1}}function Ke(e){return e.map(t=>{const n=Cn(t.label);return{id:t.id,short:n.short,full:n.full,checked:t.checked,bugged:t.bugged,notes:t.notes}})}const te={instructionsCollapsed:!0,checklistCollapsed:!1};function Tn(e){if(!e||typeof e!="object"||Array.isArray(e))return null;const t=e;return typeof t.instructionsCollapsed!="boolean"||typeof t.checklistCollapsed!="boolean"?null:{instructionsCollapsed:t.instructionsCollapsed,checklistCollapsed:t.checklistCollapsed}}const Sn=`
:host {
  all: initial;
  position: fixed;
  z-index: 2147483646;
  font-family: system-ui, sans-serif;
  color-scheme: dark;
  --bg-surface: #1b2230;
  --bg-elevated: #252e3d;
  --text-primary: #e8ecf4;
  --text-muted: #9aa6bc;
  --border: rgba(142, 160, 188, 0.18);
  --accent: #4862ce;
  --accent-contrast: #f7f8fc;
  --radius: 0.75rem;
  --type-body: 0.8125rem;
  --type-meta: 0.7rem;
  --type-section: 0.9rem;
}

@media (prefers-color-scheme: light) {
  :host {
    color-scheme: light;
    --bg-surface: #fbfcfe;
    --bg-elevated: #eef1f6;
    --text-primary: #1b2230;
    --text-muted: #5a6578;
    --border: rgba(46, 53, 69, 0.16);
    --accent: #3d52b8;
  }
}

*, *::before, *::after { box-sizing: border-box; }

.panel {
  width: min(420px, calc(100vw - 24px));
  max-height: min(70vh, 520px);
  display: flex;
  flex-direction: column;
  background: var(--bg-surface);
  color: var(--text-primary);
  border: 1px solid var(--border);
  border-radius: var(--radius);
  box-shadow: 0 12px 40px rgba(0, 0, 0, 0.35);
  overflow: hidden;
  font-size: var(--type-body);
  line-height: 1.4;
}

.panel.is-collapsed .body { display: none; }

.header {
  display: flex;
  align-items: flex-start;
  gap: 0.5rem;
  padding: 0.55rem 0.65rem;
  background: var(--bg-elevated);
  border-bottom: 1px solid var(--border);
  cursor: grab;
  touch-action: none;
  user-select: none;
}

.header:active { cursor: grabbing; }

.header-text {
  flex: 1;
  min-width: 0;
}

.display-id {
  margin: 0;
  font-size: var(--type-meta);
  color: var(--text-muted);
  font-weight: 600;
}

.title {
  margin: 0.1rem 0 0;
  font-size: var(--type-section);
  font-weight: 700;
  line-height: 1.25;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.header-actions {
  display: flex;
  gap: 0.25rem;
  flex-shrink: 0;
}

.icon-btn {
  appearance: none;
  border: 1px solid var(--border);
  background: transparent;
  color: var(--text-primary);
  border-radius: calc(var(--radius) - 0.25rem);
  width: 1.75rem;
  height: 1.75rem;
  font: inherit;
  font-size: 0.85rem;
  line-height: 1;
  cursor: pointer;
  padding: 0;
}

.icon-btn:hover { background: var(--bg-surface); }

.body {
  overflow: auto;
  padding: 0.5rem;
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

.hint {
  margin: 0;
  font-size: var(--type-meta);
  color: var(--text-muted);
}

.list {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
  gap: 0.375rem;
}

.row {
  border: 1px solid var(--border);
  border-radius: calc(var(--radius) - 0.2rem);
  background: var(--bg-elevated);
  padding: 0.375rem;
}

.row.is-bugged { border-color: rgba(220, 80, 80, 0.45); }
.row.is-current { border-color: var(--accent); }

.row-main {
  display: flex;
  gap: 0.35rem;
  align-items: center;
}

.tick {
  appearance: none;
  border: 0;
  background: transparent;
  color: var(--text-primary);
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  padding: 0.1rem;
  font: inherit;
  min-width: 1.4rem;
}

.tick-mark {
  width: 1.1rem;
  height: 1.1rem;
  border-radius: 999px;
  border: 2px solid var(--text-muted);
  display: block;
}

.tick.is-checked .tick-mark {
  border-color: var(--accent);
  background: var(--accent);
  box-shadow: inset 0 0 0 2px var(--bg-elevated);
}

.expand {
  appearance: none;
  border: 0;
  background: transparent;
  color: var(--text-primary);
  text-align: left;
  flex: 1;
  min-width: 0;
  cursor: pointer;
  font: inherit;
  padding: 0.15rem 0;
}

.expand strong { font-weight: 650; }

.row-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 0.25rem;
  margin-top: 0.35rem;
}

.btn {
  appearance: none;
  border: 1px solid var(--border);
  background: var(--bg-surface);
  color: var(--text-primary);
  border-radius: calc(var(--radius) - 0.25rem);
  font: inherit;
  font-size: var(--type-meta);
  font-weight: 600;
  padding: 0.3rem 0.5rem;
  cursor: pointer;
}

.btn-primary {
  background: var(--accent);
  border-color: var(--accent);
  color: var(--accent-contrast);
}

.btn:disabled {
  opacity: 0.45;
  cursor: not-allowed;
}

.bug-form {
  display: flex;
  flex-direction: column;
  gap: 0.35rem;
  margin-top: 0.35rem;
}

.bug-form label {
  display: flex;
  flex-direction: column;
  gap: 0.2rem;
  font-size: var(--type-meta);
  color: var(--text-muted);
}

.bug-form textarea {
  resize: vertical;
  min-height: 3.5rem;
  border: 1px solid var(--border);
  border-radius: calc(var(--radius) - 0.25rem);
  background: var(--bg-surface);
  color: var(--text-primary);
  font: inherit;
  padding: 0.35rem;
}

.warning {
  margin: 0;
  font-size: var(--type-meta);
  color: var(--text-muted);
}

.error {
  margin: 0;
  font-size: var(--type-meta);
  color: #e07070;
}

.notes {
  margin: 0.25rem 0 0;
  padding-left: 1rem;
  font-size: var(--type-meta);
  color: var(--text-muted);
}

.section {
  display: flex;
  flex-direction: column;
  gap: 0.35rem;
  min-width: 0;
}

.section-toggle {
  appearance: none;
  display: flex;
  align-items: baseline;
  gap: 0.4rem;
  width: 100%;
  margin: 0;
  padding: 0.25rem 0;
  border: 0;
  background: transparent;
  color: var(--text-muted);
  font: inherit;
  font-size: var(--type-meta);
  font-weight: 700;
  letter-spacing: 0.02em;
  text-transform: uppercase;
  text-align: left;
  cursor: pointer;
}

.section-progress {
  font-weight: 650;
  color: var(--text-primary);
  text-transform: none;
  letter-spacing: 0;
}

.help {
  display: flex;
  flex-direction: column;
  gap: 0.4rem;
  min-width: 0;
}

.help h3,
.help h4 {
  margin: 0;
  font-size: var(--type-body);
  font-weight: 650;
  color: var(--text-primary);
}

.help p,
.help li {
  margin: 0;
  font-size: var(--type-meta);
  color: var(--text-muted);
}

.help ul {
  margin: 0;
  padding-left: 1.1rem;
}
`,p={itemDone:"Feito",itemOpen:"A fazer",flagAsBug:"Marcar como bug",motivo:"Motivo",motivoPlaceholder:"Descreva o problema encontrado",cancelFlag:"Cancelar",taskBugWarning:"Este card volta para To Do, inclusive as subtarefas.",noChecklist:"Esta tarefa não tem checklist.",collapseOverlay:"Recolher",expandOverlay:"Expandir",closeFloatingChecklist:"Fechar checklist flutuante",overlayDragHint:"Arraste pelo cabeçalho",instructionsHeading:"Instruções",checklistHeading:"Checklist",checklistChanged:"A checklist mudou. Recarregue e tente de novo.",motivoRequired:"O motivo do bug é obrigatório.",itemMotivoRequired:"O motivo do bug do item é obrigatório.",apiError:"Não foi possível falar com a API. Tente de novo.",sessionExpired:"Sessão expirada. Entre de novo no Arc Todo.",signInFirst:"Entre no Arc Todo primeiro"};let x=null,P=null,o=null,N=null;function Mn(e){return e.status==="expired"?p.sessionExpired:e.status==="not_signed_in"?p.signInFirst:e.error==="stale"?p.checklistChanged:e.error==="motivo"?p.motivoRequired:e.error==="api"||e.status==="error"?p.apiError:null}function In(){const e=document.getElementById(_);if(e&&P&&x===e)return{host:e,shadow:P};e==null||e.remove();const t=document.createElement("div");t.id=_,t.setAttribute("aria-hidden","false"),Object.assign(t.style,{position:"fixed",zIndex:String(pt),left:"0px",top:"0px"});const n=t.attachShadow({mode:"open"}),r=document.createElement("style");return r.textContent=Sn,n.appendChild(r),document.documentElement.appendChild(t),x=t,P=n,{host:t,shadow:n}}async function Ln(){try{const e=await A.storage.local.get(oe);return En(e[oe])}catch{return null}}async function Nn(e,t){try{await A.storage.local.set({[oe]:{left:e,top:t}})}catch{}}async function Pn(){try{const e=await A.storage.local.get(ie);return Tn(e[ie])??te}catch{return te}}async function Ze(){if(o)try{await A.storage.local.set({[ie]:{instructionsCollapsed:o.instructionsCollapsed,checklistCollapsed:o.checklistCollapsed}})}catch{}}function ue(e,t){if(!x)return;const n=x.getBoundingClientRect(),r=xn(e,t,{width:window.innerWidth,height:window.innerHeight},{width:n.width||420,height:Math.min(n.height||48,48)});x.style.left=`${r.left}px`,x.style.top=`${r.top}px`}function Qe(){if(!x)return;const e=Number.parseFloat(x.style.left||"0"),t=Number.parseFloat(x.style.top||"0");ue(e,t)}async function Rn(){if(!x)return;const e=await Ln(),t={width:420,height:320},n=e??bn({width:window.innerWidth,height:window.innerHeight},t);ue(n.left,n.top)}function On(e){if(!x||e.button!==0)return;const t=e.target;if(t!=null&&t.closest("button"))return;const n=Number.parseFloat(x.style.left||"0"),r=Number.parseFloat(x.style.top||"0");N={pointerId:e.pointerId,startX:e.clientX,startY:e.clientY,originLeft:n,originTop:r},e.currentTarget.setPointerCapture(e.pointerId),e.preventDefault()}function $n(e){!N||e.pointerId!==N.pointerId||ue(N.originLeft+(e.clientX-N.startX),N.originTop+(e.clientY-N.startY))}function Je(e){if(!N||e.pointerId!==N.pointerId||!x)return;N=null;const t=Number.parseFloat(x.style.left||"0"),n=Number.parseFloat(x.style.top||"0");Nn(t,n)}function w(){if(!P||!o)return;const e=P.querySelector(".panel");if(!e)return;e.classList.toggle("is-collapsed",o.collapsed);const t=P.querySelector(".title"),n=P.querySelector(".display-id");t&&(t.textContent=o.task.title),n&&(n.textContent=o.task.displayId);const r=P.querySelector('[data-action="collapse"]');r&&(r.setAttribute("aria-label",o.collapsed?p.expandOverlay:p.collapseOverlay),r.textContent=o.collapsed?"▸":"▾");const i=P.querySelector(".body");if(!i)return;if(i.replaceChildren(),o.error){const d=document.createElement("p");d.className="error",d.setAttribute("role","alert"),d.textContent=o.error,i.appendChild(d)}const s=document.createElement("p");s.className="hint",s.textContent=p.overlayDragHint,i.appendChild(s),o.helpMarkdown&&i.appendChild(_n(o.helpMarkdown));const a=Ke(o.items);if(a.length===0){const d=document.createElement("p");d.className="hint",d.textContent=p.noChecklist,i.appendChild(d)}else i.appendChild(Dn(a.map(d=>d.id)));if(o.taskBugOpen)i.appendChild(zn());else{const d=document.createElement("button");d.type="button",d.className="btn",d.textContent=p.flagAsBug,d.disabled=o.busy,d.addEventListener("click",()=>{o&&(o.taskBugOpen=!0,o.taskNote="",o.error=null,w())}),i.appendChild(d)}}function Bn(e){const t=o.items.find(u=>u.id===e),n=document.createElement("li"),r=An(o.items,o.expandedId);n.className=["row",t.bugged?"is-bugged":"",t.id===r?"is-current":""].filter(Boolean).join(" ");const i=document.createElement("div");i.className="row-main";const s=document.createElement("button");s.type="button",s.className=t.checked?"tick is-checked":"tick",s.setAttribute("aria-pressed",String(t.checked)),s.setAttribute("aria-label",t.checked?p.itemDone:p.itemOpen),s.disabled=o.busy;const a=document.createElement("span");a.className="tick-mark",a.setAttribute("aria-hidden","true"),s.append(a),s.addEventListener("click",()=>{Hn(t.id)});const d=Ke([t])[0],f=document.createElement("button");f.type="button",f.className="expand";const y=o.expandedId===t.id;if(f.setAttribute("aria-expanded",String(y)),y)f.textContent=d.full;else{const u=document.createElement("strong");u.textContent=d.short,f.appendChild(u)}if(f.addEventListener("click",()=>{o&&(o.expandedId=o.expandedId===t.id?null:t.id,w())}),i.append(s,f),n.appendChild(i),t.notes.length){const u=document.createElement("ul");u.className="notes";for(const b of t.notes){const T=document.createElement("li");T.innerHTML="";const R=document.createElement("strong");R.textContent=`${p.motivo}: `,T.append(R,document.createTextNode(b)),u.appendChild(T)}n.appendChild(u)}if(o.reportingItemId===t.id)n.appendChild(Fn(t.id));else if(y){const u=document.createElement("div");u.className="row-actions";const b=document.createElement("button");b.type="button",b.className="btn",b.textContent=p.flagAsBug,b.disabled=o.busy,b.addEventListener("click",()=>{o&&(o.reportingItemId=t.id,o.itemNote="",o.error=null,w())}),u.appendChild(b),n.appendChild(u)}return n}function et(e,t,n,r){const i=document.createElement("button");i.type="button",i.className="section-toggle",i.setAttribute("aria-expanded",String(t));const s=document.createTextNode(e);if(i.appendChild(s),r){i.appendChild(document.createTextNode(" "));const a=document.createElement("span");a.className="section-progress",a.textContent=r,i.appendChild(a)}return i.addEventListener("click",n),i}function _n(e){const t=document.createElement("section");t.className="section";const n=!o.instructionsCollapsed;if(t.appendChild(et(p.instructionsHeading,n,()=>{o&&(o.instructionsCollapsed=!o.instructionsCollapsed,Ze(),w())})),n){const r=document.createElement("div");r.className="help",kn(r,e),t.appendChild(r)}return t}function Dn(e){const t=document.createElement("section");t.className="section";const n=!o.checklistCollapsed,r=o.items.filter(i=>i.checked).length;if(t.appendChild(et(p.checklistHeading,n,()=>{o&&(o.checklistCollapsed=!o.checklistCollapsed,Ze(),w())},`${r}/${o.items.length}`)),n){const i=document.createElement("ul");i.className="list";for(const s of e)i.appendChild(Bn(s));t.appendChild(i)}return t}function Fn(e){const t=document.createElement("div");t.className="bug-form";const n=document.createElement("label");n.textContent=p.motivo;const r=document.createElement("textarea");r.value=o.itemNote,r.placeholder=p.motivoPlaceholder,r.rows=3,r.addEventListener("input",()=>{o&&(o.itemNote=r.value,s.disabled=o.busy||!o.itemNote.trim())}),n.appendChild(r);const i=document.createElement("div");i.className="row-actions";const s=document.createElement("button");s.type="button",s.className="btn btn-primary",s.textContent=p.flagAsBug,s.disabled=o.busy||!o.itemNote.trim(),s.addEventListener("click",()=>{jn(e)});const a=document.createElement("button");return a.type="button",a.className="btn",a.textContent=p.cancelFlag,a.addEventListener("click",()=>{o&&(o.reportingItemId=null,o.itemNote="",w())}),i.append(s,a),t.append(n,i),t}function zn(){const e=document.createElement("div");e.className="bug-form";const t=document.createElement("p");t.className="warning",t.textContent=p.taskBugWarning;const n=document.createElement("label");n.textContent=p.motivo;const r=document.createElement("textarea");r.value=o.taskNote,r.placeholder=p.motivoPlaceholder,r.rows=3,r.addEventListener("input",()=>{o&&(o.taskNote=r.value,s.disabled=o.busy||!o.taskNote.trim())}),n.appendChild(r);const i=document.createElement("div");i.className="row-actions";const s=document.createElement("button");s.type="button",s.className="btn btn-primary",s.textContent=p.flagAsBug,s.disabled=o.busy||!o.taskNote.trim(),s.addEventListener("click",()=>{qn()});const a=document.createElement("button");return a.type="button",a.className="btn",a.textContent=p.cancelFlag,a.addEventListener("click",()=>{o&&(o.taskBugOpen=!1,o.taskNote="",w())}),i.append(s,a),e.append(t,n,i),e}function ne(e){if(!o)return!1;const t=Mn(e);if(t)return o.error=t,!1;if(o.error=null,e.items){o.items=e.items;const n=o.expandedId;(!n||!e.items.some(r=>r.id===n))&&(o.expandedId=de(e.items))}return e.snapshot&&(o.snapshot=e.snapshot),e.helpMarkdown!==void 0&&(o.helpMarkdown=e.helpMarkdown??null),!0}async function tt(){if(o){o.busy=!0,w();try{const e=await A.runtime.sendMessage({type:"task.get",task:o.task});ne(e)}finally{o&&(o.busy=!1),w()}}}async function Hn(e){if(!(!o||o.busy)){o.busy=!0,o.error=null,w();try{const t=await A.runtime.sendMessage({type:"checklist.tick",task:o.task,itemId:e,snapshot:o.snapshot,source:"overlay"});if(ne(t),o){const n=o.items.find(r=>r.id===e);n!=null&&n.checked?o.expandedId=hn(o.items,e):o.expandedId=e}}finally{o&&(o.busy=!1),w()}}}async function jn(e){if(!(!o||o.busy)){if(!o.itemNote.trim()){o.error=p.itemMotivoRequired,w();return}o.busy=!0,o.error=null,w();try{const t=await A.runtime.sendMessage({type:"checklist.flagItem",task:o.task,itemId:e,note:o.itemNote,snapshot:o.snapshot,source:"overlay"});ne(t)&&(o.reportingItemId=null,o.itemNote="")}finally{o&&(o.busy=!1),w()}}}async function qn(){if(!(!o||o.busy)){if(!o.taskNote.trim()){o.error=p.motivoRequired,w();return}o.busy=!0,o.error=null,w();try{const e=await A.runtime.sendMessage({type:"task.flag",task:o.task,note:o.taskNote,source:"overlay"});ne(e)&&(o.taskBugOpen=!1,o.taskNote="")}finally{o&&(o.busy=!1),w()}}}function Yn(){const{shadow:e}=In();if(e.querySelector(".panel"))return;const n=document.createElement("div");n.className="panel",n.setAttribute("role","dialog"),n.setAttribute("aria-label","Checklist");const r=document.createElement("div");r.className="header",r.addEventListener("pointerdown",On),r.addEventListener("pointermove",$n),r.addEventListener("pointerup",Je),r.addEventListener("pointercancel",Je);const i=document.createElement("div");i.className="header-text";const s=document.createElement("p");s.className="display-id";const a=document.createElement("h2");a.className="title",i.append(s,a);const d=document.createElement("div");d.className="header-actions";const f=document.createElement("button");f.type="button",f.className="icon-btn",f.dataset.action="collapse",f.addEventListener("click",()=>{o&&(o.collapsed=!o.collapsed,w())});const y=document.createElement("button");y.type="button",y.className="icon-btn",y.setAttribute("aria-label",p.closeFloatingChecklist),y.textContent="×",y.addEventListener("click",()=>{nt()}),d.append(f,y),r.append(i,d);const u=document.createElement("div");u.className="body",n.append(r,u),e.appendChild(n),window.addEventListener("resize",Qe)}function Wn(e){window===window.top&&(Yn(),o={task:e,items:[],snapshot:{items:[]},expandedId:null,reportingItemId:null,itemNote:"",taskBugOpen:!1,taskNote:"",collapsed:!1,instructionsCollapsed:te.instructionsCollapsed,checklistCollapsed:te.checklistCollapsed,helpMarkdown:null,busy:!1,error:null},x&&(x.style.display="block"),w(),Promise.all([Rn(),Pn()]).then(([,t])=>{o&&(o.instructionsCollapsed=t.instructionsCollapsed,o.checklistCollapsed=t.checklistCollapsed,w(),tt())}))}function nt(){N=null,o=null,window.removeEventListener("resize",Qe),x==null||x.remove(),x=null,P=null}function Xn(){window===window.top&&A.runtime.onMessage.addListener(e=>{if(!e||typeof e!="object"||!("type"in e))return;const t=e.type;if(t==="overlay.open"){const n=e.task;n!=null&&n.id&&Wn(n)}if(t==="overlay.close"&&nt(),t==="qa.checklistChanged"){if(!o||e.taskId!==o.task.id||!yn("overlay",e.source))return;tt()}})}const Un=".task-card[data-task-id], .task-list-row[data-task-id]",U="arc-todo-card-highlight";function Vn(e){return e.length===0?null:[...e].reverse().find(n=>!n.className.split(/\s+/).includes("is-subtask"))??e[0]}function Gn(e){var a,d,f,y,u;const t=(a=e.taskId)==null?void 0:a.trim(),n=(d=e.displayId)==null?void 0:d.trim(),r=(f=e.organizationId)==null?void 0:f.trim(),i=(y=e.projectId)==null?void 0:y.trim(),s=((u=e.taskTitle)==null?void 0:u.trim())||n;return!t||!n||!s||!r||!i?null:{id:t,displayId:n,title:s,organizationId:r,projectId:i}}let F=!1,rt="";function ot(e){let t=e.getElementById(U);return t||(t=e.createElement("div"),t.id=U,t.setAttribute("aria-hidden","true"),Object.assign(t.style,{position:"fixed",pointerEvents:"none",zIndex:"2147483647",outline:"2px solid #4862ce",outlineOffset:"2px",background:"rgba(72, 98, 206, 0.14)",borderRadius:"18px",boxSizing:"border-box",display:"none"}),e.documentElement.appendChild(t),t)}function Kn(e){const t=[];let n=e;for(;n;){const r=n.closest(Un);if(!(r instanceof HTMLElement))break;t.push(r),n=r.parentElement}return t}function it(e,t,n){const r=e.elementFromPoint(t,n);return!r||r.id===U||r.id===_||r.closest(`#${_}`)?null:Vn(Kn(r))}function Zn(e,t){const n=ot(e);if(!t){n.style.display="none";return}const r=t.getBoundingClientRect();n.style.display="block",n.style.left=`${r.left}px`,n.style.top=`${r.top}px`,n.style.width=`${r.width}px`,n.style.height=`${r.height}px`}function st(e){F&&Zn(document,it(document,e.clientX,e.clientY))}function at(e){if(!F)return;const t=it(document,e.clientX,e.clientY);if(!t)return;const n=Gn({taskId:t.dataset.taskId,displayId:t.dataset.displayId,taskTitle:t.dataset.taskTitle,organizationId:t.dataset.organizationId,projectId:t.dataset.projectId});n&&(e.preventDefault(),e.stopPropagation(),e.stopImmediatePropagation(),me(),A.runtime.sendMessage({type:"card.picked",task:n}))}function ct(e){!F||e.key!=="Escape"||(e.preventDefault(),me(),A.runtime.sendMessage({type:"card.cancelled"}))}function Qn(){window===window.top&&(F||(F=!0,rt=document.documentElement.style.cursor,document.documentElement.style.cursor="pointer",ot(document),document.addEventListener("mousemove",st,!0),document.addEventListener("click",at,!0),document.addEventListener("keydown",ct,!0)))}function me(){var e;!F&&!document.getElementById(U)||(F=!1,document.documentElement.style.cursor=rt,document.removeEventListener("mousemove",st,!0),document.removeEventListener("click",at,!0),document.removeEventListener("keydown",ct,!0),(e=document.getElementById(U))==null||e.remove())}function Jn(){window===window.top&&A.runtime.onMessage.addListener(e=>{if(!e||typeof e!="object"||!("type"in e))return;const t=e.type;t==="card.arm"&&Qn(),t==="card.disarm"&&me()})}const lt=window;function er(e){return!!(e&&typeof e=="object"&&e.type==="content.ping")}A.runtime.onMessage.addListener(e=>{if(er(e))return Promise.resolve(!0)}),lt.__arcTodoContentReady||(lt.__arcTodoContentReady=!0,window.addEventListener(ft,e=>{const t=e.detail;typeof t=="string"&&A.runtime.sendMessage({type:"capture.console",payload:t})}),A.runtime.sendMessage({type:"capture.pageReady"}),rn(),pn(),Jn(),Xn())})();
