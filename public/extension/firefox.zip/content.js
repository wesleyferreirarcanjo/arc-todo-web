(function(){"use strict";function vt(e){return e&&e.__esModule&&Object.prototype.hasOwnProperty.call(e,"default")?e.default:e}var Q={exports:{}},wt=Q.exports,we;function Et(){return we||(we=1,(function(e,t){(function(n,r){r(e)})(typeof globalThis<"u"?globalThis:typeof self<"u"?self:wt,function(n){if(!(globalThis.chrome&&globalThis.chrome.runtime&&globalThis.chrome.runtime.id))throw new Error("This script should only be loaded in a browser extension.");if(globalThis.browser&&globalThis.browser.runtime&&globalThis.browser.runtime.id)n.exports=globalThis.browser;else{const r="The message port closed before a response was received.",o=s=>{const a={alarms:{clear:{minArgs:0,maxArgs:1},clearAll:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getAll:{minArgs:0,maxArgs:0}},bookmarks:{create:{minArgs:1,maxArgs:1},get:{minArgs:1,maxArgs:1},getChildren:{minArgs:1,maxArgs:1},getRecent:{minArgs:1,maxArgs:1},getSubTree:{minArgs:1,maxArgs:1},getTree:{minArgs:0,maxArgs:0},move:{minArgs:2,maxArgs:2},remove:{minArgs:1,maxArgs:1},removeTree:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1},update:{minArgs:2,maxArgs:2}},browserAction:{disable:{minArgs:0,maxArgs:1,fallbackToNoCallback:!0},enable:{minArgs:0,maxArgs:1,fallbackToNoCallback:!0},getBadgeBackgroundColor:{minArgs:1,maxArgs:1},getBadgeText:{minArgs:1,maxArgs:1},getPopup:{minArgs:1,maxArgs:1},getTitle:{minArgs:1,maxArgs:1},openPopup:{minArgs:0,maxArgs:0},setBadgeBackgroundColor:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setBadgeText:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setIcon:{minArgs:1,maxArgs:1},setPopup:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setTitle:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},browsingData:{remove:{minArgs:2,maxArgs:2},removeCache:{minArgs:1,maxArgs:1},removeCookies:{minArgs:1,maxArgs:1},removeDownloads:{minArgs:1,maxArgs:1},removeFormData:{minArgs:1,maxArgs:1},removeHistory:{minArgs:1,maxArgs:1},removeLocalStorage:{minArgs:1,maxArgs:1},removePasswords:{minArgs:1,maxArgs:1},removePluginData:{minArgs:1,maxArgs:1},settings:{minArgs:0,maxArgs:0}},commands:{getAll:{minArgs:0,maxArgs:0}},contextMenus:{remove:{minArgs:1,maxArgs:1},removeAll:{minArgs:0,maxArgs:0},update:{minArgs:2,maxArgs:2}},cookies:{get:{minArgs:1,maxArgs:1},getAll:{minArgs:1,maxArgs:1},getAllCookieStores:{minArgs:0,maxArgs:0},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}},devtools:{inspectedWindow:{eval:{minArgs:1,maxArgs:2,singleCallbackArg:!1}},panels:{create:{minArgs:3,maxArgs:3,singleCallbackArg:!0},elements:{createSidebarPane:{minArgs:1,maxArgs:1}}}},downloads:{cancel:{minArgs:1,maxArgs:1},download:{minArgs:1,maxArgs:1},erase:{minArgs:1,maxArgs:1},getFileIcon:{minArgs:1,maxArgs:2},open:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},pause:{minArgs:1,maxArgs:1},removeFile:{minArgs:1,maxArgs:1},resume:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1},show:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},extension:{isAllowedFileSchemeAccess:{minArgs:0,maxArgs:0},isAllowedIncognitoAccess:{minArgs:0,maxArgs:0}},history:{addUrl:{minArgs:1,maxArgs:1},deleteAll:{minArgs:0,maxArgs:0},deleteRange:{minArgs:1,maxArgs:1},deleteUrl:{minArgs:1,maxArgs:1},getVisits:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1}},i18n:{detectLanguage:{minArgs:1,maxArgs:1},getAcceptLanguages:{minArgs:0,maxArgs:0}},identity:{launchWebAuthFlow:{minArgs:1,maxArgs:1}},idle:{queryState:{minArgs:1,maxArgs:1}},management:{get:{minArgs:1,maxArgs:1},getAll:{minArgs:0,maxArgs:0},getSelf:{minArgs:0,maxArgs:0},setEnabled:{minArgs:2,maxArgs:2},uninstallSelf:{minArgs:0,maxArgs:1}},notifications:{clear:{minArgs:1,maxArgs:1},create:{minArgs:1,maxArgs:2},getAll:{minArgs:0,maxArgs:0},getPermissionLevel:{minArgs:0,maxArgs:0},update:{minArgs:2,maxArgs:2}},pageAction:{getPopup:{minArgs:1,maxArgs:1},getTitle:{minArgs:1,maxArgs:1},hide:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setIcon:{minArgs:1,maxArgs:1},setPopup:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setTitle:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},show:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},permissions:{contains:{minArgs:1,maxArgs:1},getAll:{minArgs:0,maxArgs:0},remove:{minArgs:1,maxArgs:1},request:{minArgs:1,maxArgs:1}},runtime:{getBackgroundPage:{minArgs:0,maxArgs:0},getPlatformInfo:{minArgs:0,maxArgs:0},openOptionsPage:{minArgs:0,maxArgs:0},requestUpdateCheck:{minArgs:0,maxArgs:0},sendMessage:{minArgs:1,maxArgs:3},sendNativeMessage:{minArgs:2,maxArgs:2},setUninstallURL:{minArgs:1,maxArgs:1}},sessions:{getDevices:{minArgs:0,maxArgs:1},getRecentlyClosed:{minArgs:0,maxArgs:1},restore:{minArgs:0,maxArgs:1}},storage:{local:{clear:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}},managed:{get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1}},sync:{clear:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}}},tabs:{captureVisibleTab:{minArgs:0,maxArgs:2},create:{minArgs:1,maxArgs:1},detectLanguage:{minArgs:0,maxArgs:1},discard:{minArgs:0,maxArgs:1},duplicate:{minArgs:1,maxArgs:1},executeScript:{minArgs:1,maxArgs:2},get:{minArgs:1,maxArgs:1},getCurrent:{minArgs:0,maxArgs:0},getZoom:{minArgs:0,maxArgs:1},getZoomSettings:{minArgs:0,maxArgs:1},goBack:{minArgs:0,maxArgs:1},goForward:{minArgs:0,maxArgs:1},highlight:{minArgs:1,maxArgs:1},insertCSS:{minArgs:1,maxArgs:2},move:{minArgs:2,maxArgs:2},query:{minArgs:1,maxArgs:1},reload:{minArgs:0,maxArgs:2},remove:{minArgs:1,maxArgs:1},removeCSS:{minArgs:1,maxArgs:2},sendMessage:{minArgs:2,maxArgs:3},setZoom:{minArgs:1,maxArgs:2},setZoomSettings:{minArgs:1,maxArgs:2},update:{minArgs:1,maxArgs:2}},topSites:{get:{minArgs:0,maxArgs:0}},webNavigation:{getAllFrames:{minArgs:1,maxArgs:1},getFrame:{minArgs:1,maxArgs:1}},webRequest:{handlerBehaviorChanged:{minArgs:0,maxArgs:0}},windows:{create:{minArgs:0,maxArgs:1},get:{minArgs:1,maxArgs:2},getAll:{minArgs:0,maxArgs:1},getCurrent:{minArgs:0,maxArgs:1},getLastFocused:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},update:{minArgs:2,maxArgs:2}}};if(Object.keys(a).length===0)throw new Error("api-metadata.json has not been included in browser-polyfill");class l extends WeakMap{constructor(u,h=void 0){super(h),this.createItem=u}get(u){return this.has(u)||this.set(u,this.createItem(u)),super.get(u)}}const p=c=>c&&typeof c=="object"&&typeof c.then=="function",g=(c,u)=>(...h)=>{s.runtime.lastError?c.reject(new Error(s.runtime.lastError.message)):u.singleCallbackArg||h.length<=1&&u.singleCallbackArg!==!1?c.resolve(h[0]):c.resolve(h)},m=c=>c==1?"argument":"arguments",w=(c,u)=>function(b,...N){if(N.length<u.minArgs)throw new Error(`Expected at least ${u.minArgs} ${m(u.minArgs)} for ${c}(), got ${N.length}`);if(N.length>u.maxArgs)throw new Error(`Expected at most ${u.maxArgs} ${m(u.maxArgs)} for ${c}(), got ${N.length}`);return new Promise((T,I)=>{if(u.fallbackToNoCallback)try{b[c](...N,g({resolve:T,reject:I},u))}catch(f){console.warn(`${c} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `,f),b[c](...N),u.fallbackToNoCallback=!1,u.noCallback=!0,T()}else u.noCallback?(b[c](...N),T()):b[c](...N,g({resolve:T,reject:I},u))})},C=(c,u,h)=>new Proxy(u,{apply(b,N,T){return h.call(N,c,...T)}});let B=Function.call.bind(Object.prototype.hasOwnProperty);const F=(c,u={},h={})=>{let b=Object.create(null),N={has(I,f){return f in c||f in b},get(I,f,P){if(f in b)return b[f];if(!(f in c))return;let k=c[f];if(typeof k=="function")if(typeof u[f]=="function")k=C(c,c[f],u[f]);else if(B(h,f)){let U=w(f,h[f]);k=C(c,c[f],U)}else k=k.bind(c);else if(typeof k=="object"&&k!==null&&(B(u,f)||B(h,f)))k=F(k,u[f],h[f]);else if(B(h,"*"))k=F(k,u[f],h["*"]);else return Object.defineProperty(b,f,{configurable:!0,enumerable:!0,get(){return c[f]},set(U){c[f]=U}}),k;return b[f]=k,k},set(I,f,P,k){return f in b?b[f]=P:c[f]=P,!0},defineProperty(I,f,P){return Reflect.defineProperty(b,f,P)},deleteProperty(I,f){return Reflect.deleteProperty(b,f)}},T=Object.create(c);return new Proxy(T,N)},z=c=>({addListener(u,h,...b){u.addListener(c.get(h),...b)},hasListener(u,h){return u.hasListener(c.get(h))},removeListener(u,h){u.removeListener(c.get(h))}}),nr=new l(c=>typeof c!="function"?c:function(h){const b=F(h,{},{getContent:{minArgs:0,maxArgs:0}});c(b)}),yt=new l(c=>typeof c!="function"?c:function(h,b,N){let T=!1,I,f=new Promise(Z=>{I=function(O){T=!0,Z(O)}}),P;try{P=c(h,b,I)}catch(Z){P=Promise.reject(Z)}const k=P!==!0&&p(P);if(P!==!0&&!k&&!T)return!1;const U=Z=>{Z.then(O=>{N(O)},O=>{let ve;O&&(O instanceof Error||typeof O.message=="string")?ve=O.message:ve="An unexpected error occurred",N({__mozWebExtensionPolyfillReject__:!0,message:ve})}).catch(O=>{console.error("Failed to send onMessage rejected reply",O)})};return U(k?P:f),!0}),rr=({reject:c,resolve:u},h)=>{s.runtime.lastError?s.runtime.lastError.message===r?u():c(new Error(s.runtime.lastError.message)):h&&h.__mozWebExtensionPolyfillReject__?c(new Error(h.message)):u(h)},At=(c,u,h,...b)=>{if(b.length<u.minArgs)throw new Error(`Expected at least ${u.minArgs} ${m(u.minArgs)} for ${c}(), got ${b.length}`);if(b.length>u.maxArgs)throw new Error(`Expected at most ${u.maxArgs} ${m(u.maxArgs)} for ${c}(), got ${b.length}`);return new Promise((N,T)=>{const I=rr.bind(null,{resolve:N,reject:T});b.push(I),h.sendMessage(...b)})},or={devtools:{network:{onRequestFinished:z(nr)}},runtime:{onMessage:z(yt),onMessageExternal:z(yt),sendMessage:At.bind(null,"sendMessage",{minArgs:1,maxArgs:3})},tabs:{sendMessage:At.bind(null,"sendMessage",{minArgs:2,maxArgs:3})}},Ae={clear:{minArgs:1,maxArgs:1},get:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}};return a.privacy={network:{"*":Ae},services:{"*":Ae},websites:{"*":Ae}},F(s,or,a)};n.exports=o(chrome)}})})(Q)),Q.exports}var kt=Et();const y=vt(kt),Ee="arc-todo-agent-overlay",ke="arc-todo-agent-cursor",Ce="arc-todo-agent-stop";function ae(){return document.getElementById(Ee)}function Ct(e,t){var o;let n=ae();if(!n){n=document.createElement("div"),n.id=Ee,n.setAttribute("data-arc-todo-agent","1");const s=n.attachShadow({mode:"open"}),a=document.createElement("style");a.textContent=`
      :host { all: initial; }
      .wrap {
        position: fixed; inset: 0; pointer-events: none; z-index: 2147483646;
      }
      .cursor {
        position: absolute; width: 22px; height: 22px; margin: -2px 0 0 -2px;
        filter: drop-shadow(0 0 6px var(--glow));
        transition: transform 80ms linear;
      }
      .stop {
        pointer-events: auto; position: fixed; top: 12px; right: 12px;
        font: 600 12px system-ui, sans-serif; color: #f7f8fc;
        background: #3d52b8; border: 0; border-radius: 6px; padding: 6px 10px;
        box-shadow: 0 0 16px var(--glow); cursor: pointer;
      }
    `;const l=document.createElement("div");l.className="wrap";const p=document.createElement("div");p.id=ke,p.className="cursor",p.innerHTML='<svg viewBox="0 0 24 24" width="22" height="22" xmlns="http://www.w3.org/2000/svg"><path d="M4 2l16 12-7 1 4 8-4 1-4-8-5 4z" fill="#e8ecf4" stroke="#3d52b8" stroke-width="1.2"/></svg>';const g=document.createElement("button");g.id=Ce,g.className="stop",g.type="button",g.textContent="Stop",l.append(p,g),s.append(a,l),document.documentElement.append(n),g.addEventListener("click",()=>{y.runtime.sendMessage({type:"agent.stop"})})}n.style.setProperty("--glow",e);const r=(o=n.shadowRoot)==null?void 0:o.getElementById(Ce);return r&&r.setAttribute("title",`Arc AI · ${t}`),n}function Nt(e){var r,o;if(e.type==="agent.overlay.hide"){(r=ae())==null||r.remove();return}if(e.type==="agent.overlay.show"){Ct(e.color,e.clientName);return}const t=ae(),n=(o=t==null?void 0:t.shadowRoot)==null?void 0:o.getElementById(ke);n&&(n.style.transform=`translate(${e.x}px, ${e.y}px)`)}function St(){y.runtime.onMessage.addListener(e=>{if(!e||typeof e!="object")return;const t=e.type;if(t==="agent.overlay.show"||t==="agent.overlay.hide"||t==="agent.overlay.move")return Nt(e),Promise.resolve(!0)})}const Lt="arc-todo-capture",H="arc-todo-qa-overlay",Mt=2147483645,le="arcTodo.overlayPosition",ce="arcTodo.overlaySections";function Tt(e,t,n,r,o,s){const a=Math.max(0,Math.min(e,n)),l=Math.max(0,Math.min(t,r)),p=Math.min(o,Math.max(e,n)),g=Math.min(s,Math.max(t,r)),m=p-a,w=g-l;return m<4||w<4?null:{x:a,y:l,width:m,height:w}}function It(e,t,n,r,o){const s=Tt(e,t,n,r,o.width,o.height);return s?{rect:s,viewport:o}:null}const X="arc-todo-region-overlay",G="arc-todo-region-marquee",Ne=["pointerdown","mousedown","mouseup","auxclick","contextmenu","dblclick"];let _=!1,Se="",q=null;function Pt(){return{position:"fixed",inset:"0",zIndex:"2147483646",cursor:"crosshair",background:"rgba(0, 0, 0, 0.35)",boxSizing:"border-box"}}function $t(){return{position:"fixed",pointerEvents:"none",zIndex:"2147483646",outline:"2px solid #ffffff",outlineOffset:"0",boxShadow:"0 0 0 99999px rgba(0, 0, 0, 0.35)",boxSizing:"border-box",display:"none",background:"transparent"}}function Rt(e){let t=e.getElementById(X);return t||(t=e.createElement("div"),t.id=X,t.setAttribute("aria-hidden","true"),Object.assign(t.style,Pt()),e.documentElement.appendChild(t),t)}function Le(e){let t=e.getElementById(G);return t||(t=e.createElement("div"),t.id=G,t.setAttribute("aria-hidden","true"),Object.assign(t.style,$t()),e.documentElement.appendChild(t),t)}function Bt(e){return e?e.id===H?!0:!!e.closest(`#${H}`):!1}function Ot(e,t,n){const r=e.getElementById(X),o=e.getElementById(G);r&&(r.style.pointerEvents="none"),o&&(o.style.pointerEvents="none");const s=e.elementFromPoint(t,n);return r&&(r.style.pointerEvents="auto"),s}function Me(e){_&&(e.preventDefault(),e.stopPropagation(),e.stopImmediatePropagation())}function _t(e,t,n,r){const o=Math.min(e,n),s=Math.min(t,r),a=Le(document);a.style.display="block",a.style.left=`${o}px`,a.style.top=`${s}px`,a.style.width=`${Math.abs(n-e)}px`,a.style.height=`${Math.abs(r-t)}px`}function Te(){const e=document.getElementById(G);e&&(e.style.display="none")}function zt(){return{width:window.innerWidth,height:window.innerHeight}}function Ie(e){if(!_||e.button!==0)return;const t=Ot(document,e.clientX,e.clientY);Bt(t)||(q={x:e.clientX,y:e.clientY},Te())}function Pe(e){!_||!q||_t(q.x,q.y,e.clientX,e.clientY)}function $e(e){if(!_||!q)return;const t=q;q=null;const n=It(t.x,t.y,e.clientX,e.clientY,zt());Te(),n&&(y.runtime.sendMessage({type:"region.picked",rect:n.rect,viewport:n.viewport,devicePixelRatio:window.devicePixelRatio}),de())}function Re(e){!_||e.key!=="Escape"||(e.preventDefault(),de(),y.runtime.sendMessage({type:"region.cancelled"}))}function qt(){if(window===window.top&&!_){_=!0,Se=document.documentElement.style.cursor,document.documentElement.style.cursor="crosshair",Rt(document),Le(document),document.addEventListener("pointerdown",Ie,!0),document.addEventListener("pointermove",Pe,!0),document.addEventListener("pointerup",$e,!0),document.addEventListener("keydown",Re,!0);for(const e of Ne)document.addEventListener(e,Me,!0)}}function de(){var e,t;if(!(!_&&!document.getElementById(X))){_=!1,q=null,document.documentElement.style.cursor=Se,document.removeEventListener("pointerdown",Ie,!0),document.removeEventListener("pointermove",Pe,!0),document.removeEventListener("pointerup",$e,!0),document.removeEventListener("keydown",Re,!0);for(const n of Ne)document.removeEventListener(n,Me,!0);(e=document.getElementById(X))==null||e.remove(),(t=document.getElementById(G))==null||t.remove()}}function Dt(){window===window.top&&y.runtime.onMessage.addListener(e=>{if(!e||typeof e!="object"||!("type"in e))return;const t=e.type;t==="region.arm"&&qt(),t==="region.disarm"&&de()})}function Ft(e){var t;return((t=e.find(n=>!n.checked))==null?void 0:t.id)??null}function Ht(e,t){var o;const n=e.findIndex(s=>s.id===t);return((o=(n>=0?e.slice(n+1):e).find(s=>!s.checked))==null?void 0:o.id)??Ft(e)}function jt(e,t){if(t&&e.some(n=>n.id===t))return t}function Wt(e,t){return t==="panel"||t==="overlay"?t!==e:!0}function Yt(e,t,n,r,o=48){const s=o-r.width,a=n.width-o,l=0,p=Math.max(0,n.height-o);return{left:Math.min(a,Math.max(s,e)),top:Math.min(p,Math.max(l,t))}}function Ut(e,t,n=16){return{left:Math.max(n,e.width-t.width-n),top:Math.max(n,e.height-t.height-n)}}const Be=/(\*\*[^*]+\*\*|\*[^*]+\*|`[^`]+`|\[[^\]]+\]\(https?:\/\/[^)\s]+\)|https?:\/\/[^\s<>"'`]+)/g;function Xt(e){const t=[];let n=0;Be.lastIndex=0;let r;for(;r=Be.exec(e);){r.index>n&&t.push({type:"text",text:e.slice(n,r.index)});const o=r[0];if(o.startsWith("**"))t.push({type:"strong",text:o.slice(2,-2)});else if(o.startsWith("*"))t.push({type:"em",text:o.slice(1,-1)});else if(o.startsWith("`"))t.push({type:"code",text:o.slice(1,-1)});else if(o.startsWith("[")){const s=o.match(/^\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)$/);s&&t.push({type:"a",text:s[1],href:s[2]})}else{const s=o.replace(/[),.;:!?]+$/,""),a=o.slice(s.length);s&&t.push({type:"a",text:s,href:s}),a&&t.push({type:"text",text:a})}n=r.index+o.length}return n<e.length&&t.push({type:"text",text:e.slice(n)}),t.length>0?t:[{type:"text",text:e}]}function Gt(e,t){const n=t.join(`
`).trim();n&&e.push({type:"p",text:n})}function Vt(e){return`h${Math.min(e.length,4)}`}function Kt(e){const t=[];let n=[],r=[],o=[],s=null;function a(){r.length!==0&&(t.push({type:"ul",items:r}),r=[])}function l(){o.length!==0&&(t.push({type:"ol",items:o}),o=[])}function p(){const m=n;n=[],Gt(t,m)}function g(){a(),l()}for(const m of e.split(`
`)){if(s){m.startsWith("```")?(t.push({type:"pre",text:s.join(`
`)}),s=null):s.push(m);continue}if(m.startsWith("```")){g(),p(),s=[];continue}if(/^(-{3,}|\*{3,}|_{3,})\s*$/.test(m.trim())){g(),p(),t.push({type:"hr"});continue}const w=m.match(/^>\s?(.*)$/);if(w){g(),p();const z=t[t.length-1];(z==null?void 0:z.type)==="blockquote"?z.text=`${z.text}
${w[1]}`:t.push({type:"blockquote",text:w[1]});continue}const C=m.match(/^(#{1,4})\s+(.*)$/),B=m.match(/^[-*]\s+(.*)$/),F=m.match(/^\d+\.\s+(.*)$/);if(C){g(),p(),t.push({type:Vt(C[1]),text:C[2]});continue}if(B){l(),p(),r.push(B[1]);continue}if(F){a(),p(),o.push(F[1]);continue}if(!m.trim()){g(),p();continue}g(),n.push(m)}return s&&t.push({type:"pre",text:s.join(`
`)}),g(),p(),t}function ue(e,t){for(const n of Xt(t)){if(n.type==="text"){e.appendChild(document.createTextNode(n.text));continue}if(n.type==="a"){const o=document.createElement("a");o.href=n.href,o.target="_blank",o.rel="noopener noreferrer",o.textContent=n.text,e.appendChild(o);continue}const r=document.createElement(n.type==="strong"?"strong":n.type==="em"?"em":"code");r.textContent=n.text,e.appendChild(r)}}function Zt(e,t){for(const n of Kt(t)){if(n.type==="ul"||n.type==="ol"){const o=document.createElement(n.type);for(const s of n.items){const a=document.createElement("li");ue(a,s),o.appendChild(a)}e.appendChild(o);continue}if(n.type==="pre"){const o=document.createElement("pre"),s=document.createElement("code");s.textContent=n.text,o.appendChild(s),e.appendChild(o);continue}if(n.type==="hr"){e.appendChild(document.createElement("hr"));continue}if(n.type==="blockquote"){const o=document.createElement("blockquote");ue(o,n.text),e.appendChild(o);continue}const r=document.createElement(n.type);ue(r,n.text),e.appendChild(r)}}function Qt(e){if(!e||typeof e!="object"||Array.isArray(e))return null;const t=e;return typeof t.left!="number"||typeof t.top!="number"||!Number.isFinite(t.left)||!Number.isFinite(t.top)?null:{left:t.left,top:t.top}}const Oe=60;function Jt(e){const t=e.replace(/\*\*/g,"").trim(),n=e.match(/^\s*\*\*(.+?)\*\*/);if(n)return{short:n[1].replace(/\*\*/g,"").trim(),full:t,fromBold:!0};const r=t.indexOf(":");return r>0?{short:t.slice(0,r).trim(),full:t,fromBold:!1}:t.length>Oe?{short:`${t.slice(0,Oe)}…`,full:t,fromBold:!1}:{short:t,full:t,fromBold:!1}}function _e(e){return e.map(t=>{const n=Jt(t.label);return{id:t.id,short:n.short,full:n.full,checked:t.checked,bugged:t.bugged,notes:t.notes}})}const J={instructionsCollapsed:!1,checklistCollapsed:!1};function en(e){if(!e||typeof e!="object"||Array.isArray(e))return null;const t=e;return typeof t.instructionsCollapsed!="boolean"||typeof t.checklistCollapsed!="boolean"?null:{instructionsCollapsed:t.instructionsCollapsed,checklistCollapsed:t.checklistCollapsed}}const tn=`
:host {
  all: initial;
  position: fixed;
  z-index: 2147483645;
  font-family: system-ui, sans-serif;
  color-scheme: dark;
  --bg-surface: #1b2230;
  --bg-elevated: #252e3d;
  --text-primary: #e8ecf4;
  --text-muted: #9aa6bc;
  --border: rgba(142, 160, 188, 0.18);
  --accent: #4862ce;
  --accent-contrast: #f7f8fc;
  --radius: 0.75rem;
  --type-body: 0.8125rem;
  --type-meta: 0.7rem;
  --type-section: 0.9rem;
}

@media (prefers-color-scheme: light) {
  :host {
    color-scheme: light;
    --bg-surface: #fbfcfe;
    --bg-elevated: #eef1f6;
    --text-primary: #1b2230;
    --text-muted: #5a6578;
    --border: rgba(46, 53, 69, 0.16);
    --accent: #3d52b8;
  }
}

*, *::before, *::after { box-sizing: border-box; }

.panel {
  width: min(420px, calc(100vw - 24px));
  max-height: min(70vh, 520px);
  display: flex;
  flex-direction: column;
  background: var(--bg-surface);
  color: var(--text-primary);
  border: 1px solid var(--border);
  border-radius: var(--radius);
  box-shadow: 0 12px 40px rgba(0, 0, 0, 0.35);
  overflow: hidden;
  font-size: var(--type-body);
  line-height: 1.4;
}

.panel.is-collapsed .body { display: none; }

.header {
  display: flex;
  align-items: flex-start;
  gap: 0.5rem;
  padding: 0.55rem 0.65rem;
  background: var(--bg-elevated);
  border-bottom: 1px solid var(--border);
  cursor: grab;
  touch-action: none;
  user-select: none;
}

.header:active { cursor: grabbing; }

.header-text {
  flex: 1;
  min-width: 0;
}

.display-id {
  margin: 0;
  font-size: var(--type-meta);
  color: var(--text-muted);
  font-weight: 600;
}

.title {
  margin: 0.1rem 0 0;
  font-size: var(--type-section);
  font-weight: 700;
  line-height: 1.25;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.header-actions {
  display: flex;
  gap: 0.25rem;
  flex-shrink: 0;
}

.icon-btn {
  appearance: none;
  border: 1px solid var(--border);
  background: transparent;
  color: var(--text-primary);
  border-radius: calc(var(--radius) - 0.25rem);
  width: 1.75rem;
  height: 1.75rem;
  font: inherit;
  font-size: 0.85rem;
  line-height: 1;
  cursor: pointer;
  padding: 0;
}

.icon-btn:hover { background: var(--bg-surface); }

.body {
  overflow: auto;
  padding: 0.5rem;
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

.hint {
  margin: 0;
  font-size: var(--type-meta);
  color: var(--text-muted);
}

.list {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
  gap: 0.375rem;
}

.row {
  border: 1px solid var(--border);
  border-radius: calc(var(--radius) - 0.2rem);
  background: var(--bg-elevated);
  padding: 0.375rem;
}

.row.is-bugged { border-color: rgba(220, 80, 80, 0.45); }
.row.is-current { border-color: var(--accent); }

.row-main {
  display: flex;
  gap: 0.35rem;
  align-items: center;
}

.tick {
  appearance: none;
  border: 0;
  background: transparent;
  color: var(--text-primary);
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  padding: 0.1rem;
  font: inherit;
  min-width: 1.4rem;
}

.tick-mark {
  width: 1.1rem;
  height: 1.1rem;
  border-radius: 999px;
  border: 2px solid var(--text-muted);
  display: block;
}

.tick.is-checked .tick-mark {
  border-color: var(--accent);
  background: var(--accent);
  box-shadow: inset 0 0 0 2px var(--bg-elevated);
}

.expand {
  appearance: none;
  border: 0;
  background: transparent;
  color: var(--text-primary);
  text-align: left;
  flex: 1;
  min-width: 0;
  cursor: pointer;
  font: inherit;
  padding: 0.15rem 0;
}

.expand strong { font-weight: 650; }

.row-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 0.25rem;
  margin-top: 0.35rem;
}

.btn {
  appearance: none;
  border: 1px solid var(--border);
  background: var(--bg-surface);
  color: var(--text-primary);
  border-radius: calc(var(--radius) - 0.25rem);
  font: inherit;
  font-size: var(--type-meta);
  font-weight: 600;
  padding: 0.3rem 0.5rem;
  cursor: pointer;
}

.btn-primary {
  background: var(--accent);
  border-color: var(--accent);
  color: var(--accent-contrast);
}

.btn:disabled {
  opacity: 0.45;
  cursor: not-allowed;
}

.bug-form {
  display: flex;
  flex-direction: column;
  gap: 0.35rem;
  margin-top: 0.35rem;
}

.bug-form label {
  display: flex;
  flex-direction: column;
  gap: 0.2rem;
  font-size: var(--type-meta);
  color: var(--text-muted);
}

.bug-form textarea {
  resize: vertical;
  min-height: 3.5rem;
  border: 1px solid var(--border);
  border-radius: calc(var(--radius) - 0.25rem);
  background: var(--bg-surface);
  color: var(--text-primary);
  font: inherit;
  padding: 0.35rem;
}

.warning {
  margin: 0;
  font-size: var(--type-meta);
  color: var(--text-muted);
}

.error {
  margin: 0;
  font-size: var(--type-meta);
  color: #e07070;
}

.notes {
  margin: 0.25rem 0 0;
  padding-left: 1rem;
  font-size: var(--type-meta);
  color: var(--text-muted);
}

.section {
  display: flex;
  flex-direction: column;
  gap: 0.35rem;
  min-width: 0;
}

.section-toggle {
  appearance: none;
  display: flex;
  align-items: baseline;
  gap: 0.4rem;
  width: 100%;
  margin: 0;
  padding: 0.25rem 0;
  border: 0;
  background: transparent;
  color: var(--text-muted);
  font: inherit;
  font-size: var(--type-meta);
  font-weight: 700;
  letter-spacing: 0.02em;
  text-transform: uppercase;
  text-align: left;
  cursor: pointer;
}

.section-progress {
  font-weight: 650;
  color: var(--text-primary);
  text-transform: none;
  letter-spacing: 0;
}

.help {
  display: flex;
  flex-direction: column;
  gap: 0.4rem;
  min-width: 0;
}

.help p,
.help li {
  margin: 0;
  font-size: var(--type-meta);
  color: var(--text-muted);
}

.help ul,
.help ol {
  margin: 0;
  padding-left: 1.1rem;
}

.help h1,
.help h2,
.help h3,
.help h4 {
  margin: 0;
  font-size: var(--type-body);
  font-weight: 650;
  color: var(--text-primary);
}

.help strong { font-weight: 700; color: var(--text-primary); }
.help em { font-style: italic; }
.help code {
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  font-size: 0.88em;
  padding: 0.05em 0.3em;
  border-radius: 4px;
  border: 1px solid var(--border);
}
.help a { color: var(--accent); }
.help pre {
  margin: 0;
  padding: 0.45rem 0.55rem;
  overflow-x: auto;
  border: 1px solid var(--border);
  border-radius: 0.35rem;
  font-size: var(--type-meta);
}
.help pre code { padding: 0; border: none; }
.help hr {
  width: 100%;
  border: none;
  border-top: 1px solid var(--border);
  margin: 0.2rem 0;
}
.help blockquote {
  margin: 0;
  padding: 0.15rem 0 0.15rem 0.6rem;
  border-left: 2px solid var(--border);
  color: var(--text-muted);
}
`,x={itemDone:"Feito",itemOpen:"A fazer",flagAsBug:"Marcar como bug",solveBug:"Marcar como resolvido",solveItem:"Resolvido",motivo:"Motivo",motivoPlaceholder:"Descreva o problema encontrado",cancelFlag:"Cancelar",taskBugWarning:"Este card volta para To Do, inclusive as subtarefas.",noChecklist:"Esta tarefa não tem checklist.",collapseOverlay:"Recolher",expandOverlay:"Expandir",closeFloatingChecklist:"Fechar checklist flutuante",overlayDragHint:"Arraste pelo cabeçalho",instructionsHeading:"Instruções",checklistHeading:"Checklist",checklistChanged:"A checklist mudou. Recarregue e tente de novo.",motivoRequired:"O motivo do bug é obrigatório.",itemMotivoRequired:"O motivo do bug do item é obrigatório.",apiError:"Não foi possível falar com a API. Tente de novo.",sessionExpired:"Sessão expirada. Entre de novo no Arc Todo.",signInFirst:"Entre no Arc Todo primeiro"};let v=null,R=null,i=null,$=null;function nn(e){return e.status==="expired"?x.sessionExpired:e.status==="not_signed_in"?x.signInFirst:e.error==="stale"?x.checklistChanged:e.error==="motivo"?x.motivoRequired:e.error==="api"||e.status==="error"?x.apiError:null}function rn(){const e=document.getElementById(H);if(e&&R&&v===e)return{host:e,shadow:R};e==null||e.remove();const t=document.createElement("div");t.id=H,t.setAttribute("aria-hidden","false"),Object.assign(t.style,{position:"fixed",zIndex:String(Mt),left:"0px",top:"0px"});const n=t.attachShadow({mode:"open"}),r=document.createElement("style");return r.textContent=tn,n.appendChild(r),document.documentElement.appendChild(t),v=t,R=n,{host:t,shadow:n}}async function on(){try{const e=await y.storage.local.get(le);return Qt(e[le])}catch{return null}}async function sn(e,t){try{await y.storage.local.set({[le]:{left:e,top:t}})}catch{}}async function an(){try{const e=await y.storage.local.get(ce);return en(e[ce])??J}catch{return J}}async function ze(){if(i)try{await y.storage.local.set({[ce]:{instructionsCollapsed:i.instructionsCollapsed,checklistCollapsed:i.checklistCollapsed}})}catch{}}function me(e,t){if(!v)return;const n=v.getBoundingClientRect(),r=Yt(e,t,{width:window.innerWidth,height:window.innerHeight},{width:n.width||420,height:Math.min(n.height||48,48)});v.style.left=`${r.left}px`,v.style.top=`${r.top}px`}function qe(){if(!v)return;const e=Number.parseFloat(v.style.left||"0"),t=Number.parseFloat(v.style.top||"0");me(e,t)}async function ln(){if(!v)return;const e=await on(),t={width:420,height:320},n=e??Ut({width:window.innerWidth,height:window.innerHeight},t);me(n.left,n.top)}function cn(e){if(!v||e.button!==0)return;const t=e.target;if(t!=null&&t.closest("button"))return;const n=Number.parseFloat(v.style.left||"0"),r=Number.parseFloat(v.style.top||"0");$={pointerId:e.pointerId,startX:e.clientX,startY:e.clientY,originLeft:n,originTop:r},e.currentTarget.setPointerCapture(e.pointerId),e.preventDefault()}function dn(e){!$||e.pointerId!==$.pointerId||me($.originLeft+(e.clientX-$.startX),$.originTop+(e.clientY-$.startY))}function De(e){if(!$||e.pointerId!==$.pointerId||!v)return;$=null;const t=Number.parseFloat(v.style.left||"0"),n=Number.parseFloat(v.style.top||"0");sn(t,n)}function A(){if(!R||!i)return;const e=R.querySelector(".panel");if(!e)return;e.classList.toggle("is-collapsed",i.collapsed);const t=R.querySelector(".title"),n=R.querySelector(".display-id");t&&(t.textContent=i.task.title),n&&(n.textContent=i.task.displayId);const r=R.querySelector('[data-action="collapse"]');r&&(r.setAttribute("aria-label",i.collapsed?x.expandOverlay:x.collapseOverlay),r.textContent=i.collapsed?"▸":"▾");const o=R.querySelector(".body");if(!o)return;if(o.replaceChildren(),i.error){const l=document.createElement("p");l.className="error",l.setAttribute("role","alert"),l.textContent=i.error,o.appendChild(l)}const s=document.createElement("p");s.className="hint",s.textContent=x.overlayDragHint,o.appendChild(s),i.helpMarkdown&&o.appendChild(mn(i.helpMarkdown));const a=_e(i.items);if(a.length===0){const l=document.createElement("p");l.className="hint",l.textContent=x.noChecklist,o.appendChild(l)}else o.appendChild(pn(a.map(l=>l.id)));if(i.taskBugOpen)o.appendChild(fn());else if(i.isBug){const l=document.createElement("button");l.type="button",l.className="btn",l.textContent=x.solveBug,l.disabled=i.busy,l.addEventListener("click",()=>{An()}),o.appendChild(l)}else{const l=document.createElement("button");l.type="button",l.className="btn",l.textContent=x.flagAsBug,l.disabled=i.busy,l.addEventListener("click",()=>{i&&(i.taskBugOpen=!0,i.taskNote="",i.error=null,A())}),o.appendChild(l)}}function un(e){const t=i.items.find(m=>m.id===e),n=document.createElement("li"),r=jt(i.items,i.expandedId);n.className=["row",t.bugged?"is-bugged":"",t.id===r?"is-current":""].filter(Boolean).join(" ");const o=document.createElement("div");o.className="row-main";const s=document.createElement("button");s.type="button",s.className=t.checked?"tick is-checked":"tick",s.setAttribute("aria-pressed",String(t.checked)),s.setAttribute("aria-label",t.checked?x.itemDone:x.itemOpen),s.disabled=i.busy;const a=document.createElement("span");a.className="tick-mark",a.setAttribute("aria-hidden","true"),s.append(a),s.addEventListener("click",()=>{hn(t.id)});const l=_e([t])[0],p=document.createElement("button");p.type="button",p.className="expand";const g=i.expandedId===t.id;if(p.setAttribute("aria-expanded",String(g)),g)p.textContent=l.full;else{const m=document.createElement("strong");m.textContent=l.short,p.appendChild(m)}if(p.addEventListener("click",()=>{i&&(i.expandedId=i.expandedId===t.id?null:t.id,A())}),o.append(s,p),n.appendChild(o),t.notes.length){const m=document.createElement("ul");m.className="notes";for(const w of t.notes){const C=document.createElement("li");C.innerHTML="";const B=document.createElement("strong");B.textContent=`${x.motivo}: `,C.append(B,document.createTextNode(w)),m.appendChild(C)}n.appendChild(m)}if(i.reportingItemId===t.id)n.appendChild(gn(t.id));else if(g){const m=document.createElement("div");m.className="row-actions";const w=document.createElement("button");if(w.type="button",w.className="btn",w.textContent=x.flagAsBug,w.disabled=i.busy,w.addEventListener("click",()=>{i&&(i.reportingItemId=t.id,i.itemNote="",i.error=null,A())}),m.appendChild(w),t.bugged){const C=document.createElement("button");C.type="button",C.className="btn",C.textContent=x.solveItem,C.disabled=i.busy,C.addEventListener("click",()=>{yn(t.id)}),m.appendChild(C)}n.appendChild(m)}return n}function Fe(e,t,n,r){const o=document.createElement("button");o.type="button",o.className="section-toggle",o.setAttribute("aria-expanded",String(t));const s=document.createTextNode(e);if(o.appendChild(s),r){o.appendChild(document.createTextNode(" "));const a=document.createElement("span");a.className="section-progress",a.textContent=r,o.appendChild(a)}return o.addEventListener("click",n),o}function mn(e){const t=document.createElement("section");t.className="section";const n=!i.instructionsCollapsed;if(t.appendChild(Fe(x.instructionsHeading,n,()=>{i&&(i.instructionsCollapsed=!i.instructionsCollapsed,ze(),A())})),n){const r=document.createElement("div");r.className="help markdown-content",Zt(r,e),t.appendChild(r)}return t}function pn(e){const t=document.createElement("section");t.className="section";const n=!i.checklistCollapsed,r=i.items.filter(o=>o.checked).length;if(t.appendChild(Fe(x.checklistHeading,n,()=>{i&&(i.checklistCollapsed=!i.checklistCollapsed,ze(),A())},`${r}/${i.items.length}`)),n){const o=document.createElement("ul");o.className="list";for(const s of e)o.appendChild(un(s));t.appendChild(o)}return t}function gn(e){const t=document.createElement("div");t.className="bug-form";const n=document.createElement("label");n.textContent=x.motivo;const r=document.createElement("textarea");r.value=i.itemNote,r.placeholder=x.motivoPlaceholder,r.rows=3,r.addEventListener("input",()=>{i&&(i.itemNote=r.value,s.disabled=i.busy||!i.itemNote.trim())}),n.appendChild(r);const o=document.createElement("div");o.className="row-actions";const s=document.createElement("button");s.type="button",s.className="btn btn-primary",s.textContent=x.flagAsBug,s.disabled=i.busy||!i.itemNote.trim(),s.addEventListener("click",()=>{xn(e)});const a=document.createElement("button");return a.type="button",a.className="btn",a.textContent=x.cancelFlag,a.addEventListener("click",()=>{i&&(i.reportingItemId=null,i.itemNote="",A())}),o.append(s,a),t.append(n,o),t}function fn(){const e=document.createElement("div");e.className="bug-form";const t=document.createElement("p");t.className="warning",t.textContent=x.taskBugWarning;const n=document.createElement("label");n.textContent=x.motivo;const r=document.createElement("textarea");r.value=i.taskNote,r.placeholder=x.motivoPlaceholder,r.rows=3,r.addEventListener("input",()=>{i&&(i.taskNote=r.value,s.disabled=i.busy||!i.taskNote.trim())}),n.appendChild(r);const o=document.createElement("div");o.className="row-actions";const s=document.createElement("button");s.type="button",s.className="btn btn-primary",s.textContent=x.flagAsBug,s.disabled=i.busy||!i.taskNote.trim(),s.addEventListener("click",()=>{bn()});const a=document.createElement("button");return a.type="button",a.className="btn",a.textContent=x.cancelFlag,a.addEventListener("click",()=>{i&&(i.taskBugOpen=!1,i.taskNote="",A())}),o.append(s,a),e.append(t,n,o),e}function j(e){if(!i)return!1;const t=nn(e);if(t)return i.error=t,!1;if(i.error=null,e.items){i.items=e.items;const n=i.expandedId;n&&!e.items.some(r=>r.id===n)&&(i.expandedId=null)}return e.snapshot&&(i.snapshot=e.snapshot),e.helpMarkdown!==void 0&&(i.helpMarkdown=e.helpMarkdown??null),e.isBug!==void 0&&(i.isBug=e.isBug),!0}async function He(){if(i){i.busy=!0,A();try{const e=await y.runtime.sendMessage({type:"task.get",task:i.task});j(e)}finally{i&&(i.busy=!1),A()}}}async function hn(e){if(!(!i||i.busy)){i.busy=!0,i.error=null,A();try{const t=await y.runtime.sendMessage({type:"checklist.tick",task:i.task,itemId:e,snapshot:i.snapshot,source:"overlay"});if(j(t),i){const n=i.items.find(r=>r.id===e);n!=null&&n.checked?i.expandedId=Ht(i.items,e):i.expandedId=e}}finally{i&&(i.busy=!1),A()}}}async function xn(e){if(!(!i||i.busy)){if(!i.itemNote.trim()){i.error=x.itemMotivoRequired,A();return}i.busy=!0,i.error=null,A();try{const t=await y.runtime.sendMessage({type:"checklist.flagItem",task:i.task,itemId:e,note:i.itemNote,snapshot:i.snapshot,source:"overlay"});j(t)&&(i.reportingItemId=null,i.itemNote="")}finally{i&&(i.busy=!1),A()}}}async function bn(){if(!(!i||i.busy)){if(!i.taskNote.trim()){i.error=x.motivoRequired,A();return}i.busy=!0,i.error=null,A();try{const e=await y.runtime.sendMessage({type:"task.flag",task:i.task,note:i.taskNote,source:"overlay"});j(e)&&(i.taskBugOpen=!1,i.taskNote="")}finally{i&&(i.busy=!1),A()}}}async function yn(e){if(!(!i||i.busy)){i.busy=!0,i.error=null,A();try{const t=await y.runtime.sendMessage({type:"checklist.unflagItem",task:i.task,itemId:e,snapshot:i.snapshot,source:"overlay"});j(t)}finally{i&&(i.busy=!1),A()}}}async function An(){if(!(!i||i.busy)){i.busy=!0,i.error=null,A();try{const e=await y.runtime.sendMessage({type:"task.unflag",task:i.task,source:"overlay"});j(e)}finally{i&&(i.busy=!1),A()}}}function vn(){const{shadow:e}=rn();if(e.querySelector(".panel"))return;const n=document.createElement("div");n.className="panel",n.setAttribute("role","dialog"),n.setAttribute("aria-label","Checklist");const r=document.createElement("div");r.className="header",r.addEventListener("pointerdown",cn),r.addEventListener("pointermove",dn),r.addEventListener("pointerup",De),r.addEventListener("pointercancel",De);const o=document.createElement("div");o.className="header-text";const s=document.createElement("p");s.className="display-id";const a=document.createElement("h2");a.className="title",o.append(s,a);const l=document.createElement("div");l.className="header-actions";const p=document.createElement("button");p.type="button",p.className="icon-btn",p.dataset.action="collapse",p.addEventListener("click",()=>{i&&(i.collapsed=!i.collapsed,A())});const g=document.createElement("button");g.type="button",g.className="icon-btn",g.setAttribute("aria-label",x.closeFloatingChecklist),g.textContent="×",g.addEventListener("click",()=>{je()}),l.append(p,g),r.append(o,l);const m=document.createElement("div");m.className="body",n.append(r,m),e.appendChild(n),window.addEventListener("resize",qe)}function wn(e){window===window.top&&(vn(),i={task:e,items:[],snapshot:{items:[]},expandedId:null,reportingItemId:null,itemNote:"",taskBugOpen:!1,taskNote:"",collapsed:!1,instructionsCollapsed:J.instructionsCollapsed,checklistCollapsed:J.checklistCollapsed,helpMarkdown:null,isBug:!1,busy:!1,error:null},v&&(v.style.display="block"),A(),Promise.all([ln(),an()]).then(([,t])=>{i&&(i.instructionsCollapsed=t.instructionsCollapsed,i.checklistCollapsed=t.checklistCollapsed,A(),He())}))}function je(){$=null,i=null,window.removeEventListener("resize",qe),v==null||v.remove(),v=null,R=null}function En(){window===window.top&&y.runtime.onMessage.addListener(e=>{if(!e||typeof e!="object"||!("type"in e))return;const t=e.type;if(t==="overlay.open"){const n=e.task;n!=null&&n.id&&wn(n)}if(t==="overlay.close"&&je(),t==="qa.checklistChanged"){if(!i||e.taskId!==i.task.id||!Wt("overlay",e.source))return;He()}})}const L={designHeading:"Notas de design",designNote:"O que deve mudar",designNotePlaceholder:"Descreva o que a IA deve alterar neste elemento",designEmpty:"Toque nos elementos da página para comentar.",designRemove:"Remover",designExit:"Sair",designClear:"Limpar",copy:"Copiar",copied:"Copiado",copyWithScreenshot:"Copiar com captura",overlayDragHint:"Arraste pelo cabeçalho"};async function We(e,t){if(!t){await navigator.clipboard.writeText(e);return}const n=await(await fetch(t)).blob();try{await navigator.clipboard.write([new ClipboardItem({"text/plain":new Blob([e],{type:"text/plain"}),[n.type||"image/png"]:n})])}catch{await navigator.clipboard.writeText(e)}}function kn(e){return e.reduce((t,n)=>Math.max(t,n.n),0)+1}function Cn(e,t){if(t<1)return null;const n=e.slice(0,t),r=n.lastIndexOf("@");if(r<0)return null;const o=n.slice(r+1);return/[\s]/.test(o)?null:{start:r,query:o}}function Nn(e,t,n){const r=n.toLowerCase();return e.filter(o=>o.n!==t).filter(o=>r?String(o.n).startsWith(r)||o.hit.selector.toLowerCase().includes(r):!0).map(o=>({n:o.n,label:o.hit.selector}))}function Sn(e,t,n,r){const o=`@${r}`;return{note:`${e.slice(0,t)}${o}${e.slice(n)}`,caret:t+o.length}}function Ye(e,t,n,r,o,s,a=4){return{x:Math.min(Math.max(e,a),Math.max(a,o-n-a)),y:Math.min(Math.max(t,a),Math.max(a,s-r-a))}}const Ln=6,Ue=200,Mn=3;function Tn(e){return{color:(e==null?void 0:e.color)??"",fontSize:(e==null?void 0:e.fontSize)??"",display:(e==null?void 0:e.display)??""}}function Xe(e){const{x:t,y:n,width:r,height:o}=e.rect;return`${e.selector}@${Math.round(t)},${Math.round(n)},${Math.round(r)},${Math.round(o)}`}function ee(e){return typeof CSS<"u"&&typeof CSS.escape=="function"?CSS.escape(e):e.replace(/([^\w-])/g,"\\$1")}function In(e){return e.filter(t=>/^[A-Za-z_][\w-]*$/.test(t)).slice(0,Mn)}function Ge(e,t=Ue){const n=(e??"").replace(/\s+/g," ").trim();return n.length<=t?n:n.slice(0,t)}function Pn(e){const t=e.parentElement;return t?Array.from(t.children).indexOf(e)+1:1}function $n(e,t){if(!t)return!1;try{return e.querySelectorAll(`#${ee(t)}`).length===1}catch{return!1}}function Ve(e){return{tagName:e.tagName,id:e.id,classes:Array.from(e.classList),nthChild:Pn(e),parent:e.parentElement?Ve(e.parentElement):null}}function Rn(e){const t=e.tagName.toLowerCase();if(t==="html"||t==="body")return t;const n=In(e.classes);let r=t;return n.length&&(r+=n.map(o=>`.${ee(o)}`).join("")),e.nthChild>0&&(r+=`:nth-child(${e.nthChild})`),r}function Bn(e,t,n=Ln){if(e.id&&t(e.id))return`#${ee(e.id)}`;const r=[];let o=e,s=0;for(;o&&s<n;){if(o.id&&t(o.id)){r.unshift(`#${ee(o.id)}`);break}if(r.unshift(Rn(o)),o.tagName.toLowerCase()==="html")break;o=o.parent,s+=1}return r.join(" > ")}function On(e,t){const n=e.getBoundingClientRect(),r=typeof getComputedStyle=="function"?getComputedStyle(e):void 0;return{tag:e.tagName.toLowerCase(),id:e.id,classes:Array.from(e.classList),text:Ge(e.textContent),title:t.document.title??"",url:t.locationHref??(typeof location<"u"?location.href:""),selector:Bn(Ve(e),o=>$n(t.document,o)),rect:{x:n.left,y:n.top,width:n.width,height:n.height},viewport:{width:t.innerWidth,height:t.innerHeight},computed:Tn(r)}}function _n(e,t){const n=e.classes.length?e.classes.join(", "):"(none)";return`\`\`\`markdown
${["## Element","",`- Selector: \`${e.selector}\``,`- Tag: ${e.tag}`,`- Id: ${e.id||"(none)"}`,`- Classes: ${n}`,`- Text: ${e.text||"(none)"}`,`- Title: ${e.title||"(none)"}`,`- URL: ${e.url}`,"- Screenshot: omitted"].join(`
`)}
\`\`\``}function zn(e,t){const n=e.classes.length?e.classes.join(", "):"(none)",{x:r,y:o,width:s,height:a}=e.rect,l=(e.note??"").trim()||"(none)";return[`### ${t}. \`${e.selector}\``,"",`- Tag: ${e.tag}`,`- Id: ${e.id||"(none)"}`,`- Classes: ${n}`,`- Text: ${Ge(e.text,Ue)||"(none)"}`,`- Href: ${e.url}`,`- Rect: ${Math.round(r)}, ${Math.round(o)}, ${Math.round(s)} × ${Math.round(a)}`,`- Color: ${e.computed.color||"(none)"}`,`- Font-size: ${e.computed.fontSize||"(none)"}`,`- Display: ${e.computed.display||"(none)"}`,`- Note: ${l}`].join(`
`)}function Ke(e,t){const n=e.map(a=>"hit"in a?{...a.hit,note:a.note,n:a.n}:a),r=t==="omitted"?"omitted":"PNG of the viewport";return`\`\`\`markdown
${["## Design notes","",...n.map((a,l)=>zn(a,a.n??l+1)),"",`- Screenshot: ${r}`].join(`
`)}
\`\`\``}function qn(e){if(!e||typeof e!="object")return"dev";const t=e.purpose;return t==="qa-crop"||t==="qa-record"||t==="design"?t:"dev"}function Dn(e){return e==="dev"}function Fn(e){return e!=="design"}function Hn(e,t,n){return e==="qa-crop"?{type:"capture.elementPicked",hit:t}:e==="qa-record"?{type:"capture.elementForRecord",hit:t}:{type:"picker.picked",hit:t,keepArmed:e==="design",removed:n==null?void 0:n.removed}}const V="arc-todo-picker-hover",Ze="arc-todo-picker-selected",Qe="arc-todo-design-tray",Je="arc-todo-picker-badge",et=["pointerdown","mousedown","mouseup","auxclick","contextmenu","dblclick"],jn=`
:host {
  all: initial;
  position: fixed;
  z-index: 2147483647;
  font-family: system-ui, sans-serif;
  color-scheme: dark;
  --bg: #1b2230;
  --elev: #252e3d;
  --text: #e8ecf4;
  --muted: #9aa6bc;
  --border: rgba(142, 160, 188, 0.18);
  --accent: #4862ce;
  --on-accent: #f7f8fc;
}
@media (prefers-color-scheme: light) {
  :host {
    color-scheme: light;
    --bg: #fbfcfe;
    --elev: #eef1f6;
    --text: #1b2230;
    --muted: #5a6578;
    --border: rgba(46, 53, 69, 0.16);
    --accent: #3d52b8;
  }
}
*, *::before, *::after { box-sizing: border-box; }
.tray {
  width: min(340px, 44vw);
  max-height: 60vh;
  display: flex;
  flex-direction: column;
  gap: 6px;
  padding: 10px;
  background: var(--bg);
  color: var(--text);
  border: 1px solid var(--border);
  border-radius: 12px;
  box-shadow: 0 12px 40px rgba(0, 0, 0, 0.35);
  font-size: 12.5px;
  line-height: 1.4;
}
.head {
  display: flex;
  align-items: baseline;
  cursor: grab;
  user-select: none;
  touch-action: none;
}
.tray.is-dragging .head { cursor: grabbing; }
.title {
  font-size: 11px;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  color: var(--muted);
}
.empty { margin: 0; color: var(--muted); }
.list {
  list-style: none;
  margin: 0;
  padding: 0;
  overflow-y: auto;
  min-height: 0;
  display: flex;
  flex-direction: column;
  gap: 6px;
}
.pin {
  display: flex;
  flex-direction: column;
  gap: 4px;
  border: 1px solid var(--border);
  border-radius: 8px;
  padding: 6px;
  position: relative;
}
.pin-head { display: flex; align-items: center; gap: 6px; }
.n {
  min-width: 16px;
  height: 16px;
  padding: 0 4px;
  border-radius: 999px;
  background: var(--accent);
  color: var(--on-accent);
  font-size: 11px;
  font-weight: 600;
  line-height: 16px;
  text-align: center;
  flex: none;
}
.label {
  flex: 1;
  min-width: 0;
  font-family: ui-monospace, monospace;
  font-size: 11px;
  color: var(--muted);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.remove {
  border: 0;
  background: transparent;
  color: var(--muted);
  cursor: pointer;
  font-size: 14px;
  line-height: 1;
  padding: 0 2px;
}
.note-label {
  display: flex;
  flex-direction: column;
  gap: 4px;
  color: var(--muted);
  font-size: 11px;
}
textarea {
  width: 100%;
  resize: vertical;
  min-height: 32px;
  font: inherit;
  color: var(--text);
  background: var(--elev);
  border: 1px solid var(--border);
  border-radius: 6px;
  padding: 4px 6px;
}
.mentions {
  position: absolute;
  left: 6px;
  right: 6px;
  z-index: 2;
  margin: 0;
  padding: 4px;
  list-style: none;
  background: var(--elev);
  border: 1px solid var(--border);
  border-radius: 6px;
  max-height: 140px;
  overflow-y: auto;
}
.mentions button {
  display: block;
  width: 100%;
  text-align: left;
  border: 0;
  background: transparent;
  color: var(--text);
  font: inherit;
  padding: 4px 6px;
  cursor: pointer;
  border-radius: 4px;
}
.mentions button:hover { background: var(--accent); color: var(--on-accent); }
.foot { display: flex; flex-wrap: wrap; gap: 6px; }
.foot button {
  border: 1px solid var(--border);
  background: var(--elev);
  color: var(--text);
  border-radius: 8px;
  padding: 5px 10px;
  font: inherit;
  cursor: pointer;
}
.foot button:disabled { opacity: 0.5; cursor: default; }
.foot .primary { background: var(--accent); color: var(--on-accent); border-color: transparent; }
`;let M=!1,S="dev",tt="",nt=0,E=[],d=null,D=null,pe=null,W=null;function rt(){return{position:"fixed",pointerEvents:"none",zIndex:"2147483647",outline:"2px solid #4862ce",outlineOffset:"1px",background:"rgba(72, 98, 206, 0.12)",boxSizing:"border-box",display:"none"}}function te(e,t){e.style.display="block",e.style.left=`${t.left}px`,e.style.top=`${t.top}px`,e.style.width=`${t.width}px`,e.style.height=`${t.height}px`}function ge(e){let t=e.getElementById(V);return t||(t=e.createElement("div"),t.id=V,t.setAttribute("aria-hidden","true"),Object.assign(t.style,rt()),e.documentElement.appendChild(t),t)}function ot(e,t){const n=e.createElement("div");return n.className=Ze,n.id=`arc-todo-picker-selected-${nt}`,nt+=1,n.setAttribute("aria-hidden","true"),Object.assign(n.style,rt(),{display:"block",outline:"2px dashed #4862ce",background:"transparent"}),e.documentElement.appendChild(n),n}function it(e,t,n){const r=e.createElement("span");return r.className=Je,r.setAttribute("aria-hidden","true"),r.textContent=String(t),Object.assign(r.style,{position:"fixed",pointerEvents:"none",zIndex:"2147483647",minWidth:"16px",height:"16px",padding:"0 4px",borderRadius:"999px",background:"#4862ce",color:"#f7f8fc",fontSize:"11px",fontWeight:"600",lineHeight:"16px",textAlign:"center",fontFamily:"system-ui, sans-serif",boxSizing:"border-box"}),fe(r,n),e.documentElement.appendChild(r),r}function fe(e,t){e.style.top=`${t.top-9}px`,e.style.left=`${t.left-9}px`}function Wn(e){return e?e.id===H?!0:!!e.closest(`#${H}`):!1}function Yn(e){return e?e.id===V||e.id===Qe||e.classList.contains(Ze)||e.classList.contains(Je)||Wn(e):!1}function he(e){return!!(d&&e.composedPath().includes(d))}function st(e,t,n){const r=e.elementFromPoint(t,n);return!r||Yn(r)?null:r}function at(e){M&&(he(e)||(e.preventDefault(),e.stopPropagation(),e.stopImmediatePropagation()))}function xe(e,t){const n=ge(e);if(!t){n.style.display="none";return}te(n,t.getBoundingClientRect())}function lt(e){return On(e,{document,innerWidth:window.innerWidth,innerHeight:window.innerHeight,locationHref:location.href})}function be(){return E.map(({n:e,hit:t,note:n})=>({n:e,hit:t,note:n}))}function ne(){var e,t;K();for(const n of E)(e=n.box)==null||e.remove(),(t=n.badge)==null||t.remove(),n.box=null,n.badge=null;d==null||d.remove(),d=null}function ct(){ne(),E=[],W=null}function Un(){for(const e of E){if(!e.el.isConnected)continue;const t=e.el.getBoundingClientRect();e.box||(e.box=ot(document)),te(e.box,t),e.badge?fe(e.badge,t):e.badge=it(document,e.n,t)}dt(),oe(),Y()}function Xn(){var e,t;for(const n of E){if(!n.el.isConnected){(e=n.box)==null||e.remove(),(t=n.badge)==null||t.remove(),n.box=null,n.badge=null;continue}const r=n.el.getBoundingClientRect();n.box&&te(n.box,r),n.badge&&fe(n.badge,r)}}function dt(){if(d!=null&&d.isConnected){d.style.display="",re();return}d=document.createElement("div"),d.id=Qe;const e=d.attachShadow({mode:"open"}),t=document.createElement("style");t.textContent=jn;const n=document.createElement("aside");n.className="tray",n.setAttribute("aria-label",L.designHeading);const r=document.createElement("div");r.className="head",r.setAttribute("role","separator"),r.setAttribute("aria-label",L.overlayDragHint);const o=document.createElement("span");o.className="title",o.textContent=L.designHeading,r.appendChild(o),r.addEventListener("pointerdown",Gn);const s=document.createElement("ul");s.className="list";const a=document.createElement("div");a.className="foot",n.append(r,s,a),e.append(t,n),document.documentElement.appendChild(d),re()}function re(){if(d){if(!D){d.style.right="12px",d.style.bottom="12px",d.style.left="auto",d.style.top="auto";return}d.style.left=`${D.x}px`,d.style.top=`${D.y}px`,d.style.right="auto",d.style.bottom="auto"}}function Gn(e){var l,p;if(e.button!==0||!d)return;const t=e.currentTarget,n=d.getBoundingClientRect(),r=e.clientX-n.left,o=e.clientY-n.top;try{t.setPointerCapture(e.pointerId)}catch{}(p=(l=d.shadowRoot)==null?void 0:l.querySelector(".tray"))==null||p.classList.add("is-dragging");const s=g=>{d&&(D=Ye(g.clientX-r,g.clientY-o,n.width,n.height,window.innerWidth,window.innerHeight),re())},a=()=>{var g,m;(m=(g=d==null?void 0:d.shadowRoot)==null?void 0:g.querySelector(".tray"))==null||m.classList.remove("is-dragging"),t.removeEventListener("pointermove",s),t.removeEventListener("pointerup",a),t.removeEventListener("pointercancel",a)};t.addEventListener("pointermove",s),t.addEventListener("pointerup",a),t.addEventListener("pointercancel",a)}function K(){var e,t;pe=null,(t=(e=d==null?void 0:d.shadowRoot)==null?void 0:e.querySelector(".mentions"))==null||t.remove()}function oe(){var t;const e=(t=d==null?void 0:d.shadowRoot)==null?void 0:t.querySelector(".list");if(e){if(e.replaceChildren(),E.length===0){const n=document.createElement("p");n.className="empty",n.textContent=L.designEmpty,e.appendChild(n);return}for(const n of E)e.appendChild(Vn(n))}}function Vn(e){const t=document.createElement("li");t.className="pin";const n=document.createElement("div");n.className="pin-head";const r=document.createElement("span");r.className="n",r.textContent=String(e.n);const o=document.createElement("span");o.className="label",o.title=e.hit.selector,o.textContent=e.hit.selector;const s=document.createElement("button");s.type="button",s.className="remove",s.setAttribute("aria-label",L.designRemove),s.textContent="×",s.addEventListener("click",()=>{Kn(e.n)}),n.append(r,o,s);const a=document.createElement("label");a.className="note-label",a.append(L.designNote);const l=document.createElement("textarea");return l.rows=2,l.placeholder=L.designNotePlaceholder,l.value=e.note,l.addEventListener("input",()=>{e.note=l.value,ye(e,l)}),l.addEventListener("click",()=>ye(e,l)),l.addEventListener("keyup",p=>{p.key!=="Escape"&&ye(e,l)}),a.appendChild(l),t.append(n,a),t}function ye(e,t){var a,l;const n=t.selectionStart??t.value.length,r=Cn(t.value,n);if(K(),!r)return;const o=Nn(be(),e.n,r.query);if(o.length===0)return;pe={n:e.n,start:r.start,caret:n};const s=document.createElement("ul");s.className="mentions",s.setAttribute("role","listbox");for(const p of o){const g=document.createElement("li"),m=document.createElement("button");m.type="button",m.setAttribute("role","option"),m.textContent=`@${p.n}  ${p.label}`,m.addEventListener("click",()=>{const w=Sn(t.value,r.start,n,p.n);e.note=w.note,t.value=w.note,t.focus(),t.setSelectionRange(w.caret,w.caret),K()}),g.appendChild(m),s.appendChild(g)}(l=(a=t.parentElement)==null?void 0:a.parentElement)==null||l.appendChild(s)}function Y(){var a;const e=(a=d==null?void 0:d.shadowRoot)==null?void 0:a.querySelector(".foot");if(!e)return;e.replaceChildren();const t=E.length>0,n=document.createElement("button");n.type="button",n.textContent=W==="text"?L.copied:L.copy,n.disabled=!t,n.addEventListener("click",()=>void ut(!1));const r=document.createElement("button");r.type="button",r.textContent=W==="png"?L.copied:L.copyWithScreenshot,r.disabled=!t,r.addEventListener("click",()=>void ut(!0));const o=document.createElement("button");o.type="button",o.textContent=L.designClear,o.disabled=!t,o.addEventListener("click",()=>{ct(),dt(),oe(),Y()});const s=document.createElement("button");s.type="button",s.className="primary",s.textContent=L.designExit,s.addEventListener("click",()=>xt()),e.append(n,r,o,s)}function Kn(e){var n,r;const t=E.find(o=>o.n===e);(n=t==null?void 0:t.box)==null||n.remove(),(r=t==null?void 0:t.badge)==null||r.remove(),E=E.filter(o=>o.n!==e),K(),oe(),Y()}function Zn(e,t){if(E.some(s=>s.el===e||Xe(s.hit)===Xe(t)))return;const n=e.getBoundingClientRect(),r=kn(E);E.push({n:r,el:e,hit:t,note:"",box:ot(document),badge:it(document,r,n)});const o=E[E.length-1];o!=null&&o.box&&te(o.box,n),oe(),Y()}async function ut(e){if(E.length!==0){if(W=null,!e){await We(Ke(be(),"omitted")),W="text",Y();return}d&&(d.style.display="none"),xe(document,null),await new Promise(t=>{window.setTimeout(t,50)});try{const t=await y.runtime.sendMessage({type:"picker.screenshot"});if(d&&(d.style.display=""),!t.draftScreenshot)return;await We(Ke(be(),"viewport"),t.draftScreenshot),W="png",Y()}catch{d&&(d.style.display="")}}}function mt(e){if(M){if(he(e)){xe(document,null);return}xe(document,st(document,e.clientX,e.clientY))}}function ie(){if(M&&S==="design"&&(Xn(),D&&d)){const e=d.getBoundingClientRect();D=Ye(D.x,D.y,e.width,e.height,window.innerWidth,window.innerHeight),re()}}async function Qn(){return{error:"idle"}}async function pt(e){if(!M||he(e))return;const t=st(document,e.clientX,e.clientY);if(!t)return;if(e.preventDefault(),e.stopPropagation(),e.stopImmediatePropagation(),S==="design"){Zn(t,lt(t));return}const n=lt(t);if(Dn(S)){const o=_n(n);try{await navigator.clipboard.writeText(o)}catch{}}const r=Hn(S,n);Fn(S)&&se(),y.runtime.sendMessage(r)}function gt(e){if(!(!M||e.key!=="Escape")){if(e.preventDefault(),S==="design"){if(e.stopPropagation(),e.stopImmediatePropagation(),pe){K();return}xt();return}se(),y.runtime.sendMessage({type:"picker.cancelled"})}}function ft(){tt=document.documentElement.style.cursor,document.documentElement.style.cursor="crosshair",ge(document),document.addEventListener("mousemove",mt,!0),document.addEventListener("click",pt,!0),document.addEventListener("keydown",gt,!0);for(const e of et)document.addEventListener(e,at,!0);window.addEventListener("scroll",ie,!0),window.addEventListener("resize",ie)}function ht(){var e;document.documentElement.style.cursor=tt,document.removeEventListener("mousemove",mt,!0),document.removeEventListener("click",pt,!0),document.removeEventListener("keydown",gt,!0);for(const t of et)document.removeEventListener(t,at,!0);window.removeEventListener("scroll",ie,!0),window.removeEventListener("resize",ie),(e=document.getElementById(V))==null||e.remove()}function xt(){se(),y.runtime.sendMessage({type:"design.exited"})}function Jn(e="dev"){if(window===window.top){if(e==="design"){M&&S!=="design"&&(ht(),M=!1),S="design",M||(ft(),M=!0),Un();return}if((S==="design"||E.some(t=>t.box))&&ne(),M){S!==e&&(ge(document).style.display="none"),S=e;return}M=!0,S=e,ft()}}function se(){const e=S==="design"||E.length>0;if(!M&&!document.getElementById(V)&&!d){e&&ne();return}if(M=!1,S="dev",ht(),e){ne();return}ct()}function er(){window===window.top&&y.runtime.onMessage.addListener(e=>{if(!e||typeof e!="object"||!("type"in e))return;const t=e.type;if(t==="picker.arm"&&Jn(qn(e)),t==="picker.disarm"&&se(),t==="capture.stopElementRecord")return Qn()})}const bt=window;function tr(e){return!!(e&&typeof e=="object"&&e.type==="content.ping")}y.runtime.onMessage.addListener(e=>{if(tr(e))return Promise.resolve(!0)}),bt.__arcTodoContentReady||(bt.__arcTodoContentReady=!0,window.addEventListener(Lt,e=>{const t=e.detail;typeof t=="string"&&y.runtime.sendMessage({type:"capture.console",payload:t})}),y.runtime.sendMessage({type:"capture.pageReady"}),er(),Dt(),En(),St())})();
