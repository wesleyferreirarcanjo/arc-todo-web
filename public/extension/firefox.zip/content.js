(function(){"use strict";function Me(e){return e&&e.__esModule&&Object.prototype.hasOwnProperty.call(e,"default")?e.default:e}var H={exports:{}},$e=H.exports,te;function Oe(){return te||(te=1,(function(e,t){(function(r,o){o(e)})(typeof globalThis<"u"?globalThis:typeof self<"u"?self:$e,function(r){if(!(globalThis.chrome&&globalThis.chrome.runtime&&globalThis.chrome.runtime.id))throw new Error("This script should only be loaded in a browser extension.");if(globalThis.browser&&globalThis.browser.runtime&&globalThis.browser.runtime.id)r.exports=globalThis.browser;else{const o="The message port closed before a response was received.",s=l=>{const u={alarms:{clear:{minArgs:0,maxArgs:1},clearAll:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getAll:{minArgs:0,maxArgs:0}},bookmarks:{create:{minArgs:1,maxArgs:1},get:{minArgs:1,maxArgs:1},getChildren:{minArgs:1,maxArgs:1},getRecent:{minArgs:1,maxArgs:1},getSubTree:{minArgs:1,maxArgs:1},getTree:{minArgs:0,maxArgs:0},move:{minArgs:2,maxArgs:2},remove:{minArgs:1,maxArgs:1},removeTree:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1},update:{minArgs:2,maxArgs:2}},browserAction:{disable:{minArgs:0,maxArgs:1,fallbackToNoCallback:!0},enable:{minArgs:0,maxArgs:1,fallbackToNoCallback:!0},getBadgeBackgroundColor:{minArgs:1,maxArgs:1},getBadgeText:{minArgs:1,maxArgs:1},getPopup:{minArgs:1,maxArgs:1},getTitle:{minArgs:1,maxArgs:1},openPopup:{minArgs:0,maxArgs:0},setBadgeBackgroundColor:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setBadgeText:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setIcon:{minArgs:1,maxArgs:1},setPopup:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setTitle:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},browsingData:{remove:{minArgs:2,maxArgs:2},removeCache:{minArgs:1,maxArgs:1},removeCookies:{minArgs:1,maxArgs:1},removeDownloads:{minArgs:1,maxArgs:1},removeFormData:{minArgs:1,maxArgs:1},removeHistory:{minArgs:1,maxArgs:1},removeLocalStorage:{minArgs:1,maxArgs:1},removePasswords:{minArgs:1,maxArgs:1},removePluginData:{minArgs:1,maxArgs:1},settings:{minArgs:0,maxArgs:0}},commands:{getAll:{minArgs:0,maxArgs:0}},contextMenus:{remove:{minArgs:1,maxArgs:1},removeAll:{minArgs:0,maxArgs:0},update:{minArgs:2,maxArgs:2}},cookies:{get:{minArgs:1,maxArgs:1},getAll:{minArgs:1,maxArgs:1},getAllCookieStores:{minArgs:0,maxArgs:0},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}},devtools:{inspectedWindow:{eval:{minArgs:1,maxArgs:2,singleCallbackArg:!1}},panels:{create:{minArgs:3,maxArgs:3,singleCallbackArg:!0},elements:{createSidebarPane:{minArgs:1,maxArgs:1}}}},downloads:{cancel:{minArgs:1,maxArgs:1},download:{minArgs:1,maxArgs:1},erase:{minArgs:1,maxArgs:1},getFileIcon:{minArgs:1,maxArgs:2},open:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},pause:{minArgs:1,maxArgs:1},removeFile:{minArgs:1,maxArgs:1},resume:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1},show:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},extension:{isAllowedFileSchemeAccess:{minArgs:0,maxArgs:0},isAllowedIncognitoAccess:{minArgs:0,maxArgs:0}},history:{addUrl:{minArgs:1,maxArgs:1},deleteAll:{minArgs:0,maxArgs:0},deleteRange:{minArgs:1,maxArgs:1},deleteUrl:{minArgs:1,maxArgs:1},getVisits:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1}},i18n:{detectLanguage:{minArgs:1,maxArgs:1},getAcceptLanguages:{minArgs:0,maxArgs:0}},identity:{launchWebAuthFlow:{minArgs:1,maxArgs:1}},idle:{queryState:{minArgs:1,maxArgs:1}},management:{get:{minArgs:1,maxArgs:1},getAll:{minArgs:0,maxArgs:0},getSelf:{minArgs:0,maxArgs:0},setEnabled:{minArgs:2,maxArgs:2},uninstallSelf:{minArgs:0,maxArgs:1}},notifications:{clear:{minArgs:1,maxArgs:1},create:{minArgs:1,maxArgs:2},getAll:{minArgs:0,maxArgs:0},getPermissionLevel:{minArgs:0,maxArgs:0},update:{minArgs:2,maxArgs:2}},pageAction:{getPopup:{minArgs:1,maxArgs:1},getTitle:{minArgs:1,maxArgs:1},hide:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setIcon:{minArgs:1,maxArgs:1},setPopup:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setTitle:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},show:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},permissions:{contains:{minArgs:1,maxArgs:1},getAll:{minArgs:0,maxArgs:0},remove:{minArgs:1,maxArgs:1},request:{minArgs:1,maxArgs:1}},runtime:{getBackgroundPage:{minArgs:0,maxArgs:0},getPlatformInfo:{minArgs:0,maxArgs:0},openOptionsPage:{minArgs:0,maxArgs:0},requestUpdateCheck:{minArgs:0,maxArgs:0},sendMessage:{minArgs:1,maxArgs:3},sendNativeMessage:{minArgs:2,maxArgs:2},setUninstallURL:{minArgs:1,maxArgs:1}},sessions:{getDevices:{minArgs:0,maxArgs:1},getRecentlyClosed:{minArgs:0,maxArgs:1},restore:{minArgs:0,maxArgs:1}},storage:{local:{clear:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}},managed:{get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1}},sync:{clear:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}}},tabs:{captureVisibleTab:{minArgs:0,maxArgs:2},create:{minArgs:1,maxArgs:1},detectLanguage:{minArgs:0,maxArgs:1},discard:{minArgs:0,maxArgs:1},duplicate:{minArgs:1,maxArgs:1},executeScript:{minArgs:1,maxArgs:2},get:{minArgs:1,maxArgs:1},getCurrent:{minArgs:0,maxArgs:0},getZoom:{minArgs:0,maxArgs:1},getZoomSettings:{minArgs:0,maxArgs:1},goBack:{minArgs:0,maxArgs:1},goForward:{minArgs:0,maxArgs:1},highlight:{minArgs:1,maxArgs:1},insertCSS:{minArgs:1,maxArgs:2},move:{minArgs:2,maxArgs:2},query:{minArgs:1,maxArgs:1},reload:{minArgs:0,maxArgs:2},remove:{minArgs:1,maxArgs:1},removeCSS:{minArgs:1,maxArgs:2},sendMessage:{minArgs:2,maxArgs:3},setZoom:{minArgs:1,maxArgs:2},setZoomSettings:{minArgs:1,maxArgs:2},update:{minArgs:1,maxArgs:2}},topSites:{get:{minArgs:0,maxArgs:0}},webNavigation:{getAllFrames:{minArgs:1,maxArgs:1},getFrame:{minArgs:1,maxArgs:1}},webRequest:{handlerBehaviorChanged:{minArgs:0,maxArgs:0}},windows:{create:{minArgs:0,maxArgs:1},get:{minArgs:1,maxArgs:2},getAll:{minArgs:0,maxArgs:1},getCurrent:{minArgs:0,maxArgs:1},getLastFocused:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},update:{minArgs:2,maxArgs:2}}};if(Object.keys(u).length===0)throw new Error("api-metadata.json has not been included in browser-polyfill");class d extends WeakMap{constructor(a,m=void 0){super(m),this.createItem=a}get(a){return this.has(a)||this.set(a,this.createItem(a)),super.get(a)}}const h=i=>i&&typeof i=="object"&&typeof i.then=="function",k=(i,a)=>(...m)=>{l.runtime.lastError?i.reject(new Error(l.runtime.lastError.message)):a.singleCallbackArg||m.length<=1&&a.singleCallbackArg!==!1?i.resolve(m[0]):i.resolve(m)},p=i=>i==1?"argument":"arguments",I=(i,a)=>function(g,...y){if(y.length<a.minArgs)throw new Error(`Expected at least ${a.minArgs} ${p(a.minArgs)} for ${i}(), got ${y.length}`);if(y.length>a.maxArgs)throw new Error(`Expected at most ${a.maxArgs} ${p(a.maxArgs)} for ${i}(), got ${y.length}`);return new Promise((w,E)=>{if(a.fallbackToNoCallback)try{g[i](...y,k({resolve:w,reject:E},a))}catch(c){console.warn(`${i} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `,c),g[i](...y),a.fallbackToNoCallback=!1,a.noCallback=!0,w()}else a.noCallback?(g[i](...y),w()):g[i](...y,k({resolve:w,reject:E},a))})},R=(i,a,m)=>new Proxy(a,{apply(g,y,w){return m.call(y,i,...w)}});let O=Function.call.bind(Object.prototype.hasOwnProperty);const X=(i,a={},m={})=>{let g=Object.create(null),y={has(E,c){return c in i||c in g},get(E,c,C){if(c in g)return g[c];if(!(c in i))return;let x=i[c];if(typeof x=="function")if(typeof a[c]=="function")x=R(i,i[c],a[c]);else if(O(m,c)){let F=I(c,m[c]);x=R(i,i[c],F)}else x=x.bind(i);else if(typeof x=="object"&&x!==null&&(O(a,c)||O(m,c)))x=X(x,a[c],m[c]);else if(O(m,"*"))x=X(x,a[c],m["*"]);else return Object.defineProperty(g,c,{configurable:!0,enumerable:!0,get(){return i[c]},set(F){i[c]=F}}),x;return g[c]=x,x},set(E,c,C,x){return c in g?g[c]=C:i[c]=C,!0},defineProperty(E,c,C){return Reflect.defineProperty(g,c,C)},deleteProperty(E,c){return Reflect.deleteProperty(g,c)}},w=Object.create(i);return new Proxy(w,y)},Q=i=>({addListener(a,m,...g){a.addListener(i.get(m),...g)},hasListener(a,m){return a.hasListener(i.get(m))},removeListener(a,m){a.removeListener(i.get(m))}}),zt=new d(i=>typeof i!="function"?i:function(m){const g=X(m,{},{getContent:{minArgs:0,maxArgs:0}});i(g)}),Ie=new d(i=>typeof i!="function"?i:function(m,g,y){let w=!1,E,c=new Promise(j=>{E=function(P){w=!0,j(P)}}),C;try{C=i(m,g,E)}catch(j){C=Promise.reject(j)}const x=C!==!0&&h(C);if(C!==!0&&!x&&!w)return!1;const F=j=>{j.then(P=>{y(P)},P=>{let ee;P&&(P instanceof Error||typeof P.message=="string")?ee=P.message:ee="An unexpected error occurred",y({__mozWebExtensionPolyfillReject__:!0,message:ee})}).catch(P=>{console.error("Failed to send onMessage rejected reply",P)})};return F(x?C:c),!0}),jt=({reject:i,resolve:a},m)=>{l.runtime.lastError?l.runtime.lastError.message===o?a():i(new Error(l.runtime.lastError.message)):m&&m.__mozWebExtensionPolyfillReject__?i(new Error(m.message)):a(m)},Pe=(i,a,m,...g)=>{if(g.length<a.minArgs)throw new Error(`Expected at least ${a.minArgs} ${p(a.minArgs)} for ${i}(), got ${g.length}`);if(g.length>a.maxArgs)throw new Error(`Expected at most ${a.maxArgs} ${p(a.maxArgs)} for ${i}(), got ${g.length}`);return new Promise((y,w)=>{const E=jt.bind(null,{resolve:y,reject:w});g.push(E),m.sendMessage(...g)})},Ht={devtools:{network:{onRequestFinished:Q(zt)}},runtime:{onMessage:Q(Ie),onMessageExternal:Q(Ie),sendMessage:Pe.bind(null,"sendMessage",{minArgs:1,maxArgs:3})},tabs:{sendMessage:Pe.bind(null,"sendMessage",{minArgs:2,maxArgs:3})}},J={clear:{minArgs:1,maxArgs:1},get:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}};return u.privacy={network:{"*":J},services:{"*":J},websites:{"*":J}},X(l,Ht,u)};r.exports=s(chrome)}})})(H)),H.exports}var Be=Oe();const v=Me(Be),Re="arc-todo-capture";function Fe(e,t){return t==="panel"||t==="overlay"?t!==e:!0}function _e(e,t,r,o,s=48){const l=s-o.width,u=r.width-s,d=0,h=Math.max(0,r.height-s);return{left:Math.min(u,Math.max(l,e)),top:Math.min(h,Math.max(d,t))}}function ze(e,t,r=16){return{left:Math.max(r,e.width-t.width-r),top:Math.max(r,e.height-t.height-r)}}const B="arc-todo-qa-overlay",je=2147483646,Y="arcTodo.overlayPosition";function He(e){if(!e||typeof e!="object"||Array.isArray(e))return null;const t=e;return typeof t.left!="number"||typeof t.top!="number"||!Number.isFinite(t.left)||!Number.isFinite(t.top)?null:{left:t.left,top:t.top}}const re=60;function De(e){const t=e.replace(/\*\*/g,"").trim(),r=e.match(/^\s*\*\*(.+?)\*\*/);if(r)return{short:r[1].replace(/\*\*/g,"").trim(),full:t,fromBold:!0};const o=t.indexOf(":");return o>0?{short:t.slice(0,o).trim(),full:t,fromBold:!1}:t.length>re?{short:`${t.slice(0,re)}…`,full:t,fromBold:!1}:{short:t,full:t,fromBold:!1}}function ne(e){return e.map(t=>{const r=De(t.label);return{id:t.id,short:r.short,full:r.full,checked:t.checked,bugged:t.bugged,notes:t.notes}})}const qe=`
:host {
  all: initial;
  position: fixed;
  z-index: 2147483646;
  font-family: system-ui, sans-serif;
  color-scheme: dark;
  --bg-surface: #1b2230;
  --bg-elevated: #252e3d;
  --text-primary: #e8ecf4;
  --text-muted: #9aa6bc;
  --border: rgba(142, 160, 188, 0.18);
  --accent: #4862ce;
  --accent-contrast: #f7f8fc;
  --radius: 0.75rem;
  --type-body: 0.8125rem;
  --type-meta: 0.7rem;
  --type-section: 0.9rem;
}

@media (prefers-color-scheme: light) {
  :host {
    color-scheme: light;
    --bg-surface: #fbfcfe;
    --bg-elevated: #eef1f6;
    --text-primary: #1b2230;
    --text-muted: #5a6578;
    --border: rgba(46, 53, 69, 0.16);
    --accent: #3d52b8;
  }
}

*, *::before, *::after { box-sizing: border-box; }

.panel {
  width: min(300px, calc(100vw - 24px));
  max-height: min(70vh, 520px);
  display: flex;
  flex-direction: column;
  background: var(--bg-surface);
  color: var(--text-primary);
  border: 1px solid var(--border);
  border-radius: var(--radius);
  box-shadow: 0 12px 40px rgba(0, 0, 0, 0.35);
  overflow: hidden;
  font-size: var(--type-body);
  line-height: 1.4;
}

.panel.is-collapsed .body { display: none; }

.header {
  display: flex;
  align-items: flex-start;
  gap: 0.5rem;
  padding: 0.55rem 0.65rem;
  background: var(--bg-elevated);
  border-bottom: 1px solid var(--border);
  cursor: grab;
  touch-action: none;
  user-select: none;
}

.header:active { cursor: grabbing; }

.header-text {
  flex: 1;
  min-width: 0;
}

.display-id {
  margin: 0;
  font-size: var(--type-meta);
  color: var(--text-muted);
  font-weight: 600;
}

.title {
  margin: 0.1rem 0 0;
  font-size: var(--type-section);
  font-weight: 700;
  line-height: 1.25;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.header-actions {
  display: flex;
  gap: 0.25rem;
  flex-shrink: 0;
}

.icon-btn {
  appearance: none;
  border: 1px solid var(--border);
  background: transparent;
  color: var(--text-primary);
  border-radius: calc(var(--radius) - 0.25rem);
  width: 1.75rem;
  height: 1.75rem;
  font: inherit;
  font-size: 0.85rem;
  line-height: 1;
  cursor: pointer;
  padding: 0;
}

.icon-btn:hover { background: var(--bg-surface); }

.body {
  overflow: auto;
  padding: 0.5rem;
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

.hint {
  margin: 0;
  font-size: var(--type-meta);
  color: var(--text-muted);
}

.list {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
  gap: 0.375rem;
}

.row {
  border: 1px solid var(--border);
  border-radius: calc(var(--radius) - 0.2rem);
  background: var(--bg-elevated);
  padding: 0.375rem;
}

.row.is-bugged { border-color: rgba(220, 80, 80, 0.45); }

.row-main {
  display: flex;
  gap: 0.35rem;
  align-items: flex-start;
}

.tick {
  appearance: none;
  border: 0;
  background: transparent;
  color: var(--text-primary);
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 0.15rem;
  cursor: pointer;
  padding: 0.15rem;
  font: inherit;
  font-size: var(--type-meta);
  min-width: 2.5rem;
}

.tick-mark {
  width: 1.1rem;
  height: 1.1rem;
  border-radius: 999px;
  border: 2px solid var(--text-muted);
  display: block;
}

.tick.is-checked .tick-mark {
  border-color: var(--accent);
  background: var(--accent);
  box-shadow: inset 0 0 0 2px var(--bg-elevated);
}

.expand {
  appearance: none;
  border: 0;
  background: transparent;
  color: var(--text-primary);
  text-align: left;
  flex: 1;
  min-width: 0;
  cursor: pointer;
  font: inherit;
  padding: 0.15rem 0;
}

.expand strong { font-weight: 650; }

.row-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 0.25rem;
  margin-top: 0.35rem;
}

.btn {
  appearance: none;
  border: 1px solid var(--border);
  background: var(--bg-surface);
  color: var(--text-primary);
  border-radius: calc(var(--radius) - 0.25rem);
  font: inherit;
  font-size: var(--type-meta);
  font-weight: 600;
  padding: 0.3rem 0.5rem;
  cursor: pointer;
}

.btn-primary {
  background: var(--accent);
  border-color: var(--accent);
  color: var(--accent-contrast);
}

.btn:disabled {
  opacity: 0.45;
  cursor: not-allowed;
}

.bug-form {
  display: flex;
  flex-direction: column;
  gap: 0.35rem;
  margin-top: 0.35rem;
}

.bug-form label {
  display: flex;
  flex-direction: column;
  gap: 0.2rem;
  font-size: var(--type-meta);
  color: var(--text-muted);
}

.bug-form textarea {
  resize: vertical;
  min-height: 3.5rem;
  border: 1px solid var(--border);
  border-radius: calc(var(--radius) - 0.25rem);
  background: var(--bg-surface);
  color: var(--text-primary);
  font: inherit;
  padding: 0.35rem;
}

.warning {
  margin: 0;
  font-size: var(--type-meta);
  color: var(--text-muted);
}

.error {
  margin: 0;
  font-size: var(--type-meta);
  color: #e07070;
}

.notes {
  margin: 0.25rem 0 0;
  padding-left: 1rem;
  font-size: var(--type-meta);
  color: var(--text-muted);
}
`,f={itemDone:"Feito",itemOpen:"A fazer",flagAsBug:"Marcar como bug",motivo:"Motivo",motivoPlaceholder:"Descreva o problema encontrado",cancelFlag:"Cancelar",taskBugWarning:"Este card volta para To Do, inclusive as subtarefas.",noChecklist:"Esta tarefa não tem checklist.",collapseOverlay:"Recolher",expandOverlay:"Expandir",closeFloatingChecklist:"Fechar checklist flutuante",overlayDragHint:"Arraste pelo cabeçalho",checklistChanged:"A checklist mudou. Recarregue e tente de novo.",motivoRequired:"O motivo do bug é obrigatório.",itemMotivoRequired:"O motivo do bug do item é obrigatório.",apiError:"Não foi possível falar com a API. Tente de novo.",sessionExpired:"Sessão expirada. Entre de novo no Arc Todo.",signInFirst:"Entre no Arc Todo primeiro"};let A=null,L=null,n=null,N=null;function We(e){return e.status==="expired"?f.sessionExpired:e.status==="not_signed_in"?f.signInFirst:e.error==="stale"?f.checklistChanged:e.error==="motivo"?f.motivoRequired:e.error==="api"||e.status==="error"?f.apiError:null}function Xe(){const e=document.getElementById(B);if(e&&L&&A===e)return{host:e,shadow:L};e==null||e.remove();const t=document.createElement("div");t.id=B,t.setAttribute("aria-hidden","false"),Object.assign(t.style,{position:"fixed",zIndex:String(je),left:"0px",top:"0px"});const r=t.attachShadow({mode:"open"}),o=document.createElement("style");return o.textContent=qe,r.appendChild(o),document.documentElement.appendChild(t),A=t,L=r,{host:t,shadow:r}}async function Ye(){try{const e=await v.storage.local.get(Y);return He(e[Y])}catch{return null}}async function Ue(e,t){try{await v.storage.local.set({[Y]:{left:e,top:t}})}catch{}}function U(e,t){if(!A)return;const r=A.getBoundingClientRect(),o=_e(e,t,{width:window.innerWidth,height:window.innerHeight},{width:r.width||280,height:Math.min(r.height||48,48)});A.style.left=`${o.left}px`,A.style.top=`${o.top}px`}function oe(){if(!A)return;const e=Number.parseFloat(A.style.left||"0"),t=Number.parseFloat(A.style.top||"0");U(e,t)}async function Ge(){if(!A)return;const e=await Ye(),t={width:280,height:320},r=e??ze({width:window.innerWidth,height:window.innerHeight},t);U(r.left,r.top)}function Ve(e){if(!A||e.button!==0)return;const t=e.target;if(t!=null&&t.closest("button"))return;const r=Number.parseFloat(A.style.left||"0"),o=Number.parseFloat(A.style.top||"0");N={pointerId:e.pointerId,startX:e.clientX,startY:e.clientY,originLeft:r,originTop:o},e.currentTarget.setPointerCapture(e.pointerId),e.preventDefault()}function Ke(e){!N||e.pointerId!==N.pointerId||U(N.originLeft+(e.clientX-N.startX),N.originTop+(e.clientY-N.startY))}function se(e){if(!N||e.pointerId!==N.pointerId||!A)return;N=null;const t=Number.parseFloat(A.style.left||"0"),r=Number.parseFloat(A.style.top||"0");Ue(t,r)}function b(){if(!L||!n)return;const e=L.querySelector(".panel");if(!e)return;e.classList.toggle("is-collapsed",n.collapsed);const t=L.querySelector(".title"),r=L.querySelector(".display-id");t&&(t.textContent=n.task.title),r&&(r.textContent=n.task.displayId);const o=L.querySelector('[data-action="collapse"]');o&&(o.setAttribute("aria-label",n.collapsed?f.expandOverlay:f.collapseOverlay),o.textContent=n.collapsed?"▸":"▾");const s=L.querySelector(".body");if(!s)return;if(s.replaceChildren(),n.error){const d=document.createElement("p");d.className="error",d.setAttribute("role","alert"),d.textContent=n.error,s.appendChild(d)}const l=document.createElement("p");l.className="hint",l.textContent=f.overlayDragHint,s.appendChild(l);const u=ne(n.items);if(u.length===0){const d=document.createElement("p");d.className="hint",d.textContent=f.noChecklist,s.appendChild(d)}else{const d=document.createElement("ul");d.className="list";for(const h of u)d.appendChild(Ze(h.id));s.appendChild(d)}if(n.taskBugOpen)s.appendChild(Je());else{const d=document.createElement("button");d.type="button",d.className="btn",d.textContent=f.flagAsBug,d.disabled=n.busy,d.addEventListener("click",()=>{n&&(n.taskBugOpen=!0,n.taskNote="",n.error=null,b())}),s.appendChild(d)}}function Ze(e){const t=n.items.find(p=>p.id===e),r=document.createElement("li");r.className=t.bugged?"row is-bugged":"row";const o=document.createElement("div");o.className="row-main";const s=document.createElement("button");s.type="button",s.className=t.checked?"tick is-checked":"tick",s.setAttribute("aria-pressed",String(t.checked)),s.disabled=n.busy;const l=document.createElement("span");l.className="tick-mark",l.setAttribute("aria-hidden","true");const u=document.createElement("span");u.textContent=t.checked?f.itemDone:f.itemOpen,s.append(l,u),s.addEventListener("click",()=>{et(t.id)});const d=ne([t])[0],h=document.createElement("button");h.type="button",h.className="expand";const k=n.expandedId===t.id;if(h.setAttribute("aria-expanded",String(k)),k)h.textContent=d.full;else{const p=document.createElement("strong");p.textContent=d.short,h.appendChild(p)}if(h.addEventListener("click",()=>{n&&(n.expandedId=n.expandedId===t.id?null:t.id,b())}),o.append(s,h),r.appendChild(o),t.notes.length){const p=document.createElement("ul");p.className="notes";for(const I of t.notes){const R=document.createElement("li");R.innerHTML="";const O=document.createElement("strong");O.textContent=`${f.motivo}: `,R.append(O,document.createTextNode(I)),p.appendChild(R)}r.appendChild(p)}if(n.reportingItemId===t.id)r.appendChild(Qe(t.id));else{const p=document.createElement("div");p.className="row-actions";const I=document.createElement("button");I.type="button",I.className="btn",I.textContent=f.flagAsBug,I.disabled=n.busy,I.addEventListener("click",()=>{n&&(n.reportingItemId=t.id,n.itemNote="",n.error=null,b())}),p.appendChild(I),r.appendChild(p)}return r}function Qe(e){const t=document.createElement("div");t.className="bug-form";const r=document.createElement("label");r.textContent=f.motivo;const o=document.createElement("textarea");o.value=n.itemNote,o.placeholder=f.motivoPlaceholder,o.rows=3,o.addEventListener("input",()=>{n&&(n.itemNote=o.value,l.disabled=n.busy||!n.itemNote.trim())}),r.appendChild(o);const s=document.createElement("div");s.className="row-actions";const l=document.createElement("button");l.type="button",l.className="btn btn-primary",l.textContent=f.flagAsBug,l.disabled=n.busy||!n.itemNote.trim(),l.addEventListener("click",()=>{tt(e)});const u=document.createElement("button");return u.type="button",u.className="btn",u.textContent=f.cancelFlag,u.addEventListener("click",()=>{n&&(n.reportingItemId=null,n.itemNote="",b())}),s.append(l,u),t.append(r,s),t}function Je(){const e=document.createElement("div");e.className="bug-form";const t=document.createElement("p");t.className="warning",t.textContent=f.taskBugWarning;const r=document.createElement("label");r.textContent=f.motivo;const o=document.createElement("textarea");o.value=n.taskNote,o.placeholder=f.motivoPlaceholder,o.rows=3,o.addEventListener("input",()=>{n&&(n.taskNote=o.value,l.disabled=n.busy||!n.taskNote.trim())}),r.appendChild(o);const s=document.createElement("div");s.className="row-actions";const l=document.createElement("button");l.type="button",l.className="btn btn-primary",l.textContent=f.flagAsBug,l.disabled=n.busy||!n.taskNote.trim(),l.addEventListener("click",()=>{rt()});const u=document.createElement("button");return u.type="button",u.className="btn",u.textContent=f.cancelFlag,u.addEventListener("click",()=>{n&&(n.taskBugOpen=!1,n.taskNote="",b())}),s.append(l,u),e.append(t,r,s),e}function D(e){if(!n)return!1;const t=We(e);return t?(n.error=t,!1):(n.error=null,e.items&&(n.items=e.items),e.snapshot&&(n.snapshot=e.snapshot),!0)}async function ie(){if(n){n.busy=!0,b();try{const e=await v.runtime.sendMessage({type:"task.get",task:n.task});D(e)}finally{n&&(n.busy=!1),b()}}}async function et(e){if(!(!n||n.busy)){n.busy=!0,n.error=null,b();try{const t=await v.runtime.sendMessage({type:"checklist.tick",task:n.task,itemId:e,snapshot:n.snapshot,source:"overlay"});D(t)}finally{n&&(n.busy=!1),b()}}}async function tt(e){if(!(!n||n.busy)){if(!n.itemNote.trim()){n.error=f.itemMotivoRequired,b();return}n.busy=!0,n.error=null,b();try{const t=await v.runtime.sendMessage({type:"checklist.flagItem",task:n.task,itemId:e,note:n.itemNote,snapshot:n.snapshot,source:"overlay"});D(t)&&(n.reportingItemId=null,n.itemNote="")}finally{n&&(n.busy=!1),b()}}}async function rt(){if(!(!n||n.busy)){if(!n.taskNote.trim()){n.error=f.motivoRequired,b();return}n.busy=!0,n.error=null,b();try{const e=await v.runtime.sendMessage({type:"task.flag",task:n.task,note:n.taskNote,source:"overlay"});D(e)&&(n.taskBugOpen=!1,n.taskNote="")}finally{n&&(n.busy=!1),b()}}}function nt(){const{shadow:e}=Xe();if(e.querySelector(".panel"))return;const r=document.createElement("div");r.className="panel",r.setAttribute("role","dialog"),r.setAttribute("aria-label","Checklist");const o=document.createElement("div");o.className="header",o.addEventListener("pointerdown",Ve),o.addEventListener("pointermove",Ke),o.addEventListener("pointerup",se),o.addEventListener("pointercancel",se);const s=document.createElement("div");s.className="header-text";const l=document.createElement("p");l.className="display-id";const u=document.createElement("h2");u.className="title",s.append(l,u);const d=document.createElement("div");d.className="header-actions";const h=document.createElement("button");h.type="button",h.className="icon-btn",h.dataset.action="collapse",h.addEventListener("click",()=>{n&&(n.collapsed=!n.collapsed,b())});const k=document.createElement("button");k.type="button",k.className="icon-btn",k.setAttribute("aria-label",f.closeFloatingChecklist),k.textContent="×",k.addEventListener("click",()=>{ae()}),d.append(h,k),o.append(s,d);const p=document.createElement("div");p.className="body",r.append(o,p),e.appendChild(r),window.addEventListener("resize",oe)}function ot(e){window===window.top&&(nt(),n={task:e,items:[],snapshot:{items:[]},expandedId:null,reportingItemId:null,itemNote:"",taskBugOpen:!1,taskNote:"",collapsed:!1,busy:!1,error:null},A&&(A.style.display="block"),b(),Ge().then(()=>{ie()}))}function ae(){N=null,n=null,window.removeEventListener("resize",oe),A==null||A.remove(),A=null,L=null}function st(){window===window.top&&v.runtime.onMessage.addListener(e=>{if(!e||typeof e!="object"||!("type"in e))return;const t=e.type;if(t==="overlay.open"){const r=e.task;r!=null&&r.id&&ot(r)}if(t==="overlay.close"&&ae(),t==="qa.checklistChanged"){if(!n||e.taskId!==n.task.id||!Fe("overlay",e.source))return;ie()}})}const it=".task-card[data-task-id], .task-list-row[data-task-id]",_="arc-todo-card-highlight";function at(e){return e.length===0?null:[...e].reverse().find(r=>!r.className.split(/\s+/).includes("is-subtask"))??e[0]}function lt(e){var u,d,h,k,p;const t=(u=e.taskId)==null?void 0:u.trim(),r=(d=e.displayId)==null?void 0:d.trim(),o=(h=e.organizationId)==null?void 0:h.trim(),s=(k=e.projectId)==null?void 0:k.trim(),l=((p=e.taskTitle)==null?void 0:p.trim())||r;return!t||!r||!l||!o||!s?null:{id:t,displayId:r,title:l,organizationId:o,projectId:s}}let $=!1,le="";function ce(e){let t=e.getElementById(_);return t||(t=e.createElement("div"),t.id=_,t.setAttribute("aria-hidden","true"),Object.assign(t.style,{position:"fixed",pointerEvents:"none",zIndex:"2147483647",outline:"2px solid #4862ce",outlineOffset:"2px",background:"rgba(72, 98, 206, 0.14)",borderRadius:"18px",boxSizing:"border-box",display:"none"}),e.documentElement.appendChild(t),t)}function ct(e){const t=[];let r=e;for(;r;){const o=r.closest(it);if(!(o instanceof HTMLElement))break;t.push(o),r=o.parentElement}return t}function de(e,t,r){const o=e.elementFromPoint(t,r);return!o||o.id===_||o.id===B||o.closest(`#${B}`)?null:at(ct(o))}function dt(e,t){const r=ce(e);if(!t){r.style.display="none";return}const o=t.getBoundingClientRect();r.style.display="block",r.style.left=`${o.left}px`,r.style.top=`${o.top}px`,r.style.width=`${o.width}px`,r.style.height=`${o.height}px`}function me(e){$&&dt(document,de(document,e.clientX,e.clientY))}function ue(e){if(!$)return;const t=de(document,e.clientX,e.clientY);if(!t)return;const r=lt({taskId:t.dataset.taskId,displayId:t.dataset.displayId,taskTitle:t.dataset.taskTitle,organizationId:t.dataset.organizationId,projectId:t.dataset.projectId});r&&(e.preventDefault(),e.stopPropagation(),e.stopImmediatePropagation(),G(),v.runtime.sendMessage({type:"card.picked",task:r}))}function ge(e){!$||e.key!=="Escape"||(e.preventDefault(),G(),v.runtime.sendMessage({type:"card.cancelled"}))}function mt(){window===window.top&&($||($=!0,le=document.documentElement.style.cursor,document.documentElement.style.cursor="pointer",ce(document),document.addEventListener("mousemove",me,!0),document.addEventListener("click",ue,!0),document.addEventListener("keydown",ge,!0)))}function G(){var e;!$&&!document.getElementById(_)||($=!1,document.documentElement.style.cursor=le,document.removeEventListener("mousemove",me,!0),document.removeEventListener("click",ue,!0),document.removeEventListener("keydown",ge,!0),(e=document.getElementById(_))==null||e.remove())}function ut(){window===window.top&&v.runtime.onMessage.addListener(e=>{if(!e||typeof e!="object"||!("type"in e))return;const t=e.type;t==="card.arm"&&mt(),t==="card.disarm"&&G()})}const gt=6,ft=200,pt=3;function At(e){return{color:(e==null?void 0:e.color)??"",fontSize:(e==null?void 0:e.fontSize)??"",display:(e==null?void 0:e.display)??""}}function fe(e){const{x:t,y:r,width:o,height:s}=e.rect;return`${e.selector}@${Math.round(t)},${Math.round(r)},${Math.round(o)},${Math.round(s)}`}function q(e){return typeof CSS<"u"&&typeof CSS.escape=="function"?CSS.escape(e):e.replace(/([^\w-])/g,"\\$1")}function ht(e){return e.filter(t=>/^[A-Za-z_][\w-]*$/.test(t)).slice(0,pt)}function xt(e,t=ft){const r=(e??"").replace(/\s+/g," ").trim();return r.length<=t?r:r.slice(0,t)}function bt(e){const t=e.parentElement;return t?Array.from(t.children).indexOf(e)+1:1}function yt(e,t){if(!t)return!1;try{return e.querySelectorAll(`#${q(t)}`).length===1}catch{return!1}}function pe(e){return{tagName:e.tagName,id:e.id,classes:Array.from(e.classList),nthChild:bt(e),parent:e.parentElement?pe(e.parentElement):null}}function vt(e){const t=e.tagName.toLowerCase();if(t==="html"||t==="body")return t;const r=ht(e.classes);let o=t;return r.length&&(o+=r.map(s=>`.${q(s)}`).join("")),e.nthChild>0&&(o+=`:nth-child(${e.nthChild})`),o}function kt(e,t,r=gt){if(e.id&&t(e.id))return`#${q(e.id)}`;const o=[];let s=e,l=0;for(;s&&l<r;){if(s.id&&t(s.id)){o.unshift(`#${q(s.id)}`);break}if(o.unshift(vt(s)),s.tagName.toLowerCase()==="html")break;s=s.parent,l+=1}return o.join(" > ")}function wt(e,t){const r=e.getBoundingClientRect(),o=typeof getComputedStyle=="function"?getComputedStyle(e):void 0;return{tag:e.tagName.toLowerCase(),id:e.id,classes:Array.from(e.classList),text:xt(e.textContent),title:t.document.title??"",url:t.locationHref??(typeof location<"u"?location.href:""),selector:kt(pe(e),s=>yt(t.document,s)),rect:{x:r.left,y:r.top,width:r.width,height:r.height},viewport:{width:t.innerWidth,height:t.innerHeight},computed:At(o)}}function Et(e,t){const r=e.classes.length?e.classes.join(", "):"(none)";return`\`\`\`markdown
${["## Element","",`- Selector: \`${e.selector}\``,`- Tag: ${e.tag}`,`- Id: ${e.id||"(none)"}`,`- Classes: ${r}`,`- Text: ${e.text||"(none)"}`,`- Title: ${e.title||"(none)"}`,`- URL: ${e.url}`,"- Screenshot: omitted"].join(`
`)}
\`\`\``}function Ct(e){if(!e||typeof e!="object")return"dev";const t=e.purpose;return t==="qa-crop"||t==="design"?t:"dev"}function Nt(e){return e==="dev"}function Tt(e){return e!=="design"}function Lt(e,t,r){return e==="qa-crop"?{type:"capture.elementPicked",hit:t}:{type:"picker.picked",hit:t,keepArmed:e==="design",removed:r==null?void 0:r.removed}}const z="arc-todo-picker-hover",Ae="arc-todo-picker-selected",he=["pointerdown","mousedown","mouseup","auxclick","contextmenu","dblclick"];let M=!1,S="dev",xe="",be=0;const T=new Map;function ye(){return{position:"fixed",pointerEvents:"none",zIndex:"2147483647",outline:"2px solid #4862ce",outlineOffset:"1px",background:"rgba(72, 98, 206, 0.12)",boxSizing:"border-box",display:"none"}}function V(e,t){e.style.display="block",e.style.left=`${t.left}px`,e.style.top=`${t.top}px`,e.style.width=`${t.width}px`,e.style.height=`${t.height}px`}function K(e){let t=e.getElementById(z);return t||(t=e.createElement("div"),t.id=z,t.setAttribute("aria-hidden","true"),Object.assign(t.style,ye()),e.documentElement.appendChild(t),t)}function St(e){const t=e.createElement("div");return t.className=Ae,t.id=`arc-todo-picker-selected-${be}`,be+=1,t.setAttribute("aria-hidden","true"),Object.assign(t.style,ye(),{display:"block"}),e.documentElement.appendChild(t),t}function It(e){return e?e.id===B?!0:!!e.closest(`#${B}`):!1}function Pt(e){return e?e.id===z||e.classList.contains(Ae)||It(e):!1}function ve(e,t,r){const o=e.elementFromPoint(t,r);return!o||Pt(o)?null:o}function ke(e){M&&(e.preventDefault(),e.stopPropagation(),e.stopImmediatePropagation())}function Mt(e,t){const r=K(e);if(!t){r.style.display="none";return}V(r,t.getBoundingClientRect())}function we(e){return wt(e,{document,innerWidth:window.innerWidth,innerHeight:window.innerHeight,locationHref:location.href})}function $t(e){if(T.has(e))return e;for(const t of T.keys())if(fe(T.get(t).hit)===fe(we(e)))return t;return null}function Ot(e,t){const r=St(document);V(r,e.getBoundingClientRect()),T.set(e,{hit:t,box:r})}function Ee(e){const t=T.get(e);return t==null||t.box.remove(),T.delete(e),t==null?void 0:t.hit}function Ce(){for(const e of T.values())e.box.remove();T.clear()}function Bt(){for(const[e,t]of T){if(!e.isConnected){Ee(e);continue}V(t.box,e.getBoundingClientRect())}}function Ne(e){M&&Mt(document,ve(document,e.clientX,e.clientY))}function W(){!M||S!=="design"||Bt()}async function Te(e){if(!M)return;const t=ve(document,e.clientX,e.clientY);if(!t)return;e.preventDefault(),e.stopPropagation(),e.stopImmediatePropagation();const r=$t(t),o=S==="design"&&(!!r||e.shiftKey),s=o&&r?T.get(r).hit:we(t);if(S==="design")if(o&&r)Ee(r);else if(!o)Ot(t,s);else return;if(Nt(S)){const u=Et(s);try{await navigator.clipboard.writeText(u)}catch{}}const l=Lt(S,s,{removed:o});Tt(S)&&Z(),v.runtime.sendMessage(l)}function Le(e){!M||e.key!=="Escape"||(e.preventDefault(),Z(),v.runtime.sendMessage({type:"picker.cancelled"}))}function Rt(e="dev"){if(window===window.top){if(M){S!==e&&(Ce(),K(document).style.display="none"),S=e;return}M=!0,S=e,xe=document.documentElement.style.cursor,document.documentElement.style.cursor="crosshair",K(document),document.addEventListener("mousemove",Ne,!0),document.addEventListener("click",Te,!0),document.addEventListener("keydown",Le,!0);for(const t of he)document.addEventListener(t,ke,!0);window.addEventListener("scroll",W,!0),window.addEventListener("resize",W)}}function Z(){var e;if(!(!M&&!document.getElementById(z)&&T.size===0)){M=!1,S="dev",document.documentElement.style.cursor=xe,document.removeEventListener("mousemove",Ne,!0),document.removeEventListener("click",Te,!0),document.removeEventListener("keydown",Le,!0);for(const t of he)document.removeEventListener(t,ke,!0);window.removeEventListener("scroll",W,!0),window.removeEventListener("resize",W),(e=document.getElementById(z))==null||e.remove(),Ce()}}function Ft(){window===window.top&&v.runtime.onMessage.addListener(e=>{if(!e||typeof e!="object"||!("type"in e))return;const t=e.type;t==="picker.arm"&&Rt(Ct(e)),t==="picker.disarm"&&Z()})}const Se=window;function _t(e){return!!(e&&typeof e=="object"&&e.type==="content.ping")}v.runtime.onMessage.addListener(e=>{if(_t(e))return Promise.resolve(!0)}),Se.__arcTodoContentReady||(Se.__arcTodoContentReady=!0,window.addEventListener(Re,e=>{const t=e.detail;typeof t=="string"&&v.runtime.sendMessage({type:"capture.console",payload:t})}),v.runtime.sendMessage({type:"capture.pageReady"}),Ft(),ut(),st())})();
