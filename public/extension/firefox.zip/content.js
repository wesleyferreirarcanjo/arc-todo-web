(function(){"use strict";function qr(e){return e&&e.__esModule&&Object.prototype.hasOwnProperty.call(e,"default")?e.default:e}var ze={exports:{}},Hr=ze.exports,Vt;function Vr(){return Vt||(Vt=1,(function(e,t){(function(n,r){r(e)})(typeof globalThis<"u"?globalThis:typeof self<"u"?self:Hr,function(n){if(!(globalThis.chrome&&globalThis.chrome.runtime&&globalThis.chrome.runtime.id))throw new Error("This script should only be loaded in a browser extension.");if(globalThis.browser&&globalThis.browser.runtime&&globalThis.browser.runtime.id)n.exports=globalThis.browser;else{const r="The message port closed before a response was received.",o=i=>{const a={alarms:{clear:{minArgs:0,maxArgs:1},clearAll:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getAll:{minArgs:0,maxArgs:0}},bookmarks:{create:{minArgs:1,maxArgs:1},get:{minArgs:1,maxArgs:1},getChildren:{minArgs:1,maxArgs:1},getRecent:{minArgs:1,maxArgs:1},getSubTree:{minArgs:1,maxArgs:1},getTree:{minArgs:0,maxArgs:0},move:{minArgs:2,maxArgs:2},remove:{minArgs:1,maxArgs:1},removeTree:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1},update:{minArgs:2,maxArgs:2}},browserAction:{disable:{minArgs:0,maxArgs:1,fallbackToNoCallback:!0},enable:{minArgs:0,maxArgs:1,fallbackToNoCallback:!0},getBadgeBackgroundColor:{minArgs:1,maxArgs:1},getBadgeText:{minArgs:1,maxArgs:1},getPopup:{minArgs:1,maxArgs:1},getTitle:{minArgs:1,maxArgs:1},openPopup:{minArgs:0,maxArgs:0},setBadgeBackgroundColor:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setBadgeText:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setIcon:{minArgs:1,maxArgs:1},setPopup:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setTitle:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},browsingData:{remove:{minArgs:2,maxArgs:2},removeCache:{minArgs:1,maxArgs:1},removeCookies:{minArgs:1,maxArgs:1},removeDownloads:{minArgs:1,maxArgs:1},removeFormData:{minArgs:1,maxArgs:1},removeHistory:{minArgs:1,maxArgs:1},removeLocalStorage:{minArgs:1,maxArgs:1},removePasswords:{minArgs:1,maxArgs:1},removePluginData:{minArgs:1,maxArgs:1},settings:{minArgs:0,maxArgs:0}},commands:{getAll:{minArgs:0,maxArgs:0}},contextMenus:{remove:{minArgs:1,maxArgs:1},removeAll:{minArgs:0,maxArgs:0},update:{minArgs:2,maxArgs:2}},cookies:{get:{minArgs:1,maxArgs:1},getAll:{minArgs:1,maxArgs:1},getAllCookieStores:{minArgs:0,maxArgs:0},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}},devtools:{inspectedWindow:{eval:{minArgs:1,maxArgs:2,singleCallbackArg:!1}},panels:{create:{minArgs:3,maxArgs:3,singleCallbackArg:!0},elements:{createSidebarPane:{minArgs:1,maxArgs:1}}}},downloads:{cancel:{minArgs:1,maxArgs:1},download:{minArgs:1,maxArgs:1},erase:{minArgs:1,maxArgs:1},getFileIcon:{minArgs:1,maxArgs:2},open:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},pause:{minArgs:1,maxArgs:1},removeFile:{minArgs:1,maxArgs:1},resume:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1},show:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},extension:{isAllowedFileSchemeAccess:{minArgs:0,maxArgs:0},isAllowedIncognitoAccess:{minArgs:0,maxArgs:0}},history:{addUrl:{minArgs:1,maxArgs:1},deleteAll:{minArgs:0,maxArgs:0},deleteRange:{minArgs:1,maxArgs:1},deleteUrl:{minArgs:1,maxArgs:1},getVisits:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1}},i18n:{detectLanguage:{minArgs:1,maxArgs:1},getAcceptLanguages:{minArgs:0,maxArgs:0}},identity:{launchWebAuthFlow:{minArgs:1,maxArgs:1}},idle:{queryState:{minArgs:1,maxArgs:1}},management:{get:{minArgs:1,maxArgs:1},getAll:{minArgs:0,maxArgs:0},getSelf:{minArgs:0,maxArgs:0},setEnabled:{minArgs:2,maxArgs:2},uninstallSelf:{minArgs:0,maxArgs:1}},notifications:{clear:{minArgs:1,maxArgs:1},create:{minArgs:1,maxArgs:2},getAll:{minArgs:0,maxArgs:0},getPermissionLevel:{minArgs:0,maxArgs:0},update:{minArgs:2,maxArgs:2}},pageAction:{getPopup:{minArgs:1,maxArgs:1},getTitle:{minArgs:1,maxArgs:1},hide:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setIcon:{minArgs:1,maxArgs:1},setPopup:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setTitle:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},show:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},permissions:{contains:{minArgs:1,maxArgs:1},getAll:{minArgs:0,maxArgs:0},remove:{minArgs:1,maxArgs:1},request:{minArgs:1,maxArgs:1}},runtime:{getBackgroundPage:{minArgs:0,maxArgs:0},getPlatformInfo:{minArgs:0,maxArgs:0},openOptionsPage:{minArgs:0,maxArgs:0},requestUpdateCheck:{minArgs:0,maxArgs:0},sendMessage:{minArgs:1,maxArgs:3},sendNativeMessage:{minArgs:2,maxArgs:2},setUninstallURL:{minArgs:1,maxArgs:1}},sessions:{getDevices:{minArgs:0,maxArgs:1},getRecentlyClosed:{minArgs:0,maxArgs:1},restore:{minArgs:0,maxArgs:1}},storage:{local:{clear:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}},managed:{get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1}},sync:{clear:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}}},tabs:{captureVisibleTab:{minArgs:0,maxArgs:2},create:{minArgs:1,maxArgs:1},detectLanguage:{minArgs:0,maxArgs:1},discard:{minArgs:0,maxArgs:1},duplicate:{minArgs:1,maxArgs:1},executeScript:{minArgs:1,maxArgs:2},get:{minArgs:1,maxArgs:1},getCurrent:{minArgs:0,maxArgs:0},getZoom:{minArgs:0,maxArgs:1},getZoomSettings:{minArgs:0,maxArgs:1},goBack:{minArgs:0,maxArgs:1},goForward:{minArgs:0,maxArgs:1},highlight:{minArgs:1,maxArgs:1},insertCSS:{minArgs:1,maxArgs:2},move:{minArgs:2,maxArgs:2},query:{minArgs:1,maxArgs:1},reload:{minArgs:0,maxArgs:2},remove:{minArgs:1,maxArgs:1},removeCSS:{minArgs:1,maxArgs:2},sendMessage:{minArgs:2,maxArgs:3},setZoom:{minArgs:1,maxArgs:2},setZoomSettings:{minArgs:1,maxArgs:2},update:{minArgs:1,maxArgs:2}},topSites:{get:{minArgs:0,maxArgs:0}},webNavigation:{getAllFrames:{minArgs:1,maxArgs:1},getFrame:{minArgs:1,maxArgs:1}},webRequest:{handlerBehaviorChanged:{minArgs:0,maxArgs:0}},windows:{create:{minArgs:0,maxArgs:1},get:{minArgs:1,maxArgs:2},getAll:{minArgs:0,maxArgs:1},getCurrent:{minArgs:0,maxArgs:1},getLastFocused:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},update:{minArgs:2,maxArgs:2}}};if(Object.keys(a).length===0)throw new Error("api-metadata.json has not been included in browser-polyfill");class s extends WeakMap{constructor(y,m=void 0){super(m),this.createItem=y}get(y){return this.has(y)||this.set(y,this.createItem(y)),super.get(y)}}const l=b=>b&&typeof b=="object"&&typeof b.then=="function",d=(b,y)=>(...m)=>{i.runtime.lastError?b.reject(new Error(i.runtime.lastError.message)):y.singleCallbackArg||m.length<=1&&y.singleCallbackArg!==!1?b.resolve(m[0]):b.resolve(m)},u=b=>b==1?"argument":"arguments",p=(b,y)=>function(v,...w){if(w.length<y.minArgs)throw new Error(`Expected at least ${y.minArgs} ${u(y.minArgs)} for ${b}(), got ${w.length}`);if(w.length>y.maxArgs)throw new Error(`Expected at most ${y.maxArgs} ${u(y.maxArgs)} for ${b}(), got ${w.length}`);return new Promise((A,E)=>{if(y.fallbackToNoCallback)try{v[b](...w,d({resolve:A,reject:E},y))}catch(x){console.warn(`${b} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `,x),v[b](...w),y.fallbackToNoCallback=!1,y.noCallback=!0,A()}else y.noCallback?(v[b](...w),A()):v[b](...w,d({resolve:A,reject:E},y))})},h=(b,y,m)=>new Proxy(y,{apply(v,w,A){return m.call(w,b,...A)}});let k=Function.call.bind(Object.prototype.hasOwnProperty);const B=(b,y={},m={})=>{let v=Object.create(null),w={has(E,x){return x in b||x in v},get(E,x,P){if(x in v)return v[x];if(!(x in b))return;let $=b[x];if(typeof $=="function")if(typeof y[x]=="function")$=h(b,b[x],y[x]);else if(k(m,x)){let ee=p(x,m[x]);$=h(b,b[x],ee)}else $=$.bind(b);else if(typeof $=="object"&&$!==null&&(k(y,x)||k(m,x)))$=B($,y[x],m[x]);else if(k(m,"*"))$=B($,y[x],m["*"]);else return Object.defineProperty(v,x,{configurable:!0,enumerable:!0,get(){return b[x]},set(ee){b[x]=ee}}),$;return v[x]=$,$},set(E,x,P,$){return x in v?v[x]=P:b[x]=P,!0},defineProperty(E,x,P){return Reflect.defineProperty(v,x,P)},deleteProperty(E,x){return Reflect.deleteProperty(v,x)}},A=Object.create(b);return new Proxy(A,w)},V=b=>({addListener(y,m,...v){y.addListener(b.get(m),...v)},hasListener(y,m){return y.hasListener(b.get(m))},removeListener(y,m){y.removeListener(b.get(m))}}),te=new s(b=>typeof b!="function"?b:function(m){const v=B(m,{},{getContent:{minArgs:0,maxArgs:0}});b(v)}),J=new s(b=>typeof b!="function"?b:function(m,v,w){let A=!1,E,x=new Promise(xe=>{E=function(G){A=!0,xe(G)}}),P;try{P=b(m,v,E)}catch(xe){P=Promise.reject(xe)}const $=P!==!0&&l(P);if(P!==!0&&!$&&!A)return!1;const ee=xe=>{xe.then(G=>{w(G)},G=>{let Be;G&&(G instanceof Error||typeof G.message=="string")?Be=G.message:Be="An unexpected error occurred",w({__mozWebExtensionPolyfillReject__:!0,message:Be})}).catch(G=>{console.error("Failed to send onMessage rejected reply",G)})};return ee($?P:x),!0}),U=({reject:b,resolve:y},m)=>{i.runtime.lastError?i.runtime.lastError.message===r?y():b(new Error(i.runtime.lastError.message)):m&&m.__mozWebExtensionPolyfillReject__?b(new Error(m.message)):y(m)},ve=(b,y,m,...v)=>{if(v.length<y.minArgs)throw new Error(`Expected at least ${y.minArgs} ${u(y.minArgs)} for ${b}(), got ${v.length}`);if(v.length>y.maxArgs)throw new Error(`Expected at most ${y.maxArgs} ${u(y.maxArgs)} for ${b}(), got ${v.length}`);return new Promise((w,A)=>{const E=U.bind(null,{resolve:w,reject:A});v.push(E),m.sendMessage(...v)})},F={devtools:{network:{onRequestFinished:V(te)}},runtime:{onMessage:V(J),onMessageExternal:V(J),sendMessage:ve.bind(null,"sendMessage",{minArgs:1,maxArgs:3})},tabs:{sendMessage:ve.bind(null,"sendMessage",{minArgs:2,maxArgs:3})}},K={clear:{minArgs:1,maxArgs:1},get:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}};return a.privacy={network:{"*":K},services:{"*":K},websites:{"*":K}},B(i,F,a)};n.exports=o(chrome)}})})(ze)),ze.exports}var Wr=Vr();const L=qr(Wr),f={appName:"Arc Todo",modeToggleLabel:"Modo do painel",modeQa:"Modo QA",modeDev:"Modo desenvolvedor",modeDesign:"Modo design",modeSettings:"Settings",skipToContent:"Pular para o conteúdo",designHeading:"Notas de design",designPick:"Escolher elementos",designNote:"O que deve mudar",designNotePlaceholder:"Descreva o que a IA deve alterar neste elemento",designEmpty:"Toque nos elementos da página para comentar.",designRemove:"Remover",designExit:"Sair",designClear:"Limpar",designCopyEmpty:"Escolha um elemento para copiar.",designCaptureFailed:"Não foi possível capturar a imagem.",designLiveCss:"CSS ao vivo",designCssInvalid:"Este CSS não pôde ser aplicado. Corrija o texto e tente de novo.",designRemoveCss:"Remover CSS",designCopyLive:"Copiar ao vivo",designPasteCss:"Colar CSS",designCopyLiveEmpty:"Escolha um elemento ou escreva o CSS ao vivo para copiar.",designPasteCssFailed:"Não foi possível colar o CSS. Cole com Ctrl+V no campo.",designPasteCssEmpty:"A área de transferência não tem CSS.",designPasteCssInvalid:"O CSS da área de transferência não é válido. A lista foi mantida.",designCssMaster:"Ativar pré-visualização",designCssItemsLabel:"Itens de CSS",designCssEmpty:"Nenhum CSS nesta página. Cole um trecho para começar.",designCssItemToggle:"Ativar item",designCssSaveFailed:"Não foi possível salvar o CSS. Tente de novo.",designViewportTitle:"Tamanho da página",designViewportOriginal:"Tamanho original",designViewportCustom:"Personalizado",designViewportPreset:"Tamanho predefinido",designViewportWidth:"Largura",designViewportHeight:"Altura",designViewportApply:"Aplicar tamanho",designViewportRestore:"Restaurar tamanho",designViewportPending:"Aplicando tamanho…",designViewportMeasured:"Medido",designViewportMismatch:"O tamanho medido não corresponde ao solicitado.",designViewportInvalid:"Use números inteiros de 1 a 10.000.000 para largura e altura.",designViewportFailed:"Não foi possível aplicar o tamanho. O último tamanho válido continua ativo.",designViewportUnsupported:"A prévia de tamanho só funciona no Chrome e no Edge. No Firefox, o restante do Modo design continua disponível.",designViewportPresetPhone:"Celular",designViewportPresetTablet:"Tablet",designViewportPresetBoardCompact:"Quadro compacto",designViewportPresetBoardDesktop:"Quadro desktop",designViewportPresetWide:"Tela ampla",designPreviewToggle:"Pré-visualizar",designPreviewCopies:"Cópias extras",designPreviewLabel:"Texto do rótulo",designPreviewLabelPlaceholder:"Texto alternativo…",designPreviewReset:"Redefinir prévia",designPreviewInvalidCount:"Use um número inteiro de 0 a 20.",designPreviewNoText:"Selecione um elemento com um único texto para pré-visualizar o rótulo.",designPreviewAmbiguousText:"Este elemento tem mais de um texto. Selecione um rótulo de texto.",designPreviewUnavailableElement:"Não foi possível aplicar a prévia neste elemento.",designPreviewDegraded:"Alguns trechos não puderam ser copiados com segurança.",designPreviewUnavailable:"Prévia indisponível",designStateHeading:"Estados",designStateNormal:"Normal",designStateHover:"Hover",designStateFocus:"Foco",designStateActive:"Pressionado",designStateChecked:"Marcado",designStateDisabled:"Desativado",designStatePickExample:"Usar exemplo da página…",designStatePickHint:"Clique em um elemento da página que mostre o estado desejado.",designStateNoMarkers:"Este exemplo não tem classe ou atributo de estado aproveitável.",designStateUnsupported:"Este navegador não consegue forçar estados do elemento.",designStateFailed:"Não foi possível aplicar o estado. Tente de novo.",designStateStale:"O elemento mudou na página. Selecione-o de novo.",designStateIncompatible:"Este elemento não tem esse estado nativo.",designStateNoDiff:"Este marcador não altera a aparência do elemento.",designStatePartial:"A prévia pode estar incompleta.",designStateLost:"O navegador encerrou a prévia de estado.",signInFirst:"Entre no Arc Todo para usar este painel.",sessionExpired:"Sessão expirada. Entre de novo no Arc Todo.",apiError:"Não foi possível falar com a API. Tente de novo.",loading:"Carregando…",openArcTodo:"Abrir Arc Todo e entrar",retry:"Tentar de novo",qaQueue:"Fila de QA",viewToggleLabel:"Como ver a fila",viewCards:"Cards",viewChecklist:"Checklist",emptyQueue:"Nenhum card na fila de QA. Adicione pais da lista abaixo.",addAllParents:"Adicionar todos os pais",removeFromQueue:"Remover",switchQaProject:"Trocar o projeto de QA",switchQaProjectConfirm:"Trocar de projeto",switchQaProjectHint:"Sua fila de QA já tem cards de outro projeto. Confirme a troca para substituir esse lote, ou mantenha a fila atual.",queueAlreadyQueued:"Esse card já está na sua fila de QA.",projectLabel:"Projeto",projectHint:"Sigla ou nome",statusLabel:"Status",assigneeLabel:"Responsável",startSession:"Iniciar sessão de teste",stopSession:"Encerrar sessão de teste",discardSession:"Descartar sessão",captureRegion:"Capturar região",captureElement:"Capturar elemento",freeArea:"Área livre",sessionBadge:"Sessão",captureHeading:"Captura",capturedErrors:"erros capturados",emptyCapture:"Nenhum erro capturado ainda.",captureWindow:"Janela",captureWindow30s:"Últimos 30 s",captureWindow60s:"Últimos 60 s",captureWindow2m:"Últimos 2 min",captureWindowSession:"Sessão inteira",frozenHint:"Sessão encerrada. Os eventos ficam congelados até você descartar.",needWebPage:"Abra uma página web para capturar.",pageBlocked:"Esta página do navegador não permite seleção de elementos. Abra uma página normal.",needQueue:"Capture só com um card na fila de QA.",needSelectedTask:"Escolha um card da fila de QA para marcar o bug.",captureFailed:"Não foi possível capturar a região.",annotateRect:"Retângulo",annotateArrow:"Seta",annotateFreehand:"Traço",saveCapture:"Guardar",discardCapture:"Descartar captura",cancelCrop:"Cancelar",openInArcTodo:"Abrir no Arc Todo",reloadChecklist:"Recarregar",flagAsBug:"Marcar como bug",motivo:"Motivo",motivoPlaceholder:"Descreva o problema encontrado",motivoRequired:"O motivo do bug é obrigatório.",itemMotivoRequired:"O motivo do bug do item é obrigatório.",taskBugWarning:"Este card volta para To Do, inclusive as subtarefas.",checklistChanged:"A checklist mudou. Recarregue e tente de novo.",noChecklist:"Esta tarefa não tem checklist.",logsUnavailable:"Não foi possível guardar o log da sessão. O bug foi marcado, mas o log não chegou ao card.",evidenceFailed:"Não foi possível enviar a captura. O bug foi marcado mesmo assim.",cancelFlag:"Cancelar",pickElement:"Escolher elemento",pickerEmpty:"Escolha um elemento da página para copiar os detalhes.",copy:"Copiar",copied:"Copiado",copyWithScreenshot:"Copiar com captura",copyImage:"Copiar imagem",copyBusy:"Copiando…",itemDone:"Feito",itemOpen:"A fazer",startRecord:"Gravar tela",recordElement:"Gravar elemento",recordElementHint:"A gravação fica só no elemento escolhido. O Chrome pede para compartilhar esta aba.",stopRecord:"Parar gravação",recordingLabel:"Gravando",recordWarning:"Fechar o painel perde a gravação",recordFailed:"Não foi possível gravar a tela.",recordUploadFailed:"Não foi possível enviar o clipe.",recordUploaded:"Clipe enviado.",copyForAi:"Copiar para IA",openEnvironment:"Abrir ambiente",openFloatingChecklist:"Abrir checklist flutuante",closeFloatingChecklist:"Fechar checklist flutuante",collapseOverlay:"Recolher",expandOverlay:"Expandir",overlayDragHint:"Arraste pelo cabeçalho",overlayLoading:"Carregando a checklist…",retestHeading:"Retestar",lastMotivo:"Último Motivo",previousEvidence:"Evidências anteriores",previousLogs:"Logs anteriores",noPreviousEvidence:"Sem evidências anteriores.",backToQueue:"Voltar para a fila",focusedStepEyebrow:"Passo em foco",instructionsHeading:"Instruções",checklistHeading:"Checklist",attachEvidence:"Anexar evidência",evidenceAttached:"Evidência anexada.",attachFailed:"Não foi possível anexar a evidência.",evidenceGoesHere:"Capturas e clipes deste passo anexam neste item.",composeHeading:"Nota e evidências",composeNote:"Nota",composePlaceholder:"Escreva o que aconteceu",composeSend:"Enviar",composeSending:"Enviando…",composeEdit:"Editar",composeRemove:"Remover",composeWillAttachBug:"Estas evidências vão juntas no próximo Marcar como bug.",composeWillFlag:"Enviar anexa neste passo e marca como bug.",composeToTask:"Foco neste card.",needFocusedItem:"Foque um passo da checklist para capturar ou gravar.",solveBug:"Marcar como resolvido",solveItem:"Resolvido",focusTask:"Focar neste card",focusItem:"Focar neste passo",updateAvailable:"Nova versão disponível",updateHint:"Escolha a pasta descompactada que você carregou no navegador. Da próxima vez, um clique basta.",updateFirefoxHint:"Baixe o zip e carregue de novo em about:debugging. A extensão temporária some ao fechar o Firefox.",updateAction:"Atualizar",updateDownload:"Baixar zip",updateDismiss:"Agora não",updateBusy:"Atualizando…",updateFailed:"Não foi possível atualizar. Baixe o zip e carregue de novo.",updateWrongFolder:"Essa pasta não é a extensão Arc Todo. Escolha a pasta descompactada com manifest.json.",agentHeading:"Agente do navegador",agentEnable:"Permitir que esta Chrome seja operada",agentEnabled:"Modo agente ligado",agentConsent:"Quando uma IA pedir para operar",agentConsentOff:"Desligado",agentConsentAlways:"Sempre",agentConsentAsk:"Perguntar",agentAskPrompt:"Permitir esta ferramenta de IA?",agentAllow:"Permitir",agentDeny:"Recusar",agentStop:"Parar",agentConnected:"Conectado ao Arc Browser.",agentDisconnected:"Desconectado.",agentNeedSignIn:"Entre no Arc Todo primeiro para registrar este navegador.",agentSessionLive:"Sessão ao vivo"},Wt="arc-todo-agent-overlay",jt="arc-todo-agent-cursor",Ut="arc-todo-agent-stop";function et(){return document.getElementById(Wt)}function jr(e,t){var o;let n=et();if(!n){n=document.createElement("div"),n.id=Wt,n.setAttribute("data-arc-todo-agent","1");const i=n.attachShadow({mode:"open"}),a=document.createElement("style");a.textContent=`
      :host {
        all: initial;
        --text-primary: #e8ecf4;
        --accent: #3d52b8;
        --accent-contrast: #f7f8fc;
        --z-overlay: 2147483646;
      }
      .wrap {
        position: fixed; inset: 0; pointer-events: none;
        z-index: var(--z-overlay);
      }
      .cursor {
        position: absolute; width: 22px; height: 22px; margin: -2px 0 0 -2px;
        filter: drop-shadow(0 0 6px var(--glow));
      }
      .cursor-path { fill: var(--text-primary); stroke: var(--accent); }
      .stop {
        pointer-events: auto; position: fixed; top: 12px; right: 12px;
        font: 600 12px system-ui, sans-serif; color: var(--accent-contrast);
        background: var(--accent); border: 0; border-radius: 6px;
        padding: 6px 10px;
        box-shadow: 0 0 16px var(--glow); cursor: pointer;
      }
      @media (prefers-reduced-motion: no-preference) {
        .cursor { transition: transform 80ms linear; }
      }
    `;const s=document.createElement("div");s.className="wrap";const l=document.createElement("div");l.id=jt,l.className="cursor",l.setAttribute("aria-hidden","true"),l.innerHTML='<svg viewBox="0 0 24 24" width="22" height="22" xmlns="http://www.w3.org/2000/svg"><path class="cursor-path" d="M4 2l16 12-7 1 4 8-4 1-4-8-5 4z" stroke-width="1.2"/></svg>';const d=document.createElement("button");d.id=Ut,d.className="stop",d.type="button",d.textContent=f.agentStop,s.append(l,d),i.append(a,s),document.documentElement.append(n),d.addEventListener("click",()=>{L.runtime.sendMessage({type:"agent.stop"})})}n.style.setProperty("--glow",e);const r=(o=n.shadowRoot)==null?void 0:o.getElementById(Ut);return r&&r.setAttribute("title",`Arc AI · ${t}`),n}function Ur(e){var r,o;if(e.type==="agent.overlay.hide"){(r=et())==null||r.remove();return}if(e.type==="agent.overlay.show"){jr(e.color,e.clientName);return}const t=et(),n=(o=t==null?void 0:t.shadowRoot)==null?void 0:o.getElementById(jt);n&&(n.style.transform=`translate(${e.x}px, ${e.y}px)`)}function Kr(){L.runtime.onMessage.addListener(e=>{if(!e||typeof e!="object")return;const t=e.type;if(t==="agent.overlay.show"||t==="agent.overlay.hide"||t==="agent.overlay.move")return Ur(e),Promise.resolve(!0)})}const Yr="arc-todo-capture",ue="arc-todo-qa-overlay",Gr=2147483645,tt="arcTodo.overlayPosition",nt="arcTodo.overlaySections";function Kt(e,t,n,r,o,i){const a=Math.max(0,Math.min(e,n)),s=Math.max(0,Math.min(t,r)),l=Math.min(o,Math.max(e,n)),d=Math.min(i,Math.max(t,r)),u=l-a,p=d-s;return u<4||p<4?null:{x:a,y:s,width:u,height:p}}function Yt(e,t,n){return t.width===0||t.height===0?{x:0,y:0}:{x:e.x/t.width*n.width,y:e.y/t.height*n.height}}function Xr(e,t,n){const r=Yt({x:e.x,y:e.y},t,n),o=Yt({x:e.x+e.width,y:e.y+e.height},t,n);return Kt(r.x,r.y,o.x,o.y,n.width,n.height)}function Qr(e,t,n,r,o){const i=Kt(e,t,n,r,o.width,o.height);return i?{rect:i,viewport:o}:null}const Pe="arc-todo-region-overlay",Ie="arc-todo-region-marquee",Gt="2147483646",Zr="rgba(0, 0, 0, 0.35)",Jr="#ffffff";function Xt(e){e.style.setProperty("--arc-region-scrim",Zr),e.style.setProperty("--arc-region-line",Jr)}const Qt=["pointerdown","mousedown","mouseup","auxclick","contextmenu","dblclick"];let ne=!1,Zt="",ae=null;function eo(){return{position:"fixed",inset:"0",zIndex:Gt,cursor:"crosshair",background:"var(--arc-region-scrim)",boxSizing:"border-box"}}function to(){return{position:"fixed",pointerEvents:"none",zIndex:Gt,outline:"2px solid var(--arc-region-line)",outlineOffset:"0",boxShadow:"0 0 0 99999px var(--arc-region-scrim)",boxSizing:"border-box",display:"none",background:"transparent"}}function no(e){let t=e.getElementById(Pe);return t||(t=e.createElement("div"),t.id=Pe,t.setAttribute("aria-hidden","true"),Xt(t),Object.assign(t.style,eo()),e.documentElement.appendChild(t),t)}function Jt(e){let t=e.getElementById(Ie);return t||(t=e.createElement("div"),t.id=Ie,t.setAttribute("aria-hidden","true"),Xt(t),Object.assign(t.style,to()),e.documentElement.appendChild(t),t)}function ro(e){return e?e.id===ue?!0:!!e.closest(`#${ue}`):!1}function oo(e,t,n){const r=e.getElementById(Pe),o=e.getElementById(Ie);r&&(r.style.pointerEvents="none"),o&&(o.style.pointerEvents="none");const i=e.elementFromPoint(t,n);return r&&(r.style.pointerEvents="auto"),i}function en(e){ne&&(e.preventDefault(),e.stopPropagation(),e.stopImmediatePropagation())}function io(e,t,n,r){const o=Math.min(e,n),i=Math.min(t,r),a=Jt(document);a.style.display="block",a.style.left=`${o}px`,a.style.top=`${i}px`,a.style.width=`${Math.abs(n-e)}px`,a.style.height=`${Math.abs(r-t)}px`}function tn(){const e=document.getElementById(Ie);e&&(e.style.display="none")}function ao(){return{width:window.innerWidth,height:window.innerHeight}}function nn(e){if(!ne||e.button!==0)return;const t=oo(document,e.clientX,e.clientY);ro(t)||(ae={x:e.clientX,y:e.clientY},tn())}function rn(e){!ne||!ae||io(ae.x,ae.y,e.clientX,e.clientY)}function on(e){if(!ne||!ae)return;const t=ae;ae=null;const n=Qr(t.x,t.y,e.clientX,e.clientY,ao());tn(),n&&(L.runtime.sendMessage({type:"region.picked",rect:n.rect,viewport:n.viewport,devicePixelRatio:window.devicePixelRatio}),rt())}function an(e){!ne||e.key!=="Escape"||(e.preventDefault(),rt(),L.runtime.sendMessage({type:"region.cancelled"}))}function so(){if(window===window.top&&!ne){ne=!0,Zt=document.documentElement.style.cursor,document.documentElement.style.cursor="crosshair",no(document),Jt(document),document.addEventListener("pointerdown",nn,!0),document.addEventListener("pointermove",rn,!0),document.addEventListener("pointerup",on,!0),document.addEventListener("keydown",an,!0);for(const e of Qt)document.addEventListener(e,en,!0)}}function rt(){var e,t;if(!(!ne&&!document.getElementById(Pe))){ne=!1,ae=null,document.documentElement.style.cursor=Zt,document.removeEventListener("pointerdown",nn,!0),document.removeEventListener("pointermove",rn,!0),document.removeEventListener("pointerup",on,!0),document.removeEventListener("keydown",an,!0);for(const n of Qt)document.removeEventListener(n,en,!0);(e=document.getElementById(Pe))==null||e.remove(),(t=document.getElementById(Ie))==null||t.remove()}}function co(){window===window.top&&L.runtime.onMessage.addListener(e=>{if(!e||typeof e!="object"||!("type"in e))return;const t=e.type;t==="region.arm"&&so(),t==="region.disarm"&&rt()})}function lo(e){var t;return((t=e.find(n=>!n.checked))==null?void 0:t.id)??null}function uo(e,t){var o;const n=e.findIndex(i=>i.id===t);return((o=(n>=0?e.slice(n+1):e).find(i=>!i.checked))==null?void 0:o.id)??lo(e)}function mo(e,t){if(t&&e.some(n=>n.id===t))return t}function po(e,t){return t==="panel"||t==="overlay"?t!==e:!0}function fo(e,t,n,r,o=48){const i=o-r.width,a=n.width-o,s=0,l=Math.max(0,n.height-o);return{left:Math.min(a,Math.max(i,e)),top:Math.min(l,Math.max(s,t))}}function go(e,t,n=16){return{left:Math.max(n,e.width-t.width-n),top:Math.max(n,e.height-t.height-n)}}const sn=/(\*\*[^*]+\*\*|\*[^*]+\*|`[^`]+`|\[[^\]]+\]\(https?:\/\/[^)\s]+\)|https?:\/\/[^\s<>"'`]+)/g;function ho(e){const t=[];let n=0;sn.lastIndex=0;let r;for(;r=sn.exec(e);){r.index>n&&t.push({type:"text",text:e.slice(n,r.index)});const o=r[0];if(o.startsWith("**"))t.push({type:"strong",text:o.slice(2,-2)});else if(o.startsWith("*"))t.push({type:"em",text:o.slice(1,-1)});else if(o.startsWith("`"))t.push({type:"code",text:o.slice(1,-1)});else if(o.startsWith("[")){const i=o.match(/^\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)$/);i&&t.push({type:"a",text:i[1],href:i[2]})}else{const i=o.replace(/[),.;:!?]+$/,""),a=o.slice(i.length);i&&t.push({type:"a",text:i,href:i}),a&&t.push({type:"text",text:a})}n=r.index+o.length}return n<e.length&&t.push({type:"text",text:e.slice(n)}),t.length>0?t:[{type:"text",text:e}]}function bo(e,t){const n=t.join(`
`).trim();n&&e.push({type:"p",text:n})}function vo(e){return`h${Math.min(e.length,4)}`}function xo(e){const t=[];let n=[],r=[],o=[],i=null;function a(){r.length!==0&&(t.push({type:"ul",items:r}),r=[])}function s(){o.length!==0&&(t.push({type:"ol",items:o}),o=[])}function l(){const u=n;n=[],bo(t,u)}function d(){a(),s()}for(const u of e.split(`
`)){if(i){u.startsWith("```")?(t.push({type:"pre",text:i.join(`
`)}),i=null):i.push(u);continue}if(u.startsWith("```")){d(),l(),i=[];continue}if(/^(-{3,}|\*{3,}|_{3,})\s*$/.test(u.trim())){d(),l(),t.push({type:"hr"});continue}const p=u.match(/^>\s?(.*)$/);if(p){d(),l();const V=t[t.length-1];(V==null?void 0:V.type)==="blockquote"?V.text=`${V.text}
${p[1]}`:t.push({type:"blockquote",text:p[1]});continue}const h=u.match(/^(#{1,4})\s+(.*)$/),k=u.match(/^[-*]\s+(.*)$/),B=u.match(/^\d+\.\s+(.*)$/);if(h){d(),l(),t.push({type:vo(h[1]),text:h[2]});continue}if(k){s(),l(),r.push(k[1]);continue}if(B){a(),l(),o.push(B[1]);continue}if(!u.trim()){d(),l();continue}d(),n.push(u)}return i&&t.push({type:"pre",text:i.join(`
`)}),d(),l(),t}function ot(e,t){for(const n of ho(t)){if(n.type==="text"){e.appendChild(document.createTextNode(n.text));continue}if(n.type==="a"){const o=document.createElement("a");o.href=n.href,o.target="_blank",o.rel="noopener noreferrer",o.textContent=n.text,e.appendChild(o);continue}const r=document.createElement(n.type==="strong"?"strong":n.type==="em"?"em":"code");r.textContent=n.text,e.appendChild(r)}}function yo(e,t){for(const n of xo(t)){if(n.type==="ul"||n.type==="ol"){const o=document.createElement(n.type);for(const i of n.items){const a=document.createElement("li");ot(a,i),o.appendChild(a)}e.appendChild(o);continue}if(n.type==="pre"){const o=document.createElement("pre"),i=document.createElement("code");i.textContent=n.text,o.appendChild(i),e.appendChild(o);continue}if(n.type==="hr"){e.appendChild(document.createElement("hr"));continue}if(n.type==="blockquote"){const o=document.createElement("blockquote");ot(o,n.text),e.appendChild(o);continue}const r=document.createElement(n.type);ot(r,n.text),e.appendChild(r)}}function wo(e){if(!e||typeof e!="object"||Array.isArray(e))return null;const t=e;return typeof t.left!="number"||typeof t.top!="number"||!Number.isFinite(t.left)||!Number.isFinite(t.top)?null:{left:t.left,top:t.top}}const cn=60;function Ao(e){const t=e.replace(/\*\*/g,"").trim(),n=e.match(/^\s*\*\*(.+?)\*\*/);if(n)return{short:n[1].replace(/\*\*/g,"").trim(),full:t,fromBold:!0};const r=t.indexOf(":");return r>0?{short:t.slice(0,r).trim(),full:t,fromBold:!1}:t.length>cn?{short:`${t.slice(0,cn)}…`,full:t,fromBold:!1}:{short:t,full:t,fromBold:!1}}function ln(e){return e.map(t=>{const n=Ao(t.label);return{id:t.id,short:n.short,full:n.full,checked:t.checked,bugged:t.bugged,notes:t.notes}})}const De={instructionsCollapsed:!1,checklistCollapsed:!1};function Co(e){if(!e||typeof e!="object"||Array.isArray(e))return null;const t=e;return typeof t.instructionsCollapsed!="boolean"||typeof t.checklistCollapsed!="boolean"?null:{instructionsCollapsed:t.instructionsCollapsed,checklistCollapsed:t.checklistCollapsed}}const dn=':root,[data-theme=dark]{--font-display: "Newsreader", Georgia, serif;--font-body: "Figtree", system-ui, sans-serif;--type-page: 1.75rem;--type-kpi: 2.25rem;--type-section: 1.05rem;--type-card: 1rem;--type-body: .875rem;--type-meta: .75rem;font-family:var(--font-body);line-height:1.5;font-weight:400;--bg-page: #0d1119;--bg-shell: #131924;--bg-surface: #1b2230;--bg-elevated: #252e3d;--text-primary: #e8ecf4;--text-muted: #9aa6bc;--text: var(--text-primary);--text-secondary: var(--text-muted);--border: rgba(142, 160, 188, .18);--border-strong: rgba(142, 160, 188, .34);--border-subtle: var(--border);--accent: #4862ce;--accent-secondary: #6846b8;--accent-tertiary: #4a5d9c;--accent-contrast: #f7f8fc;--danger-bg: #342027;--danger-text: #e38a90;--danger: var(--danger-text);--info-bg: #142a34;--info-text: #7fc8dd;--success-bg: #173027;--success-text: #7fc19b;--warning-bg: #33291a;--warning-text: #d5aa63;--smart-copy: #f5a524;--bug-badge: #f13a48;--bug-resolved-badge: #129b56;--color-success: var(--success-text);--color-danger: var(--danger-text);--link: #8cb4ff;--surface-muted: color-mix(in srgb, var(--bg-elevated) 78%, var(--bg-page));--entity-rail-width: 6px;--entity-mix-fill: 14%;--entity-mix-badge: 26%;--entity-mix-header: 22%;--entity-corner-opacity: .28;--entity-rail-card-width: 3px;--entity-rail-card-mix: 80%;--entity-corner-glow-mix: 40%;--entity-rail-glow-out-mix: 34%;--entity-rail-glow-in-mix: 14%;--shadow: rgba(6, 10, 18, .48);--shadow-soft: 0 4px 18px rgba(6, 10, 18, .36);--shadow-card: 0 8px 28px rgba(6, 10, 18, .4), 0 0 0 1px rgba(142, 160, 188, .1);--shadow-neon: var(--shadow-card);--shadow-lift: 0 12px 32px rgba(6, 10, 18, .46);--ring: rgba(140, 180, 255, .42);--ring-strong: rgba(104, 70, 184, .38);--drop-glow: 0 0 0 2px rgba(140, 180, 255, .24);--gradient-page: radial-gradient(ellipse 70% 42% at 12% -8%, rgba(72, 98, 206, .08), transparent 55%), radial-gradient(ellipse 50% 36% at 92% 8%, rgba(104, 70, 184, .07), transparent 52%);--gradient-accent: linear-gradient(135deg, #4862ce 0%, #6846b8 100%);--gradient-header: linear-gradient(90deg, rgba(72, 98, 206, .24), rgba(104, 70, 184, .14));--radius-sm: 10px;--radius-md: 16px;--radius-lg: 22px;--radius-xl: 28px;--radius-blob: 28px 8px 28px 8px;--radius-blob-alt: 8px 28px 8px 28px;--radius-control: 16px 6px 16px 6px;--radius-control-alt: 6px 16px 6px 16px;--radius-pill: 999px;--button-height: 2.65rem;--button-height-sm: 2.15rem;--sidebar-expanded-width: 260px;--sidebar-collapsed-width: 72px;--sidebar-width: var(--sidebar-collapsed-width);--board-column-min-width: 280px;--transition-fast: .15s ease;--transition-base: .22s ease;--icon-nav: 1.25rem;--icon-duotone-fill: .22;--z-banner: 40;--z-fab: 41;--z-toast: 80;--z-modal: 900;--z-chat: 950;--criticity-low-bg: rgba(154, 166, 188, .16);--criticity-low-text: #9aa6bc;--criticity-medium-bg: rgba(213, 170, 99, .16);--criticity-medium-text: #d5aa63;--criticity-high-bg: rgba(104, 70, 184, .18);--criticity-high-text: #c4b4ee;--criticity-critical-bg: rgba(227, 138, 144, .16);--criticity-critical-text: #e38a90;color:var(--text-primary);background:var(--bg-page)}[data-theme=light]{--bg-page: #e6eaf2;--bg-shell: #f3f5f9;--bg-surface: #fbfcfe;--bg-elevated: #eef1f6;--text-primary: #1b2230;--text-muted: #5a6578;--text: var(--text-primary);--border: rgba(46, 53, 69, .16);--border-strong: rgba(46, 53, 69, .28);--border-subtle: var(--border);--accent: #3d52b8;--accent-secondary: #5a3ea8;--accent-tertiary: #4a5d9c;--accent-contrast: #f7f8fc;--danger-bg: rgba(180, 83, 90, .12);--danger-text: #b4535a;--danger: var(--danger-text);--info-bg: rgba(42, 122, 144, .12);--info-text: #2a7a90;--success-bg: rgba(47, 122, 88, .12);--success-text: #2f7a58;--warning-bg: rgba(138, 106, 40, .12);--warning-text: #8a6a28;--smart-copy: #c47d0a;--bug-badge: #e11d32;--bug-resolved-badge: #0d8a4b;--color-success: var(--success-text);--color-danger: var(--danger-text);--link: #3d52b8;--surface-muted: color-mix(in srgb, var(--bg-elevated) 70%, var(--bg-page));--shadow: rgba(27, 34, 48, .12);--shadow-soft: 0 4px 16px rgba(27, 34, 48, .08);--shadow-card: 0 8px 24px rgba(27, 34, 48, .1), 0 0 0 1px rgba(46, 53, 69, .1);--shadow-neon: var(--shadow-card);--shadow-lift: 0 12px 28px rgba(27, 34, 48, .12);--ring: rgba(61, 82, 184, .38);--ring-strong: rgba(90, 62, 168, .32);--drop-glow: 0 0 0 2px rgba(61, 82, 184, .2);--gradient-page: radial-gradient(ellipse 70% 42% at 12% -8%, rgba(61, 82, 184, .06), transparent 55%), radial-gradient(ellipse 50% 36% at 92% 8%, rgba(90, 62, 168, .05), transparent 52%);--gradient-accent: linear-gradient(135deg, #3d52b8 0%, #5a3ea8 100%);--gradient-header: linear-gradient(90deg, rgba(61, 82, 184, .16), rgba(90, 62, 168, .1));--criticity-low-bg: rgba(90, 101, 120, .14);--criticity-low-text: #5a6578;--criticity-medium-bg: rgba(138, 106, 40, .14);--criticity-medium-text: #8a6a28;--criticity-high-bg: rgba(90, 62, 168, .12);--criticity-high-text: #5a3ea8;--criticity-critical-bg: rgba(180, 83, 90, .12);--criticity-critical-text: #b4535a}*{box-sizing:border-box}body{margin:0;min-height:100vh;background:var(--bg-page);color:var(--text-primary)}h1,h2,h3,h4,p{margin:0}button,input,select,textarea{font:inherit}button:focus-visible,a:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible{outline:2px solid var(--ring);outline-offset:2px}',un=dn.replace(/:root/g,":host").replace(/\[data-theme(=[^\]]+)\]/g,":host([data-theme$1])"),Eo=`
:host {
  all: initial;
  position: fixed;
  z-index: 2147483645;
}

${un}

:host {
  color-scheme: dark;
  background: transparent;
}
:host([data-theme='light']) {
  color-scheme: light;
}

*, *::before, *::after { box-sizing: border-box; }

.panel {
  width: min(420px, calc(100vw - 24px));
  max-height: min(70vh, 520px);
  display: flex;
  flex-direction: column;
  background: var(--bg-surface);
  color: var(--text-primary);
  border: 1px solid var(--border);
  border-radius: var(--radius-md);
  box-shadow: var(--shadow-lift);
  overflow: hidden;
  font-size: var(--type-body);
  line-height: 1.4;
}

.panel.is-collapsed .body { display: none; }
.panel:focus-visible { outline: 2px solid var(--ring); outline-offset: 2px; }

.header {
  display: flex;
  align-items: flex-start;
  gap: 0.5rem;
  padding: 0.55rem 0.65rem;
  background: var(--bg-elevated);
  border-bottom: 1px solid var(--border);
  cursor: grab;
  touch-action: none;
  user-select: none;
}

.header:active { cursor: grabbing; }

.header-text {
  flex: 1;
  min-width: 0;
}

.display-id {
  margin: 0;
  font-size: var(--type-meta);
  color: var(--text-muted);
  font-weight: 600;
}

.title {
  margin: 0.1rem 0 0;
  font-size: var(--type-section);
  font-weight: 700;
  line-height: 1.25;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.header-actions {
  display: flex;
  gap: 0.25rem;
  flex-shrink: 0;
}

.icon-btn {
  appearance: none;
  border: 1px solid var(--border);
  background: transparent;
  color: var(--text-primary);
  border-radius: var(--radius-sm);
  min-width: 1.75rem;
  min-height: 1.75rem;
  font: inherit;
  font-size: var(--type-body);
  line-height: 1;
  cursor: pointer;
  padding: 0;
}

@media (hover: hover) and (pointer: fine) {
  .icon-btn:hover { background: var(--bg-surface); }
}

@media (pointer: coarse) {
  .icon-btn { min-width: 2.75rem; min-height: 2.75rem; }
}

.body {
  overflow: auto;
  padding: 0.5rem;
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

.hint {
  margin: 0;
  font-size: var(--type-meta);
  color: var(--text-muted);
}

.list {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
  gap: 0.375rem;
}

.row {
  border: 1px solid var(--border);
  border-radius: var(--radius-sm);
  background: var(--bg-elevated);
  padding: 0.375rem;
}

.row.is-bugged { border-color: var(--danger); }
.row.is-current {
  border-color: var(--accent);
  box-shadow: inset 0.2rem 0 0 var(--accent);
}

.row-main {
  display: flex;
  gap: 0.35rem;
  align-items: center;
}

.tick {
  appearance: none;
  border: 0;
  background: transparent;
  color: var(--text-primary);
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  padding: 0.1rem;
  font: inherit;
  min-width: 1.5rem;
  min-height: 1.5rem;
}

.tick-mark {
  width: 1.1rem;
  height: 1.1rem;
  border-radius: 999px;
  border: 2px solid var(--text-muted);
  display: flex;
  align-items: center;
  justify-content: center;
}

.tick.is-checked .tick-mark {
  border-color: var(--accent);
  background: var(--accent);
}

.tick.is-checked .tick-mark::after {
  content: '✓';
  color: var(--accent-contrast);
  font-size: var(--type-meta);
  font-weight: 700;
  line-height: 1;
}

.expand {
  appearance: none;
  border: 0;
  background: transparent;
  color: var(--text-primary);
  text-align: left;
  flex: 1;
  min-width: 0;
  cursor: pointer;
  font: inherit;
  padding: 0.15rem 0;
}

.expand strong { font-weight: 650; }

.row-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 0.25rem;
  margin-top: 0.35rem;
}

.btn {
  appearance: none;
  border: 1px solid var(--border);
  background: var(--bg-surface);
  color: var(--text-primary);
  border-radius: var(--radius-control);
  font: inherit;
  font-size: var(--type-meta);
  font-weight: 600;
  min-height: 1.5rem;
  padding: 0.3rem 0.5rem;
  cursor: pointer;
}

.btn-primary {
  background: var(--accent);
  border-color: var(--accent);
  color: var(--accent-contrast);
}

.btn:disabled {
  opacity: 0.45;
  cursor: not-allowed;
}

.bug-form {
  display: flex;
  flex-direction: column;
  gap: 0.35rem;
  margin-top: 0.35rem;
}

.bug-form label {
  display: flex;
  flex-direction: column;
  gap: 0.2rem;
  font-size: var(--type-meta);
  color: var(--text-muted);
}

.bug-form textarea {
  resize: vertical;
  min-height: 3.5rem;
  border: 1px solid var(--border);
  border-radius: var(--radius-sm);
  background: var(--bg-surface);
  color: var(--text-primary);
  font: inherit;
  padding: 0.35rem;
}

.warning {
  margin: 0;
  font-size: var(--type-meta);
  color: var(--text-muted);
}

.error {
  margin: 0;
  font-size: var(--type-meta);
  color: var(--danger);
}

.notes {
  margin: 0.25rem 0 0;
  padding-left: 1rem;
  font-size: var(--type-meta);
  color: var(--text-muted);
}

.section {
  display: flex;
  flex-direction: column;
  gap: 0.35rem;
  min-width: 0;
}

.section-heading {
  margin: 0;
  font-size: var(--type-meta);
}

.section-toggle {
  appearance: none;
  display: flex;
  align-items: baseline;
  gap: 0.4rem;
  width: 100%;
  margin: 0;
  min-height: 1.5rem;
  padding: 0.25rem 0;
  border: 0;
  background: transparent;
  color: var(--text-muted);
  font: inherit;
  font-size: var(--type-meta);
  font-weight: 700;
  letter-spacing: 0.02em;
  text-transform: uppercase;
  text-align: left;
  cursor: pointer;
}

.section-progress {
  font-weight: 650;
  color: var(--text-primary);
  text-transform: none;
  letter-spacing: 0;
}

.help {
  display: flex;
  flex-direction: column;
  gap: 0.4rem;
  min-width: 0;
}

.help p,
.help li {
  margin: 0;
  font-size: var(--type-meta);
  color: var(--text-muted);
}

.help ul,
.help ol {
  margin: 0;
  padding-left: 1.1rem;
}

.help h1,
.help h2,
.help h3,
.help h4 {
  margin: 0;
  font-size: var(--type-body);
  font-weight: 650;
  color: var(--text-primary);
}

.help strong { font-weight: 700; color: var(--text-primary); }
.help em { font-style: italic; }
.help code {
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  font-size: 0.88em;
  padding: 0.05em 0.3em;
  border-radius: var(--radius-sm);
  border: 1px solid var(--border);
}
.help a { color: var(--link); }
.help pre {
  margin: 0;
  padding: 0.45rem 0.55rem;
  overflow-x: auto;
  border: 1px solid var(--border);
  border-radius: var(--radius-sm);
  font-size: var(--type-meta);
}
.help pre code { padding: 0; border: none; }
.help hr {
  width: 100%;
  border: none;
  border-top: 1px solid var(--border);
  margin: 0.2rem 0;
}
.help blockquote {
  margin: 0;
  padding: 0.15rem 0 0.15rem 0.6rem;
  border-left: 2px solid var(--border);
  color: var(--text-muted);
}
`,T=f;let R=null,Y=null,c=null,it=null,Q=null;function ko(e){return e.status==="expired"?T.sessionExpired:e.status==="not_signed_in"?T.signInFirst:e.error==="stale"?T.checklistChanged:e.error==="motivo"?T.motivoRequired:e.error==="api"||e.status==="error"?T.apiError:null}function So(){const e=document.getElementById(ue);if(e&&Y&&R===e)return{host:e,shadow:Y};e==null||e.remove();const t=document.createElement("div");t.id=ue,Object.assign(t.style,{position:"fixed",zIndex:String(Gr),left:"0px",top:"0px"});const n=t.attachShadow({mode:"open"}),r=document.createElement("style");return r.textContent=dn.replace(/:root/g,":host")+Eo,n.appendChild(r),document.documentElement.appendChild(t),R=t,Y=n,{host:t,shadow:n}}async function Lo(){try{const e=await L.storage.local.get(tt);return wo(e[tt])}catch{return null}}async function To(e,t){try{await L.storage.local.set({[tt]:{left:e,top:t}})}catch{}}async function No(){try{const e=await L.storage.local.get(nt);return Co(e[nt])??De}catch{return De}}async function mn(){if(c)try{await L.storage.local.set({[nt]:{instructionsCollapsed:c.instructionsCollapsed,checklistCollapsed:c.checklistCollapsed}})}catch{}}function at(e,t){if(!R)return;const n=R.getBoundingClientRect(),r=fo(e,t,{width:window.innerWidth,height:window.innerHeight},{width:n.width||420,height:Math.min(n.height||48,48)});R.style.left=`${r.left}px`,R.style.top=`${r.top}px`}function pn(){if(!R)return;const e=Number.parseFloat(R.style.left||"0"),t=Number.parseFloat(R.style.top||"0");at(e,t)}async function Po(){if(!R)return;const e=await Lo(),t={width:420,height:320},n=e??go({width:window.innerWidth,height:window.innerHeight},t);at(n.left,n.top)}function Io(e){if(!R||e.button!==0)return;const t=e.target;if(t!=null&&t.closest("button"))return;const n=Number.parseFloat(R.style.left||"0"),r=Number.parseFloat(R.style.top||"0");Q={pointerId:e.pointerId,startX:e.clientX,startY:e.clientY,originLeft:n,originTop:r},e.currentTarget.setPointerCapture(e.pointerId),e.preventDefault()}function Mo(e){!Q||e.pointerId!==Q.pointerId||at(Q.originLeft+(e.clientX-Q.startX),Q.originTop+(e.clientY-Q.startY))}function fn(e){if(!Q||e.pointerId!==Q.pointerId||!R)return;Q=null;const t=Number.parseFloat(R.style.left||"0"),n=Number.parseFloat(R.style.top||"0");To(t,n)}function _(){if(!Y||!c)return;const e=Y.querySelector(".panel");if(!e)return;e.classList.toggle("is-collapsed",c.collapsed);const t=Y.querySelector(".title"),n=Y.querySelector(".display-id");t&&(t.textContent=c.task.title),n&&(n.textContent=c.task.displayId);const r=Y.querySelector('[data-action="collapse"]');r&&(r.setAttribute("aria-label",c.collapsed?T.expandOverlay:T.collapseOverlay),r.setAttribute("aria-expanded",String(!c.collapsed)),r.textContent=c.collapsed?"▸":"▾");const o=Y.querySelector(".body");if(!o)return;if(o.replaceChildren(),c.error){const s=document.createElement("p");s.className="error",s.setAttribute("role","alert"),s.textContent=c.error,o.appendChild(s)}const i=document.createElement("p");i.className="hint",i.textContent=T.overlayDragHint,o.appendChild(i),c.helpMarkdown&&o.appendChild(Ro(c.helpMarkdown));const a=ln(c.items);if(a.length===0){const s=document.createElement("p");s.className="hint",s.textContent=c.loading?T.overlayLoading:T.noChecklist,o.appendChild(s)}else o.appendChild(_o(a.map(s=>s.id)));if(c.taskBugOpen)o.appendChild(Bo());else if(c.isBug){const s=document.createElement("button");s.type="button",s.className="btn",s.textContent=T.solveBug,s.disabled=c.busy,s.addEventListener("click",()=>{Ho()}),o.appendChild(s)}else{const s=document.createElement("button");s.type="button",s.className="btn",s.textContent=T.flagAsBug,s.disabled=c.busy,s.addEventListener("click",()=>{c&&(c.taskBugOpen=!0,c.taskNote="",c.error=null,_())}),o.appendChild(s)}}function $o(e){const t=c.items.find(u=>u.id===e),n=document.createElement("li"),r=mo(c.items,c.expandedId);n.className=["row",t.bugged?"is-bugged":"",t.id===r?"is-current":""].filter(Boolean).join(" ");const o=document.createElement("div");o.className="row-main";const i=document.createElement("button");i.type="button",i.className=t.checked?"tick is-checked":"tick",i.setAttribute("aria-pressed",String(t.checked)),i.setAttribute("aria-label",t.checked?T.itemDone:T.itemOpen),i.disabled=c.busy;const a=document.createElement("span");a.className="tick-mark",a.setAttribute("aria-hidden","true"),i.append(a),i.addEventListener("click",()=>{zo(t.id)});const s=ln([t])[0],l=document.createElement("button");l.type="button",l.className="expand";const d=c.expandedId===t.id;if(l.setAttribute("aria-expanded",String(d)),d)l.textContent=s.full;else{const u=document.createElement("strong");u.textContent=s.short,l.appendChild(u)}if(l.addEventListener("click",()=>{c&&(c.expandedId=c.expandedId===t.id?null:t.id,_())}),o.append(i,l),n.appendChild(o),t.notes.length){const u=document.createElement("ul");u.className="notes";for(const p of t.notes){const h=document.createElement("li");h.innerHTML="";const k=document.createElement("strong");k.textContent=`${T.motivo}: `,h.append(k,document.createTextNode(p)),u.appendChild(h)}n.appendChild(u)}if(c.reportingItemId===t.id)n.appendChild(Oo(t.id));else if(d){const u=document.createElement("div");u.className="row-actions";const p=document.createElement("button");if(p.type="button",p.className="btn",p.textContent=T.flagAsBug,p.disabled=c.busy,p.addEventListener("click",()=>{c&&(c.reportingItemId=t.id,c.itemNote="",c.error=null,_())}),u.appendChild(p),t.bugged){const h=document.createElement("button");h.type="button",h.className="btn",h.textContent=T.solveItem,h.disabled=c.busy,h.addEventListener("click",()=>{qo(t.id)}),u.appendChild(h)}n.appendChild(u)}return n}function gn(e,t,n,r){const o=document.createElement("button");o.type="button",o.className="section-toggle",o.setAttribute("aria-expanded",String(t));const i=document.createTextNode(e);if(o.appendChild(i),r){o.appendChild(document.createTextNode(" "));const s=document.createElement("span");s.className="section-progress",s.textContent=r,o.appendChild(s)}o.addEventListener("click",n);const a=document.createElement("h3");return a.className="section-heading",a.appendChild(o),a}function Ro(e){const t=document.createElement("section");t.className="section";const n=!c.instructionsCollapsed;if(t.appendChild(gn(T.instructionsHeading,n,()=>{c&&(c.instructionsCollapsed=!c.instructionsCollapsed,mn(),_())})),n){const r=document.createElement("div");r.className="help markdown-content",yo(r,e),t.appendChild(r)}return t}function _o(e){const t=document.createElement("section");t.className="section";const n=!c.checklistCollapsed,r=c.items.filter(o=>o.checked).length;if(t.appendChild(gn(T.checklistHeading,n,()=>{c&&(c.checklistCollapsed=!c.checklistCollapsed,mn(),_())},`${r}/${c.items.length}`)),n){const o=document.createElement("ul");o.className="list";for(const i of e)o.appendChild($o(i));t.appendChild(o)}return t}function Oo(e){const t=document.createElement("div");t.className="bug-form";const n=document.createElement("label");n.textContent=T.motivo;const r=document.createElement("textarea");r.value=c.itemNote,r.placeholder=T.motivoPlaceholder,r.rows=3,r.addEventListener("input",()=>{c&&(c.itemNote=r.value,i.disabled=c.busy||!c.itemNote.trim())}),n.appendChild(r);const o=document.createElement("div");o.className="row-actions";const i=document.createElement("button");i.type="button",i.className="btn btn-primary",i.textContent=T.flagAsBug,i.disabled=c.busy||!c.itemNote.trim(),i.addEventListener("click",()=>{Do(e)});const a=document.createElement("button");return a.type="button",a.className="btn",a.textContent=T.cancelFlag,a.addEventListener("click",()=>{c&&(c.reportingItemId=null,c.itemNote="",_())}),o.append(i,a),t.append(n,o),t}function Bo(){const e=document.createElement("div");e.className="bug-form";const t=document.createElement("p");t.className="warning",t.textContent=T.taskBugWarning;const n=document.createElement("label");n.textContent=T.motivo;const r=document.createElement("textarea");r.value=c.taskNote,r.placeholder=T.motivoPlaceholder,r.rows=3,r.addEventListener("input",()=>{c&&(c.taskNote=r.value,i.disabled=c.busy||!c.taskNote.trim())}),n.appendChild(r);const o=document.createElement("div");o.className="row-actions";const i=document.createElement("button");i.type="button",i.className="btn btn-primary",i.textContent=T.flagAsBug,i.disabled=c.busy||!c.taskNote.trim(),i.addEventListener("click",()=>{Fo()});const a=document.createElement("button");return a.type="button",a.className="btn",a.textContent=T.cancelFlag,a.addEventListener("click",()=>{c&&(c.taskBugOpen=!1,c.taskNote="",_())}),o.append(i,a),e.append(t,n,o),e}function ye(e){if(!c)return!1;const t=ko(e);if(t)return c.error=t,!1;if(c.error=null,e.items){c.items=e.items;const n=c.expandedId;n&&!e.items.some(r=>r.id===n)&&(c.expandedId=null)}return e.snapshot&&(c.snapshot=e.snapshot),e.helpMarkdown!==void 0&&(c.helpMarkdown=e.helpMarkdown??null),e.isBug!==void 0&&(c.isBug=e.isBug),!0}async function hn(){if(c){c.busy=!0,_();try{const e=await L.runtime.sendMessage({type:"task.get",task:c.task});ye(e)}finally{c&&(c.busy=!1,c.loading=!1),_()}}}async function zo(e){if(!(!c||c.busy)){c.busy=!0,c.error=null,_();try{const t=await L.runtime.sendMessage({type:"checklist.tick",task:c.task,itemId:e,snapshot:c.snapshot,source:"overlay"});if(ye(t),c){const n=c.items.find(r=>r.id===e);n!=null&&n.checked?c.expandedId=uo(c.items,e):c.expandedId=e}}finally{c&&(c.busy=!1),_()}}}async function Do(e){if(!(!c||c.busy)){if(!c.itemNote.trim()){c.error=T.itemMotivoRequired,_();return}c.busy=!0,c.error=null,_();try{const t=await L.runtime.sendMessage({type:"checklist.flagItem",task:c.task,itemId:e,note:c.itemNote,snapshot:c.snapshot,source:"overlay"});ye(t)&&(c.reportingItemId=null,c.itemNote="")}finally{c&&(c.busy=!1),_()}}}async function Fo(){if(!(!c||c.busy)){if(!c.taskNote.trim()){c.error=T.motivoRequired,_();return}c.busy=!0,c.error=null,_();try{const e=await L.runtime.sendMessage({type:"task.flag",task:c.task,note:c.taskNote,source:"overlay"});ye(e)&&(c.taskBugOpen=!1,c.taskNote="")}finally{c&&(c.busy=!1),_()}}}async function qo(e){if(!(!c||c.busy)){c.busy=!0,c.error=null,_();try{const t=await L.runtime.sendMessage({type:"checklist.unflagItem",task:c.task,itemId:e,snapshot:c.snapshot,source:"overlay"});ye(t)}finally{c&&(c.busy=!1),_()}}}async function Ho(){if(!(!c||c.busy)){c.busy=!0,c.error=null,_();try{const e=await L.runtime.sendMessage({type:"task.unflag",task:c.task,source:"overlay"});ye(e)}finally{c&&(c.busy=!1),_()}}}function Vo(){const{shadow:e}=So();if(e.querySelector(".panel"))return;const n=document.createElement("div");n.className="panel",n.setAttribute("role","dialog"),n.setAttribute("aria-label",T.checklistHeading),n.tabIndex=-1,n.addEventListener("keydown",p=>{p.key==="Escape"&&(p.preventDefault(),p.stopPropagation(),st())});const r=document.createElement("div");r.className="header",r.addEventListener("pointerdown",Io),r.addEventListener("pointermove",Mo),r.addEventListener("pointerup",fn),r.addEventListener("pointercancel",fn);const o=document.createElement("div");o.className="header-text";const i=document.createElement("p");i.className="display-id";const a=document.createElement("h2");a.className="title",o.append(i,a);const s=document.createElement("div");s.className="header-actions";const l=document.createElement("button");l.type="button",l.className="icon-btn",l.dataset.action="collapse",l.addEventListener("click",()=>{c&&(c.collapsed=!c.collapsed,_())});const d=document.createElement("button");d.type="button",d.className="icon-btn",d.setAttribute("aria-label",T.closeFloatingChecklist),d.textContent="×",d.addEventListener("click",()=>{st()}),s.append(l,d),r.append(o,s);const u=document.createElement("div");u.className="body",n.append(r,u),e.appendChild(n),window.addEventListener("resize",pn)}function Wo(e){var n;if(window!==window.top)return;Vo(),R&&(R.dataset.theme=window.matchMedia("(prefers-color-scheme: light)").matches?"light":"dark");const t=document.activeElement;it=t&&t!==R&&t!==document.body?t:null,c={task:e,items:[],snapshot:{items:[]},expandedId:null,reportingItemId:null,itemNote:"",taskBugOpen:!1,taskNote:"",collapsed:!1,instructionsCollapsed:De.instructionsCollapsed,checklistCollapsed:De.checklistCollapsed,helpMarkdown:null,isBug:!1,busy:!1,loading:!0,error:null},R&&(R.style.display="block"),_(),(n=Y==null?void 0:Y.querySelector(".panel"))==null||n.focus(),Promise.all([Po(),No()]).then(([,r])=>{c&&(c.instructionsCollapsed=r.instructionsCollapsed,c.checklistCollapsed=r.checklistCollapsed,_(),hn())})}function st(){Q=null,c=null,window.removeEventListener("resize",pn),R==null||R.remove(),R=null,Y=null;const e=it;it=null,e instanceof HTMLElement&&e.isConnected&&e.focus({preventScroll:!0})}function jo(){window===window.top&&L.runtime.onMessage.addListener(e=>{if(!e||typeof e!="object"||!("type"in e))return;const t=e.type;if(t==="overlay.open"){const n=e.task;n!=null&&n.id&&Wo(n)}if(t==="overlay.close"&&st(),t==="qa.checklistChanged"){if(!c||e.taskId!==c.task.id||!po("overlay",e.source))return;hn()}})}function Uo(e){return new Promise((t,n)=>{const r=new Image;r.onload=()=>t(r),r.onerror=()=>n(new Error("image")),r.src=e})}async function Ko(e,t,n){const r=await Uo(e),o=Xr(t,n,{width:r.naturalWidth||r.width,height:r.naturalHeight||r.height});if(!o)throw new Error("empty");const i=document.createElement("canvas");i.width=Math.max(1,Math.round(o.width)),i.height=Math.max(1,Math.round(o.height));const a=i.getContext("2d");if(!a)throw new Error("canvas");return a.drawImage(r,o.x,o.y,o.width,o.height,0,0,i.width,i.height),i.toDataURL("image/png")}async function bn(e,t){{await navigator.clipboard.writeText(e);return}}async function Yo(e){const t=await(await fetch(e)).blob();await navigator.clipboard.write([new ClipboardItem({"image/png":t})])}function Go(e){return e.reduce((t,n)=>Math.max(t,n.n),0)+1}function Xo(e,t){if(t<1)return null;const n=e.slice(0,t),r=n.lastIndexOf("@");if(r<0)return null;const o=n.slice(r+1);return/[\s]/.test(o)?null:{start:r,query:o}}function Qo(e,t,n){const r=n.toLowerCase();return e.filter(o=>o.n!==t).filter(o=>r?String(o.n).startsWith(r)||o.hit.selector.toLowerCase().includes(r):!0).map(o=>({n:o.n,label:o.hit.selector}))}function Zo(e,t,n,r){const o=`@${r}`;return{note:`${e.slice(0,t)}${o}${e.slice(n)}`,caret:t+o.length}}function Jo(e,t){const n=/^@(\d+)$/.exec(e);return n?t.some(r=>r.n===Number(n[1])):!1}function ei(e){const t=[],n=/@(\d+)\b/g;let r;for(;r=n.exec(e);){const o=Number(r[1]);t.includes(o)||t.push(o)}return t}function vn(e,t,n,r,o,i,a=4){return{x:Math.min(Math.max(e,a),Math.max(a,o-n-a)),y:Math.min(Math.max(t,a),Math.max(a,i-r-a))}}const ct=1;function lt(){return{version:ct,enabled:!0,items:[]}}function ti(e){try{const t=new URL(e);return`${t.origin==="null"?`${t.protocol}//${t.host}`:t.origin}${t.pathname}`}catch{return""}}function xn(e){if(!e||typeof e!="object"||Array.isArray(e))return null;const t=e;if(t.version!==ct||typeof t.enabled!="boolean"||!Array.isArray(t.items))return null;const n=[];for(const r of t.items){if(!r||typeof r!="object"||Array.isArray(r))return null;const o=r;if(typeof o.id!="string"||o.id.length===0||typeof o.css!="string"||typeof o.enabled!="boolean")return null;n.push({id:o.id,css:o.css,enabled:o.enabled})}return{version:ct,enabled:t.enabled,items:n}}function ni(e){return e.enabled?e.items.filter(t=>t.enabled).map(t=>t.css).join(`
`):""}function yn(e,t,n){return{...e,items:e.items.map(r=>r.id!==t?r:{...r,...n.css!==void 0?{css:n.css}:{},...n.enabled!==void 0?{enabled:n.enabled}:{}})}}function ri(e,t){return{...e,enabled:t}}const wn=48;function oi(e){const t=ii(e).replace(/\/\*[\s\S]*?\*\//g," ").replace(/\s+/g," ").trim();return t?t.length>wn?`${t.slice(0,wn-1)}…`:t:""}function ii(e){const t=e.length;let n=0;for(;;){for(;n<t&&Cn(e[n]);)n+=1;if(e[n]==="/"&&e[n+1]==="*"){const i=e.indexOf("*/",n+2);if(i===-1)return"";n=i+2;continue}break}const r=n;let o=0;for(;n<t;){const i=e[n];if(i==="/"&&e[n+1]==="*"){const a=e.indexOf("*/",n+2);if(a===-1)break;n=a+2;continue}if(i==='"'||i==="'"){n=An(e,n);continue}if(i==="\\"){n+=2;continue}if(i==="("||i==="[")o+=1;else if(i===")"||i==="]")o=Math.max(0,o-1);else if(o===0&&(i==="{"||i===";"))break;n+=1}return e.slice(r,n)}function An(e,t){const n=e[t];let r=t+1;const o=e.length;for(;r<o;){const i=e[r];if(i==="\\"){r+=2;continue}if(i===n)return r+1;if(i===`
`||i==="\r"||i==="\f")return r;r+=1}return r}function Cn(e){return e===" "||e===`
`||e==="	"||e==="\r"||e==="\f"}const ai={"{":"}","(":")","[":"]"};function si(e){const t=[],n=[],r=e.length;let o=0,i=!1,a="";const s=()=>n.length===0,l=u=>{!s()||i||Cn(u)||(i=!0,a=u)},d=()=>{i=!1,a=""};for(;o<r;){const u=e[o],p=e[o+1];if(u==="/"&&p==="*"){const h=e.indexOf("*/",o+2);if(h===-1)return t.push("unterminated comment"),t;o=h+2;continue}if(u==='"'||u==="'"){const h=An(e,o);l(u),ci(e,o,h)||t.push("unterminated string"),o=h;continue}if(u==="\\"){l(u),o+=2;continue}if(u==="{"||u==="("||u==="["){u==="{"&&s()&&d(),n.push(u),o+=1;continue}if(u==="}"||u===")"||u==="]"){const h=n[n.length-1];if((h?ai[h]:void 0)!==u)return t.push(`unmatched '${u}'`),t;n.pop(),s()&&d(),o+=1;continue}if(u===";"&&s()){if(i&&a!=="@")return t.push("unexpected text outside a rule"),t;d(),o+=1;continue}l(u),o+=1}return n.length>0?(t.push(`unclosed '${n[n.length-1]}'`),t):(i&&t.push("incomplete rule at end of input"),t)}function ci(e,t,n){return n>t+1&&e[n-1]===e[t]}const dt=4;function En(e){return{left:e.x,top:e.y,right:e.x+e.width,bottom:e.y+e.height,centerY:e.y+e.height/2}}function kn(e,t){return e.left>t.left&&e.right<t.right&&e.top>t.top&&e.bottom<t.bottom}function li(e,t){const n=Math.min(e.right,t.right)-Math.max(e.left,t.left),r=Math.min(e.bottom,t.bottom)-Math.max(e.top,t.top);return n<=0||r<=0?0:n*r}function di(e,t){const n=En(e.rect),r=En(t.rect),o=[];return kn(n,r)?o.push(`#${e.n} is inside #${t.n}`):kn(r,n)?o.push(`#${e.n} contains #${t.n}`):li(n,r)>0?o.push(`#${e.n} overlaps #${t.n}`):(n.right<=r.left?o.push(`#${e.n} is ${Math.round(r.left-n.right)}px to the left of #${t.n}`):n.left>=r.right&&o.push(`#${e.n} is ${Math.round(n.left-r.right)}px to the right of #${t.n}`),n.bottom<=r.top?o.push(`#${e.n} is ${Math.round(r.top-n.bottom)}px above #${t.n}`):n.top>=r.bottom&&o.push(`#${e.n} is ${Math.round(n.top-r.bottom)}px below #${t.n}`)),Math.abs(n.top-r.top)<=dt?o.push("top edges aligned"):Math.abs(n.centerY-r.centerY)<=dt&&o.push("center edges aligned"),Math.abs(n.left-r.left)<=dt&&o.push("left edges aligned"),o}const ui=6,Sn=200,mi=3,ut=new Set(["main","nav","aside","header","footer","dialog","form"]),Ln='h1,h2,h3,h4,h5,h6,[role="heading"]';function Tn(e,t,n,r){if(!e&&!t&&!n&&!r)return"";const o=e||"0px",i=t||"0px",a=n||"0px",s=r||"0px";return o===i&&i===a&&a===s?o:o===a&&i===s?`${o} ${i}`:i===s?`${o} ${i} ${a}`:`${o} ${i} ${a} ${s}`}function pi(e){const t=(e==null?void 0:e.borderTopWidth)??"";return!t||t==="0px"?"":[t,(e==null?void 0:e.borderTopStyle)??"",(e==null?void 0:e.borderTopColor)??""].filter(Boolean).join(" ")}function fi(e){return{color:(e==null?void 0:e.color)??"",fontSize:(e==null?void 0:e.fontSize)??"",display:(e==null?void 0:e.display)??"",padding:Tn(e==null?void 0:e.paddingTop,e==null?void 0:e.paddingRight,e==null?void 0:e.paddingBottom,e==null?void 0:e.paddingLeft),margin:Tn(e==null?void 0:e.marginTop,e==null?void 0:e.marginRight,e==null?void 0:e.marginBottom,e==null?void 0:e.marginLeft),gap:(e==null?void 0:e.gap)||(e==null?void 0:e.rowGap)||"",border:pi(e),background:(e==null?void 0:e.backgroundColor)??"",fontWeight:(e==null?void 0:e.fontWeight)??""}}function mt(e){const{x:t,y:n,width:r,height:o}=e.rect;return`${e.selector}@${Math.round(t)},${Math.round(n)},${Math.round(r)},${Math.round(o)}`}function we(e){return typeof CSS<"u"&&typeof CSS.escape=="function"?CSS.escape(e):e.replace(/([^\w-])/g,"\\$1")}function gi(e){return e.filter(t=>/^[A-Za-z_][\w-]*$/.test(t)).slice(0,mi)}function W(e,t=Sn){const n=(e??"").replace(/\s+/g," ").trim();return n.length<=t?n:n.slice(0,t)}function hi(e){const t=e.parentElement;return t?Array.from(t.children).indexOf(e)+1:1}function bi(e,t){if(!t)return!1;try{return e.querySelectorAll(`#${we(t)}`).length===1}catch{return!1}}function Nn(e){return{tagName:e.tagName,id:e.id,classes:Array.from(e.classList),nthChild:hi(e),parent:e.parentElement?Nn(e.parentElement):null}}function vi(e){const t=e.tagName.toLowerCase();if(t==="html"||t==="body")return t;const n=gi(e.classes);let r=t;return n.length&&(r+=n.map(o=>`.${we(o)}`).join("")),e.nthChild>0&&(r+=`:nth-child(${e.nthChild})`),r}function xi(e,t,n=ui){if(e.id&&t(e.id))return`#${we(e.id)}`;const r=[];let o=e,i=0;for(;o&&i<n;){if(o.id&&t(o.id)){r.unshift(`#${we(o.id)}`);break}if(r.unshift(vi(o)),o.tagName.toLowerCase()==="html")break;o=o.parent,i+=1}return r.join(" > ")}function pt(e){const t=(e.getAttribute("role")||"").trim();if(t)return t;const n=e.tagName.toLowerCase();if(n==="a")return"link";if(n==="button")return"button";if(n==="input"){const r=(e.getAttribute("type")||"").toLowerCase();if(r==="button"||r==="submit")return"button"}return/^h[1-6]$/.test(n)?"heading":ut.has(n)?n:n==="img"?"image":n}function Pn(e,t){const n=(e.getAttribute("aria-labelledby")||"").trim();if(!n)return"";const r=n.split(/\s+/).map(o=>{var i;try{const a=(i=t.querySelector)==null?void 0:i.call(t,`#${we(o)}`);return W(a==null?void 0:a.textContent)}catch{return""}}).filter(Boolean);return W(r.join(" "))}function ft(e,t,n=!0){var d,u;const r=(e.getAttribute("aria-label")||"").trim();if(r)return W(r);const o=Pn(e,t);if(o)return o;if(e.id)try{const p=(d=t.querySelector)==null?void 0:d.call(t,`label[for="${we(e.id)}"]`),h=W(p==null?void 0:p.textContent);if(h)return h}catch{}const i=(u=e.closest)==null?void 0:u.call(e,"label");if(i&&i!==e){const p=W(i.textContent);if(p)return p}const a=(e.getAttribute("alt")||"").trim();if(a)return W(a);const s=(e.getAttribute("placeholder")||"").trim();if(s)return W(s);const l=(e.getAttribute("title")||"").trim();return l?W(l):n?W(e.textContent):""}function In(e,t){return ft(e,t)||W(e.textContent)}function yi(e,t){var r;const n=(r=e.parentElement)==null?void 0:r.closest(Ln);return n?In(n,t):""}function Mn(e,t){const n=(e.getAttribute("aria-label")||"").trim();if(n)return W(n);const r=Pn(e,t);if(r)return r;const o=e.querySelector(Ln);return o?In(o,t):""}function $n(e){const t=e.tagName.toLowerCase();if(ut.has(t))return!0;const n=(e.getAttribute("role")||"").trim().toLowerCase();return ut.has(n)}function wi(e,t){let n=e.parentElement;for(;n;){const r=n.tagName.toLowerCase();if(r==="html"||r==="body")break;if($n(n)){const o=Mn(n,t);if(o)return{role:pt(n),name:o}}n=n.parentElement}return null}function Ai(e,t){const n=[];let r=e.parentElement;for(;r&&n.length<3;){const o=r.tagName.toLowerCase();if(o==="html"||o==="body")break;const i=pt(r),a=ft(r,t,!1)||($n(r)?Mn(r,t):"");n.push(a?`${i} "${a}"`:i),r=r.parentElement}return n.join(" > ")}function Rn(e,t){const n=e.getBoundingClientRect(),r=typeof getComputedStyle=="function"?getComputedStyle(e):void 0,o=t.document;return{tag:e.tagName.toLowerCase(),id:e.id,classes:Array.from(e.classList),text:W(e.textContent),title:t.document.title??"",url:t.locationHref??(typeof location<"u"?location.href:""),selector:xi(Nn(e),i=>bi(t.document,i)),rect:{x:n.left,y:n.top,width:n.width,height:n.height},viewport:{width:t.innerWidth,height:t.innerHeight},role:pt(e),accessibleName:ft(e,o),nearestHeading:yi(e,o),nearestLandmark:wi(e,o),parentChain:Ai(e,o),computed:fi(r)}}function Ci(e,t){const n=e.classes.length?e.classes.join(", "):"(none)";return`\`\`\`markdown
${["## Element","",`- Selector: \`${e.selector}\``,`- Tag: ${e.tag}`,`- Id: ${e.id||"(none)"}`,`- Classes: ${n}`,`- Text: ${e.text||"(none)"}`,`- Title: ${e.title||"(none)"}`,`- URL: ${e.url}`,"- Screenshot: omitted"].join(`
`)}
\`\`\``}function gt(e){return e?e.split(/\s+/).every(t=>t==="0px"||t==="0"):!0}function Ei(e){return!e||/\bnone\b/i.test(e)?!0:/^0px\b/.test(e)}function ki(e){if(!e)return!0;const t=e.replace(/\s+/g,"").toLowerCase();return t==="transparent"||t==="rgba(0,0,0,0)"||t==="rgb(0,0,0,0)"}function Si(e){return e?e==="400"||e.toLowerCase()==="normal":!0}function Li(e){const t=e.role||e.tag,n=e.accessibleName;let r=n?`${t} "${n}"`:t;const o=e.nearestLandmark;return o!=null&&o.name&&(e.role!==o.role||e.accessibleName!==o.name)&&(r+=` in ${o.role} "${o.name}"`),r}function Ti(e){var n;const t=[];return e.nearestHeading&&t.push(`heading "${e.nearestHeading}"`),(n=e.nearestLandmark)!=null&&n.name&&t.push(`landmark ${e.nearestLandmark.role} "${e.nearestLandmark.name}"`),e.parentChain&&t.push(`parents ${e.parentChain}`),t.length?`- Location: ${t.join("; ")}`:null}function Ni(e){const t=[],n=(r,o,i=!o)=>{i||t.push(`- ${r}: ${o}`)};return n("Color",e.color),n("Font-size",e.fontSize),n("Display",e.display),n("Padding",e.padding,gt(e.padding)),n("Margin",e.margin,gt(e.margin)),n("Gap",e.gap,gt(e.gap)),n("Border",e.border,Ei(e.border)),n("Background",e.background,ki(e.background)),n("Font-weight",e.fontWeight,Si(e.fontWeight)),t}function Pi(e,t,n){const r=ei(e.note??""),o=[];for(const i of r){if(i===t||!Jo(`@${i}`,n.map(s=>({n:s.n??0}))))continue;const a=n.find(s=>s.n===i);a&&o.push(...di({n:t,rect:e.rect},{n:i,rect:a.rect}))}return o.length?`- Relations: ${o.join("; ")}`:null}function _n(e,t,n){const r=[`### ${t}. ${Li(e)}`,"",Ti(e),`- Selector: \`${e.selector}\``,`- Tag: ${e.tag}`];e.id&&r.push(`- Id: ${e.id}`),e.classes.length&&r.push(`- Classes: ${e.classes.join(", ")}`),r.push(`- Text: ${W(e.text,Sn)||"(none)"}`,`- Href: ${e.url}`,`- Rect: ${Math.round(e.rect.x)}, ${Math.round(e.rect.y)}, ${Math.round(e.rect.width)} × ${Math.round(e.rect.height)}`,...Ni(e.computed),`- Note: ${(e.note??"").trim()||"(none)"}`);const o=Pi(e,t,n);return o&&r.push(o),r.filter(i=>i!==null).join(`
`)}function Ii(e,t){const r=e.map(s=>"hit"in s?{...s.hit,note:s.note,n:s.n}:s).map((s,l)=>({...s,n:s.n??l+1}));return`\`\`\`markdown
${["## Design notes","",...r.map(s=>_n(s,s.n,r)),"","- Screenshot: omitted"].join(`
`)}
\`\`\``}function On(e){const t=["## Live CSS","","```css",e.css.trim()||"(none applied)","```",""],n=(e.disabled??[]).map(o=>o.trim()).filter(Boolean);n.length>0&&(t.push("## Disabled CSS (not applied)",""),n.forEach((o,i)=>{t.push(`### Item ${i+1}`,"","```css",o,"```","")}));const r=(e.draft??"").trim();if(r&&t.push("## Editor draft (not applied)","","```css",r,"```",""),t.push("## Computed changes",""),e.diffs.length===0)t.push("- (none)");else for(const o of e.diffs){t.push(`### \`${o.selector}\` — ${o.description}`,"");for(const i of o.changes)t.push(`- ${i.property}: ${i.before} -> ${i.after}`);t.push("")}return`${t.join(`
`).trimEnd()}
`}function Mi(e){const n=(e.elements??[]).map(o=>"hit"in o?{...o.hit,note:o.note,n:o.n}:o).map((o,i)=>({...o,n:o.n??i+1})),r=["I am testing on a live page. Reply with only the CSS to paste into the live CSS field so I can see the change now. Do not edit source files.","",`Page: ${e.pageUrl}`,"","## Selected elements",""];if(n.length===0)r.push("- (none)","");else for(const o of n)r.push(_n(o,o.n,n),"");return e.rejected&&r.push("The browser rejected the CSS already in the live field. Reply with corrected CSS only.",""),r.push(On(e).trimEnd()),`${r.join(`
`).trimEnd()}
`}const $i=1e7,Bn=[{id:"phone",width:375,height:812,labelKey:"designViewportPresetPhone"},{id:"tablet",width:768,height:1024,labelKey:"designViewportPresetTablet"},{id:"board-compact",width:1023,height:768,labelKey:"designViewportPresetBoardCompact"},{id:"board-desktop",width:1024,height:768,labelKey:"designViewportPresetBoardDesktop"},{id:"wide",width:1280,height:800,labelKey:"designViewportPresetWide"}];function zn(e){return typeof e=="number"&&Number.isInteger(e)&&e>=1&&e<=$i}function Ri(e,t){return!zn(e)||!zn(t)?null:{width:e,height:t}}const Dn=2;function _i(e,t){return Math.abs(e.width-t.width)<=Dn&&Math.abs(e.height-t.height)<=Dn}const Oi=`
.viewport-block { display: block; }
.viewport-block > summary {
  cursor: pointer;
  color: var(--text-muted);
  font-size: var(--type-meta);
  min-height: 1.5rem;
}
.viewport-block[open] {
  display: flex;
  flex-direction: column;
  gap: 0.375rem;
}
.viewport-dims {
  margin: 0;
  color: var(--text-muted);
  font-size: var(--type-meta);
}
.viewport-row {
  display: flex;
  gap: 0.375rem;
  align-items: center;
}
.viewport-row select {
  flex: 1;
  min-width: 0;
  font: inherit;
  color: var(--text-primary);
  background: var(--bg-elevated);
  border: 1px solid var(--border);
  border-radius: var(--radius-sm);
  padding: 0.25rem 0.375rem;
  min-height: 1.5rem;
}
.viewport-fields {
  display: flex;
  gap: 0.375rem;
}
.viewport-fields label {
  flex: 1;
  min-width: 0;
  display: flex;
  flex-direction: column;
  gap: 0.25rem;
  color: var(--text-muted);
  font-size: var(--type-meta);
}
.viewport-fields input {
  width: 100%;
  box-sizing: border-box;
  font: inherit;
  color: var(--text-primary);
  background: var(--bg-elevated);
  border: 1px solid var(--border);
  border-radius: var(--radius-sm);
  padding: 0.25rem 0.375rem;
  min-height: 1.5rem;
}
.viewport-fields input[aria-invalid='true'] { border-color: var(--danger); }
.viewport-actions { display: flex; gap: 0.375rem; }
.viewport-actions button {
  flex: 1;
  min-width: 0;
  border: 1px solid var(--border);
  background: var(--bg-elevated);
  color: var(--text-primary);
  border-radius: var(--radius-control);
  min-height: 1.5rem;
  padding: 0.3rem 0.625rem;
  font: inherit;
  font-size: var(--type-meta);
  cursor: pointer;
}
.viewport-actions button:disabled { opacity: 0.5; cursor: default; }
.viewport-actions .primary {
  background: var(--accent);
  color: var(--accent-contrast);
  border-color: transparent;
}
.viewport-status {
  margin: 0;
  color: var(--text-muted);
  font-size: var(--type-meta);
}
.viewport-status.is-error { color: var(--danger); }
.viewport-block select:focus-visible,
.viewport-fields input:focus-visible,
.viewport-actions button:focus-visible {
  outline: 2px solid var(--ring);
  outline-offset: 2px;
}
@media (max-width: 380px) {
  .viewport-fields { flex-direction: column; }
}
`,Bi=700,ht="__original__",Fe="__custom__";function z(e,t,n){const r=e.createElement(t);return n&&(r.className=n),r}function Fn(){return new Promise(e=>{const t=()=>{window.removeEventListener("resize",t),clearTimeout(n),e()},n=setTimeout(t,Bi);window.addEventListener("resize",t)})}function zi(e){const t=e.strings,n=document,r=z(n,"details","viewport-block"),o=z(n,"style");o.textContent=Oi;const i=z(n,"summary");i.textContent=t.designViewportTitle;const a=z(n,"p","viewport-dims"),s=z(n,"div","viewport-row"),l=z(n,"select");l.setAttribute("aria-label",t.designViewportPreset);const d=z(n,"option");d.value=ht,d.textContent=t.designViewportOriginal,d.disabled=!0,l.appendChild(d);for(const C of Bn){const S=z(n,"option");S.value=C.id,S.textContent=`${t[C.labelKey]} · ${C.width}×${C.height}`,l.appendChild(S)}s.appendChild(l);const u=z(n,"div","viewport-fields"),p=z(n,"label");p.append(t.designViewportWidth);const h=z(n,"input");h.inputMode="numeric",h.autocomplete="off",p.appendChild(h);const k=z(n,"label");k.append(t.designViewportHeight);const B=z(n,"input");B.inputMode="numeric",B.autocomplete="off",k.appendChild(B),u.append(p,k);const V=z(n,"div","viewport-actions"),te=z(n,"button","primary");te.type="button",te.textContent=t.designViewportApply;const J=z(n,"button");J.type="button",J.textContent=t.designViewportRestore,V.append(te,J);const U=z(n,"p","viewport-status");U.hidden=!0;const ve=z(n,"div");ve.append(s,u,V,U),r.append(o,i,a,ve);let F=null,K=!1,b=0,y="",m=!1,v=!1;function w(){const C=e.measure();return`${t.designViewportMeasured}: ${C.width} × ${C.height}`}function A(C,S=!1){y=C??"",m=S,E()}function E(){if(!y){U.hidden=!0,U.removeAttribute("role"),U.classList.remove("is-error"),U.textContent="";return}U.hidden=!1,U.setAttribute("role",m?"alert":"status"),U.classList.toggle("is-error",m),U.textContent=y}function x(){const C=F?F.supported:!0,S=K||!C;l.disabled=S,h.disabled=S,B.disabled=S,te.disabled=S,J.disabled=S||(F==null?void 0:F.selection.kind)==="original",F&&!F.supported&&y!==t.designViewportUnsupported&&A(t.designViewportUnsupported,!1)}function P(){if(!F)return;const C=F.selection;if(C.kind==="original"){l.value=ht;return}if(C.kind==="preset")l.value=C.id;else{let S=l.querySelector(`option[value="${Fe}"]`);S||(S=z(n,"option"),S.value=Fe,S.textContent=t.designViewportCustom,S.disabled=!0,l.appendChild(S)),l.value=Fe}h.value=String(C.width),B.value=String(C.height)}function $(C){h.setAttribute("aria-invalid",C?"true":"false"),B.setAttribute("aria-invalid",C?"true":"false")}function ee(C){return C==="invalidSize"?t.designViewportInvalid:C==="unsupported"?t.designViewportUnsupported:t.designViewportFailed}async function xe(){if(K)return;const C=Ri(Number(h.value),Number(B.value));if(!C){$(!0),A(t.designViewportInvalid,!0);return}$(!1);const S=++b;K=!0,A(t.designViewportPending,!1),x();const X=await e.request({type:"design.viewport.set",width:C.width,height:C.height}).catch(()=>{});if(K=!1,!(v||S!==b)){if(!X||X.error){X&&(F=X),P(),x(),A(ee(X==null?void 0:X.error),!0);return}F=X,P(),x(),await G(C,S)}}async function G(C,S){if(await Fn(),v||S!==b)return;const X=e.measure();if(a.textContent=w(),_i(X,C)){A(null);return}A(`${t.designViewportMismatch} (${t.designViewportMeasured}: ${X.width} × ${X.height})`,!0)}async function Be(){if(K)return;const C=++b;K=!0,A(t.designViewportPending,!1),x();const S=await e.request({type:"design.viewport.reset"}).catch(()=>{});if(K=!1,!(v||C!==b)){if(!S||S.error){S&&(F=S),P(),x(),A(ee(S==null?void 0:S.error),!0);return}F=S,P(),x(),await Fn(),!(v||C!==b)&&(a.textContent=w(),A(null))}}function Dr(){v||(e.request({type:"design.viewport.get"}).then(C=>{v||K||(F=C??null,P(),x(),C&&!C.supported&&A(t.designViewportUnsupported,!1))}).catch(()=>{}),a.textContent=w())}function Fr(){a.textContent=w()}l.addEventListener("change",()=>{if(l.value===ht||l.value===Fe)return;const C=Bn.find(S=>S.id===l.value);C&&(h.value=String(C.width),B.value=String(C.height),$(!1))});for(const C of[h,B])C.addEventListener("input",()=>$(!1));return te.addEventListener("click",()=>void xe()),J.addEventListener("click",()=>void Be()),window.addEventListener("resize",Fr),r.open=!0,a.textContent=w(),Dr(),{element:r,refresh:Dr,dispose(){v=!0,b+=1,window.removeEventListener("resize",Fr)}}}const me="data-arc-todo-preview",bt=20,Di="http://www.w3.org/1999/xhtml",qn=1,Fi=3,qi=new Set(["script","style","link","meta","base","title","noscript","noembed","noframes","template","param","source","track","keygen","isindex","image","feimage","font-face-uri","map","area","frame","frameset","animate","animatemotion","animatetransform","animatecolor","set"]),Hi=new Set(["img","picture","video","audio","iframe","object","embed","applet","portal","fencedframe","canvas"]),Vi=new Set(["src","srcset","imagesrcset","srcdoc","background","dynsrc","lowsrc","datasrc","ping","attributionsrc","autofocus","contenteditable","draggable","is","formaction","formmethod","formenctype","formnovalidate","formtarget","popovertarget","popovertargetaction","command","commandfor","nonce","longdesc","usemap","manifest","profile"]),Wi=new Set(["button","fieldset","input","keygen","object","output","select","textarea"]),ji=new Set(["a","button","input","select","textarea","summary","audio","video"]),Ui=new Set(["for","headers","itemref","aria-labelledby","aria-describedby","aria-owns","aria-controls","aria-flowto","aria-details","aria-errormessage","form","list"]),Ki=new Set(["href","xlink:href","fill","stroke","clip-path","mask","marker","marker-start","marker-mid","marker-end","filter","cursor","style"]),Yi={input:["value","checked","disabled","readOnly","required","indeterminate"],textarea:["value","disabled","readOnly","required"],select:["value","disabled"],option:["selected","disabled"],optgroup:["disabled"],button:["disabled"],fieldset:["disabled"],progress:["value"],meter:["value"],details:["open"],dialog:["open"]},Gi=/url\(\s*(['"]?)([^'")]+)\1\s*\)/gi;let Hn=0;function vt(e,t){const n=e.localName.toLowerCase();return n==="html"||n==="body"?t?"unsupported":"drop":qi.has(n)?"drop":n.includes("-")||e.hasAttribute("is")||e.shadowRoot!==null?t?"unsupported":"placeholder":Hi.has(n)||n==="input"&&(e.getAttribute("type")??"").toLowerCase()==="image"?"placeholder":"clone"}function Xi(e){return e.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}function Qi(e){Hn+=1;const t=e.replace(/[^\w-]+/g,"-").replace(/^-+|-+$/g,"")||"x";return`arc-todo-pv-${Hn}-${t}`}function Zi(e,t,n){const r=[e];for(;r.length>0;){const o=r.pop();if(o.hasAttribute(me)||t!=null&&t(o)||vt(o,o===e)!=="clone")continue;const a=o.getAttribute("id");a&&!n.has(a)&&n.set(a,Qi(a));for(let s=o.children.length-1;s>=0;s-=1)r.push(o.children[s])}}function Ji(e,t){return t.size===0?e:e.split(/\s+/).filter(Boolean).map(n=>t.get(n)??n).join(" ")}function ea(e){if(e.size===0)return null;const t=[...e.keys()].map(Xi).join("|");return new RegExp(`#(${t})(?![\\w-])`,"g")}function ta(e){return e.replace(Gi,(t,n,r)=>{const o=r.trim();return o.startsWith("#")||/^data:/i.test(o)?t:"none"})}function na(e,t){const n=ta(e),r=ea(t);return r?n.replace(r,(o,i)=>`#${t.get(i)}`):n}function Vn(e,t,n){t.namespaceURI?e.setAttributeNS(t.namespaceURI,t.name,n):e.setAttribute(t.name,n)}function ra(e,t,n){const r=e.localName.toLowerCase(),o=Wi.has(r);for(const i of Array.from(e.attributes)){const s=i.name.toLowerCase();if(s.startsWith("on")||Vi.has(s)||o&&s==="name"||r==="use"&&(s==="href"||s==="xlink:href")&&!i.value.trim().startsWith("#"))continue;if(s==="id"){const d=n.get(i.value);d&&Vn(t,i,d);continue}let l=i.value;Ui.has(s)?l=Ji(l,n):Ki.has(s)&&(l=na(l,n)),Vn(t,i,l)}(ji.has(r)||e.hasAttribute("tabindex"))&&t.setAttribute("tabindex","-1")}function oa(e,t){const n=Yi[e.localName.toLowerCase()];if(!n)return;const r=e,o=t;for(const i of n)try{i in r&&i in o&&(o[i]=r[i])}catch{}}function Wn(e,t){if(typeof getComputedStyle!="function")return"";try{return getComputedStyle(e)[t]??""}catch{return""}}function ia(e){const n=(e.getAttribute("alt")||e.getAttribute("aria-label")||e.getAttribute("title")||"").replace(/\s+/g," ").trim();return n.length>40?`${n.slice(0,40)}…`:n}function jn(e,t){const n=Wn(t,"display"),r=Wn(t,"visibility"),o=t.getBoundingClientRect();if(n==="none"||r==="hidden"||r==="collapse"||o.width===0&&o.height===0)return null;const i=e.createElement("span");i.setAttribute("aria-hidden","true");const a=n==="inline"||n==="contents"||n==="",s=o.width>0?`width:${o.width}px;`:"",l=o.height>0?`height:${o.height}px;`:"";i.style.cssText=`display:${a?"inline-block":n};box-sizing:border-box;${s}${l}border:1px dashed #9aa0aa;border-radius:4px;background:rgba(128,128,138,0.14);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font:10px/1.4 system-ui,sans-serif;color:#6b7280;padding:0 4px;`;const d=ia(t);return d&&(i.textContent=d),i}function xt(e){const t=e.createElement("span");return t.style.cssText="display:inline-block;max-width:100%;box-sizing:border-box;padding:2px 6px;border:1px dashed #9aa0aa;border-radius:4px;background:rgba(128,128,138,0.14);font:11px/1.4 system-ui,sans-serif;color:#6b7280;",t.textContent=f.designPreviewUnavailable,t}function qe(e){var n;e.setAttribute(me,""),e.setAttribute("inert","");const t=e.style;(n=t==null?void 0:t.setProperty)==null||n.call(t,"pointer-events","none","important")}function aa(e,t){const n=e.namespaceURI;return!n||n===Di?t.createElement(e.localName):t.createElementNS(n,e.nodeName)}function Un(e){const t=e.parentElement;if(!t)return!0;const n=t.localName.toLowerCase();return n==="script"||n==="style"||n==="noscript"||n==="template"?!0:!!t.closest(`[${me}]`)}function Kn(e,t,n,r){if(e.nodeType===Fi){const s=e;return Un(s)?null:t.createTextNode(s.data)}if(e.nodeType!==qn)return null;const o=e;if(o.hasAttribute(me)||r!=null&&r(o))return null;const i=vt(o,!1);if(i==="drop")return null;if(i==="placeholder")return jn(t,o);const a=aa(o,t);ra(o,a,n);for(const s of Array.from(o.childNodes)){const l=Kn(s,t,n,r);l&&a.appendChild(l)}return oa(o,a),a}function Yn(e,t={}){const r=e.ownerDocument??(typeof document<"u"?document:null);if(!r)throw new Error("buildSafeReplica requires a document");const o=vt(e,!0);if(e.hasAttribute(me)||o==="unsupported"||o==="drop"){const d=xt(r);return qe(d),{ok:!1,node:d}}if(o==="placeholder"){const d=jn(r,e)??xt(r);return qe(d),{ok:!1,node:d}}const i=r.implementation.createHTMLDocument("arc-todo-preview"),a=new Map;Zi(e,t.excludeNode,a);const s=Kn(e,i,a,t.excludeNode);if(!s||s.nodeType!==qn){const d=xt(r);return qe(d),{ok:!1,node:d}}const l=s;return qe(l),{ok:!0,node:l}}function sa(e){const t=e.trim();if(!/^\d+$/.test(t))return null;const n=Number.parseInt(t,10);return n<0||n>bt?null:n}function ca(e){const n=e.ownerDocument.createTreeWalker(e,NodeFilter.SHOW_TEXT),r=[];let o=n.nextNode();for(;o;){const i=o;if(i.data.trim()!==""&&!Un(i)&&(r.push(i),r.length>1))return"many";o=n.nextNode()}return r.length===1?r[0]:"none"}function la(e,t={}){let n=[],r=null;const o=()=>{const a=r;r=null,a&&a.node.isConnected&&a.node.data===a.preview&&(a.node.data=a.original)},i=()=>{for(const a of n)a.remove();n=[]};return{element:e,get copies(){return n},setCopies(a){if(!Number.isInteger(a)||a<0||a>bt)return{ok:!1,error:"invalid-count"};if(a>0){if(!e.isConnected)return{ok:!1,error:"disconnected"};if(!e.parentElement)return{ok:!1,error:"no-parent"}}if(i(),a===0)return{ok:!0};const s=e.parentElement,l=[];let d=!1;for(let p=0;p<a;p+=1){const h=Yn(e,t);h.ok||(d=!0),l.push(h.node)}let u=e;for(const p of l)s.insertBefore(p,u.nextSibling),u=p;return n=l,d?{ok:!0,degraded:!0}:{ok:!0}},setLabel(a){if(!e.isConnected)return{ok:!1,error:"disconnected"};const s=a===null||a==="";let l=null;if(!s){const u=ca(e);if(u==="none")return{ok:!1,error:"no-text"};if(u==="many")return{ok:!1,error:"ambiguous-text"};l=u}if(o(),s||!l)return{ok:!0};const d=l.data;return l.data=a,r={node:l,original:d,preview:a},{ok:!0}},reset(){i(),o()}}}let re=null;function Gn(e){re=e}const pe="arc-todo-live-css",yt="	";let fe=!1,Ae=null,Ce="",He=0;function da(e,t,n){return`${e}${yt}${t}${yt}${n}`}function ua(e){const[t="",n="",r=""]=e.split(yt);return{selector:t,description:n,identity:r}}function Ee(e){if(!e.trim())return{ok:!1};if(si(e).length>0)return{ok:!1};try{return wt(kt(e).cssRules)?{ok:!0}:{ok:!1}}catch{return{ok:!1}}}function wt(e){if(!e||e.length===0)return!1;for(const t of e)if(!ma(t))return!1;return!0}function ma(e){const t=e.style,n=e.cssRules,r=!n||n.length===0||wt(n);return t?(t.length>0||((n==null?void 0:n.length)??0)>0)&&r:n?n.length>0&&wt(n):!0}function pa(e){const t=kt(e),n=[];return St(t.cssRules,r=>{r.selectorText&&n.push(r.selectorText)}),n}function fa(e){const t=kt(e),n=new Set;return St(t.cssRules,r=>{const o=r.style;if(o)for(let i=0;i<o.length;i++){const a=o.item(i);a&&n.add(a)}}),[...n]}function ga(e,t,n){const r=new Map,o=wa();for(const i of t){let a;try{a=e.querySelectorAll(i)}catch{continue}for(const s of a){if(!(s instanceof Element)||Aa(s))continue;const l=Rn(s,o),d=l.selector||mt(l),u=xa(s),p=da(i,u,d);r.set(p,ya(s,n))}}return r}function Xn(e,t){const n=[];for(const[r,o]of e){const i=t.get(r);if(!i)continue;const a=[],s=new Set([...Object.keys(o),...Object.keys(i)]);for(const d of s){const u=o[d]??"",p=i[d]??"";u!==p&&a.push({property:d,before:u,after:p})}if(a.length===0)continue;const l=ua(r);n.push({selector:l.selector,description:l.description,changes:a})}return n}function Qn(){return Ae??new Map}function At(){return Ce}function Ct(e,t=document){return!e.trim()||!Ee(e).ok?new Map:ga(t,pa(e),fa(e))}function ha(){return fe?!0:!!(typeof document<"u"&&document.getElementById(pe))}async function ba(e){const t=++He;if(!e.trim())return Et(),{applied:"none"};if(!Ee(e).ok)return{applied:ke(),error:!0};const n=Ct(e),r=Ca();if(r.textContent=e,r.sheet)return fe&&(fe=!1,re==null||re.removeCss()),Zn(n),Ce=e,{applied:"dom"};if(!re)return Lt(r),{applied:ke(),error:!0};try{const o=await re.insertCss(e);return t!==He?{applied:ke()}:o!=null&&o.error?(Lt(r),{applied:ke(),error:!0}):(Zn(n),Ce=e,fe=!0,{applied:"extension"})}catch{return t!==He?{applied:ke()}:(Lt(r),{applied:ke(),error:!0})}}function Et(){var e;He+=1,typeof document<"u"&&((e=document.getElementById(pe))==null||e.remove()),fe&&(re==null||re.removeCss()),fe=!1,Ae=null,Ce=""}function kt(e){const t=new CSSStyleSheet;return t.replaceSync(e),t}function St(e,t){for(const n of e){const r=va(n);r!=null&&r.selectorText&&t(r);const o=n.cssRules;o&&St(o,t)}}function va(e){return"selectorText"in e&&"style"in e?e:null}function xa(e){const t=W(e.textContent,48);return t||e.tagName.toLowerCase()}function ya(e,t){const n={};if(typeof getComputedStyle!="function")return n;const r=getComputedStyle(e);for(const o of t)n[o]=r.getPropertyValue(o).trim();return n}function wa(){return{document,innerWidth:window.innerWidth,innerHeight:window.innerHeight,locationHref:location.href}}function Aa(e){return e.id===pe||e.id==="arc-todo-picker-hover"||e.id==="arc-todo-design-tray"||e.id===ue||e.classList.contains("arc-todo-picker-selected")||e.classList.contains("arc-todo-picker-badge")||e.closest(`[${me}]`)!==null}function Zn(e){if(!Ae){Ae=e;return}for(const[t,n]of e)Ae.has(t)||Ae.set(t,n)}function Lt(e){if(Ce){e.textContent=Ce;return}e.remove()}function Ca(){const e=document.getElementById(pe);if(e instanceof HTMLStyleElement)return e;const t=document.createElement("style");return t.id=pe,document.documentElement.appendChild(t),t}function ke(){return fe?"extension":typeof document<"u"&&document.getElementById(pe)?"dom":"none"}const Jn=["hover","focus","active"],Tt="data-arc-todo-state-target";let er=null;function Ea(e){er=e}function ka(){return er}const Sa=new Set(["button","input","select","textarea","fieldset","optgroup","option"]),La=300,Se=24,Ta=4e3,Na=new Set(["pointer-events"]);let tr=0;function Pa(){var t,n;return`arc-doc-${(((n=(t=globalThis.crypto)==null?void 0:t.randomUUID)==null?void 0:n.call(t))??`${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`).replace(/[^a-zA-Z0-9-]/g,"")}`.slice(0,80)}function Ia(){const e=globalThis.chrome;return!!(e!=null&&e.debugger)}const Ma={snapshot(e){if(typeof getComputedStyle!="function")return null;try{const t=getComputedStyle(e),n={};for(let r=0;r<t.length;r+=1){const o=t[r];o&&(n[o]=t.getPropertyValue(o))}return n}catch{return null}},diff(e,t){if(!e||!t)return["unverified"];const n=[],r=new Set([...Object.keys(e),...Object.keys(t)]);for(const o of r)Na.has(o)||(e[o]??"")!==(t[o]??"")&&n.push(o);return n}};function se(e){return e.kind==="class"?`class:${e.name}`:`attr:${e.name}=${e.value}`}function $a(e){return e.kind==="class"?`.${e.name}`:`[${e.name}="${e.value}"]`}function nr(e){return(e.startsWith("data-")||e.startsWith("aria-"))&&!e.startsWith("data-arc-todo-")}function rr(e){const t=[];for(const n of Array.from(e.classList))n&&!n.startsWith("arc-todo-")&&t.push({kind:"class",name:n});for(const n of Array.from(e.attributes))nr(n.name)&&t.push({kind:"attr",name:n.name,value:n.value});return t}const Ra=/\.(-?[_a-zA-Z][-_a-zA-Z0-9]*)/g,_a=/\[\s*([a-zA-Z_][\w-]*)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s\]"']+)))?\s*\]/g;function Oa(e,t){var i;if(typeof document>"u")return;let n;try{n=document.styleSheets}catch{return}let r=0;const o=a=>{for(let s=0;s<a.length;s+=1){if(r>=Ta||e.size>=t)return;const l=a[s];if(!l)continue;r+=1;const d=l.selectorText;if(typeof d=="string"&&d){for(const p of d.matchAll(Ra)){const h=p[1];if(h&&!h.startsWith("arc-todo-")){const k={kind:"class",name:h};e.set(se(k),k)}}for(const p of d.matchAll(_a)){const h=p[1];if(!h||!nr(h))continue;const k={kind:"attr",name:h,value:p[2]??p[3]??p[4]??""};e.set(se(k),k)}}const u=l.cssRules;u&&u.length>0&&o(u)}};for(let a=0;a<n.length&&!(e.size>=t);a+=1){let s=null;try{s=((i=n[a])==null?void 0:i.cssRules)??null}catch{s=null}s&&o(s)}}function or(e){const t=new Map,n=e.parentElement??e,r=[e];try{const o=n.querySelectorAll("*");for(let i=0;i<o.length&&r.length<La;i+=1){const a=o[i];a&&r.push(a)}}catch{}for(const o of r){if(t.size>=Se)break;for(const i of rr(o))if(t.set(se(i),i),t.size>=Se)break}return Oa(t,Se),[...t.values()].slice(0,Se)}function Nt(e,t){var n;if(t==="checked"){if(e.localName!=="input")return null;const r=((n=e.type)==null?void 0:n.toLowerCase())??"";return r==="checkbox"||r==="radio"?"checked":null}return Sa.has(e.localName)?"disabled":null}function Ba(e,t){if(t==="checked"){"checked"in e&&(e.checked=!0);return}"disabled"in e?e.disabled=!0:e.setAttribute("disabled","")}function za(e,t){if(t.kind==="class"){e.classList.add(t.name);return}e.setAttribute(t.name,t.value)}function Da(e,t){switch(t){case"hover":return e.designStateHover;case"focus":return e.designStateFocus;case"active":return e.designStateActive}}function Fa(e){const t=e.probe??Ma,n=e.pseudoSupported??Ia;let r=null,o=!1,i=null,a=[],s=[],l=null,d=Promise.resolve(),u=!1;function p(){if(u)return null;const m=e.element();return m&&m.isConnected?m:null}function h(m){return i||(tr+=1,i=`arc-es-${tr}`,m.setAttribute(Tt,i),i)}function k(){const m=e.element();m&&i&&m.getAttribute(Tt)===i&&m.removeAttribute(Tt),i=null}async function B(){const m=o;o=!1;const v=e.messenger(),w=i;k(),m&&v&&w&&await v.clearPseudo({doc:e.doc,marker:w}).catch(()=>{})}async function V(){await B(),te(),r=null}function te(){const m=l;if(l=null,!m)return;m.node.remove();const v=m.el;if(!v.isConnected)return;const w=v.style;m.display?w.setProperty("display",m.display,m.priority):w.removeProperty("display")}function J(m,v){const w=m.parentElement;if(!w)return{ok:!1,error:"unavailable"};const A=t.snapshot(m),E=Yn(m,{excludeNode:e.excludeReplicaNode});try{v(E.node)}catch{return{ok:!1,error:"failed"}}const x=m.style,P=x.getPropertyValue("display"),$=x.getPropertyPriority("display");w.insertBefore(E.node,m),x.setProperty("display","none","important");const ee=t.snapshot(E.node);return t.diff(A,ee).length===0?(E.node.remove(),P?x.setProperty("display",P,$):x.removeProperty("display"),{ok:!1,error:"no-diff"}):(l={node:E.node,el:m,display:P,priority:$},E.ok?{ok:!0}:{ok:!0,degraded:!0})}async function U(m){const v=p();if(!v)return{ok:!1,error:"unavailable"};if(m===""||m==="normal")return await V(),{ok:!0};if(m.startsWith("pseudo:")){const w=m.slice(7);if(!Jn.includes(w))return{ok:!1,error:"invalid"};const A=e.messenger();if(!A||!n())return{ok:!1,error:"unsupported"};te();const E=o,x=h(v),P=await A.setPseudo({doc:e.doc,marker:x,state:w}).catch(()=>{});return P!=null&&P.ok?(o=!0,r=m,{ok:!0}):(o=!1,E&&await A.clearPseudo({doc:e.doc,marker:x}).catch(()=>{}),k(),r=null,{ok:!1,error:P&&!P.ok?P.error:"failed"})}if(m.startsWith("native:")){const w=m.slice(7);if(w!=="checked"&&w!=="disabled")return{ok:!1,error:"invalid"};if(!Nt(v,w))return{ok:!1,error:"incompatible"};await B();const A=J(v,E=>Ba(E,w));return A.ok&&(r=m),A}if(m.startsWith("app:")){const w=Number(m.slice(4)),A=a[w];if(!A)return{ok:!1,error:"invalid"};await B();const E=J(v,x=>za(x,A));return E.ok&&(r=m),E}return{ok:!1,error:"invalid"}}function ve(m){const v=d.then(()=>U(m));return d=v.then(()=>{},()=>{}),v}function F(){const m=[{id:"",label:e.strings.designStateNormal}];if(e.messenger()&&n())for(const A of Jn)m.push({id:`pseudo:${A}`,label:Da(e.strings,A)});const w=e.element();if(w&&w.isConnected){Nt(w,"checked")&&m.push({id:"native:checked",label:e.strings.designStateChecked}),Nt(w,"disabled")&&m.push({id:"native:disabled",label:e.strings.designStateDisabled});const A=new Map;for(const E of or(w))A.set(se(E),E);for(const E of s)A.set(se(E),E);a=[...A.values()].slice(0,Se);for(let E=0;E<a.length;E+=1)m.push({id:`app:${E}`,label:$a(a[E])})}return m}async function K(m){const v=rr(m);if(v.length===0)return{ok:!1,error:"no-markers"};const w=new Set([...or(e.element()??m).map(se),...s.map(se)]);let A=0;for(const E of v){const x=se(E);w.has(x)||s.length>=Se||(w.add(x),s.push(E),A+=1)}return{ok:!0,added:A}}function b(){var m;!o&&!(r!=null&&r.startsWith("pseudo:"))||(o=!1,r!=null&&r.startsWith("pseudo:")&&(r=null),k(),(m=e.onStateLost)==null||m.call(e))}function y(){u||(u=!0,r=null,V())}return{currentId:()=>r,anchorElement:()=>l!=null&&l.node.isConnected?l.node:p(),options:F,apply:ve,applyExample:K,lost:b,reset:y}}function qa(e){if(!e||typeof e!="object")return"dev";const t=e.purpose;return t==="qa-crop"||t==="qa-record"||t==="design"?t:"dev"}function Ha(e){return e==="dev"}function Va(e){return e!=="design"}function Wa(e,t,n){return e==="qa-crop"?{type:"capture.elementPicked",hit:t}:e==="qa-record"?{type:"capture.elementForRecord",hit:t}:{type:"picker.picked",hit:t,keepArmed:e==="design",removed:n==null?void 0:n.removed}}const ja=`
:host {
  all: initial;
  position: fixed;
  z-index: 2147483647;
}
`,Ua=`
:host {
  color-scheme: dark;
  background: transparent;
}
:host([data-theme='light']) {
  color-scheme: light;
}
.tray {
  width: min(340px, calc(100vw - 24px));
  max-height: 60vh;
  display: flex;
  flex-direction: column;
  gap: 0.375rem;
  padding: 0.625rem;
  background: var(--bg-surface);
  color: var(--text-primary);
  border: 1px solid var(--border);
  border-radius: var(--radius-md);
  box-shadow: var(--shadow-lift);
  font-size: var(--type-body);
  line-height: 1.4;
}
.head {
  display: flex;
  align-items: baseline;
  cursor: grab;
  user-select: none;
  touch-action: none;
}
.tray.is-dragging .head { cursor: grabbing; }
.title {
  font-size: var(--type-meta);
  text-transform: uppercase;
  letter-spacing: 0.08em;
  color: var(--text-muted);
}
.empty { margin: 0; color: var(--text-muted); }
.list {
  list-style: none;
  margin: 0;
  padding: 0;
  overflow-y: auto;
  min-height: 0;
  display: flex;
  flex-direction: column;
  gap: 0.375rem;
}
.pin {
  display: flex;
  flex-direction: column;
  gap: 0.25rem;
  border: 1px solid var(--border);
  border-radius: var(--radius-sm);
  padding: 0.375rem;
  position: relative;
}
.pin-head { display: flex; align-items: center; gap: 0.375rem; }
.n {
  min-width: 1rem;
  height: 1rem;
  padding: 0 0.25rem;
  border-radius: 999px;
  background: var(--accent);
  color: var(--accent-contrast);
  font-size: var(--type-meta);
  font-weight: 600;
  line-height: 1rem;
  text-align: center;
  flex: none;
}
.label {
  flex: 1;
  min-width: 0;
  font-family: ui-monospace, monospace;
  font-size: var(--type-meta);
  color: var(--text-muted);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.remove {
  border: 0;
  background: transparent;
  color: var(--text-muted);
  cursor: pointer;
  font: inherit;
  font-size: var(--type-body);
  line-height: 1;
  padding: 0;
  min-width: 1.5rem;
  min-height: 1.5rem;
}
.note-label {
  display: flex;
  flex-direction: column;
  gap: 0.25rem;
  color: var(--text-muted);
  font-size: var(--type-meta);
}
textarea {
  width: 100%;
  resize: vertical;
  min-height: 2rem;
  font: inherit;
  color: var(--text-primary);
  background: var(--bg-elevated);
  border: 1px solid var(--border);
  border-radius: var(--radius-sm);
  padding: 0.25rem 0.375rem;
}
textarea:focus-visible,
.preview summary:focus-visible,
.preview-field input:focus-visible,
.preview-reset:focus-visible,
.foot button:focus-visible,
.css-block summary:focus-visible,
.css-actions button:focus-visible {
  outline: 2px solid var(--ring);
  outline-offset: 2px;
}
.preview { display: block; }
.preview summary {
  cursor: pointer;
  color: var(--text-muted);
  font-size: var(--type-meta);
  min-height: 1.5rem;
}
.preview-grid {
  display: flex;
  flex-direction: column;
  gap: 0.375rem;
  padding-top: 0.25rem;
}
.preview-field {
  display: flex;
  flex-direction: column;
  gap: 0.25rem;
  color: var(--text-muted);
  font-size: var(--type-meta);
}
.preview-field input {
  width: 100%;
  box-sizing: border-box;
  font: inherit;
  color: var(--text-primary);
  background: var(--bg-elevated);
  border: 1px solid var(--border);
  border-radius: var(--radius-sm);
  padding: 0.25rem 0.375rem;
}
.preview-reset {
  align-self: flex-start;
  border: 1px solid var(--border);
  background: var(--bg-elevated);
  color: var(--text-primary);
  border-radius: var(--radius-control);
  min-height: 1.5rem;
  padding: 0.3rem 0.625rem;
  font: inherit;
  font-size: var(--type-meta);
  cursor: pointer;
}
.preview-reset:disabled { opacity: 0.5; cursor: default; }
.preview-error {
  margin: 0;
  color: var(--danger);
  font-size: var(--type-meta);
}
.css-block { display: block; }
.css-block[open] {
  display: flex;
  flex-direction: column;
  gap: 0.25rem;
}
.css-block summary {
  cursor: pointer;
  color: var(--text-muted);
  font-size: var(--type-meta);
  min-height: 1.5rem;
}
.css-block textarea {
  min-height: 4.5rem;
  font-family: ui-monospace, monospace;
  font-size: var(--type-meta);
}
.css-master-row {
  display: flex;
  align-items: center;
  gap: 0.375rem;
  color: var(--text-primary);
  font-size: var(--type-meta);
  cursor: pointer;
}
.css-master-row input { accent-color: var(--accent); }
.css-items {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
  gap: 0.25rem;
  max-height: 9rem;
  overflow-y: auto;
}
.css-item {
  display: flex;
  align-items: center;
  gap: 0.375rem;
  border: 1px solid var(--border);
  border-radius: var(--radius-sm);
  padding: 0.125rem 0.25rem;
}
.css-item.is-selected { border-color: var(--accent); }
.css-item-check { accent-color: var(--accent); flex: none; }
.css-item-open {
  flex: 1;
  min-width: 0;
  border: 0;
  background: transparent;
  color: var(--text-primary);
  font: inherit;
  font-family: ui-monospace, monospace;
  font-size: var(--type-meta);
  text-align: left;
  cursor: pointer;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  padding: 0.125rem 0;
  min-height: 1.25rem;
}
.css-item-open:focus-visible { outline: 2px solid var(--ring); outline-offset: 1px; }
.css-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 0.375rem;
  align-items: center;
}
.css-actions button {
  border: 1px solid var(--border);
  background: var(--bg-elevated);
  color: var(--text-primary);
  border-radius: var(--radius-control);
  min-height: 1.5rem;
  padding: 0.3rem 0.625rem;
  font: inherit;
  font-size: var(--type-meta);
  cursor: pointer;
}
.css-actions button:disabled { opacity: 0.5; cursor: default; }
.css-error {
  margin: 0;
  color: var(--danger);
  font-size: var(--type-meta);
}
.css-actions .css-remove {
  border: 0;
  background: transparent;
  color: var(--text-muted);
  padding: 0.25rem 0;
}
.states {
  display: flex;
  flex-direction: column;
  gap: 0.25rem;
  border: 1px solid var(--border);
  border-radius: var(--radius-sm);
  padding: 0.25rem;
}
.states summary {
  cursor: pointer;
  color: var(--text-muted);
  font-size: var(--type-meta);
  min-height: 1.5rem;
}
.state-row {
  display: flex;
  align-items: center;
  gap: 0.375rem;
  flex-wrap: wrap;
}
.state-select,
.state-pick {
  flex: 1;
  min-width: 0;
  border: 1px solid var(--border);
  background: var(--bg-elevated);
  color: var(--text-primary);
  border-radius: var(--radius-control);
  min-height: 1.5rem;
  padding: 0.125rem 0.375rem;
  font: inherit;
  font-size: var(--type-meta);
  cursor: pointer;
}
.state-select:focus-visible,
.state-pick:focus-visible {
  outline: 2px solid var(--ring);
  outline-offset: 2px;
}
.state-status {
  margin: 0;
  color: var(--text-muted);
  font-size: var(--type-meta);
}
.state-reset {
  border: 0;
  background: transparent;
  color: var(--text-muted);
  cursor: pointer;
  font: inherit;
  font-size: var(--type-meta);
  min-height: 1.5rem;
  padding: 0 0.25rem;
}
.mentions {
  position: absolute;
  left: 0.375rem;
  right: 0.375rem;
  z-index: 2;
  margin: 0;
  padding: 0.25rem;
  list-style: none;
  background: var(--bg-elevated);
  border: 1px solid var(--border);
  border-radius: var(--radius-sm);
  max-height: 8.75rem;
  overflow-y: auto;
}
.mentions button {
  display: block;
  width: 100%;
  min-height: 1.5rem;
  text-align: left;
  border: 0;
  background: transparent;
  color: var(--text-primary);
  font: inherit;
  padding: 0.25rem 0.375rem;
  cursor: pointer;
  border-radius: var(--radius-sm);
}
@media (hover: hover) and (pointer: fine) {
  .mentions button:hover { background: var(--accent); color: var(--accent-contrast); }
}
.foot { display: grid; grid-template-columns: 1fr 1fr; gap: 0.375rem; }
.foot button {
  width: 100%;
  border: 1px solid var(--border);
  background: var(--bg-elevated);
  color: var(--text-primary);
  border-radius: var(--radius-control);
  min-height: 1.5rem;
  padding: 0.3rem 0.625rem;
  font: inherit;
  cursor: pointer;
}
.foot button:disabled { opacity: 0.5; cursor: default; }
.foot .primary { background: var(--accent); color: var(--accent-contrast); border-color: transparent; }
.status {
  margin: 0;
  color: var(--text-muted);
  font-size: var(--type-meta);
}
`,Me="arc-todo-picker-hover",ir="arc-todo-picker-selected",ar="arc-todo-design-tray",sr="arc-todo-picker-badge",cr=["pointerdown","mousedown","mouseup","auxclick","contextmenu","dblclick"];let j=!1,I="dev",lr="",dr=0,M=[],g=null,ce=null,Pt=null,Z=null,Ve=null,D="",N=lt(),oe="",le=!1,We=0,Ka=0,ur=0,je="",q=null,de=!1,Ue=!1,Ke,Le;const Ya=Pa();let Te=null;function mr(){return{position:"fixed",pointerEvents:"none",zIndex:"2147483647",outline:"2px solid #4862ce",outlineOffset:"1px",background:"rgba(72, 98, 206, 0.12)",boxSizing:"border-box",display:"none"}}function Ye(e,t){e.style.display="block",e.style.left=`${t.left}px`,e.style.top=`${t.top}px`,e.style.width=`${t.width}px`,e.style.height=`${t.height}px`}function It(e){let t=e.getElementById(Me);return t||(t=e.createElement("div"),t.id=Me,t.setAttribute("aria-hidden","true"),Object.assign(t.style,mr()),e.documentElement.appendChild(t),t)}function pr(e,t){const n=e.createElement("div");return n.className=ir,n.id=`arc-todo-picker-selected-${dr}`,dr+=1,n.setAttribute("aria-hidden","true"),Object.assign(n.style,mr(),{display:"block",outline:"2px dashed #4862ce",background:"transparent"}),e.documentElement.appendChild(n),n}function fr(e,t,n){const r=e.createElement("span");return r.className=sr,r.setAttribute("aria-hidden","true"),r.textContent=String(t),Object.assign(r.style,{position:"fixed",pointerEvents:"none",zIndex:"2147483647",minWidth:"16px",height:"16px",padding:"0 4px",borderRadius:"999px",background:"#4862ce",color:"#f7f8fc",fontSize:"11px",fontWeight:"600",lineHeight:"16px",textAlign:"center",fontFamily:"system-ui, sans-serif",boxSizing:"border-box"}),Mt(r,n),e.documentElement.appendChild(r),r}function Mt(e,t){e.style.top=`${t.top-9}px`,e.style.left=`${t.left-9}px`}function Ga(e){return e?e.id===ue?!0:!!e.closest(`#${ue}`):!1}function $t(e){return e?e.id===Me||e.id===ar||e.id===pe||e.classList.contains(ir)||e.classList.contains(sr)||e.closest(`[${me}]`)!==null||Ga(e):!1}function Rt(e){return!!(g&&e.composedPath().includes(g))}function gr(e,t,n){const r=e.elementFromPoint(t,n);return!r||$t(r)?null:r}function hr(e){j&&(Rt(e)||(e.preventDefault(),e.stopPropagation(),e.stopImmediatePropagation()))}function _t(e,t){const n=It(e);if(!t){n.style.display="none";return}Ye(n,t.getBoundingClientRect())}function Ot(e){return Rn(e,{document,innerWidth:window.innerWidth,innerHeight:window.innerHeight,locationHref:location.href})}function Bt(){return M.map(({n:e,hit:t,note:n})=>({n:e,hit:t,note:n}))}function br(){D="",q=null,de=!1,Ue=!1,le=!1,je="",We+=1}function zt(e){var t;return((t=e.stateSession)==null?void 0:t.anchorElement())??e.el}function Xa(e){return e.stateSession||(e.stateSession=Fa({element:()=>e.el.isConnected?e.el:null,messenger:()=>ka(),doc:Ya,strings:f,excludeReplicaNode:t=>$t(t),onStateLost:()=>{O(f.designStateLost),be()}})),e.stateSession}function $e(e){var t;(t=e.stateSession)==null||t.reset(),e.stateSession=null,Te===e&&(Te=null)}function vr(e){switch(e){case"unsupported":return f.designStateUnsupported;case"stale":return f.designStateStale;case"incompatible":return f.designStateIncompatible;case"no-diff":return f.designStateNoDiff;case"no-markers":return f.designStateNoMarkers;default:return f.designStateFailed}}async function Qa(e,t,n){const r=await e.apply(t.value);if(t.value=e.currentId()??"",r.ok){n.hidden=!r.degraded,n.removeAttribute("role"),n.textContent=r.degraded?f.designStatePartial:"";return}n.hidden=!1,n.setAttribute("role","alert"),n.textContent=vr(r.error)}function Za(e){const t=Xa(e),n=document.createElement("details");n.className="states";const r=document.createElement("summary");r.textContent=f.designStateHeading;const o=document.createElement("div");o.className="state-row";const i=document.createElement("select");i.setAttribute("aria-label",f.designStateHeading);for(const l of t.options()){const d=document.createElement("option");d.value=l.id,d.textContent=l.label,i.appendChild(d)}i.value=t.currentId()??"";const a=document.createElement("button");a.type="button",a.className="state-pick",a.textContent=f.designStatePickExample,a.addEventListener("click",()=>{Te=e,O(f.designStatePickHint),ie()});const s=document.createElement("p");return s.className="state-status",s.hidden=!0,i.addEventListener("change",()=>{Qa(t,i,s)}),o.append(i,a),n.append(r,o,s),n}function Dt(){var t,n;const e=I==="design"||!!g||ha();Ne(),Et(),Gn(null),br(),Le==null||Le.dispose(),Le=void 0;for(const r of M)qt(r),$e(r),(t=r.box)==null||t.remove(),(n=r.badge)==null||n.remove(),r.box=null,r.badge=null;g==null||g.remove(),g=null,e&&L.runtime.sendMessage({type:"design.disarm"})}function xr(){var e,t;Ne();for(const n of M)qt(n),$e(n),(e=n.box)==null||e.remove(),(t=n.badge)==null||t.remove(),n.box=null,n.badge=null;M=[],Z=null,Ve=null}function Ja(){for(const e of M){if(!e.el.isConnected)continue;const t=zt(e).getBoundingClientRect();e.box||(e.box=pr(document)),Ye(e.box,t),e.badge?Mt(e.badge,t):e.badge=fr(document,e.n,t)}yr(),be(),H(),ie()}function Ge(){var e,t;for(const n of M){if(!n.el.isConnected){qt(n),$e(n),(e=n.box)==null||e.remove(),(t=n.badge)==null||t.remove(),n.box=null,n.badge=null;continue}n.hit=Ot(n.el);const r=zt(n).getBoundingClientRect();n.box&&Ye(n.box,r),n.badge&&Mt(n.badge,r)}}function yr(){if(g!=null&&g.isConnected){g.style.display="",Xe();return}g=document.createElement("div"),g.id=ar,g.dataset.theme=window.matchMedia("(prefers-color-scheme: light)").matches?"light":"dark";const e=g.attachShadow({mode:"open"}),t=document.createElement("style");t.textContent=`${ja}
${un}
${Ua}`;const n=document.createElement("aside");n.className="tray",n.setAttribute("aria-label",f.designHeading);const r=document.createElement("div");r.className="head";const o=document.createElement("span");o.className="title",o.textContent=f.designHeading,r.appendChild(o),r.addEventListener("pointerdown",es);const i=document.createElement("ul");i.className="list";const a=ts(),s=ns(),l=document.createElement("div");l.className="foot";const d=document.createElement("p");d.className="status",d.hidden=!0,n.append(r,i,a,s,l,d),e.append(t,n),document.documentElement.appendChild(g),Xe()}function Xe(){if(g){if(!ce){g.style.right="12px",g.style.bottom="12px",g.style.left="auto",g.style.top="auto";return}g.style.left=`${ce.x}px`,g.style.top=`${ce.y}px`,g.style.right="auto",g.style.bottom="auto"}}function es(e){var s,l;if(e.button!==0||!g)return;const t=e.currentTarget,n=g.getBoundingClientRect(),r=e.clientX-n.left,o=e.clientY-n.top;try{t.setPointerCapture(e.pointerId)}catch{}(l=(s=g.shadowRoot)==null?void 0:s.querySelector(".tray"))==null||l.classList.add("is-dragging");const i=d=>{g&&(ce=vn(d.clientX-r,d.clientY-o,n.width,n.height,window.innerWidth,window.innerHeight),Xe())},a=()=>{var d,u;(u=(d=g==null?void 0:g.shadowRoot)==null?void 0:d.querySelector(".tray"))==null||u.classList.remove("is-dragging"),t.removeEventListener("pointermove",i),t.removeEventListener("pointerup",a),t.removeEventListener("pointercancel",a)};t.addEventListener("pointermove",i),t.addEventListener("pointerup",a),t.addEventListener("pointercancel",a)}function ts(){return Le=zi({strings:f,measure:()=>({width:window.innerWidth,height:window.innerHeight}),request:async e=>{try{return await L.runtime.sendMessage(e)}catch{return}}}),Le.element}function ns(){const e=document.createElement("details");e.className="css-block",e.open=N.items.length>0||D.trim().length>0;const t=document.createElement("summary");t.textContent=f.designLiveCss;const n=document.createElement("label");n.className="css-master-row";const r=document.createElement("input");r.type="checkbox",r.className="css-master",r.checked=N.enabled,n.append(r,f.designCssMaster),r.addEventListener("change",()=>{Lr(r.checked)});const o=document.createElement("ul");o.className="css-items",o.setAttribute("aria-label",f.designCssItemsLabel);const i=document.createElement("textarea");i.className="css-editor",i.rows=6,i.value=D,i.setAttribute("aria-label",f.designLiveCss),i.setAttribute("aria-invalid","false"),i.addEventListener("input",()=>{D=i.value,kr()}),i.addEventListener("paste",p=>{var k;if(i.value.trim()!=="")return;const h=((k=p.clipboardData)==null?void 0:k.getData("text"))??"";h.trim()&&(p.preventDefault(),Sr(h))});const a=document.createElement("p");a.className="css-error";const s=document.createElement("div");s.className="css-actions";const l=document.createElement("button");l.type="button",l.className="css-copy-live",l.textContent=f.designCopyLive,l.addEventListener("click",()=>void ss());const d=document.createElement("button");d.type="button",d.textContent=f.designPasteCss,d.addEventListener("click",()=>void cs());const u=document.createElement("button");return u.type="button",u.className="css-remove",u.textContent=f.designRemoveCss,u.disabled=!wr(),u.addEventListener("click",()=>{Lr(!1)}),s.append(l,d,u),e.append(t,n,o,i,a,s),e}function wr(){return N.enabled&&N.items.some(e=>e.enabled)}function Ar(){return ti(location.href)}function Re(){I==="design"&&Ar()!==oe&&Cr()}async function Cr(){if(I!=="design")return;const e=Ar(),t=++We;oe=e,q=null,D="",de=!1,Ue=!1,le=!1,he();let n=lt();try{const r=await L.runtime.sendMessage({type:"design.cssLoad",pageKey:e});if(t!==We||I!=="design"||oe!==e)return;n=xn(r==null?void 0:r.stack)??lt()}catch{}t!==We||I!=="design"||oe!==e||(N=n,le=!0,await _e(),he(),ge(),H(),D.trim()&&kr())}async function _e(){if(I!=="design")return;const e=ni(N);if(e===je){Qe();return}je=e;const t=await ba(e);if(I!=="design"){je="";return}Ue=!!t.error,Qe()}function Er(){return`i${Date.now().toString(36)}${Math.random().toString(36).slice(2,8)}`}function Oe(e){const t=++Ka;ur=t,L.runtime.sendMessage({...e,nonce:t}).then(n=>{const r=n;if(!(!r||r.nonce!==ur)){if(r.ok&&r.stack!==void 0){const o=xn(r.stack);o&&(N=o);return}r.ok===!1&&(O(f.designCssSaveFailed),ie())}}).catch(()=>{O(f.designCssSaveFailed),ie()})}async function kr(){const e=D;if(de=!1,le&&I==="design"&&e.trim()){q&&!N.items.some(n=>n.id===q)&&(q=null);const t=q?N.items.find(n=>n.id===q):void 0;if(t)Ee(e).ok?t.css!==e&&(N=yn(N,t.id,{css:e}),Oe({type:"design.cssUpdate",pageKey:oe,id:t.id,css:e})):de=!0;else if(Ee(e).ok){const n={id:Er(),css:e,enabled:!0};N={...N,items:[...N.items,n]},q=n.id,Oe({type:"design.cssAppend",pageKey:oe,item:n})}else de=!0}else e.trim()||(q=null);if(!le||I!=="design"){Qe();return}await _e(),he(),ge(),H()}async function Sr(e){var n;if(!le||I!=="design"){D=e;const r=(n=g==null?void 0:g.shadowRoot)==null?void 0:n.querySelector(".css-editor");r instanceof HTMLTextAreaElement&&(r.value=e);return}if(!Ee(e).ok){O(f.designPasteCssInvalid),ie();return}const t={id:Er(),css:e,enabled:!0};N={...N,items:[...N.items,t]},q=t.id,D=e,de=!1,Oe({type:"design.cssAppend",pageKey:oe,item:t}),await _e(),he(),ge(),H()}function rs(e){q===e.id?(q=null,D=""):(q=e.id,D=e.css),de=!1,he(),ge(),H()}function os(e,t){!le||I!=="design"||(N=yn(N,e.id,{enabled:t}),Oe({type:"design.cssUpdate",pageKey:oe,id:e.id,enabled:t}),_e(),he(),ge(),H())}function Lr(e){!le||I!=="design"||(N=ri(N,e),Oe({type:"design.cssEnabled",pageKey:oe,enabled:e}),_e(),he(),ge(),H())}function ge(){var t;const e=(t=g==null?void 0:g.shadowRoot)==null?void 0:t.querySelector(".css-items");if(e){if(e.replaceChildren(),N.items.length===0){const n=document.createElement("p");n.className="empty",n.textContent=f.designCssEmpty,e.appendChild(n);return}for(const n of N.items)e.appendChild(is(n))}}function is(e){const t=document.createElement("li");t.className="css-item",e.id===q&&t.classList.add("is-selected");const n=oi(e.css)||"(CSS)",r=document.createElement("input");r.type="checkbox",r.className="css-item-check",r.checked=e.enabled,r.setAttribute("aria-label",`${f.designCssItemToggle}: ${n}`),r.addEventListener("change",()=>{os(e,r.checked)});const o=document.createElement("button");return o.type="button",o.className="css-item-open",o.textContent=n,o.title=e.css,o.setAttribute("aria-pressed",e.id===q?"true":"false"),o.addEventListener("click",()=>{rs(e)}),t.append(r,o),t}function he(){const e=g==null?void 0:g.shadowRoot;if(!e)return;const t=e.querySelector(".css-block");t instanceof HTMLDetailsElement&&!t.open&&(N.items.length>0||D.trim().length>0)&&(t.open=!0);const n=e.querySelector(".css-master");n instanceof HTMLInputElement&&(n.checked=N.enabled);const r=e.querySelector(".css-editor");r instanceof HTMLTextAreaElement&&r.value!==D&&(r.value=D);const o=e.querySelector(".css-remove");o instanceof HTMLButtonElement&&(o.disabled=!wr()),ge(),Qe()}function Qe(){const e=g==null?void 0:g.shadowRoot;if(!e)return;const t=e.querySelector(".css-editor"),n=e.querySelector(".css-error");t instanceof HTMLTextAreaElement&&ls(n,t,de||Ue)}function Tr(){return N.items.filter(e=>!e.enabled||!N.enabled).map(e=>e.css)}function Nr(){if(!D.trim())return"";const t=q?N.items.find(n=>n.id===q):void 0;return t&&t.css===D?"":D}function as(){var t;const e=(t=g==null?void 0:g.shadowRoot)==null?void 0:t.querySelector(".css-copy-live");e&&(e.textContent=Z==="live"?f.copied:f.designCopyLive)}async function ss(){Ge();const e=At(),t=Tr(),n=Nr(),r=D.trim();if(Z=null,!e.trim()&&M.length===0&&!n&&t.length===0){O(f.designCopyLiveEmpty),H();return}O(null),await bn(Mi({css:e,pageUrl:location.href,rejected:!!r&&!Ee(r).ok,diffs:Xn(Qn(),Ct(e)),disabled:t,draft:n,elements:Bt()})),Z="live",H()}async function cs(){Z=null;let e="";try{e=await navigator.clipboard.readText()}catch{O(f.designPasteCssFailed),H();return}if(!e.trim()){O(f.designPasteCssEmpty),H();return}O(null),await Sr(e)}function ls(e,t,n){if(e){if(n){e.textContent=f.designCssInvalid,e.setAttribute("role","alert"),t.setAttribute("aria-invalid","true");return}e.textContent="",e.removeAttribute("role"),t.setAttribute("aria-invalid","false")}}function Ne(){var e,t;Pt=null,(t=(e=g==null?void 0:g.shadowRoot)==null?void 0:e.querySelector(".mentions"))==null||t.remove()}function be(){var t;const e=(t=g==null?void 0:g.shadowRoot)==null?void 0:t.querySelector(".list");if(e){if(e.replaceChildren(),M.length===0){const n=document.createElement("p");n.className="empty",n.textContent=f.designEmpty,e.appendChild(n);return}for(const n of M)e.appendChild(ds(n))}}function ds(e){const t=document.createElement("li");t.className="pin";const n=document.createElement("div");n.className="pin-head";const r=document.createElement("span");r.className="n",r.textContent=String(e.n);const o=document.createElement("span");o.className="label",o.title=e.hit.selector,o.textContent=e.hit.selector;const i=document.createElement("button");i.type="button",i.className="remove",i.setAttribute("aria-label",f.designRemove),i.textContent="×",i.addEventListener("click",()=>{ps(e.n)}),n.append(r,o,i);const a=document.createElement("label");a.className="note-label",a.append(f.designNote);const s=document.createElement("textarea");return s.rows=2,s.placeholder=f.designNotePlaceholder,s.value=e.note,s.addEventListener("input",()=>{e.note=s.value,Ft(e,s)}),s.addEventListener("click",()=>Ft(e,s)),s.addEventListener("keyup",l=>{l.key!=="Escape"&&Ft(e,s)}),a.appendChild(s),t.append(n,a,us(e),Za(e)),t}function Pr(e){switch(e){case"invalid-count":return f.designPreviewInvalidCount;case"no-text":return f.designPreviewNoText;case"ambiguous-text":return f.designPreviewAmbiguousText;default:return f.designPreviewUnavailableElement}}function Ir(e){return e.preview?e.preview:e.el.isConnected?(e.preview=la(e.el,{excludeNode:t=>$t(t)}),e.preview):null}function us(e){const t=document.createElement("details");t.className="preview";const n=document.createElement("summary");n.textContent=f.designPreviewToggle;const r=document.createElement("div");r.className="preview-grid";const o=document.createElement("label");o.className="preview-field",o.append(`${f.designPreviewCopies} (0–${bt})`);const i=document.createElement("input");i.type="text",i.inputMode="numeric",i.autocomplete="off",i.value=String(e.previewCopies),i.setAttribute("aria-label",f.designPreviewCopies),o.appendChild(i);const a=document.createElement("label");a.className="preview-field",a.append(f.designPreviewLabel);const s=document.createElement("input");s.type="text",s.autocomplete="off",s.placeholder=f.designPreviewLabelPlaceholder,s.value=e.previewText,s.setAttribute("aria-label",f.designPreviewLabel),a.appendChild(s);const l=document.createElement("p");l.className="preview-error",l.hidden=!0,l.setAttribute("role","alert");const d=p=>{l.hidden=!p,l.textContent=p??""};i.addEventListener("change",()=>{const p=sa(i.value);if(p===null){i.value=String(e.previewCopies),d(f.designPreviewInvalidCount);return}const h=Ir(e);if(!h){d(f.designPreviewUnavailableElement);return}const k=h.setCopies(p);if(!k.ok){i.value=String(e.previewCopies),d(Pr(k.error));return}e.previewCopies=p,i.value=String(p),d(k.degraded?f.designPreviewDegraded:null)}),s.addEventListener("change",()=>{const p=Ir(e);if(!p){d(f.designPreviewUnavailableElement);return}const h=s.value,k=p.setLabel(h===""?null:h);if(!k.ok){s.value=e.previewText,d(Pr(k.error));return}e.previewText=h===""?"":h,d(null)});const u=document.createElement("button");return u.type="button",u.className="preview-reset",u.textContent=f.designPreviewReset,u.addEventListener("click",()=>{var p;(p=e.preview)==null||p.reset(),e.previewCopies=0,e.previewText="",i.value="0",s.value="",d(null)}),r.append(o,a,u,l),t.append(n,r),t}function Ft(e,t){var a,s;const n=t.selectionStart??t.value.length,r=Xo(t.value,n);if(Ne(),!r)return;const o=Qo(Bt(),e.n,r.query);if(o.length===0)return;Pt={n:e.n,start:r.start,caret:n};const i=document.createElement("ul");i.className="mentions",i.setAttribute("aria-label",f.designNote);for(const l of o){const d=document.createElement("li"),u=document.createElement("button");u.type="button",u.textContent=`@${l.n}  ${l.label}`,u.addEventListener("click",()=>{const p=Zo(t.value,r.start,n,l.n);e.note=p.note,t.value=p.note,t.focus(),t.setSelectionRange(p.caret,p.caret),Ne()}),d.appendChild(u),i.appendChild(d)}(s=(a=t.parentElement)==null?void 0:a.parentElement)==null||s.appendChild(i)}function H(){var a;const e=(a=g==null?void 0:g.shadowRoot)==null?void 0:a.querySelector(".foot");if(!e)return;e.replaceChildren();const t=M.length>0,n=document.createElement("button");n.type="button",n.textContent=Z==="text"?f.copied:f.copy,n.addEventListener("click",()=>void hs());const r=document.createElement("button");r.type="button",r.textContent=Z==="png"?f.copied:f.copyImage,r.addEventListener("click",()=>void bs());const o=document.createElement("button");o.type="button",o.textContent=f.designClear,o.disabled=!t,o.addEventListener("click",()=>{xr(),yr(),be(),H(),ie()});const i=document.createElement("button");i.type="button",i.className="primary",i.textContent=f.designExit,i.addEventListener("click",()=>Ht()),e.append(n,r,o,i),as()}function O(e){Ve=e,ie()}function ie(){var t;const e=(t=g==null?void 0:g.shadowRoot)==null?void 0:t.querySelector(".status");if(e instanceof HTMLElement){if(!Ve){e.hidden=!0,e.removeAttribute("role"),e.textContent="";return}e.hidden=!1,e.setAttribute("role","alert"),e.textContent=Ve}}function ms(e){var i;let t=1/0,n=1/0,r=-1/0,o=-1/0;for(const a of e){const s=new Set([zt(a),a.el,...((i=a.preview)==null?void 0:i.copies)??[]]);for(const l of s){if(!l.isConnected)continue;const d=l.getBoundingClientRect();t=Math.min(t,d.left),n=Math.min(n,d.top),r=Math.max(r,d.right),o=Math.max(o,d.bottom)}}return!Number.isFinite(t)||r<=t||o<=n?null:{x:t,y:n,width:r-t,height:o-n}}function qt(e){var t;(t=e.preview)==null||t.reset(),e.preview=null,e.previewCopies=0,e.previewText=""}function ps(e){var n,r,o;const t=M.find(i=>i.n===e);(n=t==null?void 0:t.preview)==null||n.reset(),t&&$e(t),(r=t==null?void 0:t.box)==null||r.remove(),(o=t==null?void 0:t.badge)==null||o.remove(),M=M.filter(i=>i.n!==e),Ne(),be(),H()}function fs(e,t){if(M.some(i=>i.el===e||mt(i.hit)===mt(t)))return;const n=e.getBoundingClientRect(),r=Go(M);M.push({n:r,el:e,hit:t,note:"",box:pr(document),badge:fr(document,r,n),preview:null,previewCopies:0,previewText:"",stateSession:null});const o=M[M.length-1];o!=null&&o.box&&Ye(o.box,n),be(),H()}function gs(e){const t=[],n=At(),r=Tr(),o=Nr();return(n.trim()||r.length>0||o.trim())&&t.push(On({css:n,diffs:Xn(Qn(),Ct(n)),disabled:r,draft:o}).trimEnd()),M.length>0&&t.push(Ii(Bt())),t.join(`

`)}async function hs(){Ge(),Z=null;const e=!!At().trim()||N.items.length>0||!!D.trim();if(M.length===0&&!e){O(f.designCopyEmpty);return}O(null),await bn(gs()),Z="text",H()}async function bs(){if(Ge(),Z=null,M.length===0){O(f.designCopyEmpty);return}O(null),g&&(g.style.display="none"),_t(document,null),await new Promise(e=>{window.setTimeout(e,50)});try{const e=await L.runtime.sendMessage({type:"picker.screenshot"});if(!e.draftScreenshot){O(f.designCaptureFailed);return}const t=ms(M);if(!t){O(f.designCaptureFailed);return}const n=await Ko(e.draftScreenshot,t,{width:window.innerWidth,height:window.innerHeight});await Yo(n),Z="png",H()}catch{O(f.designCaptureFailed)}finally{g&&(g.style.display="")}}function Mr(e){if(j){if(Rt(e)){_t(document,null);return}_t(document,gr(document,e.clientX,e.clientY))}}function Ze(){if(j&&I==="design"&&(Ge(),ce&&g)){const e=g.getBoundingClientRect();ce=vn(ce.x,ce.y,e.width,e.height,window.innerWidth,window.innerHeight),Xe()}}async function vs(){return{error:"idle"}}async function $r(e){var o;if(!j||Rt(e))return;const t=gr(document,e.clientX,e.clientY);if(!t)return;if(e.preventDefault(),e.stopPropagation(),e.stopImmediatePropagation(),I==="design"){if(Te){const i=Te;Te=null,O(null),ie(),(o=i.stateSession)==null||o.applyExample(t).then(a=>{a.ok?(O(null),be()):O(vr(a.error)),ie()});return}fs(t,Ot(t));return}const n=Ot(t);if(Ha(I)){const i=Ci(n);try{await navigator.clipboard.writeText(i)}catch{}}const r=Wa(I,n);Va(I)&&Je(),L.runtime.sendMessage(r)}function xs(e){if(!(!((e.ctrlKey||e.metaKey)&&!e.altKey&&!e.shiftKey)||!(e.key==="d"||e.key==="D"))){if(e.preventDefault(),e.stopPropagation(),e.stopImmediatePropagation(),j&&I==="design"){Ht();return}L.runtime.sendMessage({type:"design.start"})}}function Rr(e){if(!(!j||e.key!=="Escape")){if(e.preventDefault(),I==="design"){if(e.stopPropagation(),e.stopImmediatePropagation(),Pt){Ne();return}Ht();return}e.stopPropagation(),e.stopImmediatePropagation(),Je(),L.runtime.sendMessage({type:"picker.cancelled"})}}function _r(){var e;for(const t of M)(e=t.preview)==null||e.reset(),$e(t)}function Or(){lr=document.documentElement.style.cursor,document.documentElement.style.cursor="crosshair",It(document),document.addEventListener("mousemove",Mr,!0),document.addEventListener("click",$r,!0),document.addEventListener("keydown",Rr,!0);for(const e of cr)document.addEventListener(e,hr,!0);window.addEventListener("scroll",Ze,!0),window.addEventListener("resize",Ze),window.addEventListener("popstate",Re),window.addEventListener("hashchange",Re),Ke=window.setInterval(Re,1e3),window.addEventListener("pagehide",_r)}function Br(){var e;document.documentElement.style.cursor=lr,document.removeEventListener("mousemove",Mr,!0),document.removeEventListener("click",$r,!0),document.removeEventListener("keydown",Rr,!0);for(const t of cr)document.removeEventListener(t,hr,!0);window.removeEventListener("scroll",Ze,!0),window.removeEventListener("resize",Ze),window.removeEventListener("popstate",Re),window.removeEventListener("hashchange",Re),Ke!==void 0&&(window.clearInterval(Ke),Ke=void 0),window.removeEventListener("pagehide",_r),(e=document.getElementById(Me))==null||e.remove()}function Ht(){Et(),br(),Je(),L.runtime.sendMessage({type:"design.exited"})}function ys(e="dev"){if(window===window.top){if(e==="design"){j&&I!=="design"&&(Br(),j=!1),I="design",Gn({insertCss:t=>L.runtime.sendMessage({type:"design.insertCss",css:t}),removeCss:()=>{L.runtime.sendMessage({type:"design.removeCss"})}}),Ea({setPseudo:t=>L.runtime.sendMessage({type:"design.state.set",doc:t.doc,marker:t.marker,state:t.state}),clearPseudo:t=>L.runtime.sendMessage({type:"design.state.clear",doc:t.doc,marker:t.marker})}),j||(Or(),j=!0),Ja(),Cr();return}if((I==="design"||M.some(t=>t.box))&&Dt(),j){I!==e&&(It(document).style.display="none"),I=e;return}j=!0,I=e,Or()}}function Je(){const e=I==="design"||M.length>0;if(!j&&!document.getElementById(Me)&&!g){e&&Dt();return}if(j=!1,I="dev",Br(),e){Dt();return}xr()}function ws(){window===window.top&&(document.addEventListener("keydown",xs,!0),L.runtime.onMessage.addListener(e=>{var n;if(!e||typeof e!="object"||!("type"in e))return;const t=e.type;if(t==="picker.arm"&&ys(qa(e)),t==="picker.disarm"&&Je(),t==="design.state.lost"){for(const r of M)(n=r.stateSession)==null||n.lost();be(),O(f.designStateLost)}if(t==="capture.stopElementRecord")return vs()}))}const zr=window;function As(e){return!!(e&&typeof e=="object"&&e.type==="content.ping")}L.runtime.onMessage.addListener(e=>{if(As(e))return Promise.resolve(!0)}),zr.__arcTodoContentReady||(zr.__arcTodoContentReady=!0,window.addEventListener(Yr,e=>{const t=e.detail;typeof t=="string"&&L.runtime.sendMessage({type:"capture.console",payload:t})}),L.runtime.sendMessage({type:"capture.pageReady"}),ws(),co(),jo(),Kr())})();
